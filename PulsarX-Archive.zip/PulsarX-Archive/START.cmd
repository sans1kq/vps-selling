@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 demo\run.py
goto end
:python
python demo\run.py
:end
if errorlevel 1 pause
