from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import json, mimetypes, webbrowser, threading

HERE = Path(__file__).resolve().parent
SITE = HERE.parent / 'source/control/var/www/html'
PROFILE = dict(id='00000000-0000-4000-8000-000000000001',first_name='Demo',last_name='User',email='demo@example.invalid',is_verified=True)
class Viewer(BaseHTTPRequestHandler):
    def send(self, data, kind, code=200):
        self.send_response(code)
        self.send_header('Content-Type',kind)
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self' data:; frame-src 'self'; form-action 'none'; object-src 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(data)
    def api(self, path):
        data = []
        if path == '/api/wallet': data=dict(balance_cents=1200,providers=['freekassa','rollypay','stars'],min_topup_cents=100,max_topup_cents=10000,topup_available=True)
        elif path.endswith('/history'): data=dict(items=[],has_more=False)
        elif path.endswith('/status'): data=dict(activated=True,referral_enabled=True,discount_percent=0)
        elif path.endswith(('/me','/profile','/session')): data={**PROFILE,'role':'admin'}
        elif path.endswith('/methods'): data={'methods':[]}
        elif path=='/api/admin/desk/summary':
            data=dict(attention=dict.fromkeys(('order_review','topup_review','failed_servers','expiring_gifts','due_soon','overdue_servers'),0),
                      plans={'nano':1}, completed_order_cents=300,running_servers=1,users=1,activated_users=1,chart=[])
        elif path=='/api/admin/desk/backups':
            data={'control':{},'compute':{}}
        elif path.startswith('/api/admin/desk/'):
            data={'items':[], 'total':0, 'has_more':False}
        elif path=='/api/admin/resource-pool':
            data={'resources':dict(memory_budget_bytes=8*2**30,memory_available_bytes=7*2**30,memory_reserved_bytes=2**30,
                  cpu_allocated=1,cpu_allocation_budget=8,available_for_new_bytes=80*10**9,total_bytes=100*10**9,
                  system_reserve_bytes=12*10**9,memory_total_bytes=10*2**30,memory_system_reserve_bytes=2*2**30,
                  cpu_total=4,cpu_overcommit=2),'catalog':{'plans':[]}}
        elif path=='/api/servers': data=[dict(id=PROFILE['id'],container_name='demo-nano',plan='nano',image='Debian 13',status='running',cpu_cores=1,ram_mb=1024,disk_gb=8)]
        self.send(json.dumps(data).encode(),'application/json')
    def do_POST(self):
        self.send(b'{"detail":"Read-only preview. Use the simulator in the left panel."}','application/json',409)
    def do_GET(self):
        path=urlsplit(self.path).path
        if path.startswith('/api/'):return self.api(path)
        if path=='/showcase':return self.send((HERE/'showcase.html').read_bytes(),'text/html; charset=utf-8')
        p=(SITE/path.lstrip('/')).resolve()
        if SITE not in p.parents and p!=SITE:return self.send_error(404)
        if p.is_dir():p=p/'index.html'
        if not p.is_file():return self.send_error(404)
        data=p.read_bytes()
        if p.suffix=='.html':
            bootstrap="""<script>localStorage.setItem('pulsarx_token','demo');localStorage.setItem('pulsarx_admin_token','demo');localStorage.setItem('pulsarx_user',JSON.stringify(PROFILE));const realFetch=window.fetch.bind(window);window.fetch=async(input,opts)=>{const response=await realFetch(input,opts);const path=new URL(input.url||input,location.href).pathname;const state=JSON.parse(localStorage.getItem('px_demo_state')||'null');if(state&&response.ok&&['/api/wallet','/api/servers'].includes(path)){let data=await response.json();if(path==='/api/wallet')data.balance_cents=state.balance;else data=Array.from({length:state.count},(_,i)=>({...data[0],id:'00000000-0000-4000-8000-'+String(i+1).padStart(12,'0'),container_name:'demo-nano-'+(i+1)}));return new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}})}return response};document.addEventListener('click',e=>{const a=e.target.closest('a');if(a && new URL(a.href,location.href).origin!==location.origin)e.preventDefault()},true)</script>"""
            data=data.replace(b'<head>',('<head>'+bootstrap.replace('PROFILE',json.dumps(PROFILE))).encode(),1)
        if path.rstrip('/') in ('/admin','/adminlogin'):
            nav='<nav style="position:fixed;bottom:12px;right:16px;z-index:10000;background:#291c34;border-radius:12px;padding:10px 16px"><a style="color:#efdbff" href="/showcase">← К витрине</a>'
            if path.rstrip('/')=='/adminlogin':
                nav+=' · <a style="color:#efdbff" href="/admin/">Открыть демо-админку →</a>'
            data=data.replace(b'</body>',(nav+'</nav></body>').encode(),1)
        self.send(data,mimetypes.guess_type(str(p))[0] or 'application/octet-stream')
if __name__=='__main__':
    server=ThreadingHTTPServer(('127.0.0.1',0),Viewer)
    url=f'http://127.0.0.1:{server.server_port}/showcase'
    print(url,flush=True)
    threading.Timer(.4,webbrowser.open,args=(url,)).start()
    server.serve_forever()
