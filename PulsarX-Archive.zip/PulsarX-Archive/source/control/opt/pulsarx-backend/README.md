# PulsarX Cloud — backend

Minimal FastAPI service that does what you described: user hits "create",
backend spins up an Incus container with the requested RAM/CPU/disk, waits
for it to boot, creates an SSH user, and emails the customer their
`ip + username + password`. The account is set to force a password change
on first login (`chage -d 0`).

## What it does, end to end

1. `POST /api/servers` with `{ "email": "...", "plan": "mini" }`
2. A row is written to Postgres with `status = pending`, and the request
   returns immediately with the server's id.
3. In the background:
   - `incus launch` creates a container with CPU/RAM/disk limits and
     `security.port_isolation=true` so it can't see other customers on the
     bridge.
   - Waits for it to reach `RUNNING` and get an IPv4 address.
   - Installs `openssh-server`, creates a sudo user (`admin`), sets a random
     16-char password, and runs `chage -d 0` on it so SSH forces a password
     change on first login.
   - Emails the customer the IP, username, and password.
   - Updates the row to `status = running` (or `failed` with the error, if
     something went wrong — check `error_message`).
4. Your frontend polls `GET /api/servers/{id}` until `status` is `running`
   or `failed`.

## Setup

```bash
sudo apt-get install -y python3.11-venv postgresql
sudo -u postgres createuser pulsarx -P
sudo -u postgres createdb pulsarx -O pulsarx

cd /opt
sudo git clone <your repo> pulsarx-backend   # or scp this folder over
cd pulsarx-backend
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

cp .env.example .env
nano .env   # fill in DATABASE_URL, API_KEY, SMTP_*
```

Run it once by hand to check it boots:

```bash
./venv/bin/uvicorn app.main:app --reload
```

Then install as a service:

```bash
sudo cp pulsarx-api.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now pulsarx-api
```

Nginx: proxy `/api/` on `pulsarx.example.invalid` to `127.0.0.1:8000`, same pattern you
already used for `/deploy/` and `/dashboard/`.

## Permissions the service needs

The app shells out to the `incus` CLI, so the user running it (`pulsarx` in
the unit file above) needs access to the Incus socket:

```bash
sudo useradd -r -s /usr/sbin/nologin pulsarx
sudo usermod -aG incus-admin pulsarx
```

Don't run this as root just to avoid the group-membership step — the whole
point of `security.privileged=false` on the containers is to keep a
compromised customer container from reaching a root process on the host.

## Important: disk quotas and your storage backend

You already hit `Cannot enable project quota enforcement` once, from the
`dir` storage driver on ext4 not having project quotas turned on at the
filesystem level. The `--device root,size={disk_gb}GB` line in
`incus_service.create_container` only actually *enforces* that size if your
Incus storage pool supports quotas — with `dir` on ext4 it's easy for that
setting to be silently unenforced instead of erroring, which is worse than
what you saw before.

Before relying on `disk_gb` for anything customers pay for, check your pool:

```bash
incus storage list
incus storage show <pool-name>
```

If it's `dir`, the reliable fix is a dedicated ZFS or Btrfs storage pool for
customer containers (`incus storage create customers zfs`, then launch into
it with `--storage customers`) — both enforce per-container quotas natively,
without touching host-level `fstab`/`tune2fs` again.

## Things this MVP intentionally does not do yet

- **Real auth.** `X-API-Key` is a placeholder so you can test this today.
  Before it's public, this needs to check your actual logged-in user, not a
  shared static key.
- **Billing.** No Stripe hook, no auto-suspend on non-payment yet — that was
  "version 2" in the earlier plan.
- **A queue.** `BackgroundTasks` is fine for a handful of concurrent
  creations; if people start hammering "Deploy" you'll want Celery/RQ so a
  slow `apt-get install` in one provisioning job can't block others.
- **Outbound rate limiting per container**, which was flagged earlier as the
  thing that protects your main VPS's reputation with Hetzner if one
  customer's box starts misbehaving. Worth doing before this is public,
  via `tc`/nftables on each container's veth.

## Infrastructure notes (VPS-1 / VPS-2 split)

VPS-1 (this server) hosts nginx, this backend, and Postgres.
VPS-2 hosts Incus and all customer containers, reached via Incus remote (vps2:) over the network.

Custom and free subdomains work by nginx on VPS-1 reverse-proxying to a container private IP (203.0.113.x) on VPS-2. This only works because of a WireGuard tunnel between the two hosts (wg0) - private container IPs are not otherwise reachable across the two separate hosting networks.

IMPORTANT: When a new customer container is created on VPS-2, its private IP must be added to AllowedIPs in the WireGuard config on VPS-1, or that customer domain/subdomain attachment will silently fail. Check current allowed IPs with: sudo wg show. This is currently a manual step, not automated as part of container creation.
