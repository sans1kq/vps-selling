#!/bin/bash
set -euo pipefail

DOMAIN="${1:-}"
CONTAINER_IP="${2:-}"
ADMIN_EMAIL="contact@example.invalid"

fail() { echo "ERROR: $1" >&2; exit 1; }

[[ -n "$DOMAIN" ]] || fail "domain argument missing"
[[ "$DOMAIN" =~ ^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$ ]] \
    || fail "domain fails hostname format check: $DOMAIN"
[[ "$DOMAIN" != "pulsarx.example.invalid" ]] || fail "refusing to manage our own primary domain: $DOMAIN"

[[ -n "$CONTAINER_IP" ]] || fail "container_ip argument missing"
[[ "$CONTAINER_IP" =~ ^10\.103\.180\.[0-9]{1,3}$ ]] || fail "container_ip outside expected subnet: $CONTAINER_IP"

# SECURITY-20261109-r1: private, atomically created nginx diagnostic.
umask 077
PX_NGINX_ERROR=$(mktemp /tmp/pulsarx-domain.XXXXXXXX)
trap 'rm -f -- "$PX_NGINX_ERROR"' EXIT

CONF="/etc/nginx/sites-available/customer-${DOMAIN}.conf"
LINK="/etc/nginx/sites-enabled/customer-${DOMAIN}.conf"

cat > "$CONF" << NGINXCONF
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};

    location / {
        proxy_pass http://${CONTAINER_IP}:80;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
NGINXCONF

ln -sf "$CONF" "$LINK"

if ! nginx -t 2>"$PX_NGINX_ERROR"; then
    rm -f "$CONF" "$LINK"
    cat "$PX_NGINX_ERROR" >&2
    fail "nginx config test failed, rolled back"
fi

systemctl reload nginx

if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$ADMIN_EMAIL" --redirect; then
    echo "OK: $DOMAIN configured with HTTPS"
    exit 0
else
    echo "PARTIAL: $DOMAIN configured over HTTP only, certbot failed (DNS may not be propagated yet)"
    exit 2
fi
