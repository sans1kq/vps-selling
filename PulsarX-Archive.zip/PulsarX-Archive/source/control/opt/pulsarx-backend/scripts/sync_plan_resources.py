"""Dry-run/apply plan resource changes to existing PulsarX instances.

Usage from /opt/pulsarx-backend:
  venv/bin/python scripts/sync_plan_resources.py          # dry-run
  venv/bin/python scripts/sync_plan_resources.py --apply  # grow live instances + update DB

The script never shrinks a disk. Pending-payment rows are updated in the DB so
future provisioning uses the new plan size. In-flight provisioning rows are
skipped to avoid racing the background provisioner.
"""
import argparse

from app import incus_service
from app.database import SessionLocal
from app.models import Server, ServerStatus
from app.schemas import PLANS


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="perform changes (default is dry-run)")
    args = parser.parse_args()

    db = SessionLocal()
    changed = 0
    skipped = 0
    try:
        rows = db.query(Server).filter(Server.status != ServerStatus.deleted).order_by(Server.created_at).all()
        for server in rows:
            spec = PLANS.get(server.plan)
            if not spec:
                continue
            target_disk = int(spec["disk_gb"])
            target_cpu = int(spec["cpu_cores"])
            target_ram = int(spec["ram_mb"])
            needs = (
                server.disk_gb < target_disk
                or server.cpu_cores < target_cpu
                or server.ram_mb < target_ram
            )
            if not needs:
                continue

            before = f"{server.cpu_cores}c/{server.ram_mb}MB/{server.disk_gb}GB"
            after = f"{target_cpu}c/{target_ram}MB/{target_disk}GB"
            print(f"{server.container_name}: {server.plan} {server.status.value} {before} -> {after}")

            if not args.apply:
                changed += 1
                continue

            if server.status == ServerStatus.pending_approval:
                # No container exists yet: only update what the later provisioner reads.
                server.cpu_cores = max(server.cpu_cores, target_cpu)
                server.ram_mb = max(server.ram_mb, target_ram)
                server.disk_gb = max(server.disk_gb, target_disk)
                db.commit()
                changed += 1
                continue

            if server.status in (ServerStatus.running, ServerStatus.suspended):
                incus_service.resize_container(
                    server.container_name,
                    max(server.cpu_cores, target_cpu),
                    max(server.ram_mb, target_ram),
                    max(server.disk_gb, target_disk),
                )
                server.cpu_cores = max(server.cpu_cores, target_cpu)
                server.ram_mb = max(server.ram_mb, target_ram)
                server.disk_gb = max(server.disk_gb, target_disk)
                db.commit()
                changed += 1
                continue

            print("  SKIP: provisioning/pending/failed instance; retry after it reaches a stable state")
            skipped += 1

        mode = "applied" if args.apply else "would change"
        print(f"Done: {changed} {mode}, {skipped} skipped")
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
