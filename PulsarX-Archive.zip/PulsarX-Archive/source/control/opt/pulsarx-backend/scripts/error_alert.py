#!/usr/bin/env python3
"""Scan recent pulsarx-api logs for new tracebacks/exceptions since the last
check, and email the admin a summary if any are found. State (last checked
timestamp) is kept in a small marker file so each error is reported once.
"""
import subprocess
import smtplib
import sys
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path

sys.path.insert(0, "/opt/pulsarx-backend")
from app.config import get_settings  # noqa: E402

STATE_FILE = Path("/opt/pulsarx-backend/backups/.error_alert_last_check")
settings = get_settings()


def get_last_check() -> str:
    if STATE_FILE.exists():
        return STATE_FILE.read_text().strip()
    # First run: only look at the last 5 minutes, not all history.
    return "5 min ago"


def send_alert(count: int, sample: str) -> None:
    msg = EmailMessage()
    msg["Subject"] = f"⚠ PulsarX backend errors detected ({count})"
    msg["From"] = settings.smtp_from
    msg["To"] = settings.admin_notify_email
    msg.set_content(
        f"{count} error line(s) found in pulsarx-api logs since the last check.\n\n"
        f"Sample:\n{sample}\n\n"
        "Check the full log with:\n"
        "sudo journalctl -u pulsarx-api.service --since '10 min ago' | grep -i traceback\n\n"
        "- PulsarX monitoring"
    )
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
        if settings.smtp_use_tls:
            server.starttls()
        server.login(settings.smtp_user, settings.smtp_password)
        server.send_message(msg)


def main():
    since = get_last_check()
    result = subprocess.run(
        ["journalctl", "-u", "pulsarx-api.service", "--since", since, "--no-pager"],
        capture_output=True, text=True,
    )
    lines = result.stdout.splitlines()
    error_lines = [l for l in lines if "Traceback" in l or "ERROR:" in l]

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    STATE_FILE.write_text(now)

    if error_lines:
        sample = "\n".join(error_lines[:20])
        send_alert(len(error_lines), sample)
        print(f"ALERT sent: {len(error_lines)} error line(s) found")
    else:
        print("OK: no errors found")


if __name__ == "__main__":
    main()
