#!/bin/bash
set -euo pipefail

DOMAIN="${1:-}"

fail() { echo "ERROR: $1" >&2; exit 1; }

[[ -n "$DOMAIN" ]] || fail "domain argument missing"
[[ "$DOMAIN" =~ ^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$ ]] \
    || fail "domain fails hostname format check: $DOMAIN"
[[ "$DOMAIN" != "pulsarx.example.invalid" ]] || fail "refusing to manage our own primary domain: $DOMAIN"

# SECURITY-20261109-r1: private, atomically created nginx diagnostic.
umask 077
PX_NGINX_ERROR=$(mktemp /tmp/pulsarx-domain.XXXXXXXX)
trap 'rm -f -- "$PX_NGINX_ERROR"' EXIT

CONF="/etc/nginx/sites-available/customer-${DOMAIN}.conf"
LINK="/etc/nginx/sites-enabled/customer-${DOMAIN}.conf"

rm -f "$LINK" "$CONF"

if nginx -t 2>"$PX_NGINX_ERROR"; then
    systemctl reload nginx
else
    cat "$PX_NGINX_ERROR" >&2
    fail "nginx config test failed after removal (unexpected, check manually)"
fi

# Best-effort cert cleanup; a missing cert here is not fatal (e.g. it was HTTP-only).
certbot delete --cert-name "$DOMAIN" --non-interactive 2>/dev/null || true

echo "OK: $DOMAIN removed"
