#!/usr/bin/env python3
"""Check host disk/memory usage; email the admin once when a threshold is
crossed upward, and once more when it recovers back below it. State is kept
in a small flag file so this doesn't spam an email every run while the
problem persists.
"""
import shutil
import smtplib
import sys
from email.message import EmailMessage
from pathlib import Path

sys.path.insert(0, "/opt/pulsarx-backend")
from app.config import get_settings  # noqa: E402

THRESHOLD_PCT = 85.0
STATE_FILE = Path("/opt/pulsarx-backend/backups/.host_alert_state")

settings = get_settings()


def get_usage_pct(path: str) -> float:
    total, used, _ = shutil.disk_usage(path)
    return used / total * 100


def get_mem_pct() -> float:
    with open("/proc/meminfo") as f:
        lines = {l.split(":")[0]: int(l.split()[1]) for l in f if ":" in l}
    total = lines["MemTotal"]
    available = lines.get("MemAvailable", lines["MemFree"])
    used = total - available
    return used / total * 100


def send_alert(subject: str, body: str) -> None:
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = settings.smtp_from
    msg["To"] = settings.admin_notify_email
    msg.set_content(body)
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
        if settings.smtp_use_tls:
            server.starttls()
        server.login(settings.smtp_user, settings.smtp_password)
        server.send_message(msg)


def main():
    disk_pct = round(get_usage_pct("/"), 1)
    mem_pct = round(get_mem_pct(), 1)

    was_critical = STATE_FILE.exists()
    is_critical = disk_pct >= THRESHOLD_PCT or mem_pct >= THRESHOLD_PCT

    if is_critical and not was_critical:
        send_alert(
            f"⚠ PulsarX host alert: usage above {THRESHOLD_PCT}%",
            f"Disk usage: {disk_pct}%\nMemory usage: {mem_pct}%\n\n"
            f"Threshold: {THRESHOLD_PCT}%\n\n- PulsarX monitoring",
        )
        STATE_FILE.write_text(f"disk={disk_pct} mem={mem_pct}\n")
        print(f"ALERT sent: disk={disk_pct}% mem={mem_pct}%")
    elif not is_critical and was_critical:
        send_alert(
            "✅ PulsarX host alert: usage back to normal",
            f"Disk usage: {disk_pct}%\nMemory usage: {mem_pct}%\n\n"
            f"Both are back under {THRESHOLD_PCT}%.\n\n- PulsarX monitoring",
        )
        STATE_FILE.unlink()
        print(f"RECOVERY sent: disk={disk_pct}% mem={mem_pct}%")
    else:
        print(f"OK: disk={disk_pct}% mem={mem_pct}% (critical={is_critical})")


if __name__ == "__main__":
    main()
