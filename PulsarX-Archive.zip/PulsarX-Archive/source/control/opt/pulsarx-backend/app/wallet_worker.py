from .flex_capacity import require_resources
"""Durable wallet jobs, run by a systemd timer rather than request background tasks."""
import json
import logging
import uuid
from datetime import timedelta

from sqlalchemy import text, or_, and_

from . import anypay_service, incus_service, payments_service, wallet_service, wallet_plisio, wallet_freekassa
from .capacity_service import capacity_lock, require_capacity, storage_size
from .database import SessionLocal, engine
from .models import Server, ServerStatus, User
from .schemas import PLANS
from .server_access import ensure_not_held
from .wallet_models import WalletOrder, WalletTopup

logger = logging.getLogger("pulsarx.wallet_worker")
WORKER_LOCK = 706181926


def _state(name):
    data = json.loads(incus_service._run(["incus", "list", name, "--format", "json"], timeout=20))
    matches = [r for r in data if r.get("name") == name]
    if len(matches) != 1:
        raise RuntimeError("Instance could not be verified")
    return str(matches[0].get("status", "")).lower()


def _resume(name):
    db=SessionLocal()
    try:
        server=db.query(Server).filter_by(container_name=name).populate_existing().with_for_update().one_or_none()
        if server is None:raise RuntimeError("Instance no longer exists")
        ensure_not_held(server)
        if _state(name)!="running":incus_service.start_container(name)
        if _state(name)!="running":raise RuntimeError("Instance did not start")
        db.commit()
    finally:db.close()


def _resize(name, plan):
    incus_service.validate_container_name(name)
    spec = PLANS[plan]
    pool_name = name + "-pool"
    db = SessionLocal()
    try:
        capacity_lock(db)
        server = db.query(Server).filter_by(container_name=name).populate_existing().with_for_update().one_or_none()
        if server is None:raise RuntimeError("Instance no longer exists")
        ensure_not_held(server)
        instance = json.loads(incus_service._run(["incus", "query", f"/1.0/instances/{name}?project=default"], timeout=20))
        if isinstance(instance, dict) and "metadata" in instance:
            instance = instance["metadata"]
        if instance.get("expanded_devices", {}).get("root", {}).get("pool") != pool_name:
            raise RuntimeError("Instance no longer uses its dedicated storage pool")
        pool = json.loads(incus_service._run(["incus", "query", f"/1.0/storage-pools/{pool_name}"], timeout=20))
        if isinstance(pool, dict) and "metadata" in pool:
            pool = pool["metadata"]
        if pool.get("driver") != "btrfs" or pool.get("config", {}).get("source") != f"/var/lib/incus/disks/{pool_name}.img":
            raise RuntimeError("Unexpected dedicated storage pool")
        require_resources(db,spec,name)
        current = storage_size(pool["config"]["size"])
        target = spec["disk_gb"] * 10**9
        if current < target:
            incus_service._run(["incus", "storage", "set", pool_name, f"size={spec['disk_gb']}GB"], timeout=120)
        incus_service.resize_container(name, spec["cpu_cores"], spec["ram_mb"], spec["disk_gb"])
        db.commit()
    finally:
        db.close()


def _finish(order_id, refund=False):
    db = SessionLocal()
    try:
        info = db.get(WalletOrder, order_id)
        if info is None:
            return
        acct = wallet_service.account(db, info.user_id)
        order = db.query(WalletOrder).filter_by(id=order_id).populate_existing().with_for_update().one()
        if order.status in ("completed", "refunded"):
            db.rollback()
            return
        server = db.query(Server).filter_by(id=order.server_id).with_for_update().one_or_none() if order.server_id else None
        now = wallet_service.now_utc()
        if refund:
            # Only a NEW instance whose resources have been confirmed deleted may
            # be automatically refunded. A partial resize/resume is never free.
            if order.kind != "new":
                raise RuntimeError("Unsafe automatic refund")
            wallet_service.entry(db, acct, order.amount_cents, "refund", f"order:{order.id}:refund",
                                 f"Creation refund: {order.container_name}")
            if server:
                server.status = ServerStatus.failed
                server.paid_until = None
            order.status = "refunded"
        else:
            if server is None:
                raise RuntimeError("Order instance no longer exists")
            if order.kind == "new":
                if server.status != ServerStatus.running:
                    raise RuntimeError("Provisioning has not succeeded")
                server.paid_until = now + timedelta(days=payments_service.PERIOD_DAYS[order.months])
            elif order.kind == "renew":
                server.paid_until = max(server.paid_until, now) + timedelta(days=payments_service.PERIOD_DAYS[order.months])
                if server.admin_suspended_at is None:
                    server.status = ServerStatus.running
                server.payment_failed_at = server.last_dunning_email_sent_at = None
            else:
                spec = PLANS[order.plan]
                server.plan, server.ram_mb = order.plan, spec["ram_mb"]
                server.cpu_cores, server.disk_gb = spec["cpu_cores"], max(server.disk_gb,spec["disk_gb"])
            order.status = "completed"
            order.error_code = None
        order.completed_at = now
        db.commit()
    finally:
        db.close()


def process_order(order_id):
    db = SessionLocal()
    try:
        row = db.query(WalletOrder).filter_by(id=order_id).with_for_update().one_or_none()
        if not row or row.status not in ("queued", "working"):
            return
        was_working = row.status == "working"
        row.status = "working"
        row.attempts += 1
        kind, plan, name, server_id = row.kind, row.plan, row.container_name, row.server_id
        db.commit()
    finally:
        db.close()
    try:
        if kind == "new":
            check = SessionLocal()
            try:
                server = check.get(Server, server_id) if server_id else None
                state = server.status if server else None
            finally:
                check.close()
            if state == ServerStatus.running:
                _finish(order_id)
                return
            if not was_working and state == ServerStatus.pending:
                from .routers.servers import _provision
                _provision(server_id)
                check = SessionLocal()
                try:
                    server = check.get(Server, server_id)
                    state = server.status if server else None
                finally:
                    check.close()
                if state == ServerStatus.running:
                    _finish(order_id)
                    return
            # Crash recovery or a failed provision: remove only this order's
            # dedicated resources, and credit back only after verified cleanup.
            incus_service.delete_container(name)
            _finish(order_id, refund=True)
        elif kind == "renew":
            _resume(name)
            _finish(order_id)
        else:
            _resize(name, plan)
            _finish(order_id)
    except Exception:
        logger.exception("Wallet order %s could not finish", order_id)
        db = SessionLocal()
        try:
            row = db.query(WalletOrder).filter_by(id=order_id).with_for_update().one_or_none()
            if row and row.status not in ("completed", "refunded"):
                # Retries are idempotent; retain working state so a restart never
                # blindly tries to launch the same instance a second time.
                row.status = "review" if row.attempts >= 3 else "working"
                row.error_code = "operation_needs_review" if row.status == "review" else "retrying"
                db.commit()
        finally:
            db.close()


def run():
    # A session advisory lock survives commits and is shared by every API/cron
    # worker. Keep its connection open throughout all Incus operations.
    lock = engine.connect()
    try:
        if not lock.execute(text("SELECT pg_try_advisory_lock(:key)"), {"key": WORKER_LOCK}).scalar():
            return
        lock.commit()
        db = SessionLocal()
        try:
            topups = [r[0] for r in db.query(WalletTopup.id).filter(
                or_(WalletTopup.live_notification.is_(True), WalletTopup.provider.in_(("plisio", "rollypay"))),
                or_(WalletTopup.status.in_(("pending", "creating", "closed", "cancelled", "expired")),
                    and_(WalletTopup.provider == "freekassa", WalletTopup.status == "credited"),
                    and_(WalletTopup.provider == "rollypay", WalletTopup.status.in_(("credited", "review")))),
                or_(WalletTopup.checked_at.is_(None), WalletTopup.status.in_(("pending", "creating")),
                    WalletTopup.checked_at < wallet_service.now_utc() - timedelta(minutes=5)),
                or_(WalletTopup.checked_at.is_(None), WalletTopup.created_at > wallet_service.now_utc() - timedelta(days=30)),
            ).order_by(WalletTopup.checked_at.asc().nullsfirst(), WalletTopup.created_at.desc()).limit(100)]
            orders = [r[0] for r in db.query(WalletOrder.id).filter(
                WalletOrder.status.in_(("queued", "working"))).order_by(WalletOrder.created_at).limit(20)]
        finally:
            db.close()
        unavailable = set()
        for pay_id in topups:
            db = SessionLocal()
            provider_name = None
            try:
                row = db.get(WalletTopup, pay_id)
                if row is None:
                    continue
                provider_name = row.provider
                enabled = {"anypay": anypay_service.enabled(), "plisio": wallet_plisio.enabled(),
                           "freekassa": wallet_freekassa.enabled(), "rollypay": wallet_service.wallet_rollypay.enabled()}.get(provider_name, False)
                if not enabled or provider_name in unavailable:
                    continue
                if provider_name == "plisio" and not row.transaction_id and row.status in ("pending", "creating") and row.expires_at > wallet_service.now_utc():
                    owner = db.get(User, row.user_id)
                    wallet_service.checkout_topup(db, owner, pay_id)
                wallet_service.settle_topup(db, pay_id)
            except anypay_service.ProviderUnavailable:
                db.rollback()
                logger.warning("Payment reconciliation temporarily unavailable for top-up %s", pay_id)
                unavailable.add(provider_name)
            except Exception:
                db.rollback()
                logger.exception("Top-up %s needs reconciliation", pay_id)
            finally:
                db.close()
        for order_id in orders:
            process_order(order_id)
        from .growth_service import process_pending
        process_pending()
    finally:
        try:
            lock.execute(text("SELECT pg_advisory_unlock(:key)"), {"key": WORKER_LOCK})
            lock.commit()
        finally:
            lock.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
