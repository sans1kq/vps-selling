"""Authenticated website tickets in the existing private support store.

Website customers are account UUIDs, never Telegram chat identifiers. Nothing
in this module creates a Telegram account binding or changes a wallet/server.
"""
import hashlib
import json
import sqlite3
import time
import uuid

from . import support_store as store


class RateLimited(ValueError):
    pass


def initialize():
    store.initialize()
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        columns={r['name'] for r in db.execute('PRAGMA table_info(tickets)')}
        for name,definition in (
            ('channel',"TEXT NOT NULL DEFAULT 'telegram'"),
            ('web_user_id','TEXT'),('subject',"TEXT NOT NULL DEFAULT ''"),
            ('language',"TEXT NOT NULL DEFAULT 'ru'"),('web_last_read','REAL NOT NULL DEFAULT 0')):
            if name not in columns:db.execute('ALTER TABLE tickets ADD COLUMN '+name+' '+definition)
        # Preserve the old name: an old worker's CREATE INDEX IF NOT EXISTS
        # cannot replace this index and accidentally reintroduce chat_id=0 caps.
        index=db.execute("SELECT sql FROM sqlite_master WHERE type='index' AND name='one_open_ticket'").fetchone()
        if not index or "channel='telegram'" not in index[0]:
            db.execute('DROP INDEX IF EXISTS one_open_ticket')
            db.execute("CREATE UNIQUE INDEX one_open_ticket ON tickets(chat_id) WHERE status='open' AND channel='telegram'")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS one_open_web_ticket ON tickets(web_user_id) WHERE status='open' AND channel='web'")
        db.execute('CREATE INDEX IF NOT EXISTS web_ticket_owner ON tickets(web_user_id,id)')
        db.execute('CREATE TABLE IF NOT EXISTS web_requests(key TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, ticket_id INTEGER NOT NULL REFERENCES tickets(id), message_id INTEGER REFERENCES messages(id))')
        # Compatibility guard: an older admin handler/worker after a code rollback
        # must never enqueue website replies to Telegram chat 0.
        for action in ('INSERT','UPDATE OF delivery'):
            suffix='insert' if action=='INSERT' else 'update'
            db.execute("CREATE TRIGGER IF NOT EXISTS web_delivery_"+suffix+" AFTER "+action+" ON messages WHEN NEW.direction!='notify' AND NEW.delivery IN ('queued','sending') AND EXISTS(SELECT 1 FROM tickets WHERE id=NEW.ticket_id AND channel='web') BEGIN UPDATE messages SET delivery='available',error=NULL WHERE id=NEW.id; END")
        db.execute("UPDATE messages SET delivery='available',error=NULL WHERE direction!='notify' AND delivery IN ('queued','sending') AND ticket_id IN (SELECT id FROM tickets WHERE channel='web')")
        store.put(db,'web_schema','1')


def identity(user):
    owner=str(uuid.UUID(str(user.id)))
    if not user.is_verified:raise PermissionError('Verify your email before contacting support')
    return owner


def owned(db,owner,ticket_id):
    row=db.execute("SELECT * FROM tickets WHERE id=? AND channel='web' AND web_user_id=? AND status IN ('open','closed')",(ticket_id,owner)).fetchone()
    if not row:raise LookupError('Ticket not found')
    return row


def public_ticket(row):
    return {k:row[k] for k in ('id','subject','status','created','updated')}


def request_key(owner,kind,key):
    return 'web:'+owner+':'+kind+':'+str(uuid.UUID(str(key)))


def fingerprint(*items):
    return hashlib.sha256(json.dumps(items,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def existing(db,key,signature,ticket_id=None):
    old=db.execute('SELECT * FROM web_requests WHERE key=?',(key,)).fetchone()
    if old and (old['payload_hash']!=signature or ticket_id is not None and old['ticket_id']!=ticket_id):
        raise ValueError('This request identifier was used for different content')
    return old


def check_rate(db,owner,now,creating=False):
    if creating:
        count=db.execute("SELECT count(*) FROM tickets WHERE channel='web' AND web_user_id=? AND created>?",(owner,now-86400)).fetchone()[0]
        if count>=10:raise RateLimited('Too many new tickets today; continue an existing conversation')
    count=db.execute("SELECT count(*) FROM messages m JOIN tickets t ON t.id=m.ticket_id WHERE t.channel='web' AND t.web_user_id=? AND m.direction='in' AND m.created>?",(owner,now-60)).fetchone()[0]
    if count>=10:raise RateLimited('Too many messages; please wait a minute')


def listing(user,before=0):
    owner=identity(user)
    with store.connect() as db:
        rows=db.execute("SELECT * FROM tickets WHERE channel='web' AND web_user_id=? AND status IN ('open','closed') AND (?=0 OR id<?) ORDER BY id DESC LIMIT 51",(owner,before,before)).fetchall()
        result=[]
        for row in rows[:50]:
            ticket=public_ticket(row)
            ticket['unread']=bool(db.execute("SELECT 1 FROM messages WHERE ticket_id=? AND direction IN ('out','system') AND created>? LIMIT 1",(row['id'],row['web_last_read'])).fetchone())
            result.append(ticket)
        return {'tickets':result,'next_before':rows[49]['id'] if len(rows)>50 else None}


def create(user,subject,body,language,key):
    owner=identity(user);subject=subject.strip();body=body.strip()
    if not 3<=len(subject)<=120 or not 1<=len(body)<=4000 or language not in ('ru','en','ro'):raise ValueError('Invalid ticket content')
    req=request_key(owner,'create',key);signature=fingerprint(subject,body,language);now=time.time()
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        previous=existing(db,req,signature)
        if previous:
            row=owned(db,owner,previous['ticket_id'])
            return {'ticket':public_ticket(row),'replayed':True}
        old=db.execute("SELECT id FROM tickets WHERE channel='web' AND web_user_id=? AND status='open'",(owner,)).fetchone()
        if old:raise ValueError('You already have an open ticket; continue that conversation')
        check_rate(db,owner,now,True)
        name=(str(user.first_name)+' '+str(user.last_name)).strip()+' · '+str(user.email)
        tid=db.execute("INSERT INTO tickets(chat_id,name,username,status,created,updated,unread,channel,web_user_id,subject,language) VALUES(0,?,'','open',?,?,1,'web',?,?,?)",(name[:360],now,now,owner,subject,language)).lastrowid
        mid=db.execute("INSERT INTO messages(ticket_id,direction,body,created,delivery,request_id) VALUES(?,'in',?,?,'received',?)",(tid,body,now,req)).lastrowid
        db.execute('INSERT INTO web_requests VALUES(?,?,?,?)',(req,signature,tid,mid))
        recipient=store.meta(db,'notify_chat_id')
        if recipient.isdecimal() and 0<int(recipient)<10**19:
            # Same authorized personal target as Telegram tickets, distinct key
            # namespace; no customer text or customer contact is sent to alerts.
            alert='Новое обращение с сайта #'+str(tid)+'\n\nОткрыть и ответить:\nhttps://pulsarx.example.invalid/admin/?support_ticket='+str(tid)
            store.enqueue(db,tid,alert,'notify:'+recipient+':web:'+str(tid),'notify',now)
        return {'ticket':public_ticket(owned(db,owner,tid)),'replayed':False}


def thread(user,ticket_id,before=0):
    owner=identity(user)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket=owned(db,owner,ticket_id)
        rows=db.execute("SELECT id,direction,body,created FROM messages WHERE ticket_id=? AND direction IN ('in','out','system') AND (?=0 OR id<?) ORDER BY id DESC LIMIT 101",(ticket_id,before,before)).fetchall()
        # Customer reading does not clear the administrator's incoming flag.
        if not before:db.execute('UPDATE tickets SET web_last_read=? WHERE id=?',(time.time(),ticket_id))
        return {'ticket':public_ticket(ticket),'messages':[dict(r) for r in reversed(rows[:100])],'next_before':rows[99]['id'] if len(rows)>100 else None}


def message(user,ticket_id,body,key):
    owner=identity(user);body=body.strip()
    if not 1<=len(body)<=4000:raise ValueError('Message must contain 1–4000 characters')
    req=request_key(owner,'message',key);signature=fingerprint(ticket_id,body);now=time.time()
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE');ticket=owned(db,owner,ticket_id)
        prev=existing(db,req,signature,ticket_id)
        if prev:return {'id':prev['message_id'],'replayed':True}
        if ticket['status']!='open':raise ValueError('This ticket is closed; open a new one if you need help')
        check_rate(db,owner,now)
        mid=db.execute("INSERT INTO messages(ticket_id,direction,body,created,delivery,request_id) VALUES(?,'in',?,?,'received',?)",(ticket_id,body,now,req)).lastrowid
        db.execute('INSERT INTO web_requests VALUES(?,?,?,?)',(req,signature,ticket_id,mid))
        db.execute('UPDATE tickets SET updated=?,unread=1 WHERE id=?',(now,ticket_id))
        return {'id':mid,'replayed':False}


def close_in(db,ticket,status):
    if ticket['status']==status:return
    now=time.time();db.execute('UPDATE tickets SET status=?,updated=? WHERE id=?',(status,now,ticket['id']))
    if status=='closed':
        bodies={'ru':'Обращение закрыто. Если появится другой вопрос, создайте новое обращение в разделе «Поддержка».','en':'This ticket is closed. If you need help with another issue, open a new ticket in Support.','ro':'Tichetul este închis. Pentru o altă întrebare, deschide un tichet nou în Suport.'}
        db.execute("INSERT INTO messages(ticket_id,direction,body,created,delivery,request_id) VALUES(?,'system',?,?,'available',?)",(ticket['id'],bodies.get(ticket['language'],bodies['ru']),now,'webclosed:'+str(ticket['id'])+':'+uuid.uuid4().hex))


def close(user,ticket_id):
    owner=identity(user)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE');ticket=owned(db,owner,ticket_id);close_in(db,ticket,'closed')
    return {'status':'closed'}


def channel(ticket_id):
    with store.connect() as db:
        row=db.execute('SELECT channel FROM tickets WHERE id=?',(ticket_id,)).fetchone()
    if not row:raise LookupError('Ticket not found')
    return row['channel']


def admin_listing(*args):
    value=store.listing(*args)
    with store.connect() as db:
        for ticket in value['tickets']:
            extra=db.execute('SELECT channel,subject,web_user_id FROM tickets WHERE id=?',(ticket['id'],)).fetchone()
            ticket.update(dict(extra))
    return value


def admin_thread(ticket_id,before=0):
    value=store.thread(ticket_id,before)
    with store.connect() as db:
        row=db.execute('SELECT channel,subject,web_user_id FROM tickets WHERE id=?',(ticket_id,)).fetchone()
        value['ticket'].update(dict(row))
    return value


def admin_reply(ticket_id,body,key):
    if channel(ticket_id)!='web':return store.reply(ticket_id,body,key)
    request='adminweb:'+str(uuid.UUID(key))
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket=db.execute("SELECT * FROM tickets WHERE id=? AND channel='web'",(ticket_id,)).fetchone()
        previous=db.execute('SELECT id,ticket_id,body,delivery FROM messages WHERE request_id=?',(request,)).fetchone()
        if previous:
            if previous['ticket_id']!=ticket_id or previous['body']!=body:raise ValueError('Reply request conflicts')
            return dict(previous)
        if ticket['status']!='open':raise ValueError('Reopen the ticket before replying')
        now=time.time()
        mid=db.execute("INSERT INTO messages(ticket_id,direction,body,created,delivery,request_id) VALUES(?,'out',?,?,'available',?)",(ticket_id,body,now,request)).lastrowid
        db.execute('UPDATE tickets SET updated=? WHERE id=?',(now,ticket_id))
        return {'id':mid,'ticket_id':ticket_id,'body':body,'delivery':'available'}


def admin_status(ticket_id,status):
    if channel(ticket_id)!='web':return store.set_status(ticket_id,status)
    if status not in ('open','closed'):raise ValueError('Invalid status')
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket=db.execute("SELECT * FROM tickets WHERE id=? AND channel='web'",(ticket_id,)).fetchone()
        close_in(db,ticket,status)


def admin_retry(message_id):
    with store.connect() as db:
        row=db.execute('SELECT t.channel FROM messages m JOIN tickets t ON t.id=m.ticket_id WHERE m.id=?',(message_id,)).fetchone()
    if not row:raise LookupError('Message not found')
    if row['channel']=='web':raise ValueError('Website replies are available immediately and do not need Telegram delivery')
    return store.retry_reply(message_id)
