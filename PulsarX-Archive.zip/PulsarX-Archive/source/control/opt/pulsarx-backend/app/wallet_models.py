"""Separate, additive USD wallet tables. Existing payment records are untouched."""
import uuid

from sqlalchemy import (BigInteger, Boolean, CheckConstraint, Column, DateTime,
                        ForeignKey, Integer, Sequence, String, Text, UniqueConstraint, func)
from sqlalchemy.dialects.postgresql import UUID

from .database import Base


class WalletAccount(Base):
    __tablename__ = "wallet_accounts"
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), primary_key=True)
    balance_cents = Column(BigInteger, nullable=False, default=0)
    frozen = Column(Boolean, nullable=False, default=False)
    __table_args__ = (CheckConstraint("balance_cents >= 0"),)


class WalletEntry(Base):
    __tablename__ = "wallet_entries"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("wallet_accounts.user_id"), nullable=False, index=True)
    amount_cents = Column(BigInteger, nullable=False)
    balance_after_cents = Column(BigInteger, nullable=False)
    kind = Column(String(24), nullable=False)
    reference = Column(String(100), nullable=False, unique=True)
    label = Column(String(160), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    __table_args__ = (CheckConstraint("amount_cents <> 0"), CheckConstraint("balance_after_cents >= 0"))


class WalletTopup(Base):
    __tablename__ = "wallet_topups"
    id = Column(BigInteger().with_variant(Integer, "sqlite"),
                Sequence("wallet_anypay_pay_id_seq", start=86000000000000), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    request_key = Column(UUID(as_uuid=True), nullable=False)
    amount_cents = Column(Integer, nullable=False)
    provider = Column(String(16), nullable=False, default="anypay", server_default="anypay")
    checkout_url = Column(Text, nullable=True)
    provider_hint = Column(String(32), nullable=True)
    provider_method = Column(Integer, nullable=True)
    provider_create_started_at = Column(DateTime(timezone=True), nullable=True)
    status = Column(String(24), nullable=False, default="pending")
    transaction_id = Column(String(32), nullable=True, unique=True)
    # AnyPay requires a valid live SCI receipt before reconciliation can credit.
    # Plisio separately verifies the authenticated invoice operation.
    live_notification = Column(Boolean, nullable=False, default=False)
    provider_status = Column(String(24), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    credited_at = Column(DateTime(timezone=True), nullable=True)
    checked_at = Column(DateTime(timezone=True), nullable=True)
    __table_args__ = (UniqueConstraint("user_id", "request_key"), CheckConstraint("amount_cents > 0"))


class WalletOrder(Base):
    __tablename__ = "wallet_orders"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    request_key = Column(UUID(as_uuid=True), nullable=False)
    fingerprint = Column(String(64), nullable=False)
    server_id = Column(UUID(as_uuid=True), ForeignKey("servers.id", ondelete="SET NULL"), nullable=True, index=True)
    container_name = Column(String(64), nullable=False)
    kind = Column(String(16), nullable=False)
    plan = Column(String(16), nullable=False)
    months = Column(Integer, nullable=False)
    amount_cents = Column(Integer, nullable=False)
    status = Column(String(24), nullable=False, default="queued")
    attempts = Column(Integer, nullable=False, default=0)
    error_code = Column(String(48), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    __table_args__ = (UniqueConstraint("user_id", "request_key"), CheckConstraint("amount_cents > 0"))


ACTIVE_ORDERS = ("queued", "working", "review")
