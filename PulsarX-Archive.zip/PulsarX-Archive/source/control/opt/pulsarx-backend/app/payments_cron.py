"""Run every few minutes (systemd timer).

1. settle open invoices (safety net for lost webhooks),
2. freeze servers whose paid period has ended,
3. send renewal reminders 7, 3 and 1 day before the end.
"""
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import and_, or_

from . import email_service, incus_service, payments_service
from .action_log import log_action
from .config import get_settings
from .database import SessionLocal
from .models import Payment, Server, ServerStatus
from .wallet_models import WalletOrder, ACTIVE_ORDERS
from .wallet_service import active_order

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pulsarx.payments_cron")

REMIND_DAYS = (7, 3, 1)
DELETE_AFTER_DAYS = 14
settings = get_settings()


def due_reminder(paid_until, last_reminder, now):
    """Moment (paid_until - N days) to remind for, or None if nothing is due."""
    due = None
    for d in REMIND_DAYS:
        t = paid_until - timedelta(days=d)
        if t <= now:
            due = t
    if due is None or (last_reminder is not None and last_reminder >= due):
        return None
    return due


def _expire_overdue(db, now) -> None:
    ids=[row[0] for row in db.query(Server.id).filter(Server.paid_until.isnot(None),Server.paid_until<now,
        Server.ls_subscription_id.is_(None),Server.payment_failed_at.is_(None),
        Server.status.in_((ServerStatus.running,ServerStatus.suspended))).all()]
    db.rollback()
    for ident in ids:
        server=db.query(Server).filter_by(id=ident).populate_existing().with_for_update().one_or_none()
        if (server is None or server.ls_subscription_id or server.paid_until is None or server.paid_until>=now
                or server.payment_failed_at is not None or server.status not in (ServerStatus.running,ServerStatus.suspended)
                or active_order(db,ident)):
            db.rollback();continue
        if server.status==ServerStatus.running:
            try:incus_service.stop_container(server.container_name)
            except Exception:
                db.rollback()
                logger.exception("Failed to stop overdue instance; a later sweep will retry")
                continue
        server.status=ServerStatus.suspended
        server.payment_failed_at=now;server.last_dunning_email_sent_at=now
        db.commit()
        log_action(db,"subscription_expired","server",f"{server.container_name} ({server.owner_email})",actor="system")
        try:email_service.send_crypto_suspended_email(server.owner_email,server.container_name,DELETE_AFTER_DAYS)
        except Exception:logger.exception("Failed to send expiry email")


def _send_reminders(db, now) -> None:
    rows = (
        db.query(Server)
        .filter(
            Server.paid_until.isnot(None),
            Server.paid_until > now,
            Server.paid_until < now + timedelta(days=max(REMIND_DAYS)),
            Server.ls_subscription_id.is_(None),
            Server.status == ServerStatus.running,
        )
        .all()
    )
    for server in rows:
        due = due_reminder(server.paid_until, server.renewal_reminder_for, now)
        if due is None:
            continue
        days_left = max(1, -(-int((server.paid_until - now).total_seconds()) // 86400))
        try:
            email_service.send_crypto_reminder_email(
                server.owner_email, server.container_name, days_left,
                server.paid_until.strftime("%Y-%m-%d %H:%M"),
            )
            server.renewal_reminder_for = due
            db.commit()
        except Exception:
            logger.exception("Failed to send renewal reminder for %s", server.container_name)


def _expire_stale_payments(db, now) -> None:
    """Close invoices Plisio never reported on, so nothing stays open forever."""
    db.query(Payment).filter(
        Payment.status == "created", Payment.expires_at < now - timedelta(hours=2)
    ).update({"status": "expired"}, synchronize_session=False)
    db.query(Payment).filter(
        Payment.status == "pending", Payment.expires_at < now - timedelta(hours=24)
    ).update({"status": "needs_review"}, synchronize_session=False)
    db.commit()


def _delete_unpaid_servers(db, now) -> None:
    """Remove 'awaiting payment' servers once their invoice window is over.

    Kept: servers with a live invoice, a payment in progress, a payment under
    manual review, or an admin approval token (free-instance flow).
    """
    age = timedelta(minutes=settings.invoice_expire_min + 30)
    busy = db.query(Payment.server_id).filter(
        Payment.server_id.isnot(None),
        or_(
            and_(Payment.status.in_(("created", "pending")),
                 Payment.expires_at > now - timedelta(minutes=30)),
            Payment.status.in_(("pending", "needs_review")),
        ),
    )
    rows = (
        db.query(Server)
        .filter(
            Server.status == ServerStatus.pending_approval,
            Server.approval_token.is_(None),
            Server.created_at < now - age,
            ~Server.id.in_(busy),
        )
        .all()
    )
    for server in rows:
        logger.info("Removing unpaid request %s (%s)", server.container_name, server.owner_email)
        log_action(db, "unpaid_request_removed", "server",
                   f"{server.container_name} ({server.owner_email})", actor="system")
        db.delete(server)
        db.commit()


def run() -> None:
    payments_service.sync_open_payments()
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        _expire_stale_payments(db, now)
        _delete_unpaid_servers(db, now)
        _expire_overdue(db, now)
        _send_reminders(db, now)
        from .gift_renewal import send_reminders
        send_reminders(db, now)
    finally:
        db.close()


if __name__ == "__main__":
    run()
