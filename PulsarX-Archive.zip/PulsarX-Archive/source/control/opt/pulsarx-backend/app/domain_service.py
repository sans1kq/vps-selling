import logging
import subprocess

logger = logging.getLogger("pulsarx.domain")

ADD_SCRIPT = "/opt/pulsarx-backend/scripts/add_domain.sh"
REMOVE_SCRIPT = "/opt/pulsarx-backend/scripts/remove_domain.sh"


class DomainError(RuntimeError):
    pass


def add_domain(domain: str, container_ip: str) -> str:
    """Configure nginx (+ TLS if possible) for a domain pointing at a container.

    Returns "active" (HTTPS working) or "http_only" (nginx ok, TLS failed —
    usually because DNS isn't pointed at us yet). Raises DomainError only
    if the nginx step itself failed, since that's the one unrecoverable case.
    """
    result = subprocess.run(
        ["sudo", ADD_SCRIPT, domain, container_ip],
        capture_output=True, text=True, timeout=120,
    )
    if result.returncode == 0:
        return "active"
    if result.returncode == 2:
        logger.warning("Domain %s configured HTTP-only: %s", domain, result.stdout)
        return "http_only"
    raise DomainError(result.stderr.strip() or result.stdout.strip() or "add_domain.sh failed")


def remove_domain(domain: str) -> None:
    result = subprocess.run(
        ["sudo", REMOVE_SCRIPT, domain],
        capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        raise DomainError(result.stderr.strip() or result.stdout.strip() or "remove_domain.sh failed")
