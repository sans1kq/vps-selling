"""Deterministic, non-overlapping UID/GID range allocation for customer
containers.

Incus's own automatic security.idmap.isolated allocator behaved unreliably
on this host (allocated ranges outside what /etc/subuid actually permits,
in a way that persisted across service restarts and manual fixes). Rather
than depend on that, we hand out ranges ourselves — atomically, from a
single-row counter table — and pass them to `incus launch` via raw.idmap.

Range layout: base 1,000,000 (matches "root:1000000:1000000000" in
/etc/subuid and /etc/subgid on the Incus host), 65,536 IDs per slot —
the standard LXC/Incus allocation size, enough for a full container's
worth of UIDs/GIDs including root and nobody.
"""

from sqlalchemy import text
from sqlalchemy.orm import Session

IDMAP_BASE = 1_000_000
IDMAP_SLOT_SIZE = 65536


def allocate_idmap_slot(db: Session) -> int:
    """Atomically claim the next free slot and return its host UID/GID base.

    Uses UPDATE ... RETURNING against a single-row counter table, which
    Postgres executes atomically under the row lock — safe for concurrent
    server creation requests.
    """
    result = db.execute(
        text(
            "UPDATE idmap_slot_counter SET next_slot = next_slot + 1 "
            "WHERE id = 1 RETURNING next_slot - 1"
        )
    )
    slot_number = result.scalar_one()
    db.commit()
    return IDMAP_BASE + slot_number * IDMAP_SLOT_SIZE


def raw_idmap_config(host_base: int) -> str:
    """Format the raw.idmap value incus launch expects for one slot.

    Incus's raw.idmap syntax is "<type> <container_range> <host_range>",
    where each range is either a single number or "start-end" (a dash,
    not a third number — see lxc/incus shared/idmap/set_load.go). Maps
    the full container UID/GID range (0-65535, covering root through
    nobody and all normal system accounts) to this slot's host range.
    """
    host_end = host_base + IDMAP_SLOT_SIZE - 1
    ct_end = IDMAP_SLOT_SIZE - 1
    return (
        f"uid 0-{ct_end} {host_base}-{host_end}\n"
        f"gid 0-{ct_end} {host_base}-{host_end}"
    )
