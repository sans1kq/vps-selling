from .flex_capacity import require_resources
from .flex_catalog import is_upgrade,server_spec
from .capacity_service import require_capacity
from .trial_service import is_trial
"""Crypto payments: pricing, slot reservation, invoices, settlement.

settle() is the only place where a payment turns into service time. It is
idempotent: it locks the payment row, re-checks the invoice with Plisio and
credits it at most once (credited_at).
"""
import logging
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from sqlalchemy import func, text
from sqlalchemy.orm import Session

from . import plisio_service
from .config import get_settings
from .database import SessionLocal
from .models import Payment, Server, ServerStatus
from .wallet_models import WalletOrder, ACTIVE_ORDERS
from .schemas import PLAN_LIMITS, PLANS

settings = get_settings()
logger = logging.getLogger("pulsarx.payments")

PERIOD_DAYS = {1: 30, 3: 90, 6: 180, 12: 365}
DISCOUNT_PCT = {1: 0, 3: 5, 6: 10, 12: 15}
OPEN = ("created", "pending")
SLOT_LOCK = 7001
UPGRADE_MIN_USD = Decimal("0.01")
HOLD = (ServerStatus.running, ServerStatus.provisioning, ServerStatus.pending, ServerStatus.suspended)


class SlotsFull(Exception):
    pass


def price_usd(plan: str, months: int) -> Decimal:
    base = Decimal(PLANS[plan]["price_cents"]) / 100 * months
    return (base * (100 - DISCOUNT_PCT[months]) / 100).quantize(Decimal("0.01"), ROUND_HALF_UP)


def slots_taken(db: Session, plan: str, now: datetime, exclude_server_id=None) -> int:
    held = db.query(Server).filter(Server.plan == plan, Server.status.in_(HOLD))
    reserved = db.query(Payment).filter(
        Payment.plan == plan,
        Payment.kind.in_(("new", "upgrade")),
        Payment.status.in_(OPEN),
        Payment.expires_at > now,
    )
    if exclude_server_id is not None:
        held = held.filter(Server.id != exclude_server_id)
        reserved = reserved.filter(
            Payment.server_id.is_(None) | (Payment.server_id != exclude_server_id)
        )
    upgrades = db.query(WalletOrder).filter(WalletOrder.plan == plan,
        WalletOrder.kind == "upgrade", WalletOrder.status.in_(ACTIVE_ORDERS))
    if exclude_server_id is not None:
        upgrades = upgrades.filter(WalletOrder.server_id != exclude_server_id)
    # One statement sees each reservation-to-instance transition atomically.
    counts = (held.with_entities(func.count(Server.id)).scalar_subquery(),
              reserved.with_entities(func.count(Payment.id)).scalar_subquery(),
              upgrades.with_entities(func.count(WalletOrder.id)).scalar_subquery())
    return db.query(counts[0] + counts[1] + counts[2]).scalar()


def start_payment(db: Session, server: Server, kind: str, plan: str, months: int,
                  amount: Decimal) -> Payment:
    """Reserve a slot (new/upgrade) and create a Plisio invoice. Raises SlotsFull."""
    if is_trial(server):
        raise ValueError("Payments are unavailable for a 24-hour free instance")
    if kind not in ("new", "renew", "upgrade") or plan not in PLANS or months not in PERIOD_DAYS:
        raise ValueError("bad payment parameters")
    if kind == "new" and server.status != ServerStatus.pending_approval:
        raise ValueError("server is not waiting for its first payment")
    now = datetime.now(timezone.utc)
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": SLOT_LOCK})
    from .wallet_service import ensure_idle
    db.refresh(server, with_for_update=True)
    ensure_idle(db, server.id)
    if kind in ("new", "renew") and plan != server.plan:
        raise ValueError("The instance plan changed; refresh checkout")
    if kind == "upgrade" and not is_upgrade(server.plan,plan):
        raise ValueError("Upgrade is not available")
    if kind == "new":
        require_resources(db,server_spec(server),server.container_name)
    elif kind == "upgrade":
        require_resources(db,PLANS[plan],server.container_name)
    reuse = (
        db.query(Payment)
        .filter(
            Payment.server_id == server.id, Payment.kind == kind, Payment.plan == plan,
            Payment.months == months, Payment.amount_usd == amount,
            Payment.status.in_(OPEN), Payment.expires_at > now + timedelta(minutes=10),
        )
        .order_by(Payment.id.desc())
        .first()
    )
    if reuse is not None and reuse.invoice_url:
        db.commit()
        return reuse
    if kind in ("new", "upgrade") and plan in PLAN_LIMITS:
        if slots_taken(db, plan, now, server.id if kind == "new" else None) >= PLAN_LIMITS[plan]:
            db.rollback()
            raise SlotsFull(plan)
    if kind == "new":
        db.query(Payment).filter(
            Payment.server_id == server.id, Payment.kind == "new", Payment.status.in_(OPEN)
        ).update({"status": "cancelled"}, synchronize_session=False)
    pay = Payment(
        server_id=server.id, owner_email=server.owner_email, kind=kind, plan=plan,
        months=months, amount_usd=amount,
        expires_at=now + timedelta(minutes=settings.invoice_expire_min),
    )
    db.add(pay)
    db.flush()
    try:
        inv = plisio_service.create_invoice(pay.id, plan, f"{amount:.2f}", server.owner_email)
    except Exception:
        db.rollback()
        raise
    pay.txn_id = str(inv["txn_id"])
    pay.invoice_url = inv["invoice_url"]
    db.commit()
    return pay


def _dec(value) -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError):
        return Decimal("0")


def _partially_paid(op: dict) -> bool:
    if op.get("pending_amount") is None:
        return False
    amount, pending = _dec(op.get("amount")), _dec(op.get("pending_amount"))
    return amount > 0 and 0 <= pending < amount


def _apply(db: Session, pay: Payment, now: datetime) -> list:
    """Turn a fully paid invoice into service time. Returns follow-up actions."""
    server = db.get(Server, pay.server_id) if pay.server_id else None
    if server is None:
        pay.status = "needs_review"
        logger.error("Payment %s is paid but its server no longer exists", pay.id)
        return []
    if is_trial(server):
        pay.status = "needs_review"
        logger.error("Paid invoice for a free instance needs review: %s", pay.id)
        return []
    if pay.kind in ('new','upgrade'):
        from .capacity_service import StorageCapacityError
        try:require_resources(db,PLANS[pay.plan] if pay.kind=='upgrade' else server_spec(server),server.container_name)
        except StorageCapacityError:
            pay.status='needs_review'
            logger.warning('Paid invoice awaits verified resource availability: %s',pay.id)
            return []
    pay.status = "credited"
    pay.credited_at = now
    if pay.kind == "upgrade":
        return ["resize"]
    days = timedelta(days=PERIOD_DAYS[pay.months])
    if server.status == ServerStatus.pending_approval:
        server.status = ServerStatus.pending
        server.paid_until = now + days
        return ["provision"]
    base = server.paid_until if server.paid_until and server.paid_until > now else now
    server.paid_until = base + days
    actions = []
    if server.status == ServerStatus.suspended:
        actions.append("resume")
    server.payment_failed_at = None
    server.last_dunning_email_sent_at = None
    return actions


def settle(db: Session, payment_id: int):
    """Re-check a payment with Plisio and apply it. Safe to call repeatedly.

    Returns (payment_status, follow_up_actions). Never trusts callback contents.
    """
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": SLOT_LOCK})
    pay = db.query(Payment).filter(Payment.id == payment_id).with_for_update().one_or_none()
    if pay is None or not pay.txn_id:
        db.rollback()
        return "unknown", []
    if pay.status == "credited":
        db.rollback()
        return "credited", []
    op = plisio_service.get_operation(pay.txn_id)
    st = str(op.get("status") or "").lower()
    pay.plisio_status = st
    order = op.get("order_number")
    if order not in (None, "") and str(order) != str(pay.id):
        logger.error("Payment %s: Plisio order_number %s does not match", pay.id, order)
        pay.status = "needs_review"
        db.commit()
        return pay.status, []
    actions: list = []
    overpaid = st == "mismatch" and op.get("pending_amount") is not None \
        and _dec(op.get("pending_amount")) <= 0
    if st == "completed" or overpaid:
        actions = _apply(db, pay, datetime.now(timezone.utc))
    elif st in ("pending", "pending internal"):
        pay.status = "pending"
    elif st == "expired":
        pay.status = "needs_review" if _partially_paid(op) else "expired"
    elif st == "cancelled":
        pay.status = "cancelled"
    elif st in ("mismatch", "error"):
        pay.status = "needs_review"
    db.commit()
    return pay.status, actions


def run_actions(server_id, actions: list, target_plan=None) -> None:
    """Slow follow-ups after a credited payment (run in a background task)."""
    from . import email_service, incus_service
    from .routers.servers import _provision

    db = SessionLocal()
    try:
        server = db.get(Server, server_id)
        if server is None:
            return
        if is_trial(server):
            logger.error("Refusing payment actions for free instance %s", server.id)
            return
        for action in actions:
            if action == "provision":
                _provision(server.id)
            elif action == "resume":
                from .server_access import ensure_not_held
                db.refresh(server,with_for_update=True)
                try:ensure_not_held(server)
                except Exception:
                    db.rollback();logger.warning("Paid resume awaits operator release: %s",server.id);continue
                try:
                    incus_service.start_container(server.container_name)
                except Exception:
                    logger.exception("Failed to resume %s after payment", server.container_name)
                    db.rollback();continue
                server.status = ServerStatus.running
                db.commit()
                try:
                    email_service.send_payment_resolved_email(server.owner_email, server.container_name)
                except Exception:
                    logger.exception("Failed to send payment-resolved email for %s", server.container_name)
            elif action == "resize" and target_plan in PLANS:
                spec, old_plan = PLANS[target_plan], server.plan
                try:
                    incus_service.resize_container(
                        server.container_name, spec["cpu_cores"], spec["ram_mb"], spec["disk_gb"]
                    )
                except Exception:
                    logger.exception("PAID upgrade but resize failed for %s", server.container_name)
                    continue
                server.plan, server.cpu_cores = target_plan, spec["cpu_cores"]
                server.ram_mb, server.disk_gb = spec["ram_mb"], spec["disk_gb"]
                db.commit()
                try:
                    email_service.send_upgrade_confirmation_email(
                        server.owner_email, server.container_name, old_plan, target_plan
                    )
                except Exception:
                    logger.exception("Failed to send upgrade email for %s", server.container_name)
    finally:
        db.close()


def sync_open_payments() -> None:
    """Safety net for lost webhooks: re-check recent unfinished invoices."""
    db = SessionLocal()
    try:
        since = datetime.now(timezone.utc) - timedelta(days=2)
        rows = db.query(Payment.id).filter(Payment.status.in_(OPEN), Payment.created_at > since).all()
        ids = [r[0] for r in rows]
    finally:
        db.close()
    for pid in ids:
        db2 = SessionLocal()
        try:
            _, actions = settle(db2, pid)
            if actions:
                pay = db2.get(Payment, pid)
                run_actions(pay.server_id, actions, pay.plan)
        except Exception:
            logger.exception("Payment sync failed for payment %s", pid)
        finally:
            db2.close()


def upgrade_price_usd(server, target_plan: str, now: datetime) -> Decimal:
    """Prorated top-up: monthly price difference * days left / 30 (floor UPGRADE_MIN_USD)."""
    if not is_upgrade(server.plan,target_plan):
        raise ValueError("unknown plan")
    diff = Decimal(PLANS[target_plan]["price_cents"] - PLANS[server.plan]["price_cents"]) / 100
    if diff <= 0 or not server.paid_until or server.paid_until <= now:
        raise ValueError("upgrade not possible")
    days_left = max(1, -(-int((server.paid_until - now).total_seconds()) // 86400))
    return max(UPGRADE_MIN_USD, (diff * days_left / 30).quantize(Decimal("0.01"), ROUND_HALF_UP))

# PulsarX free instance lifetime v1

# PulsarX storage preflight v1
