"""Pure HTML presentation for the existing PulsarX plaintext notifications."""
from datetime import datetime, timezone
from html import escape
import re
from urllib.parse import urlsplit

LOGO_PATH = 'px-email-brand-3b2c45f5bf.png'
FONT = 'Arial,Helvetica,sans-serif'
MONO = 'Consolas,Menlo,monospace'
URL = re.compile(r'https?://[^\s<>"\x00-\x1f]+')
FIELD = re.compile(r'^([A-Za-z][A-Za-z ()-]{0,40}):[ \t]*(.*)$')
FIELD_LABELS = {'Host', 'Port', 'Username', 'Plan', 'Image', 'Period', 'Current plan', 'Target plan'}
CODE = re.compile(r'^(Your (?:verification|login|reset|confirmation|activation) code is:)[ \t]*(.+)$')


def safe_url(value):
    try:
        parts = urlsplit(value)
        if parts.scheme not in ('http', 'https') or not parts.hostname or parts.username or parts.password:
            return None
        if any(c.isspace() or ord(c) < 32 for c in value):
            return None
        return value
    except (ValueError, TypeError):
        return None


def urls(text):
    for match in URL.finditer(text):
        start = text.rfind('\n', 0, match.start())+1
        end = text.find('\n', match.end())
        if end == -1: end = len(text)
        standalone = not text[start:match.start()].strip() and not text[match.end():end].strip()
        value = match.group() if standalone else match.group().rstrip('.,;!)]}')
        if safe_url(value):
            yield match.start(), match.start() + len(value), value


def linked(text):
    pieces = []; position = 0
    for start, end, value in urls(text):
        pieces.append(escape(text[position:start]))
        pieces.append('<a href="'+escape(value, quote=True)+'" style="color:#c09ad6;text-decoration:underline;word-break:break-all;">'+escape(value)+'</a>')
        position = end
    pieces.append(escape(text[position:]))
    return ''.join(pieces).replace('\n', '<br>')


def presentation(subject, text, base):
    """Only headings/actions are specialized; the original message stays in order."""
    headings = {
        'Your PulsarX verification code:': 'Confirm your email',
        'Your PulsarX login code:': 'Confirm your sign-in',
        'Your PulsarX password reset code:': 'Reset your account password',
        'Your PulsarX activation code:': 'Your activation code',
        'Reset SSH password code for ': 'Confirm SSH password reset',
    }
    title = next((value for prefix, value in headings.items() if subject.startswith(prefix)), subject)
    ready = re.fullmatch(r'Your PulsarX instance \((.+)\) is ready', subject)
    if ready:
        title = 'Your server is ready'
    action = (base+'/dashboard/', 'Open dashboard')
    if any(subject.startswith(prefix) for prefix in headings):
        action = (base+'/', 'Open PulsarX')
    elif subject.startswith(('Approve ', 'New PulsarX instance requested', 'Confirm deletion of ')):
        action = (base+'/admin/', 'Open administration')
    elif subject == 'Finish setting up your PulsarX instance':
        links = list(urls(text))
        if links:
            action = (links[0][2], 'Continue payment')
    return title, ready.group(1) if ready else None, action


def fields_html(rows):
    cells = []
    for index, (label, value) in enumerate(rows):
        cells.append('<tr><td style="padding:0 0 '+('0' if index == len(rows)-1 else '16')+'px;">'
            '<div style="font-family:'+FONT+';font-size:11px;line-height:17px;color:#a99aae;">'+escape(label)+'</div>'
            '<div style="font-family:'+FONT+';font-size:14px;line-height:22px;font-weight:600;color:#f3edf7;word-break:break-word;">'+escape(value)+'</div>'
            '</td></tr>')
    return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#070509" style="width:100%;background-color:#070509;border:1px solid #25152e;border-radius:12px;"><tr><td style="padding:20px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'+''.join(cells)+'</table></td></tr></table>'


def ssh_command(rows):
    values = dict(rows)
    host, port, user = (values.get(k, '') for k in ('Host', 'Port', 'Username'))
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.:-]{0,252}', host):
        return None
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_-]{0,31}', user):
        return None
    if not port.isdecimal() or not 1 <= int(port) <= 65535:
        return None
    return 'ssh '+user+'@'+host+' -p '+port


def message_html(text, instance):
    sections = []
    for paragraph in text.replace('\r\n', '\n').split('\n\n'):
        paragraph = paragraph.strip()
        if not paragraph or paragraph == '- PulsarX Cloud':
            continue
        code = CODE.fullmatch(paragraph)
        lines = paragraph.splitlines()
        fields = [FIELD.fullmatch(line) for line in lines]
        if code:
            value = code.group(2)
            size = '36' if len(value) <= 8 else '22'
            content = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#160022" style="width:100%;background-color:#160022;border:1px solid #35203e;border-radius:12px;"><tr><td style="padding:22px 20px;text-align:center;">'
            content += '<div style="font-family:'+FONT+';font-size:11px;line-height:18px;color:#bd9fcb;padding-bottom:12px;">'+escape(code.group(1).rstrip(':'))+'</div>'
            content += '<div style="font-family:'+MONO+';font-size:'+size+'px;line-height:1.4;letter-spacing:3px;font-weight:700;color:#f5edf9;word-break:break-all;">'+escape(value)+'</div></td></tr></table>'
        elif fields and all(fields) and all(match.group(1).strip() in FIELD_LABELS for match in fields):
            rows = [(match.group(1).strip(), match.group(2)) for match in fields]
            if instance and any(label == 'Host' for label, _ in rows):
                rows.insert(0, ('Server', instance))
            content = fields_html(rows)
            command = ssh_command(rows) if instance else None
            if command:
                content += '<div style="font-family:'+FONT+';font-size:11px;line-height:18px;color:#aa96b5;margin-top:15px;">Connect over SSH</div><div style="font-family:'+MONO+';font-size:12px;line-height:21px;color:#d5b8e7;word-break:break-all;margin-top:4px;">'+escape(command)+'</div>'
        else:
            content = '<div style="font-family:'+FONT+';font-size:14px;line-height:24px;color:#c2b8c8;word-break:break-word;">'+linked(paragraph)+'</div>'
        sections.append('<tr><td style="padding:0 0 20px;">'+content+'</td></tr>')
    return ''.join(sections)


def render_email(subject, text, frontend_base_url, *, year=None):
    """Render without sending, reading settings, touching storage or making requests."""
    base = str(frontend_base_url).strip().rstrip('/')
    if not safe_url(base) or urlsplit(base).query or urlsplit(base).fragment:
        base = 'https://pulsarx.example.invalid'
    subject, text = str(subject), str(text)
    title, instance, (action_url, action_label) = presentation(subject, text, base)
    preview = next((p.strip().split('\n')[0] for p in text.split('\n\n') if p.strip()), subject)
    preview = preview[:180]
    year = datetime.now(timezone.utc).year if year is None else year
    e = lambda value: escape(str(value), quote=True)
    return '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark"><meta name="supported-color-schemes" content="dark"><title>'''+e(title)+'''</title>
<style>body,table,td,a{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}table,td{mso-table-lspace:0pt;mso-table-rspace:0pt}table{border-spacing:0}img{border:0;outline:none;text-decoration:none}@media screen and (max-width:600px){.email-outer{padding:28px 14px!important}.email-card{padding:25px 22px!important}.email-title{font-size:23px!important;line-height:30px!important}}</style></head>
<body style="margin:0;padding:0;width:100%;background-color:#000000;color:#f3edf7;">
<div style="display:none;font-size:1px;line-height:1px;color:#000000;max-height:0;max-width:0;opacity:0;overflow:hidden;mso-hide:all;">'''+e(preview)+'''</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#000000" style="width:100%;background-color:#000000;"><tr><td class="email-outer" align="center" style="padding:44px 20px 48px;">
<!--[if mso]><table role="presentation" width="560" cellpadding="0" cellspacing="0" border="0"><tr><td><![endif]-->
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:560px;">
<tr><td align="center" style="padding:0 0 27px;"><table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td width="32" style="width:32px;padding-right:10px;"><img src="'''+e(base+'/'+LOGO_PATH)+'''" width="32" height="32" alt="" style="display:block;width:32px;height:32px;"></td><td style="font-family:'''+FONT+''';font-size:23px;line-height:32px;font-weight:700;letter-spacing:-.6px;color:#f5eff9;">PulsarX</td><td style="font-family:'''+FONT+''';font-size:10px;line-height:18px;color:#a28eae;padding:6px 0 0 5px;">Cloud</td></tr></table></td></tr>
<tr><td class="email-card" bgcolor="#0e0912" style="padding:31px 29px;background-color:#0e0912;border:1px solid #2c1a34;border-radius:17px;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%;">
<tr><td class="email-title" style="font-family:'''+FONT+''';font-size:25px;line-height:33px;font-weight:700;letter-spacing:-.5px;color:#f7f1fb;padding:0 0 18px;word-break:break-word;">'''+e(title)+'''</td></tr>
'''+message_html(text, instance)+'''
<tr><td style="padding-top:4px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" bgcolor="#4c0086" style="background-color:#4c0086;border:1px solid #69327e;border-radius:10px;mso-padding-alt:15px 20px;"><a href="'''+e(action_url)+'''" style="display:block;padding:15px 20px;font-family:'''+FONT+''';font-size:13px;line-height:20px;font-weight:700;color:#ffffff;text-decoration:none;text-align:center;">'''+e(action_label)+'''</a></td></tr></table></td></tr>
<tr><td style="padding:20px 0 0;font-family:'''+FONT+''';font-size:11px;line-height:18px;color:#a38eae;">If the button does not open, use this link:<br><a href="'''+e(action_url)+'''" style="color:#bf98d4;text-decoration:none;word-break:break-all;">'''+e(action_url)+'''</a></td></tr>
</table></td></tr>
<tr><td align="center" style="padding:24px 12px 0;font-family:'''+FONT+''';font-size:11px;line-height:19px;color:#a38eae;">Need help? <a href="'''+e(base+'/support/')+'''" style="color:#bda1cd;text-decoration:none;">Website support</a><span style="color:#65536f;"> &nbsp;·&nbsp; </span><a href="https://example.invalid/community" style="color:#bda1cd;text-decoration:none;">Telegram</a><br><span style="color:#817187;">© '''+e(year)+''' PulsarX Cloud</span></td></tr>
</table><!--[if mso]></td></tr></table><![endif]-->
</td></tr></table></body></html>'''
