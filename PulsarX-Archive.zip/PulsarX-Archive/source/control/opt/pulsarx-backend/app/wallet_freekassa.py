"""FreeKassa API checkout and authenticated reconciliation. https://docs.freekassa.net/

The browser redirect and callback alone never authorize a wallet credit.
"""
import fcntl
import hashlib
import hmac
import logging
import os
import re
import stat
import threading
import time
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from urllib.parse import urlsplit

import requests

from .anypay_service import ProviderUnavailable, cents
from .config import get_settings

settings = get_settings()
ID = re.compile(r"[1-9][0-9]{0,23}")
ORDER = re.compile(r"[1-9][0-9]{0,14}")
logger = logging.getLogger("pulsarx.wallet.freekassa")
CHECKOUT_HOSTS = {"pay.freekassa.net", "pay.fk.money", "fmt.me", "payment.duckgo.io"}
METHODS = {44: "СБП / SBP", 36: "Карты РФ / Russian cards", 43: "SberPay",
           11: "Банковские карты / Bank cards", 32: "Visa / Mastercard",
           14: "USDT · ERC20", 15: "USDT · TRC20", 45: "TON", 24: "Bitcoin",
           25: "Litecoin", 26: "Ethereum", 17: "BNB", 39: "TRON"}
_methods_cache = {}
_methods_lock = threading.RLock()


class AmountOutsideLimits(Exception):
    def __init__(self, method_id, limits):
        super().__init__("Amount is outside the payment method limits")
        self.method_id = method_id
        self.limits = deepcopy(limits)


def payment_limits(limits, currency):
    if not isinstance(limits, dict) or not isinstance(currency, str) or not re.fullmatch(r"[A-Z0-9]{2,12}", currency):
        return None
    values = []
    for key in ("min", "max"):
        value = limits.get(key)
        if type(value) not in (str, int, float) or not re.fullmatch(r"[0-9]{1,13}(?:\.[0-9]{1,12})?(?:[eE][+-]?[0-9]{1,2})?", str(value)):
            return None
        try:
            number = Decimal(str(value))
        except InvalidOperation:
            return None
        if not number.is_finite() or number > Decimal("1000000000000") or number.normalize().as_tuple().exponent < -12:
            return None
        values.append(number)
    lower, upper = values
    if upper <= 0 or lower > upper:
        return None
    result = {"min": format(lower.normalize(), "f"), "max": format(upper.normalize(), "f"), "currency": currency}
    # Only USD limits can be compared directly with the USD wallet input.
    # Native coin/RUB limits are never treated as dollar amounts.
    if currency == "USD":
        result["min_cents"] = int((lower * 100).to_integral_value(rounding=ROUND_CEILING))
        result["max_cents"] = int((upper * 100).to_integral_value(rounding=ROUND_FLOOR))
    return result


def validate_amount(method, amount_cents):
    limits = method.get("limits")
    if limits and limits.get("currency") == "USD" and not limits["min_cents"] <= amount_cents <= limits["max_cents"]:
        raise AmountOutsideLimits(method["id"], limits)


def amount_error_limits(body):
    if not isinstance(body, dict) or body.get("type") != "error":
        return None
    if any(str(k).replace("_", "").lower() in ("orderid", "location") for k in body):
        return None
    message = body.get("message")
    if not isinstance(message, str) or len(message) > 300:
        return None
    match = re.fullmatch(r"\s*Минимальная сумма для оплаты ([0-9]+(?:[.,][0-9]+)?)\s*([A-Z0-9]{2,12}),\s*максимальная ([0-9]+(?:[.,][0-9]+)?)\s*\2\s*[.!]?\s*", message)
    return payment_limits({"min": match[1].replace(",", "."), "max": match[3].replace(",", ".")}, match[2]) if match else None


def enabled():
    return bool(settings.freekassa_enabled and all((settings.freekassa_shop_id,
                settings.freekassa_secret_2, settings.freekassa_api_key)))


def public_checkout_host(host):
    # This checks redirect syntax only. The application never fetches checkout
    # links. Broader hosts are accepted solely with authenticated API provenance.
    if not isinstance(host, str) or len(host) > 253 or "." not in host or host.endswith("."):
        return False
    labels = host.split(".")
    if not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels):
        return False
    if not re.fullmatch(r"[a-z]{2,63}", labels[-1]):
        return False
    if labels[-1] in {"localhost", "local", "localdomain", "internal", "lan", "home", "test", "invalid", "example", "onion", "arpa"}:
        return False
    return not any(host.startswith(known + ".") for known in CHECKOUT_HOSTS)


def api_checkout_provenance(row):
    # These fields are written by checkout_topup around /orders/create, never
    # from user input. A stored URL stays bound to its FK transaction and owner.
    return (getattr(row, "provider", None) == "freekassa"
            and type(getattr(row, "provider_method", None)) is int
            and row.provider_method in METHODS
            and getattr(row, "provider_create_started_at", None) is not None
            and re.fullmatch(r"fk:[1-9][0-9]{0,23}", getattr(row, "transaction_id", None) or "") is not None)


def saved_checkout_ok(row):
    ident = (row.transaction_id or "").removeprefix("fk:")
    return checkout_ok(row.checkout_url, ident, api_response=api_checkout_provenance(row))


def checkout_ok(value, order_id=None, *, api_response=False):
    if (not isinstance(value, str) or not value or len(value) > 4096
            or any(ord(c) <= 32 or ord(c) == 127 for c in value) or "\\" in value):
        return False
    try:
        url = urlsplit(value)
        # API creation uses a verified TLS response. Saved API links additionally
        # require the persisted intent/method/FK transaction above. Legacy links
        # retain the exact-host allowlist; arbitrary browser URLs cannot opt in.
        known = url.hostname in CHECKOUT_HOSTS
        api_host = api_response is True and ID.fullmatch(str(order_id)) and public_checkout_host(url.hostname)
        if (url.scheme != "https" or not (known or api_host)
                or url.username is not None or url.password is not None or url.port not in (None, 443)
                or url.fragment or (url.path and not url.path.startswith("/"))):
            return False
        match = re.fullmatch(r"/form/([1-9][0-9]{0,23})/[^/]+/?", url.path)
        return not (match and order_id is not None and match[1] != str(order_id))
    except ValueError:
        return False


def available_methods():
    # Avoid repeating every status probe on each wallet refresh. Creation also
    # checks its selected method afresh, before recording any creation intent.
    key = (settings.freekassa_shop_id, settings.freekassa_api_key)
    with _methods_lock:
        cached = _methods_cache.get(key)
        if cached and cached[0] > time.monotonic():
            return deepcopy(cached[1])
        result = _available_methods()
        _methods_cache.clear()
        _methods_cache[key] = (time.monotonic() + 60, deepcopy(result))
        return result


def method_available(ident):
    if type(ident) is not int or ident not in METHODS:
        raise ValueError("Unsupported payment method")
    _request({}, endpoint=f"currencies/{ident}/status")
    return True


def _available_methods():
    body = _request({}, endpoint="currencies")
    rows = body.get("currencies")
    if not isinstance(rows, list) or len(rows) > 1000:
        raise ProviderUnavailable("Invalid payment methods", reason="invalid_result")
    enabled_rows = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ProviderUnavailable("Invalid payment method", reason="invalid_result")
        ident = str(row.get("id"))
        if ident.isdecimal() and str(row.get("is_enabled")) == "1":
            # A method requiring additional payer data cannot be offered by this
            # email/IP-only checkout until those inputs have been implemented.
            fields = row.get("fields")
            common = {"email", "ip", "amount", "currency"}
            names = (set(fields) if isinstance(fields, dict) else
                     {f if isinstance(f, str) else f.get("name", "unsupported") if isinstance(f, dict) else "unsupported"
                      for f in fields} if isinstance(fields, list) else set() if not fields else {"unsupported"})
            if names <= common:
                enabled_rows[int(ident)] = row
    result = []
    for ident, name in METHODS.items():
        if ident not in enabled_rows:
            continue
        try:
            method_available(ident)
        except ProviderUnavailable as exc:
            if exc.reason in ("api_error", "http_error"):
                continue
            raise
        if ident in (11, 32):
            # Use this shop's actual card name/currency, not a guessed EUR label.
            row = enabled_rows[ident]
            provided = row.get("name")
            if isinstance(provided, str) and 0 < len(provided.strip()) <= 120 and not any(ord(c) < 32 for c in provided):
                name = provided.strip()
            currency = row.get("currency")
            if isinstance(currency, str) and re.fullmatch(r"[A-Z0-9]{2,12}", currency) and currency not in name:
                name += " · " + currency
        item = {"id": ident, "name": name}
        limits = payment_limits(enabled_rows[ident].get("limits"), enabled_rows[ident].get("currency"))
        if limits:
            item["limits"] = limits
        result.append(item)
    return result


def safe_provider_error(body, request_data):
    if not isinstance(body, dict):
        return None
    message = next((body[k] for k in ("message", "error", "description")
                    if isinstance(body.get(k), str) and body[k].strip()), None)
    if message is None:
        return None
    message = message[:4096]
    secrets = [settings.freekassa_api_key, settings.freekassa_secret_1,
               settings.freekassa_secret_2]
    secrets += [request_data.get(k) for k in ("signature", "email", "ip", "tel")]
    for secret in secrets:
        if isinstance(secret, str) and secret:
            message = re.sub(re.escape(secret), "[redacted]", message, flags=re.I)
    message = re.sub(r"https?://\S+", "[url]", message)
    message = re.sub(r"\b[^\s@]+@[^\s@]+\b", "[email]", message)
    message = re.sub(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", "[ip]", message)
    message = re.sub(r"\b[0-9]{12,}\b", "[number]", message)
    message = re.sub(r"\b[A-Za-z0-9_+=/-]{20,}\b", "[redacted]", message)
    message = "".join(c if c.isprintable() else " " for c in message)
    return " ".join(message.split())[:240]


def create(row, email, payer_ip):
    import ipaddress
    try:
        address = ipaddress.ip_address(payer_ip)
        if not address.is_global:
            raise ValueError()
    except (ValueError, TypeError):
        raise ProviderUnavailable("A public payer or VPS IP is required", reason="configuration") from None
    if type(row.provider_method) is not int or row.provider_method not in METHODS:
        raise ProviderUnavailable("Select a supported payment method", reason="configuration")
    # USD is the authoritative wallet/order currency. The processor must retain
    # that exact currency and amount in /orders; otherwise reconciliation refuses
    # to credit. RUB conversion and payer fees are displayed by the processor.
    body = _request({"paymentId": str(row.id), "i": row.provider_method,
                     "email": email, "ip": str(address),
                     "amount": f"{row.amount_cents // 100}.{row.amount_cents % 100:02d}",
                     "currency": "USD"}, endpoint="orders/create")
    ident, location = created_fields(body)
    if not ID.fullmatch(ident) or not checkout_ok(location, ident, api_response=True):
        meta = checkout_metadata(body, ident, location)
        logger.warning("KASSA create response rejected: %s", meta)
        error = ProviderUnavailable("Invalid API checkout response", reason="invalid_result")
        # Keep an authenticated provider order ID / response link for diagnosis
        # or later validator repair. Neither is exposed until validation passes.
        error.fk_order_id = ident if ID.fullmatch(ident) else None
        error.fk_location = location if isinstance(location, str) and len(location) <= 4096 else None
        raise error
    return "fk:" + ident, location


def created_fields(body):
    def field(names):
        values = [v for k, v in body.items() if isinstance(k, str)
                  and k.replace("_", "").lower() in names and v is not None]
        return values[0] if values and all(v == values[0] for v in values) else None
    ident = field({"orderid"})
    return str(ident) if ident is not None else "", field({"location"})


def checkout_metadata(body, ident, location):
    try:
        url = urlsplit(location) if isinstance(location, str) else None
        host = url.hostname if url else None
        host = host if host in CHECKOUT_HOSTS else "other" if host else None
    except ValueError:
        host = "invalid"
    return {"order_id_valid": bool(ID.fullmatch(ident)), "location_present": isinstance(location, str),
            "location_host": host,
            "known_fields": [k for k in ("orderId", "order_id", "location", "Location", "orderHash", "data") if k in body]}


def validate_notification(data):
    required = ("MERCHANT_ID", "AMOUNT", "MERCHANT_ORDER_ID", "intid", "SIGN")
    if any(not isinstance(data.get(k), str) or len(data[k]) > 256 for k in required):
        raise ValueError("Invalid notification")
    if (data["MERCHANT_ID"] != settings.freekassa_shop_id
            or not ORDER.fullmatch(data["MERCHANT_ORDER_ID"]) or not ID.fullmatch(data["intid"])):
        raise ValueError("Invalid payment identifiers")
    expected = hashlib.md5(":".join((data["MERCHANT_ID"], data["AMOUNT"],
        settings.freekassa_secret_2, data["MERCHANT_ORDER_ID"])).encode()).hexdigest()
    if not re.fullmatch(r"[a-fA-F0-9]{32}", data["SIGN"]) or not hmac.compare_digest(expected, data["SIGN"].lower()):
        raise ValueError("Invalid signature")
    return int(data["MERCHANT_ORDER_ID"]), cents(data["AMOUNT"])


def _request(parameters, endpoint="orders"):
    if not enabled():
        raise ProviderUnavailable("FreeKassa is not configured", reason="configuration")
    # Persist and serialize the nonce across API processes and the timer. Never
    # replace this inode or reset its value on deployment/rollback.
    try:
        fd = os.open(settings.freekassa_nonce_file, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "r+", encoding="ascii") as stream:
            meta = os.fstat(stream.fileno())
            if not stat.S_ISREG(meta.st_mode) or meta.st_uid != os.geteuid() or meta.st_mode & 0o077:
                raise OSError("Unsafe nonce file")
            fcntl.flock(stream, fcntl.LOCK_EX)
            raw = stream.read(40).strip()
            if raw and not re.fullmatch(r"[0-9]{1,20}", raw):
                raise OSError("Invalid nonce state")
            nonce = max(int(time.time()), int(raw or "0") + 1)
            stream.seek(0); stream.write(str(nonce)); stream.truncate(); stream.flush(); os.fsync(stream.fileno())
            data = {"shopId": int(settings.freekassa_shop_id), "nonce": nonce, **parameters}
            data["signature"] = hmac.new(settings.freekassa_api_key.encode(),
                "|".join(str(data[k]) for k in sorted(data)).encode(), hashlib.sha256).hexdigest()
            return _send(data, endpoint=endpoint)
    except (OSError, ValueError):
        raise ProviderUnavailable("FreeKassa nonce storage is unavailable", reason="configuration") from None


def _send(data, endpoint="orders"):
    status_endpoint = endpoint in {f"currencies/{ident}/status" for ident in METHODS}
    if endpoint not in ("orders", "orders/create", "currencies") and not status_endpoint:
        raise ValueError("Unsupported API operation")
    try:
        response = requests.post("https://api.fk.life/v1/" + endpoint, json=data,
            timeout=(3, 5) if status_endpoint else (5, 20), allow_redirects=False, headers={"Accept": "application/json"})
    except requests.exceptions.Timeout:
        raise ProviderUnavailable("FreeKassa lookup timed out", reason="timeout") from None
    except requests.exceptions.SSLError:
        raise ProviderUnavailable("FreeKassa TLS verification failed", reason="tls") from None
    except requests.RequestException:
        raise ProviderUnavailable("FreeKassa lookup is unavailable", reason="network") from None
    body = None
    def error(reason):
        exc = ProviderUnavailable("Could not verify the payment with FreeKassa", reason=reason,
                                  http_status=response.status_code)
        # Private response bodies never leave this client. Only a bounded,
        # redacted top-level error can be used by the fixed checkout log below.
        exc.fk_error = safe_provider_error(body, data)
        if endpoint == "orders/create" and response.status_code == 400:
            exc.fk_amount_limits = amount_error_limits(body)
        return exc
    if len(response.content) > 2_000_000:
        raise error("response_too_large")
    try:
        body = response.json()
    except (ValueError, TypeError):
        raise error("invalid_json") from None
    statuses = (200, 201) if endpoint == "orders/create" else (200,)
    if response.status_code not in statuses or not isinstance(body, dict) or body.get("type") != "success":
        # Classify known errors without putting any provider response/key in logs.
        message = " ".join(str(body.get(k, ""))[:512] for k in ("message", "error", "description")) if isinstance(body, dict) else ""
        if re.search(r"api[ _-]*key.*(?:not exist|invalid|incorrect|not found)", message, re.I):
            raise error("api_key_invalid")
        if "merchant not activated" in message.lower():
            raise error("merchant_inactive")
        raise error("http_error" if response.status_code != 200 else "api_error")
    if endpoint == "orders/create" and not any(str(k).lower() == "location" for k in body):
        header_location = response.headers.get("Location")
        if isinstance(header_location, str):
            body = {**body, "location": header_location}
    if endpoint != "orders":
        return body
    records = body.get("orders")
    # Accept documented arrays, keyed objects, or an explicitly empty null.
    if records is None and body.get("pages") in (0, "0"):
        records = []
    if isinstance(records, dict):
        records = list(records.values())
    if not isinstance(records, list) or len(records) > 1000 or any(not isinstance(r, dict) for r in records):
        raise error("invalid_records")
    return records


def verify_access():
    records = _request({"page": 1})
    return {"record_count": len(records)}


def lookup(pay_id):
    records = _request({"paymentId": str(pay_id)})
    if not records:
        return None
    exact = [r for r in records if str(r.get("merchant_order_id")) == str(pay_id)]
    if len(exact) != 1:
        raise ProviderUnavailable("FreeKassa returned an ambiguous payment", reason="transaction_mismatch")
    result = exact[0]
    if (not ID.fullmatch(str(result.get("fk_order_id", "")))
            or type(result.get("status")) not in (str, int)
            or str(result["status"]) not in ("0", "1", "6", "8", "9")):
        raise ProviderUnavailable("Invalid FreeKassa payment", reason="invalid_result")
    return result
