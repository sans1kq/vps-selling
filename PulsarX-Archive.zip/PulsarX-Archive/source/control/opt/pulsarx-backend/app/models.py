import enum
import uuid

from sqlalchemy import Boolean, Column, String, Integer, Numeric, Enum, DateTime, ForeignKey, func
from sqlalchemy.dialects.postgresql import UUID

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)

    is_verified = Column(Boolean, default=False, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    verification_code = Column(String, nullable=True)
    verification_code_expires_at = Column(DateTime(timezone=True), nullable=True)

    reset_code = Column(String, nullable=True)
    reset_code_expires_at = Column(DateTime(timezone=True), nullable=True)

    login_code = Column(String, nullable=True)
    login_code_expires_at = Column(DateTime(timezone=True), nullable=True)

    registration_ip = Column(String, nullable=True)
    accepted_tos_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class UserSession(Base):
    __tablename__ = "user_sessions"

    token = Column(String, primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=False)


class AdminSession(Base):
    __tablename__ = "admin_sessions"

    token = Column(String, primary_key=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=False)


class AdminActionLog(Base):
    __tablename__ = "admin_action_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    action = Column(String, nullable=False)
    target_type = Column(String, nullable=False)
    target_label = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    actor = Column(String, nullable=False, default="admin", server_default="admin")


class ServerStatus(str, enum.Enum):
    pending_approval = "pending_approval"
    pending = "pending"
    provisioning = "provisioning"
    running = "running"
    suspended = "suspended"
    failed = "failed"
    deleted = "deleted"


class DomainStatus(str, enum.Enum):
    pending = "pending"
    active = "active"
    http_only = "http_only"
    failed = "failed"


class Server(Base):
    __tablename__ = "servers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    container_name = Column(String, unique=True, nullable=False)

    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    owner_email = Column(String, nullable=False, index=True)

    plan = Column(String, nullable=False)
    image = Column(String, nullable=False, default="debian12")
    ram_mb = Column(Integer, nullable=False)
    cpu_cores = Column(Integer, nullable=False)
    disk_gb = Column(Integer, nullable=False)

    ssh_username = Column(String, nullable=True)
    ip_address = Column(String, nullable=True)
    ssh_port = Column(Integer, nullable=True)
    web_port = Column(Integer, nullable=True)
    extra_ports = Column(String, nullable=True)  # comma-separated, e.g. "41023,44892,47105,42230,49871"

    custom_domain = Column(String, unique=True, nullable=True)
    domain_status = Column(Enum(DomainStatus), nullable=True)

    status = Column(Enum(ServerStatus), default=ServerStatus.pending_approval, nullable=False)
    error_message = Column(String, nullable=True)
    password_set = Column(Boolean, default=False, nullable=False)

    approval_token = Column(String, nullable=True)
    approval_token_expires_at = Column(DateTime(timezone=True), nullable=True)

    upgrade_target_plan = Column(String, nullable=True)
    upgrade_token = Column(String, nullable=True)
    upgrade_token_expires_at = Column(DateTime(timezone=True), nullable=True)

    ls_subscription_id = Column(String, nullable=True)
    subscription_cancelled_at = Column(DateTime(timezone=True), nullable=True)
    subscription_period_ends_at = Column(DateTime(timezone=True), nullable=True)
    payment_failed_at = Column(DateTime(timezone=True), nullable=True)
    last_dunning_email_sent_at = Column(DateTime(timezone=True), nullable=True)
    sub_action_pending = Column(String, nullable=True)
    sub_action_token = Column(String, nullable=True)
    sub_action_token_expires_at = Column(DateTime(timezone=True), nullable=True)
    renewal_reminder_for = Column(DateTime(timezone=True), nullable=True)
    paid_until = Column(DateTime(timezone=True), nullable=True)
    trial_expires_at = Column(DateTime(timezone=True), nullable=True, index=True)
    admin_suspended_at = Column(DateTime(timezone=True), nullable=True)

    reset_ssh_code = Column(String, nullable=True)
    reset_ssh_code_expires_at = Column(DateTime(timezone=True), nullable=True)

    delete_token = Column(String, nullable=True)
    delete_token_expires_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    @property
    def upgrade_pending(self) -> bool:
        return bool(self.upgrade_target_plan)

    @property
    def has_subscription(self) -> bool:
        return bool(self.ls_subscription_id)

    @property
    def subscription_cancelled(self) -> bool:
        return bool(self.subscription_cancelled_at)

    @property
    def is_trial(self) -> bool:
        return self.trial_expires_at is not None


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True)  # also used as the Plisio order_number
    server_id = Column(UUID(as_uuid=True), ForeignKey("servers.id", ondelete="SET NULL"), nullable=True, index=True)
    owner_email = Column(String, nullable=False, index=True)
    kind = Column(String, nullable=False)  # new | renew | upgrade
    plan = Column(String, nullable=False)
    months = Column(Integer, nullable=False, default=1)
    amount_usd = Column(Numeric(10, 2), nullable=False)
    txn_id = Column(String, unique=True, nullable=True)
    invoice_url = Column(String, nullable=True)
    status = Column(String, nullable=False, default="created", index=True)
    # created | pending | credited | needs_review | expired | cancelled | error
    plisio_status = Column(String, nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    credited_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# PulsarX free instance lifetime v1
