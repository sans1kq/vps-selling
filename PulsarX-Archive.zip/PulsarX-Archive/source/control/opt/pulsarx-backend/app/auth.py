import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

import bcrypt
from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from .database import get_db
from .models import AdminSession, User, UserSession

SESSION_TTL_DAYS = 30
CODE_TTL_MINUTES = 10
ADMIN_SESSION_TTL_HOURS = 12

# ---- Rate limiting (in-memory, single-process — resets on deploy/restart) ----
_rate_limit_buckets: dict[str, deque] = defaultdict(deque)


def check_rate_limit(key: str, max_attempts: int, window_seconds: int) -> None:
    """Fixed-window-ish limiter: raises 429 if `key` was hit too many times
    within `window_seconds`. Call once per (key, request) — old hits outside
    the window are pruned automatically.
    """
    now = time.monotonic()
    bucket = _rate_limit_buckets[key]
    while bucket and now - bucket[0] > window_seconds:
        bucket.popleft()
    if len(bucket) >= max_attempts:
        raise HTTPException(status_code=429, detail="Too many attempts — try again later")
    bucket.append(now)


def client_ip(request: Request) -> str:
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def hash_password(password: str) -> str:
    encoded=password.encode("utf-8")
    if len(encoded)>72:
        raise HTTPException(422,"Use a password of at most 72 UTF-8 bytes; longer passwords are not truncated.")
    return bcrypt.hashpw(encoded,bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


def generate_otp() -> str:
    return f"{secrets.randbelow(1_000_000):06d}"


def otp_expiry() -> datetime:
    return datetime.now(timezone.utc) + timedelta(minutes=CODE_TTL_MINUTES)


def generate_session_token() -> str:
    return secrets.token_urlsafe(32)


def create_session(db: Session, user: User) -> str:
    token = generate_session_token()
    session = UserSession(
        token=token,
        user_id=user.id,
        expires_at=datetime.now(timezone.utc) + timedelta(days=SESSION_TTL_DAYS),
    )
    db.add(session)
    db.commit()
    return token


def get_current_user(
    authorization: str = Header(...),
    db: Session = Depends(get_db),
) -> User:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.removeprefix("Bearer ").strip()

    session = db.get(UserSession, token)
    if session is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    if session.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired")

    user = db.get(User, session.user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    return user


def create_admin_session(db: Session) -> str:
    token = generate_session_token()
    session = AdminSession(
        token=token,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=ADMIN_SESSION_TTL_HOURS),
    )
    db.add(session)
    db.commit()
    return token


def get_current_admin(
    authorization: str = Header(...),
    db: Session = Depends(get_db),
) -> None:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.removeprefix("Bearer ").strip()

    session = db.get(AdminSession, token)
    if session is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    if session.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired")
