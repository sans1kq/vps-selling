"""Global contractual limits, merged with actual instances and pending orders."""
import json
import logging
from datetime import datetime,timezone
from sqlalchemy import and_,case,func,or_,select
from .flex_catalog import GB,GIB,MIB,PLANS,POLICY
from .models import Payment,Server,ServerStatus
from .wallet_models import ACTIVE_ORDERS,WalletOrder
logger=logging.getLogger('pulsarx.flex_capacity')

def _target_case(column,field):return case({n:p[field] for n,p in PLANS.items()},value=column,else_=0)

def reservation_query(db,now):
    live_invoice=or_(and_(Payment.status.in_(('created','pending')),Payment.expires_at>now),Payment.status.in_(('needs_review','credited')))
    paid_new=select(Payment.id).where(Payment.server_id==Server.id,Payment.kind=='new',live_invoice).correlate(Server).exists()
    wallet_new=select(WalletOrder.id).where(WalletOrder.server_id==Server.id,WalletOrder.kind=='new',WalletOrder.status.in_(ACTIVE_ORDERS)).correlate(Server).exists()
    grant=or_(Server.trial_expires_at.isnot(None),and_(Server.approval_token.isnot(None),or_(Server.approval_token_expires_at.is_(None),Server.approval_token_expires_at>now)))
    held=Server.status.in_((ServerStatus.running,ServerStatus.provisioning,ServerStatus.pending,ServerStatus.suspended))
    waiting=and_(Server.status==ServerStatus.pending_approval,or_(paid_new,wallet_new,grant))
    failed_paid=and_(Server.status==ServerStatus.failed,wallet_new)
    fields=[]
    for field in ('disk_gb','ram_mb','cpu_cores'):
        wallet=select(func.max(_target_case(WalletOrder.plan,field))).where(WalletOrder.server_id==Server.id,WalletOrder.kind=='upgrade',WalletOrder.status.in_(ACTIVE_ORDERS)).correlate(Server).scalar_subquery()
        invoice=select(func.max(_target_case(Payment.plan,field))).where(Payment.server_id==Server.id,Payment.kind=='upgrade',live_invoice).correlate(Server).scalar_subquery()
        approval=case((or_(Server.upgrade_token_expires_at.is_(None),Server.upgrade_token_expires_at>now),_target_case(Server.upgrade_target_plan,field)),else_=0)
        fields.append(func.greatest(getattr(Server,field),func.coalesce(wallet,0),func.coalesce(invoice,0),approval).label(field))
    return db.query(Server.container_name,*fields).filter(or_(held,waiting,failed_paid))

def reservation_resources(db,now=None):
    return [dict(zip(('name','disk_gb','ram_mb','cpu_cores'),r)) for r in reservation_query(db,now or datetime.now(timezone.utc)).all()]

def _cpu_count(raw,total):
    if not raw:return total
    if str(raw).isdigit():
        if int(raw)<1:raise ValueError('Invalid CPU count')
        return int(raw)
    seen=set()
    for item in str(raw).split(','):
        parts=item.split('-')
        if len(parts) not in (1,2) or not all(p.isdigit() for p in parts):raise ValueError('Unsupported CPU allocation')
        low,high=int(parts[0]),int(parts[-1])
        if high<low or high>65535:raise ValueError('Invalid CPU range')
        seen.update(range(low,high+1))
    return len(seen)

def merge_resources(rows,instances,memory_total,cpu_total,exclude_container=None):
    from .capacity_service import number,storage_size
    memory_total,cpu_total=number(memory_total,True),number(cpu_total,True)
    reserve=max(3*GIB,(memory_total+9)//10)
    budget=min(POLICY['ram_budget_gib']*GIB,max(0,memory_total-reserve))
    allocations={r['name']:{'ram':number(r['ram_mb'],True)*MIB,'cpu':number(r['cpu_cores'],True)} for r in rows}
    if not isinstance(instances,list):raise ValueError('Invalid instance inventory')
    seen=set()
    for instance in instances:
        name=instance.get('name')
        if not isinstance(name,str) or name in seen:raise ValueError('Missing/duplicate instance')
        seen.add(name);cfg=instance.get('expanded_config',instance.get('config',{}))
        ram=storage_size(cfg['limits.memory']) if cfg.get('limits.memory') else budget
        cpu=_cpu_count(cfg.get('limits.cpu'),cpu_total)
        old=allocations.setdefault(name,{'ram':0,'cpu':0});old['ram']=max(old['ram'],ram);old['cpu']=max(old['cpu'],cpu)
    if exclude_container is not None:allocations.pop(exclude_container,None)
    used=sum(r['ram'] for r in allocations.values());cpus=sum(r['cpu'] for r in allocations.values());cpu_budget=cpu_total*POLICY['cpu_overcommit']
    return {'memory_total_bytes':memory_total,'memory_budget_bytes':budget,'memory_reserved_bytes':used,'memory_available_bytes':max(0,budget-used),'memory_system_reserve_bytes':memory_total-budget,'cpu_total':cpu_total,'cpu_allocation_budget':cpu_budget,'cpu_allocated':cpus,'cpu_available':max(0,cpu_budget-cpus),'cpu_overcommit':POLICY['cpu_overcommit'],'cpu_shared':True,'resource_reservations':allocations}

def capacity_report(db,exclude_container=None):
    from .capacity_service import StorageCapacityError,calculate,remote_state,storage_size
    from .incus_service import _run
    try:
        data,pools=remote_state();rows=reservation_resources(db)
        result=calculate(data,pools,[(r['name'],r['disk_gb']) for r in rows],exclude_container)
        resources=json.loads(_run(['incus','query','/1.0/resources'],timeout=15));resources=resources.get('metadata',resources)
        instances=json.loads(_run(['incus','query','/1.0/instances?recursion=1&project=default'],timeout=15))
        if isinstance(instances,dict):instances=instances.get('metadata',instances)
        result.update(merge_resources(rows,instances,resources['memory']['total'],resources['cpu']['total'],exclude_container))
        largest=max([p['disk_gb']*GB for p in PLANS.values()]+[r['disk_gb']*GB for r in rows]+[storage_size(p['config']['size']) for p in pools if p.get('driver')=='btrfs' and p.get('config',{}).get('size')]);workspace=2*largest+8*GIB
        extra=max(0,workspace-result['system_reserve_bytes']);result['available_for_new_bytes']=max(0,result['available_for_new_bytes']-extra)
        result['system_reserve_bytes']+=extra;result['backup_workspace_reserve_bytes']=workspace;result['excluded_physical_disk_bytes']=0
        if exclude_container:
            for pool in pools:
                if pool['name']==exclude_container+'-pool':result['excluded_physical_disk_bytes']=storage_size(pool['config']['size'])
        return result
    except StorageCapacityError:raise
    except Exception as exc:
        logger.warning('Could not verify resources',exc_info=True)
        raise StorageCapacityError(503,'Resource availability is temporarily unavailable. Please try again later.') from exc

def check_resources(usage,spec):
    from .capacity_service import StorageCapacityError,number
    if usage.get('maintenance'):raise StorageCapacityError(503,'Resource maintenance is in progress. Please try again later.')
    disk=max(0,number(spec['disk_gb'],True)*GB-usage.get('excluded_physical_disk_bytes',0))
    for requested,available,message in [(disk,usage['available_for_new_bytes'],'disk'),(number(spec['ram_mb'],True)*MIB,usage['memory_available_bytes'],'RAM'),(number(spec['cpu_cores'],True),usage['cpu_available'],'shared CPU')]:
        if requested>available:raise StorageCapacityError(409,'Not enough unreserved '+message+' capacity for this plan.')
    return usage

def require_resources(db,spec,exclude_container=None):
    from .capacity_service import capacity_lock
    capacity_lock(db);return check_resources(capacity_report(db,exclude_container),spec)

def availability(db):
    from .capacity_service import StorageCapacityError
    try:usage=capacity_report(db)
    except StorageCapacityError:return {'available':False,'shared_capacity':True,'plans':{n:{'available':False,'remaining':0} for n in PLANS}}
    plans={}
    for name,p in PLANS.items():
        count=min(usage['available_for_new_bytes']//(p['disk_gb']*GB),usage['memory_available_bytes']//(p['ram_mb']*MIB),usage['cpu_available']//p['cpu_cores']) if not usage.get('maintenance') else 0
        plans[name]={'available':count>0,'remaining':int(count)}
    return {'available':not usage.get('maintenance'),'shared_capacity':True,'plans':plans}
