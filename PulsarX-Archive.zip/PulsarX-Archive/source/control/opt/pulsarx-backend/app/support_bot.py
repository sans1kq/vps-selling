"""Telegram private support transport. Never logs tokens or message content."""
import fcntl
import json
import os
import re
import shutil
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, build_opener, HTTPRedirectHandler

from . import support_store as store
from . import web_support


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


class TelegramError(Exception):
    def __init__(self, kind, code=0, retry_after=0, detail=''):
        self.kind,self.code,self.retry_after=kind,code,retry_after
        self.detail=detail
        super().__init__(kind)


def rejection(code,data):
    """Classify provider replies without retaining raw descriptions or URLs."""
    data=data if isinstance(data,dict) else {}
    description=str(data.get('description','')).lower()
    if code==401:return 'invalid_bot_token'
    if code==409:return 'polling_conflict'
    if code==429:return 'rate_limited'
    if code==403:
        if 'blocked' in description:return 'bot_blocked_by_user'
        if 'deactivated' in description or 'deleted' in description:return 'recipient_deactivated'
        if 'initiate' in description:return 'chat_not_started'
        return 'telegram_forbidden'
    if code==400:
        if 'chat not found' in description:return 'chat_not_found'
        if 'too long' in description:return 'message_too_long'
        if 'empty' in description:return 'empty_message'
        if 'thread' in description or 'topic' in description:return 'chat_topic_unavailable'
        return 'telegram_bad_request'
    if code>=500:return 'telegram_service_unavailable'
    return 'telegram_http_error'


class Telegram:
    def __init__(self, token):
        if not re.fullmatch(r'[0-9]{5,20}:[A-Za-z0-9_-]{20,150}',token):
            raise TelegramError('invalid_token_format')
        self.token=token
        self.opener=build_opener(NoRedirect())

    def failure(self,code,data,retry=0):
        description=str(data.get('description','')) if isinstance(data,dict) else ''
        description=description.replace(self.token,'[redacted]')
        description=re.sub(r'[0-9]{5,20}:[A-Za-z0-9_-]{20,150}','[redacted]',description)
        description=re.sub(r'https?://\S+','[redacted-url]',description)
        return TelegramError(rejection(code,data),code,min(int(retry or 0),3600),description[:240])

    def call(self, method, payload=None, timeout=20):
        # Methods are internal constants, never a user-supplied URL.
        if method not in {'getMe','getWebhookInfo','getUpdates','sendMessage','getFile'}:
            raise TelegramError('invalid_method')
        req=Request('https://api.telegram.org/bot'+self.token+'/'+method,
                    data=json.dumps(payload or {}).encode(),headers={'Content-Type':'application/json'})
        try:
            with self.opener.open(req,timeout=timeout) as r:
                data=json.loads(r.read(8*1024*1024))
        except HTTPError as exc:
            try:data=json.loads(exc.read(65536))
            except Exception:data={}
            retry=(data.get('parameters') or {}).get('retry_after',0)
            raise self.failure(exc.code,data,retry) from None
        except Exception:
            raise TelegramError('network_or_response_error') from None
        if not isinstance(data,dict) or not data.get('ok'):
            code=int(data.get('error_code',0)) if isinstance(data,dict) else 0
            retry=(data.get('parameters') or {}).get('retry_after',0) if isinstance(data,dict) else 0
            raise self.failure(code,data,retry)
        return data.get('result')

    def download(self, file_id):
        item=self.call('getFile',{'file_id':file_id})
        path=item.get('file_path','')
        if not re.fullmatch(r'[A-Za-z0-9_./-]+',path) or '..' in path.split('/') or path.startswith('/'):
            raise TelegramError('invalid_file_path')
        if int(item.get('file_size') or 0)>10*1024*1024:
            raise TelegramError('file_too_large')
        used=sum(p.stat().st_size for p in (store.STATE/'files').iterdir() if p.is_file() and not p.is_symlink())
        if used>2*1024**3 or shutil.disk_usage(store.STATE).free<2*1024**3:
            raise TelegramError('attachment_storage_full')
        name=uuid.uuid4().hex
        destination=store.STATE/'files'/name
        count=0
        try:
            with self.opener.open('https://api.telegram.org/file/bot'+self.token+'/'+quote(path,safe='/'),timeout=30) as r, destination.open('xb') as stream:
                os.chmod(destination,0o600)
                while True:
                    block=r.read(65536)
                    if not block:break
                    count+=len(block)
                    if count>10*1024*1024:raise TelegramError('file_too_large')
                    stream.write(block)
            return name,count
        except Exception:
            destination.unlink(missing_ok=True)
            raise TelegramError('attachment_download_failed') from None


def deliver_one(api):
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute("SELECT m.*,t.chat_id,t.channel FROM messages m JOIN tickets t ON t.id=m.ticket_id WHERE delivery='queued' AND retry_at<=? ORDER BY m.id LIMIT 1",(time.time(),)).fetchone()
        if not row:return False
        if row['channel']=='web' and row['direction']!='notify':
            db.execute("UPDATE messages SET delivery='available',error=NULL WHERE id=?",(row['id'],))
            return True
        recipient=row['chat_id']
        if row['direction']=='notify':
            target=re.fullmatch(r'notify:([1-9][0-9]{0,18}):(?:web:)?[0-9]+',row['request_id'] or '')
            if not target or store.meta(db,'notify_chat_id')!=target[1]:
                db.execute("UPDATE messages SET delivery='cancelled',error='recipient_not_authorized' WHERE id=?",(row['id'],))
                return True
            recipient=int(target[1])
        db.execute("UPDATE messages SET delivery='sending',attempts=attempts+1 WHERE id=?",(row['id'],))
    try:
        result=api.call('sendMessage',{'chat_id':recipient,'text':row['body'],
                                     'link_preview_options':{'is_disabled':True}})
        message_id=result.get('message_id') if isinstance(result,dict) else None
        if not isinstance(message_id,int):raise TelegramError('invalid_send_result')
        with store.connect() as db:
            db.execute("UPDATE messages SET delivery='sent',tg_message_id=?,error=NULL WHERE id=?",(message_id,row['id']))
    except TelegramError as exc:
        # Retrying a timed-out POST could send a second copy. Keep ambiguous
        # outcomes visible for an operator instead of silently sending again.
        retry=exc.code==429 and row['attempts']<5
        state='queued' if retry else ('failed' if 400<=exc.code<500 else 'unknown')
        with store.connect() as db:
            db.execute('UPDATE messages SET delivery=?,error=?,retry_at=? WHERE id=?',
                       (state,exc.kind+(':'+str(exc.code) if exc.code else '')+(':'+exc.detail if exc.detail else ''),time.time()+max(2,exc.retry_after),row['id']))
    return True


def download_one(api):
    with store.connect() as db:
        row=db.execute("SELECT * FROM attachments WHERE status='pending' AND retry_at<=? ORDER BY id LIMIT 1",(time.time(),)).fetchone()
    if not row:return False
    try:
        name,size=api.download(row['file_id'])
        with store.connect() as db:
            db.execute("UPDATE attachments SET status='ready',local_name=?,size=? WHERE id=?",(name,size,row['id']))
    except TelegramError:
        with store.connect() as db:
            db.execute('UPDATE attachments SET attempts=attempts+1,retry_at=?,status=? WHERE id=?',
                       (time.time()+60,'failed' if row['attempts']>=2 else 'pending',row['id']))
    return True


def run():
    os.umask(0o077)
    web_support.initialize()
    lock=open(store.STATE/'worker.lock','a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('Support worker already running')
    api=Telegram(os.environ.get('PULSARX_SUPPORT_BOT_TOKEN',''))
    with store.connect() as db:
        db.execute("UPDATE messages SET delivery='unknown',error='worker_restarted_during_send' WHERE delivery='sending'")
    while True:
        try:
            for _ in range(10):
                if not deliver_one(api):break
            download_one(api)
            with store.connect() as db:offset=int(store.meta(db,'offset','0'))
            updates=api.call('getUpdates',{'offset':offset,'timeout':5,'limit':50,'allowed_updates':['message']},timeout=15)
            if not isinstance(updates,list):raise TelegramError('invalid_update_result')
            for update in updates:store.receive(update)
            with store.connect() as db:
                store.put(db,'poll_at',time.time());store.put(db,'worker_error','')
        except TelegramError as exc:
            with store.connect() as db:store.put(db,'worker_error',exc.kind+(':'+str(exc.code) if exc.code else ''))
            print('Support transport: '+exc.kind+(' HTTP '+str(exc.code) if exc.code else ''),flush=True)
            time.sleep(max(5,min(exc.retry_after,60)))
        except Exception:
            # Avoid logging raw request/URL exceptions with the bot token.
            with store.connect() as db:store.put(db,'worker_error','internal_error')
            print('Support worker: internal error; no message content logged',flush=True)
            time.sleep(5)


if __name__=='__main__':
    run()
