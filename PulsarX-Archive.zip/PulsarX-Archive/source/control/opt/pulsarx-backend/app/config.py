from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    database_url: str
    api_key: str
    incus_image: str = "images:debian/12"
    base_domain: str = "pulsarx.example.invalid"
    direct_domain: str = "direct.pulsarx.example.invalid"
    bridge_network: str = "incusbr0"

    smtp_host: str
    smtp_port: int = 587
    smtp_user: str
    smtp_password: str
    smtp_from: str
    smtp_use_tls: bool = True

    resend_api_key: str
    email_from: str

    ls_api_key: str
    ls_webhook_secret: str
    ls_store_id: str
    ls_variant_mini: str
    ls_variant_plus: str
    frontend_base_url: str = "https://pulsarx.example.invalid"
    plisio_api_key: str = ""
    plisio_webhook_token: str = ""
    invoice_expire_min: int = 60
    webhook_base_url: str = ""

    # Live AnyPay keys are entered on the VPS; never embedded in an installer.
    anypay_enabled: bool = False
    anypay_project_id: str = ""
    anypay_secret_key: str = ""
    anypay_api_id: str = ""
    anypay_api_key: str = ""
    anypay_notification_ips: str = "185.162.128.38,185.162.128.39,185.162.128.88"
    # Only an actual Cloudflare peer may supply CF-Connecting-IP.
    anypay_proxy_cidrs: str = "173.245.48.0/20,103.21.244.0/22,103.22.200.0/22,103.31.4.0/22,141.101.64.0/18,108.162.192.0/18,190.93.240.0/20,188.114.96.0/20,197.234.240.0/22,198.41.128.0/17,162.158.0.0/15,104.16.0.0/13,104.24.0.0/14,172.64.0.0/13,131.0.72.0/22,2400:cb00::/32,2606:4700::/32,2803:f800::/32,2405:b500::/32,2405:8100::/32,2a06:98c0::/29,2c0f:f248::/32"
    freekassa_enabled: bool = False
    freekassa_shop_id: str = "0"
    freekassa_secret_1: str = ""
    freekassa_secret_2: str = ""
    freekassa_api_key: str = ""
    # Used when the application cannot recover a trusted public client IP.
    freekassa_payer_ip: str = "192.0.2.11"
    freekassa_nonce_file: str = "/opt/pulsarx-backend/.freekassa-api-nonce"
    freekassa_notification_ips: str = "168.119.157.136,168.119.60.227,178.154.197.79,51.250.54.238"
    wallet_anypay_checkout_enabled: bool = True
    wallet_min_topup_cents: int = 100
    wallet_max_topup_cents: int = 10000

    # RollyPay fields must be declared in the main dotenv settings too.
    rollypay_enabled: bool = False
    rollypay_api_key: str = ""
    rollypay_signing_secret: str = ""
    rollypay_terminal_id: str = ""

    admin_username: str = "sansik"
    admin_password_hash: str
    admin_notify_email: str = "contact@example.invalid"


@lru_cache
def get_settings() -> Settings:
    return Settings()
