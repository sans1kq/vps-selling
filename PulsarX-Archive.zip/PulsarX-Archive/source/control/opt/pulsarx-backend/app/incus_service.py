from .pool_cleanup import prepare_dedicated_pool_cleanup, validate_container_name
from .capacity_service import guarded_pool_create
import re
import secrets
import shlex
import string
import subprocess
import time
import uuid

from .config import get_settings
import json

settings = get_settings()


class IncusError(RuntimeError):
    pass


def _run_raw(cmd: list[str], timeout: int = 60) -> str:
    """Run a command on the host and return stdout, raising on failure."""
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        raise IncusError(
            f"Command failed: {' '.join(shlex.quote(c) for c in cmd)}\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
    return result.stdout



def _pulsarx_storage_ready():
    try:
        info = json.loads(_run_raw(['incus', 'query', '/1.0'], timeout=15))
        if isinstance(info, dict) and 'metadata' in info:
            info = info['metadata']
        if not isinstance(info, dict) or not isinstance(info.get('config'), dict):
            raise ValueError('Invalid host state')
        if info['config'].get('user.pulsarx.storage_maintenance'):
            raise IncusError('Storage maintenance is in progress. Please try again later.')
    except IncusError:
        raise
    except Exception as exc:
        raise IncusError('Storage maintenance state could not be verified') from exc


def _run(cmd: list[str], timeout: int = 60) -> str:
    readonly = cmd[:2] in (['incus', 'list'], ['incus', 'info'], ['incus', 'version'])
    readonly = readonly or (cmd[:2] == ['incus', 'query'] and len(cmd) == 3)
    readonly = readonly or (cmd[:2] == ['incus', 'storage'] and len(cmd) > 2 and cmd[2] in ('list', 'show', 'info'))
    readonly = readonly or (cmd[:2] == ['incus', 'config'] and len(cmd) > 2 and cmd[2] in ('get', 'show'))
    if cmd and cmd[0] == 'incus' and not readonly:
        _pulsarx_storage_ready()
    return _run_raw(cmd, timeout)


def _exec(container: str, script: str, timeout: int = 180) -> str:
    """Run a shell script inside a container via `incus exec`."""
    return _run(["incus", "exec", container, "--", "bash", "-c", script], timeout=timeout)


def generate_container_name() -> str:
    return f"mini-{uuid.uuid4().hex[:10]}"


def generate_password(length: int = 16) -> str:
    # Letters + digits only, on purpose: this password gets interpolated into a
    # shell command inside the container (see provision_user). No quotes or
    # shell metacharacters means nothing to escape and nothing that can break out.
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def create_container(
    name: str, cpu_cores: int, ram_mb: int, disk_gb: int, image_alias: str,
    raw_idmap: str | None = None,
) -> None:
    """Launch an isolated, resource-limited container for one customer.

    raw_idmap, when given, pins this container to its own UID/GID range
    (see idmap_service.py) instead of relying on Incus's automatic
    allocator, which behaved unreliably on this host.
    """
    # Each container gets its own dedicated loop-backed btrfs pool, sized
    # exactly to what the customer paid for. This is deliberate: the shared
    # "pool-btrfs" pool only enforces disk usage via btrfs qgroups, which
    # (a) are trivially bypassable by a user creating nested subvolumes, and
    # (b) don't affect what `df` reports inside the container -- customers
    # always saw the whole shared pool's size there, which was confusing
    # and looked like the quota wasn't real.
    pool_name = f"{name}-pool"
    guarded_pool_create(name, disk_gb, lambda: _run(["incus", "storage", "create", pool_name, "btrfs", f"size={disk_gb}GB"], timeout=60), ram_mb=ram_mb, cpu_cores=cpu_cores)

    cmd = [
        "incus", "launch", image_alias, name,
        "--config", f"limits.cpu={cpu_cores}",
        "--config", "limits.cpu.allowance=100%",
        "--config", f"limits.memory={ram_mb}MiB",
        "--config", f"limits.processes={max(1024, int(ram_mb))}",
        "--config", "security.nesting=false",
        "--config", "security.privileged=false",
        "--storage", pool_name,
    ]
    if raw_idmap:
        cmd += ["--config", f"raw.idmap={raw_idmap}"]
    # _provision owns rollback for the whole operation, including storage
    # creation timeouts and failures after launch. Keep the original error.
    _run(cmd, timeout=300)
    _run(["incus","config","device","set",name,"root",f"size={disk_gb}GB"])


def enable_isolation(name: str) -> None:
    """Keep customer containers from seeing each other's broadcast/ARP traffic.

    Must be called only after the container already has its IPv4 lease.
    """
    _run(["incus", "config", "device", "override", name, "eth0", "security.port_isolation=true"])


def wait_for_running(name: str, attempts: int = 30, delay: float = 2.0) -> None:
    for _ in range(attempts):
        out = _run(["incus", "list", name, "--format", "csv", "-c", "s"])
        if out.strip() == "RUNNING":
            return
        time.sleep(delay)
    raise IncusError(f"Container {name} did not reach RUNNING state in time")


def get_ipv4(name: str, attempts: int = 30, delay: float = 2.0) -> str:
    for _ in range(attempts):
        out = _run(["incus", "list", name, "--format", "csv", "-c", "4"])
        addr = out.strip().split(" ")[0]
        if addr:
            return addr
        time.sleep(delay)
    raise IncusError(f"Container {name} did not get an IPv4 address in time")


def provision_user(name: str, username: str) -> None:
    """Install SSH, create a sudo user, and lock the account.

    No password is set here on purpose: the account stays locked (login via
    password impossible) until the customer picks their own password from
    the dashboard, via set_user_password(). This avoids ever generating or
    emailing a password, and the fragile "password expired, change it now"
    SSH/PAM prompt some clients handle poorly.
    """
    script = f"""
set -e
export DEBIAN_FRONTEND=noninteractive

for i in 1 2 3 4 5; do
    if apt-get update -qq; then
        break
    fi
    sleep 3
done

apt-get install -y -qq openssh-server sudo >/dev/null

id -u {username} >/dev/null 2>&1 || useradd -m -s /bin/bash {username}
usermod -aG sudo {username}
passwd -l {username}

echo 'Unattended-Upgrade::Automatic-Reboot "false";' > /etc/apt/apt.conf.d/52pulsarx-no-autoreboot

sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl enable ssh >/dev/null 2>&1
systemctl restart ssh
"""
    _exec(name, script)


def lock_user_password(name: str, username: str) -> None:
    """Lock the SSH user's password (forces them to set a new one from the dashboard).

    Used for the "reset instance password" flow: same locked state as right
    after provisioning, before the customer ever set a password.
    """
    script = f"passwd -l {username}"
    _exec(name, script)


def set_user_password(name: str, username: str, password: str) -> None:
    """Pass the exact password as one quoted chpasswd record, never shell words."""
    import base64
    if not re.fullmatch(r"[a-z_][a-z0-9_-]{0,31}",username) or any(ord(c) in (0,10,13) for c in password):
        raise ValueError("Invalid account name or multiline password")
    encoded=base64.b64encode(password.encode()).decode()
    script=f"""set -e
printf '%s:%s\\n' {shlex.quote(username)} "$(printf '%s' '{encoded}' | base64 -d)" | chpasswd
passwd -u {shlex.quote(username)}
"""
    try:_exec(name,script)
    except Exception:
        # The normal command exception contains the script; its base64 payload
        # must not become an HTTP error or a monitoring email.
        raise IncusError("Instance password update failed") from None


def generate_ssh_host_port() -> int:
    """Pick a random port in a range reserved for customer SSH forwarding."""
    return secrets.randbelow(10000) + 20000  # 20000-29999


def add_ssh_forward(name: str, host_port: int) -> None:
    """Expose the container's SSH port on a public port on the host.

    Containers only have a private bridge IP (10.x.x.x), which isn't
    reachable from the internet — this NATs a host port to it instead.
    """
    _run(
        [
            "incus", "config", "device", "add", name, "ssh-proxy", "proxy",
            f"listen=tcp:0.0.0.0:{host_port}",
            "connect=tcp:127.0.0.1:22",
        ]
    )


def allocate_ssh_forward(name: str, attempts: int = 10) -> int:
    """Try random host ports until one isn't already taken by another container."""
    last_exc: Exception | None = None
    for _ in range(attempts):
        port = generate_ssh_host_port()
        try:
            add_ssh_forward(name, port)
            return port
        except IncusError as exc:
            last_exc = exc
    raise IncusError(f"Could not allocate a free SSH port after {attempts} attempts") from last_exc


def generate_web_host_port() -> int:
    """Pick a random port in a range reserved for customer web (HTTP) forwarding.

    Kept disjoint from the SSH range (20000-29999) so the two never collide.
    """
    return secrets.randbelow(10000) + 30000  # 30000-39999


def add_web_forward(name: str, host_port: int) -> None:
    """Expose the container's port 80 on a public port on the host.

    Same NAT pattern as add_ssh_forward: the container only has a private
    bridge IP, so this is what actually makes a website inside it reachable
    from the internet.
    """
    _run(
        [
            "incus", "config", "device", "add", name, "web-proxy", "proxy",
            f"listen=tcp:0.0.0.0:{host_port}",
            "connect=tcp:127.0.0.1:80",
        ]
    )


def allocate_web_forward(name: str, attempts: int = 10) -> int:
    """Try random host ports until one isn't already taken by another container."""
    last_exc: Exception | None = None
    for _ in range(attempts):
        port = generate_web_host_port()
        try:
            add_web_forward(name, port)
            return port
        except IncusError as exc:
            last_exc = exc
    raise IncusError(f"Could not allocate a free web port after {attempts} attempts") from last_exc


def generate_extra_host_port() -> int:
    """Pick a random port in a range reserved for arbitrary customer TCP services.

    Kept disjoint from SSH (20000-29999) and web (30000-39999) ranges.
    """
    return secrets.randbelow(10000) + 40000  # 40000-49999


def add_extra_forward(name: str, device_suffix: str, port: int) -> None:
    """Expose one arbitrary TCP port 1:1 (same port number in and out).

    Lets the customer run anything inside their container (game server,
    bot, secondary API, etc.) on that port and have it reachable directly
    at host_ip:port, with no separate internal/external mapping to track.
    """
    _run(
        [
            "incus", "config", "device", "add", name, f"extra-proxy-{device_suffix}", "proxy",
            f"listen=tcp:0.0.0.0:{port}",
            f"connect=tcp:127.0.0.1:{port}",
        ]
    )


def allocate_extra_ports(name: str, count: int = 5, attempts_per_port: int = 10) -> list[int]:
    """Allocate `count` free arbitrary TCP ports (1:1 forward) for one container."""
    allocated: list[int] = []
    for i in range(count):
        last_exc: Exception | None = None
        for _ in range(attempts_per_port):
            port = generate_extra_host_port()
            if port in allocated:
                continue
            try:
                add_extra_forward(name, str(i), port)
                allocated.append(port)
                break
            except IncusError as exc:
                last_exc = exc
        else:
            raise IncusError(
                f"Could not allocate extra port {i + 1}/{count} after {attempts_per_port} attempts"
            ) from last_exc
    return allocated

def write_ports_motd(name: str, ssh_port: int, web_port: int, extra_ports: list[int], domain: str) -> None:
    """Write a login banner inside the container listing all forwarded ports.

    Shown automatically on every SSH login (via /etc/motd), so the customer
    always knows their ports even if they never open the dashboard.
    """
    extra_list = "\n".join(f"  - {domain}:{p}  ->  container port {p} (yours to use for anything)" for p in extra_ports)
    motd = f"""
================================================================
 PulsarX Cloud -- your server's public ports
================================================================
 SSH:      {domain}:{ssh_port}
 Web (80): {domain}:{web_port}

 Extra ports (1:1, run anything on these -- game servers, bots, APIs):
{extra_list}
================================================================
"""
    script = f'cat > /etc/motd << "MOTDEOF"\n{motd}\nMOTDEOF'
    _run(["incus", "exec", name, "--", "bash", "-c", script])



def resize_container(name: str, cpu_cores: int, ram_mb: int, disk_gb: int) -> None:
    """Grow a container to a larger plan without stopping it.

    Customer containers created by ``create_container`` use a dedicated
    loop-backed btrfs pool named ``<container>-pool``.  Growing only the root
    device quota is not enough when that backing loop is still smaller, so grow
    the dedicated pool first and then raise the root-device limit.  Legacy
    containers on a shared pool keep the old behaviour and only receive the
    root-device quota change.

    This function is intentionally grow-only in normal PulsarX flows.
    """
    expected_pool = f"{name}-pool"
    try:
        root_pool = _run(["incus", "config", "device", "get", name, "root", "pool"]).strip()
    except IncusError:
        root_pool = ""

    from .capacity_service import storage_size
    target_bytes = disk_gb * 10**9
    old_quota = _run(['incus','config','device','get',name,'root','size']).strip()
    # Preserve the exact existing root entitlement; never round it down or
    # attempt an in-place shrink when switching marketing units.
    if old_quota:
        target_bytes = max(target_bytes,storage_size(old_quota))
    if root_pool == expected_pool:
        pool=json.loads(_run(['incus','query',f'/1.0/storage-pools/{root_pool}?project=default']))
        pool=pool.get('metadata',pool)
        current=storage_size(pool['config']['size'])
        if not old_quota:target_bytes=max(target_bytes,current)
        if current < target_bytes:
            _run(['incus','storage','set',root_pool,'size',str(target_bytes)+'B'],timeout=120)
    _run(['incus','config','set',name,f'limits.cpu={cpu_cores}','limits.cpu.allowance=100%',f'limits.memory={ram_mb}MiB',f'limits.processes={max(1024, int(ram_mb))}'])
    _run(['incus','config','device','set',name,'root','size='+str(target_bytes)+'B'])


def get_host_usage() -> dict:
    """Snapshot of the physical host's own CPU/RAM/disk — not any container's."""
    load1, load5, load15 = __import__("os").getloadavg()
    cpu_count = int(_run(["nproc"]).strip())

    mem_out = _run(["free", "-b"])
    mem_line = [l for l in mem_out.splitlines() if l.startswith("Mem:")][0].split()
    mem_total = int(mem_line[1])
    mem_used = int(mem_line[2])

    disk_out = _run(["df", "-B1", "--output=size,used", "/"])
    disk_line = disk_out.strip().splitlines()[-1].split()
    disk_total = int(disk_line[0])
    disk_used = int(disk_line[1])

    return {
        "cpu_cores": cpu_count,
        "load_1m": round(load1, 2),
        "load_5m": round(load5, 2),
        "load_15m": round(load15, 2),
        "load_pct": round(min(load1 / cpu_count * 100, 100.0), 1) if cpu_count else 0.0,
        "memory_used_mb": round(mem_used / (1024 * 1024), 1),
        "memory_total_mb": round(mem_total / (1024 * 1024), 1),
        "memory_pct": round(mem_used / mem_total * 100, 1) if mem_total else 0.0,
        "disk_used_gb": round(disk_used / (1024 ** 3), 1),
        "disk_total_gb": round(disk_total / (1024 ** 3), 1),
        "disk_pct": round(disk_used / disk_total * 100, 1) if disk_total else 0.0,
    }


# ---- Admin: usage, logs, delete ----

def get_container_usage(name: str, cpu_cores: int, ram_mb: int, disk_gb: int) -> dict:
    """Snapshot CPU/RAM/disk usage. Two samples ~0.6s apart to compute a CPU %."""
    def _state() -> dict:
        result = subprocess.run(
            ["incus", "query", f"/1.0/instances/{name}/state"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "incus query failed")
        return json.loads(result.stdout)

    s1 = _state()
    cpu1 = s1.get("cpu", {}).get("usage", 0)
    net1 = s1.get("network", {}).get("eth0", {}).get("counters", {})
    rx1 = net1.get("bytes_received", 0)
    tx1 = net1.get("bytes_sent", 0)
    time.sleep(0.6)
    s2 = _state()
    cpu2 = s2.get("cpu", {}).get("usage", 0)
    net2 = s2.get("network", {}).get("eth0", {}).get("counters", {})
    rx2 = net2.get("bytes_received", 0)
    tx2 = net2.get("bytes_sent", 0)

    elapsed_s = 0.6
    elapsed_ns = elapsed_s * 1_000_000_000 * max(cpu_cores, 1)
    cpu_pct = round(max(0.0, cpu2 - cpu1) / elapsed_ns * 100, 1) if elapsed_ns else 0.0
    cpu_pct = min(cpu_pct, 100.0)

    mem_bytes = s2.get("memory", {}).get("usage", 0) or 0
    mem_limit_bytes = ram_mb * 1024 * 1024
    mem_pct = round(mem_bytes / mem_limit_bytes * 100, 1) if mem_limit_bytes else 0.0

    disk_bytes = s2.get("disk", {}).get("root", {}).get("usage", 0)
    disk_usage_available = disk_bytes is not None
    disk_bytes = disk_bytes or 0
    disk_limit_bytes = disk_gb * 10 ** 9
    # Legacy services can have more disk than the advertised minimum.
    quota=_run(['incus','config','device','get',name,'root','size']).strip()
    if quota:
        from .capacity_service import storage_size
        disk_limit_bytes=max(disk_limit_bytes,storage_size(quota))
    disk_pct = round(disk_bytes / disk_limit_bytes * 100, 1) if disk_limit_bytes else 0.0

    rx_kbps = round(max(0, rx2 - rx1) / 1024 / elapsed_s, 1)
    tx_kbps = round(max(0, tx2 - tx1) / 1024 / elapsed_s, 1)

    return {
        "cpu_pct": cpu_pct,
        "memory_used_mb": round(mem_bytes / (1024 * 1024), 1),
        "memory_limit_mb": ram_mb,
        "memory_pct": min(mem_pct, 100.0),
        "disk_used_gb": round(disk_bytes / 10**9, 2) if disk_usage_available else None,
        "disk_usage_available": disk_usage_available,
        "disk_limit_gb": round(disk_limit_bytes / 10**9, 2),
        "disk_pct": min(disk_pct, 100.0),
        "network_rx_kbps": rx_kbps,
        "network_tx_kbps": tx_kbps,
    }








def stop_container(name: str) -> None:
    """Suspend a customer's container without deleting it or its data."""
    _pulsarx_storage_ready()
    result = subprocess.run(["incus", "stop", name, "--force"], capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "failed to stop container")


def start_container(name: str) -> None:
    """Resume a previously suspended container."""
    _pulsarx_storage_ready()
    result = subprocess.run(["incus", "start", name], capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "failed to start container")


def restart_container(name: str) -> None:
    """Restart a running container in place."""
    _pulsarx_storage_ready()
    result = subprocess.run(["incus", "restart", name, "--force"], capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "failed to restart container")


def _pulsarx_resource_exists(command: list[str], name: str) -> bool:
    """Only a valid, successful Incus listing can establish absence."""
    try:
        rows = json.loads(_run(command, timeout=30))
    except (ValueError, TypeError) as exc:
        raise IncusError("Invalid JSON from Incus while checking resources") from exc
    if not isinstance(rows, list) or any(
        not isinstance(row, dict) or not isinstance(row.get("name"), str)
        for row in rows
    ):
        raise IncusError("Unexpected Incus resource list")
    return any(row["name"] == name for row in rows)


def _pulsarx_delete_if_present(
    list_command: list[str], name: str, delete_command: list[str],
) -> None:
    if not _pulsarx_resource_exists(list_command, name):
        return
    try:
        _run(delete_command, timeout=90)
    except (IncusError, subprocess.TimeoutExpired):
        # A concurrent delete or a client timeout can leave the resource
        # already gone. Suppress the error only after confirming absence.
        if _pulsarx_resource_exists(list_command, name):
            raise

    if _pulsarx_resource_exists(list_command, name):
        raise IncusError("Deletion could not be verified: " + name)


def delete_container(name: str) -> None:
    """Remove an instance and its dedicated pool; safe to repeat."""
    validate_container_name(name)
    _pulsarx_delete_if_present(
        ["incus", "list", name, "--format", "json"],
        name,
        ["incus", "delete", name, "--force"],
    )
    # Never remove the pool if instance removal failed or was unverified.
    pool_name = f"{name}-pool"
    prepare_dedicated_pool_cleanup(name, _run)
    _pulsarx_delete_if_present(
        ["incus", "storage", "list", "--format", "json"],
        pool_name,
        ["incus", "storage", "delete", pool_name],
    )
    if name == "mini-0f419f50e2":
        _run(["incus", "config", "set", "user.pulsarx.storage_gc="+name], timeout=20)

# PulsarX provisioning rollback v1

# PulsarX storage preflight v1

# PulsarX pool image cleanup v1

# PulsarX terminal privacy v1
