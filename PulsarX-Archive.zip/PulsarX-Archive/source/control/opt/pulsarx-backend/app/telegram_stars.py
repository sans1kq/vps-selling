"""Telegram XTR -> the existing USD wallet. No Incus calls from webhooks.

Dedicated payment bot: never replace the support bot's polling transport.
All DB work is dispatched to threads with its own SQLAlchemy session.
"""
import asyncio
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_CEILING
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import uuid

import urllib.request as _tg_request
import http.client as _tg_http
from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response
from pydantic import BaseModel, Field, StrictBool, StrictInt
from sqlalchemy import BigInteger, Boolean, Column, CheckConstraint, DateTime, ForeignKey, Integer, String, UniqueConstraint, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.exc import IntegrityError
from starlette.concurrency import run_in_threadpool
from . import auth, growth_service, payments_service, wallet_service
from .database import Base, SessionLocal, engine
from .growth_models import ReferralBenefit, ReferralTopup
from .models import User
from .wallet_models import WalletAccount, WalletTopup

router=APIRouter(prefix='/api/telegram',tags=['telegram-stars'])
log=logging.getLogger('pulsarx.stars')
# httpx INFO logs include the Bot API URL, which contains a secret.
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger('httpcore').setLevel(logging.WARNING)
RATE=Decimal('0.013')  # Merchant reward reference, NOT the user's purchase price.
MARKUP=Decimal('1.30')

class StarsLink(Base):
    __tablename__='px_stars_links'
    user_id=Column(UUID(as_uuid=True),ForeignKey('users.id'),primary_key=True)
    telegram_id=Column(BigInteger,nullable=False,unique=True)

class StarsLinkIntent(Base):
    __tablename__='px_stars_link_intents'
    id=Column(UUID(as_uuid=True),primary_key=True)
    user_id=Column(UUID(as_uuid=True),ForeignKey('users.id'),nullable=False,index=True)
    token_hash=Column(String(64),nullable=False,unique=True)
    expires_at=Column(DateTime(timezone=True),nullable=False)
    telegram_id=Column(BigInteger,nullable=True)
    display_name=Column(String(160),nullable=True)
    confirmed=Column(Boolean,nullable=False,default=False)

class StarsInvoice(Base):
    __tablename__='px_stars_invoices'
    id=Column(UUID(as_uuid=True),primary_key=True)
    topup_id=Column(BigInteger,ForeignKey('wallet_topups.id'),nullable=False,unique=True)
    user_id=Column(UUID(as_uuid=True),ForeignKey('users.id'),nullable=False,index=True)
    telegram_id=Column(BigInteger,nullable=False)
    request_key=Column(UUID(as_uuid=True),nullable=False)
    fingerprint=Column(String(64),nullable=False)
    stars=Column(Integer,nullable=False)
    credit_cents=Column(Integer,nullable=False)
    pay_cents=Column(Integer,nullable=False)
    state=Column(String(24),nullable=False,default='created')
    expires_at=Column(DateTime(timezone=True),nullable=False)
    checkout_id=Column(String(256),nullable=True)
    charge_id=Column(String(256),nullable=True,unique=True)
    refunded_at=Column(DateTime(timezone=True),nullable=True)
    debt_cents=Column(Integer,nullable=False,default=0)
    __table_args__=(UniqueConstraint('user_id','request_key'),CheckConstraint('stars > 0 AND pay_cents > 0 AND credit_cents >= pay_cents AND debt_cents >= 0'),)

def init_schema():
    Base.metadata.create_all(engine,tables=[StarsLink.__table__,StarsLinkIntent.__table__,StarsInvoice.__table__])

def now():return datetime.now(timezone.utc)
def utc(t):return t.replace(tzinfo=timezone.utc) if t.tzinfo is None else t
def configured():
    return bool(os.getenv('PX_STARS_BOT_TOKEN') and os.getenv('PX_STARS_WEBHOOK_SECRET') and re.fullmatch(r'[A-Za-z0-9_]{5,32}',os.getenv('PX_STARS_BOT_USERNAME','')))
def enabled():return configured() and os.getenv('PX_STARS_ENABLED')=='1'
def require_enabled():
    if not enabled():raise HTTPException(503,'Stars пока не подключён. Выберите другой способ оплаты.')

@contextmanager
def session():
    with SessionLocal() as db:
        if db.bind.dialect.name=='postgresql':
            db.execute(text("SET LOCAL lock_timeout = '1500ms'"))
            db.execute(text("SET LOCAL statement_timeout = '2500ms'"))
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise

class _StarsNoRedirect(_tg_request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

def _stars_post(method,payload):
    # A fresh HTTPS connection, no redirects, proxy, or automatic POST retries.
    opener=_tg_request.build_opener(_tg_request.ProxyHandler({}),_StarsNoRedirect())
    req=_tg_request.Request('https://api.telegram.org/bot'+os.environ['PX_STARS_BOT_TOKEN']+'/'+method,
        data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'},method='POST')
    with opener.open(req,timeout=4) as resp:
        raw=resp.read(2_000_001)
    if len(raw)>2_000_000:raise ValueError('oversize response')
    result=json.loads(raw)
    if not isinstance(result,dict) or result.get('ok') is not True:raise ValueError('rejected')
    return result.get('result')

async def tg(method,payload):
    if method not in {'createInvoiceLink','sendInvoice','answerPreCheckoutQuery','sendMessage','getStarTransactions','refundStarPayment'}:
        raise ValueError('Unsupported Telegram method')
    try:
        return await asyncio.wait_for(asyncio.to_thread(_stars_post, method, payload), timeout=5)
    except (asyncio.TimeoutError,OSError,ValueError,KeyError,_tg_http.HTTPException) as exc:
        log.warning('Telegram call failed: %s (%s, HTTP %s)',method,type(exc).__name__,getattr(exc,'code','-'))
        raise HTTPException(502,'Telegram временно недоступен. Проверьте статус операции перед повтором.') from None

class QuoteRequest(BaseModel):
    plan_key:str|None=None
    months:StrictInt=1
    amount_cents:StrictInt|None=Field(default=None,ge=100,le=10000)
    apply_referral:StrictBool=False

class InvoiceRequest(QuoteRequest):
    user_id:uuid.UUID|None=None
    request_key:uuid.UUID
    expected_stars:StrictInt=Field(gt=0)
    expected_credit_cents:StrictInt=Field(gt=0)
    accepted_terms:StrictBool

class ConfirmLink(BaseModel):
    intent_id:uuid.UUID
    telegram_id:StrictInt
    code:str=Field(pattern=r'^[0-9]{8}$')

def terms(body, first_topup=False, invited=False):
    if body.plan_key is not None:
        if body.amount_cents is not None or body.plan_key not in payments_service.PLANS or body.months not in payments_service.PERIOD_DAYS:
            raise HTTPException(422,'Неверный тариф или период.')
        credit=int(payments_service.price_usd(body.plan_key,body.months)*100)
    else:
        if body.amount_cents is None or body.months!=1:raise HTTPException(422,'Укажите сумму пополнения.')
        credit=body.amount_cents
    if not 100<=credit<=10000:raise HTTPException(422,'Пополнение Stars: от $1 до $100.')
    pay=growth_service.discounted_topup_cents(credit, first_topup=first_topup, referral=body.apply_referral or invited)
    stars=int((Decimal(pay)/100*MARKUP/RATE).to_integral_value(rounding=ROUND_CEILING))
    return {'credit_cents':credit,'pay_cents':pay,'stars':stars,'currency':'XTR','markup_percent':30,
            'period_discount_percent':payments_service.DISCOUNT_PCT[body.months] if body.plan_key else 0,
            'referral_discount_cents':credit-pay}

def quote_for(user_id,body):
    with session() as db:
        acct=wallet_service.account(db,user_id)
        if acct.frozen:raise HTTPException(409,'Баланс ограничен. Обратитесь в поддержку.')
        release_expired(db,user_id)
        if body.apply_referral and not growth_service.eligible(db,user_id):raise HTTPException(409,'Реферальная скидка недоступна.')
        return terms(body, not growth_service.activation(db,user_id)['activated'], growth_service.eligible(db,user_id))

def release_expired(db,user_id):
    rows=db.query(StarsInvoice).filter(StarsInvoice.user_id==user_id,StarsInvoice.state.in_(('created','sent','send_unknown','approved')),StarsInvoice.expires_at<=now()).with_for_update().all()
    for row in rows:
        topup=db.get(WalletTopup,row.topup_id)
        if row.checkout_id:
            # An approval can outlive the payable link. Keep the original
            # receipt identity and referral reservation for late settlement.
            row.state='awaiting_receipt'
            topup.status='review'
            continue
        row.state='expired';topup.status='expired'
        benefit=db.query(ReferralBenefit).filter_by(user_id=user_id).with_for_update().one_or_none()
        if benefit and benefit.consumed_topup_id==row.topup_id and benefit.consumed_at is None:benefit.consumed_topup_id=None
    if rows:
        # The wallet session disables autoflush. Subsequent eligibility and
        # pending-invoice queries in this transaction must see the expiry.
        db.flush()

def create_record(user_id,body):
    mark=hashlib.sha256(json.dumps(body.model_dump(mode='json',exclude={'request_key','expected_stars','expected_credit_cents','user_id'}),sort_keys=True).encode()).hexdigest()
    with session() as db:
        acct=wallet_service.account(db,user_id)
        release_expired(db,user_id)
        old=db.query(StarsInvoice).filter_by(user_id=user_id,request_key=body.request_key).one_or_none()
        if old:
            if old.fingerprint!=mark:raise HTTPException(409,'Этот запрос уже использован для другой суммы.')
            return invoice_out(old),False
        if acct.frozen:raise HTTPException(409,'Баланс ограничен. Обратитесь в поддержку.')
        link=db.get(StarsLink,user_id)
        if not link:raise HTTPException(409,'Сначала привяжите Telegram.')
        if db.query(StarsInvoice.id).filter(StarsInvoice.user_id==user_id,StarsInvoice.state.in_(('created','sent','send_unknown','approved'))).first():
            raise HTTPException(409,'Уже есть счёт Stars. Проверьте его статус.')
        wallet_service.expire_topups(db,user_id)
        if wallet_service.open_topups(db,user_id).first():
            raise HTTPException(409,'Сначала завершите или отмените другое пополнение.')
        q=terms(body, not growth_service.activation(db,user_id)['activated'], growth_service.eligible(db,user_id))
        if q['stars']!=body.expected_stars or q['credit_cents']!=body.expected_credit_cents:raise HTTPException(409,'Цена изменилась. Обновите расчёт.')
        benefit=None
        if body.apply_referral or growth_service.eligible(db,user_id):
            benefit=db.query(ReferralBenefit).filter_by(user_id=user_id).populate_existing().with_for_update().one_or_none()
            if not benefit or benefit.consumed_topup_id is not None:raise HTTPException(409,'Реферальная скидка уже использована или зарезервирована.')
        expiry=now()+timedelta(minutes=30)
        topup=WalletTopup(user_id=user_id,request_key=body.request_key,amount_cents=q['pay_cents'],provider='stars',status='pending',expires_at=expiry)
        db.add(topup);db.flush()
        row=StarsInvoice(id=uuid.uuid4(),topup_id=topup.id,user_id=user_id,telegram_id=link.telegram_id,request_key=body.request_key,fingerprint=mark,stars=q['stars'],credit_cents=q['credit_cents'],pay_cents=q['pay_cents'],state='created',expires_at=expiry)
        db.add(row)
        if q['pay_cents'] < q['credit_cents']:
            growth_service.bind_topup(db,topup,q['credit_cents'])
        if benefit:
            benefit.consumed_topup_id=topup.id
        db.flush()
        return invoice_out(row),True

def invoice_out(row):
    return {'id':str(row.id),'telegram_id':row.telegram_id,'stars':row.stars,'credit_cents':row.credit_cents,'state':row.state,'expires_at':row.expires_at,'debt_cents':row.debt_cents}

def mark_sent(ident,state):
    with session() as db:
        row=db.query(StarsInvoice).filter_by(id=uuid.UUID(ident)).with_for_update().one()
        if row.state=='created':row.state=state

def parse_id(value):
    try:return uuid.UUID(value) if isinstance(value,str) else None
    except ValueError:return None

def validate_payment(row,telegram_id,payment):
    return bool(row and type(telegram_id) is int and row.telegram_id==telegram_id and payment.get('currency')=='XTR' and type(payment.get('total_amount')) is int and payment['total_amount']==row.stars and parse_id(payment.get('invoice_payload'))==row.id)

def precheckout(query):
    ident=parse_id(query.get('invoice_payload'))
    if not enabled() or not ident or not isinstance(query.get('id'),str) or len(query['id'])>256:return False
    with session() as db:
        info=db.get(StarsInvoice,ident)
        if not info:return False
        acct=wallet_service.account(db,info.user_id)
        row=db.query(StarsInvoice).filter_by(id=ident).populate_existing().with_for_update().one()
        sender=query.get('from')
        if not isinstance(sender,dict):return False
        if not validate_payment(row,sender.get('id'),query) or acct.frozen:return False
        if row.checkout_id==query['id'] and row.state=='approved':return True
        if row.state not in ('created','sent','send_unknown') or utc(row.expires_at)<=now() or row.checkout_id:return False
        link=db.get(StarsLink,row.user_id)
        if not link or link.telegram_id!=row.telegram_id:return False
        row.checkout_id=query['id'];row.state='approved'
        return True

def settle(telegram_id,payment,refund=False):
    ident=parse_id(payment.get('invoice_payload'));charge=payment.get('telegram_payment_charge_id')
    if not ident or not isinstance(charge,str) or not 1<=len(charge)<=256:raise HTTPException(400,'Malformed payment')
    with session() as db:
        info=db.get(StarsInvoice,ident)
        if not info:raise HTTPException(409,'Unknown invoice; reconciliation required')
        acct=wallet_service.account(db,info.user_id)
        row=db.query(StarsInvoice).filter_by(id=ident).populate_existing().with_for_update().one()
        if not validate_payment(row,telegram_id,payment):raise HTTPException(409,'Payment mismatch')
        if row.charge_id and row.charge_id!=charge:raise HTTPException(409,'Second charge requires review')
        other=db.query(StarsInvoice.id).filter(StarsInvoice.charge_id==charge,StarsInvoice.id!=row.id).first()
        if other:raise HTTPException(409,'Charge already assigned')
        topup=db.query(WalletTopup).filter_by(id=row.topup_id).with_for_update().one()
        if row.refunded_at is not None:return
        if refund:
            if row.state=='paid':
                debit=min(int(acct.balance_cents),row.credit_cents)
                if debit:wallet_service.entry(db,acct,-debit,'refund','stars-refund:'+row.id.hex,'Telegram Stars refund')
                row.debt_cents=row.credit_cents-debit
                if row.debt_cents:acct.frozen=True
            row.refunded_at=now();row.state='refunded';row.charge_id=charge;topup.status='refunded';topup.provider_status='refunded'
            benefit=db.query(ReferralBenefit).filter_by(user_id=row.user_id).with_for_update().one_or_none()
            if benefit and benefit.consumed_topup_id==row.topup_id and benefit.consumed_at is None:benefit.consumed_at=now()
            return
        if row.state=='paid':return
        # Late authentic payments are honored even after a local deadline.
        wallet_service.entry(db,acct,row.pay_cents,'topup','stars:'+row.id.hex,'Telegram Stars top-up')
        if row.credit_cents>row.pay_cents:
            growth_service.credit_discount(db,acct,topup)
            if db.get(ReferralTopup,topup.id).applied_at is None:
                row.credit_cents=row.pay_cents
        row.state='paid';row.charge_id=charge
        topup.status='credited';topup.provider_status='paid';topup.credited_at=now();topup.checked_at=now();topup.live_notification=True

def link_new(user_id):
    raw=secrets.token_urlsafe(24)
    with session() as db:
        db.add(StarsLinkIntent(id=uuid.uuid4(),user_id=user_id,token_hash=hashlib.sha256(raw.encode()).hexdigest(),expires_at=now()+timedelta(minutes=10)))
    return {'url':'https://t.me/'+os.environ['PX_STARS_BOT_USERNAME']+'?start=px_'+raw}

def link_candidate(raw,telegram_id,name):
    with session() as db:
        row=db.query(StarsLinkIntent).filter_by(token_hash=hashlib.sha256(raw.encode()).hexdigest()).with_for_update().one_or_none()
        if not row or utc(row.expires_at)<=now() or row.confirmed:return False
        if row.telegram_id and row.telegram_id!=telegram_id:return False
        row.telegram_id=telegram_id;row.display_name=name[:160]
        return website_link_code(row)

def website_link_code(row):
    message = f'px-site-link-v1:{row.id}:{row.user_id}:{row.telegram_id}'.encode()
    digest = hmac.digest(os.environ['PX_STARS_WEBHOOK_SECRET'].encode(), message, 'sha256')
    return f'{int.from_bytes(digest, "big") % 100000000:08d}'

def link_confirm(user_id,body):
    with session() as db:
        # Serialize binding changes for the website account.
        wallet_service.account(db,user_id)
        row=db.query(StarsLinkIntent).filter_by(id=body.intent_id,user_id=user_id).with_for_update().one_or_none()
        if not row or row.confirmed or row.telegram_id!=body.telegram_id or utc(row.expires_at)<=now():raise HTTPException(409,'Привязка истекла или изменилась.')
        if not hmac.compare_digest(website_link_code(row),body.code):
            raise HTTPException(409,'Проверьте код из личного сообщения бота.')
        old=db.get(StarsLink,user_id)
        taken=db.query(StarsLink).filter_by(telegram_id=body.telegram_id).one_or_none()
        if (old and old.telegram_id!=body.telegram_id) or (taken and taken.user_id!=user_id):raise HTTPException(409,'Telegram уже привязан. Для смены обратитесь в поддержку.')
        if not old:db.add(StarsLink(user_id=user_id,telegram_id=body.telegram_id))
        row.confirmed=True
        return {'linked':True}

def status_for(user_id):
    with session() as db:
        wallet_service.account(db,user_id);release_expired(db,user_id)
        link=db.get(StarsLink,user_id)
        candidate=db.query(StarsLinkIntent).filter(StarsLinkIntent.user_id==user_id,StarsLinkIntent.telegram_id.isnot(None),StarsLinkIntent.confirmed.is_(False),StarsLinkIntent.expires_at>now()).order_by(StarsLinkIntent.expires_at.desc()).first()
        invoices=db.query(StarsInvoice).filter_by(user_id=user_id).order_by(StarsInvoice.topup_id.desc()).limit(10).all()
        return {'server_time':now(),'enabled':enabled(),'linked':bool(link),'telegram_id':link.telegram_id if link else None,'bot_url':'https://t.me/'+os.getenv('PX_STARS_BOT_USERNAME','') if configured() else None,'candidate':{'id':str(candidate.id),'telegram_id':candidate.telegram_id,'name':candidate.display_name} if candidate else None,'invoices':[invoice_out(x) for x in invoices]}

def verified_user(user=Depends(auth.get_current_user)):
    growth_service.ensure_verified(user)
    return user

@router.get('/status')
async def status(response:Response,user=Depends(verified_user)):
    response.headers['Cache-Control']='private, no-store'
    return await run_in_threadpool(status_for,user.id)

@router.post('/link')
async def start_link(user=Depends(verified_user)):
    require_enabled();auth.check_rate_limit('stars-link:'+str(user.id),10,600)
    return await run_in_threadpool(link_new,user.id)

@router.post('/link/confirm')
async def confirm_link(body:ConfirmLink,user=Depends(verified_user)):
    require_enabled()
    auth.check_rate_limit('stars-confirm:'+str(user.id),5,600)
    try:return await run_in_threadpool(link_confirm,user.id,body)
    except IntegrityError:raise HTTPException(409,'Этот Telegram уже привязан.') from None

@router.post('/quote')
async def quote(body:QuoteRequest,user=Depends(verified_user)):
    require_enabled();auth.check_rate_limit('stars-quote:'+str(user.id),60,300)
    return await run_in_threadpool(quote_for,user.id,body)

@router.post('/create-invoice')
async def create_invoice(body:InvoiceRequest,user=Depends(verified_user)):
    require_enabled();auth.check_rate_limit('stars-create:'+str(user.id),20,600)
    if body.user_id is not None and body.user_id!=user.id:raise HTTPException(403,'Чужой аккаунт.')
    if not body.accepted_terms:raise HTTPException(422,'Подтвердите условия оплаты.')
    try:row,fresh=await run_in_threadpool(create_record,user.id,body)
    except IntegrityError:raise HTTPException(409,'Запрос уже использован. Обновите статус платежей.') from None
    if fresh:
        try:
            await tg('sendInvoice',{'chat_id':row['telegram_id'],'title':'PulsarX balance','description':f"Credit ${row['credit_cents']/100:.2f}. Stars price includes a 30% merchant markup. VPS purchase is separate.",'payload':row['id'],'provider_token':'','currency':'XTR','prices':[{'label':'PulsarX balance','amount':row['stars']}],'start_parameter':'px_invoice'})
        except HTTPException:
            await run_in_threadpool(mark_sent,row['id'],'send_unknown')
            raise
        await run_in_threadpool(mark_sent,row['id'],'sent');row['state']='sent'
    return {**row,'bot_url':'https://t.me/'+os.environ['PX_STARS_BOT_USERNAME']}

@router.post('/webhook')
async def webhook(request:Request,x_telegram_bot_api_secret_token:str|None=Header(default=None)):
    secret=os.getenv('PX_STARS_WEBHOOK_SECRET','')
    if not secret or not x_telegram_bot_api_secret_token or not hmac.compare_digest(secret,x_telegram_bot_api_secret_token):raise HTTPException(403,'Forbidden')
    raw=bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw)>65536:raise HTTPException(413,'Body too large')
    try:
        update=json.loads(raw)
        if not isinstance(update,dict):raise ValueError()
    except (ValueError,UnicodeError):raise HTTPException(400,'Invalid JSON') from None
    q=update.get('pre_checkout_query')
    if isinstance(q,dict):
        valid=False
        try:
            valid=await asyncio.wait_for(run_in_threadpool(precheckout,q), timeout=3)
        except Exception:valid=False
        payload={'pre_checkout_query_id':str(q.get('id',''))[:256],'ok':valid}
        if not valid:payload['error_message']='Счёт недоступен или изменился. Проверьте его в кабинете PulsarX.'
        await tg('answerPreCheckoutQuery',payload)
        return {'ok':True}
    message=update.get('message',{})
    if not isinstance(message,dict):return {'ok':True}
    chat=message.get('chat',{})
    if not isinstance(chat,dict) or chat.get('type')!='private' or type(chat.get('id')) is not int:return {'ok':True}
    for key,refund in [('successful_payment',False),('refunded_payment',True)]:
        if isinstance(message.get(key),dict):
            try:await run_in_threadpool(settle,chat['id'],message[key],refund)
            except IntegrityError:raise HTTPException(409,'Payment needs review') from None
            return {'ok':True}
    words=str(message.get('text','')).split(maxsplit=1)
    command=words[0].split('@')[0] if words else ''
    reply=None
    if command=='/start' and len(words)==2 and re.fullmatch(r'px_[A-Za-z0-9_-]{32}',words[1]):
        user=message.get('from',{})
        if not isinstance(user,dict):return {'ok':True}
        if user.get('id')!=chat['id']:return {'ok':True}
        ok=await run_in_threadpool(link_candidate,words[1][3:],chat['id'],str(user.get('first_name',''))+' @'+str(user.get('username','')))
        reply=f'Код привязки: {ok}. Введите его в своём кабинете PulsarX, если вы запросили привязку.' if ok else 'Ссылка истекла. Создайте новую в кабинете PulsarX.'
    elif command in ('/start','/terms','/paysupport','/support'):
        reply='PulsarX: https://pulsarx.example.invalid/dashboard/?tab=wallet\nУсловия: https://pulsarx.example.invalid/terms/\nОплата и возвраты: https://pulsarx.example.invalid/support/\nПоддержку покупок оказывает PulsarX, а не Telegram.'
    if reply:
        response={'method':'sendMessage','chat_id':chat['id'],'text':reply}
        if command=='/start':
            if len(words)==1:response['text']='Откройте кошелёк PulsarX, чтобы привязать аккаунт и пополнить баланс звёздами.'
            response['reply_markup']={'inline_keyboard':[[{'text':'Открыть кошелёк','web_app':{'url':'https://pulsarx.example.invalid/mini-pay/'}}]]}
        return response
    return {'ok':True}

async def reconciliation_loop():
    while True:
        try:
            if configured():await reconcile()
        except asyncio.CancelledError:raise
        except Exception:log.warning('Stars reconciliation unavailable; saved receipts retained')
        await asyncio.sleep(120)

async def reconcile():
    """Authenticated reconciliation; bounded to 1000 most recent transactions."""
    if not configured():return
    for offset in range(0,1000,100):
        result=await tg('getStarTransactions',{'offset':offset,'limit':100})
        rows=result.get('transactions',[]) if isinstance(result,dict) else []
        for item in rows:
            if not isinstance(item,dict):continue
            partner=item.get('source') or item.get('receiver') or {}
            refund=bool(item.get('receiver'))
            if not isinstance(partner,dict):continue
            if partner.get('type')!='user' or partner.get('transaction_type')!='invoice_payment' or not partner.get('invoice_payload'):continue
            if item.get('nanostar_amount',0)!=0:continue
            payment={'currency':'XTR','total_amount':abs(item.get('amount',0)),'invoice_payload':partner['invoice_payload'],'telegram_payment_charge_id':item['id']}
            try:await run_in_threadpool(settle,partner.get('user',{}).get('id'),payment,refund)
            except HTTPException:log.warning('Stars reconciliation requires review')
        if len(rows)<100:return
    log.warning('Stars history exceeds bounded reconciliation window; manual full reconciliation required')

if __name__=='__main__':
    import sys
    if sys.argv[1:]==['--migrate']:init_schema()
    elif sys.argv[1:]==['--reconcile']:asyncio.run(reconcile())
    else:raise SystemExit('Use --migrate or --reconcile')

@router.get('/capabilities')
def capabilities():
    return {'release':'PORTAL-20261117-r1','enabled':enabled(),'currency':'XTR','markup_percent':30,'bot_url':'https://t.me/'+os.environ['PX_STARS_BOT_USERNAME'] if configured() else None}

# PulsarX Pay Mini App
from urllib.parse import parse_qsl
import time as _mt
class MiniPair(Base):
    __tablename__='px_mini_pair_v1'
    id=Column(UUID(as_uuid=True),primary_key=True)
    uid=Column(UUID(as_uuid=True),ForeignKey('users.id'),nullable=False,index=True)
    tid=Column(BigInteger,nullable=False,index=True)
    expires=Column(DateTime(timezone=True),nullable=False)
    attempts=Column(Integer,nullable=False,default=0)
    used=Column(Boolean,nullable=False,default=False)

@router.on_event('startup')
def _mini_schema():
    init_schema()
    MiniPair.__table__.create(engine,checkfirst=True)

def _tid(x_px_init:str=Header(default='')):
    require_enabled()
    bad=HTTPException(401,'Закройте и снова откройте мини-приложение через бота.')
    if not 1<=len(x_px_init)<=8192:raise bad
    try:
        pairs=parse_qsl(x_px_init,keep_blank_values=True,strict_parsing=True,max_num_fields=40)
        data=dict(pairs)
        if len(pairs)!=len(data):raise ValueError()
        sig=data.pop('hash')
        key=hmac.digest(b'WebAppData',os.environ['PX_STARS_BOT_TOKEN'].encode(),'sha256')
        if not hmac.compare_digest(sig,hmac.new(key,'\n'.join(k+'='+data[k] for k in sorted(data)).encode(),'sha256').hexdigest()):raise ValueError()
        if not -30<=_mt.time()-int(data['auth_date'])<=900:raise ValueError()
        tid=json.loads(data['user'])['id']
        if type(tid)!=int or not 0<tid<2**53:raise ValueError()
        return tid
    except (KeyError,ValueError,TypeError):raise bad from None

class MiniEmail(BaseModel):email:str=Field(min_length=3,max_length=254)
class MiniConfirm(BaseModel):
    id:uuid.UUID
    code:str=Field(pattern=r'^[0-9]{8}$')
def _pin(row):
    value=hmac.digest(os.environ['PX_STARS_WEBHOOK_SECRET'].encode(),f'px-mini-code-v1:{row.id}:{row.uid}:{row.tid}'.encode(),'sha256')
    return f'{int.from_bytes(value,"big")%100000000:08d}'
def _bound(db,tid):return db.query(StarsLink).filter_by(telegram_id=tid).one_or_none()

@router.post('/mini/request')
def mini_request(body:MiniEmail,tid=Depends(_tid)):
    auth.check_rate_limit('mini-req:'+str(tid),4,600)
    ident=uuid.uuid4()
    with session() as db:
        u=db.query(User).filter_by(email=body.email.strip().lower(),is_verified=True).with_for_update().one_or_none()
        if u and not _bound(db,tid) and not db.get(StarsLink,u.id):
            # At most one active prompt per account. Another Telegram cannot replace it.
            active=db.query(MiniPair).filter_by(uid=u.id,used=False).filter(MiniPair.expires>now()).first()
            if active and active.tid==tid:ident=active.id
            elif not active:db.add(MiniPair(id=ident,uid=u.id,tid=tid,expires=now()+timedelta(minutes=5)))
    return {'id':str(ident)}
@router.get('/mini/prompt')
def mini_prompt(response:Response,user=Depends(verified_user)):
    response.headers['Cache-Control']='private, no-store'
    with session() as db:
        row=db.query(MiniPair).filter_by(uid=user.id,used=False).filter(MiniPair.expires>now(),MiniPair.attempts<5).first()
        return {'prompt':None if not row else {'id':str(row.id),'telegram_id':str(row.tid),'code':_pin(row),'expires_at':row.expires}}
@router.post('/mini/confirm')
def mini_confirm(body:MiniConfirm,tid=Depends(_tid)):
    auth.check_rate_limit('mini-conf:'+str(tid),12,600)
    success=False
    try:
        with session() as db:
            row=db.query(MiniPair).filter_by(id=body.id,tid=tid,used=False).filter(MiniPair.expires>now(),MiniPair.attempts<5).with_for_update().one_or_none()
            if row:
                row.attempts+=1
                if hmac.compare_digest(_pin(row),body.code) and not db.get(StarsLink,row.uid) and not _bound(db,tid):
                    db.add(StarsLink(user_id=row.uid,telegram_id=tid));row.used=True;success=True
    except IntegrityError:success=False
    if not success:raise HTTPException(409,'Код неверен, истёк или аккаунт уже привязан.')
    return {'linked':True}
def _mini_uid(tid):
    with session() as db:
        link=_bound(db,tid)
        if not link or not db.get(User,link.user_id).is_verified:raise HTTPException(403,'Требуется привязка.')
        return link.user_id
@router.get('/mini/me')
def mini_me(response:Response,tid=Depends(_tid)):
    response.headers['Cache-Control']='private, no-store'
    with session() as db:
        link=_bound(db,tid)
        if not link:return {'linked':False,'telegram_id':str(tid)}
        user=db.get(User,link.user_id);growth_service.ensure_verified(user)
        account = wallet_service.account(db,user.id)
        release_expired(db,user.id)
        latest = db.query(StarsInvoice).filter_by(user_id=user.id,telegram_id=tid).order_by(StarsInvoice.topup_id.desc()).first()
        return {'linked':True,'email':user.email,'balance_cents':account.balance_cents,
                'frozen':account.frozen,'invoice':invoice_out(latest) if latest else None,
                'server_time':now()}
@router.post('/mini/quote')
def mini_quote(body:QuoteRequest,tid=Depends(_tid)):
    auth.check_rate_limit('mini-q:'+str(tid),60,300)
    return quote_for(_mini_uid(tid),body)
@router.post('/mini/invoice')
async def mini_invoice(body:InvoiceRequest,tid=Depends(_tid)):
    auth.check_rate_limit('mini-i:'+str(tid),15,300)
    if not body.accepted_terms or body.user_id is not None:raise HTTPException(422,'Проверьте условия.')
    uid=await run_in_threadpool(_mini_uid,tid)
    try:row,_=await run_in_threadpool(create_record,uid,body)
    except IntegrityError:raise HTTPException(409,'Обновите счёт.') from None
    return await mini_invoice_link(row)

@router.post('/mini/invoices/{invoice_id}/open')
async def open_saved_invoice(invoice_id:uuid.UUID,tid=Depends(_tid)):
    auth.check_rate_limit('mini-open:'+str(tid),15,300)
    def owned_invoice():
        uid = _mini_uid(tid)
        with session() as db:
            acct = wallet_service.account(db,uid)
            if acct.frozen:raise HTTPException(409,'Баланс ограничен.')
            row = db.query(StarsInvoice).filter_by(id=invoice_id,user_id=uid,telegram_id=tid).one_or_none()
            if row is None:raise HTTPException(404,'Счёт не найден.')
            return invoice_out(row)
    return await mini_invoice_link(await run_in_threadpool(owned_invoice))

async def mini_invoice_link(row):
    if row['state'] not in ('created','sent','send_unknown') or utc(row['expires_at'])<=now():raise HTTPException(409,'Счёт закрыт или уже обрабатывается.')
    url=await tg('createInvoiceLink',{'title':'Баланс PulsarX','description':f"Пополнение на ${row['credit_cents']/100:.2f}",'payload':row['id'],'currency':'XTR','provider_token':'','prices':[{'label':'Баланс','amount':row['stars']}]})
    if not isinstance(url,str) or not url.startswith('https://t.me/'):raise HTTPException(502,'Не удалось получить ссылку на счёт.')
    await run_in_threadpool(mark_sent,row['id'],'sent')
    return {'url':url,'id':row['id'],'expires_at':row['expires_at']}
