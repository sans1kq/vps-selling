"""Independent operator hold and user power-action entitlement policy."""
from datetime import datetime,timezone
from fastapi import HTTPException
from .trial_service import ensure_trial_active,utc


def ensure_not_held(server):
    if getattr(server,"admin_suspended_at",None) is not None:
        raise HTTPException(403,"This instance was suspended by an administrator. Contact support.")


def ensure_user_start_allowed(server):
    ensure_not_held(server)
    ensure_trial_active(server)
    now=datetime.now(timezone.utc)
    if server.ls_subscription_id:
        if server.payment_failed_at is not None:
            raise HTTPException(402,"Resolve the failed subscription payment before starting this instance")
        if server.subscription_cancelled_at is not None and (server.subscription_period_ends_at is None or utc(server.subscription_period_ends_at)<=now):
            raise HTTPException(402,"The subscription has ended. Contact support before restarting.")
    elif not server.trial_expires_at and server.paid_until is not None and utc(server.paid_until)<=now:
        raise HTTPException(402,"Renew this instance before starting it")
