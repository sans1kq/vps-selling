from .flex_capacity import require_resources
from .flex_catalog import is_upgrade
"""USD cents, account locks, an append-only application ledger and durable orders."""
import hashlib
import json
import logging
import uuid
from types import SimpleNamespace
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

from fastapi import HTTPException
from sqlalchemy import text, update
from sqlalchemy.dialects.postgresql import insert

from . import anypay_service, incus_service, payments_service, wallet_plisio, wallet_freekassa, wallet_rollypay
from .capacity_service import capacity_lock, require_capacity
from .config import get_settings
from .models import Payment, Server, ServerStatus
from .schemas import IMAGES, PLANS, PLAN_LIMITS
from .trial_service import is_trial
from .server_access import ensure_not_held
from .wallet_models import ACTIVE_ORDERS, WalletAccount, WalletEntry, WalletOrder, WalletTopup

settings = get_settings()
logger = logging.getLogger("pulsarx.wallet")
from . import growth_service as growth
OPEN_TOPUPS = ("pending", "creating")
MONEY_PENDING = ("paid", "partially-paid", "pending", "pending internal", "processing")


def now_utc():
    return datetime.now(timezone.utc)


def account(db, user_id):
    db.execute(insert(WalletAccount).values(user_id=user_id, balance_cents=0, frozen=False)
               .on_conflict_do_nothing(index_elements=["user_id"]))
    return db.query(WalletAccount).filter_by(user_id=user_id).populate_existing().with_for_update().one()


def entry(db, acct, amount, kind, reference, label):
    if type(amount) is not int or amount == 0:
        raise ValueError("Nonzero integer cents are required")
    result = db.execute(update(WalletAccount).where(
        WalletAccount.user_id == acct.user_id,
        WalletAccount.balance_cents + amount >= 0,
    ).values(balance_cents=WalletAccount.balance_cents + amount).returning(WalletAccount.balance_cents))
    balance = result.scalar_one_or_none()
    if balance is None:
        raise HTTPException(402, detail={"code": "insufficient_balance", "message": "Top up your balance before paying.",
                                        "required_cents": -amount, "balance_cents": acct.balance_cents})
    db.add(WalletEntry(user_id=acct.user_id, amount_cents=amount, balance_after_cents=balance,
                       kind=kind, reference=reference, label=label[:160]))
    db.flush()
    return balance


def summary(db, user_id):
    from . import telegram_stars
    acct = account(db, user_id)
    telegram_stars.release_expired(db, user_id)
    expire_topups(db, user_id)
    pending = open_topups(db, user_id).order_by(WalletTopup.created_at.desc(), WalletTopup.id.desc()).all()
    providers = [name for name, ready in (("freekassa", wallet_freekassa.enabled()),
                 ("plisio", wallet_plisio.enabled()), ("rollypay", wallet_rollypay.enabled()),
                 ("anypay", anypay_service.enabled() and settings.wallet_anypay_checkout_enabled),
                 ("stars", telegram_stars.enabled())) if ready]
    result = {"currency": "USD", "balance_cents": acct.balance_cents, "frozen": acct.frozen,
              "topup_available": bool(providers), "providers": providers,
              "pending_topup": topup_out(pending[0]) if pending else None, "pending_count": len(pending),
              "server_time": now_utc(), "min_topup_cents": settings.wallet_min_topup_cents,
              "max_topup_cents": settings.wallet_max_topup_cents}
    result["referral"]=growth.status(db,user_id)
    db.commit()
    return result


def payment_evidence(row):
    if row.provider == "rollypay":
        return wallet_rollypay.paid_evidence(row)
    return row.provider_status in MONEY_PENDING


def expire_topups(db, user_id):
    # An old SCI checkout must never be resumed or recreated through the API.
    # Keep the record available for authenticated late-payment reconciliation.
    db.query(WalletTopup).filter(WalletTopup.user_id == user_id,
        WalletTopup.provider == "freekassa", WalletTopup.provider_method.is_(None),
        WalletTopup.status.in_(OPEN_TOPUPS), WalletTopup.credited_at.is_(None),
        WalletTopup.live_notification.is_(False),
    ).update({WalletTopup.status: "closed"}, synchronize_session="fetch")
    if not anypay_service.enabled():
        # AnyPay was explicitly disabled by the operator. Retain every record,
        # but an old uncredited invoice must not block the remaining providers.
        db.query(WalletTopup).filter(WalletTopup.user_id == user_id,
            WalletTopup.provider == "anypay", WalletTopup.status.in_(OPEN_TOPUPS),
            WalletTopup.credited_at.is_(None),
        ).update({WalletTopup.status: "closed"}, synchronize_session="fetch")
    # RollyPay processing means QR activation, not received funds.
    # A durable paid receipt keeps a payment protected even if a later API
    # response is stale. Other providers retain their existing state rules.
    rolly_paid = db.query(wallet_rollypay.RollyReceipt.topup_id).filter(
        wallet_rollypay.RollyReceipt.status == "paid")
    # The local checkout deadline never cancels a transfer at the provider.
    # Signed receipts and authenticated late settlements still credit once.
    db.query(WalletTopup).filter(
        WalletTopup.user_id == user_id, WalletTopup.status.in_(OPEN_TOPUPS),
        WalletTopup.expires_at <= now_utc(), WalletTopup.provider != "stars",
        ((WalletTopup.provider_status.is_(None) | ~WalletTopup.provider_status.in_(MONEY_PENDING)) |
         ((WalletTopup.provider == "rollypay") & (WalletTopup.provider_status == "processing"))),
        ((WalletTopup.provider != "rollypay") | ~WalletTopup.id.in_(rolly_paid)),
    ).update({WalletTopup.status: "expired"}, synchronize_session="fetch")


def open_topups(db, user_id):
    return db.query(WalletTopup).filter(WalletTopup.user_id == user_id, WalletTopup.status.in_(OPEN_TOPUPS))


def new_topup(db, user, amount_cents, request_key, provider_name="anypay", provider_method=None, rollypay_quote=None, referral_credit_cents=None):
    if provider_name == "rollypay":
        if provider_method is not None:
            raise HTTPException(400, "A KASSA method cannot be used with RollyPay")
        return wallet_rollypay.new_topup(db, user, amount_cents, request_key, rollypay_quote, referral_credit_cents)
    if provider_name not in ("anypay", "plisio", "freekassa"):
        raise HTTPException(400, "Unknown payment provider")
    ready = {"anypay": anypay_service.enabled() and settings.wallet_anypay_checkout_enabled,
             "plisio": wallet_plisio.enabled(), "freekassa": wallet_freekassa.enabled()}
    if not ready[provider_name]:
        raise HTTPException(503, "Balance top-ups are temporarily unavailable")
    if provider_name == "freekassa":
        provider_method = 44 if provider_method is None else provider_method
        if type(provider_method) is not int or provider_method not in wallet_freekassa.METHODS:
            raise HTTPException(400, "Unknown KASSA payment method")
    elif provider_method is not None:
        raise HTTPException(400, "A KASSA method cannot be used with another provider")
    if not user.is_verified:
        raise HTTPException(403, "Verify your email first")
    if type(amount_cents) is not int or not settings.wallet_min_topup_cents <= amount_cents <= settings.wallet_max_topup_cents:
        raise HTTPException(400, "Amount is outside the permitted top-up range")
    acct = account(db, user.id)
    if acct.frozen:
        raise HTTPException(409, "Balance is under review. Please contact support.")
    previous = db.query(WalletTopup).filter_by(user_id=user.id, request_key=request_key).one_or_none()
    if previous:
        growth.verify_terms(db,previous,referral_credit_cents)
        if (previous.amount_cents != amount_cents or previous.provider != provider_name
                or previous.provider_method != provider_method):
            raise HTTPException(409, "This request key was already used for a different top-up")
        db.commit()
        return previous
    expire_topups(db, user.id)
    active = open_topups(db, user.id).order_by(WalletTopup.created_at.desc(), WalletTopup.id.desc()).first()
    if active:
        growth.verify_terms(db,active,referral_credit_cents)
        if (active.amount_cents == amount_cents and active.provider == provider_name
                and active.provider_method == provider_method):
            db.commit()
            return active
        raise HTTPException(409, detail={"code": "active_topup", "message": "Continue or close your open invoice first.",
                                         "topup_id": str(active.id)})
    lifetime = max(15, min(1440, settings.invoice_expire_min)) if provider_name == "plisio" else 24 * 60
    row = WalletTopup(user_id=user.id, amount_cents=amount_cents, request_key=request_key,
                      provider=provider_name, provider_method=provider_method,
                      status="creating" if provider_name in ("plisio", "freekassa") else "pending",
                      expires_at=now_utc() + timedelta(minutes=lifetime))
    db.add(row)
    db.flush()
    growth.bind_topup(db,row,referral_credit_cents)
    if row.id >= 10**15:
        raise RuntimeError("AnyPay order number limit reached")
    db.commit()
    return row


def checkout_topup(db, user, pay_id, payer_ip=None):
    saved = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).one_or_none()
    if saved is not None and saved.provider == "stars":
        raise HTTPException(409, "Откройте счёт в Telegram из раздела Stars.")
    if saved is not None and saved.provider == "rollypay":
        return wallet_rollypay.checkout(db, user, pay_id)
    acct = account(db, user.id)
    expire_topups(db, user.id)
    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).populate_existing().with_for_update().one_or_none()
    if row is None:
        raise HTTPException(404, "Top-up not found")
    if acct.frozen or not topup_out(row)["can_resume"]:
        db.commit()
        raise HTTPException(409, "This invoice is no longer open for payment")
    if row.provider == "anypay":
        checkout_url = anypay_service.checkout(row, user.email)
    elif row.provider == "freekassa":
        if row.checkout_url:
            if not wallet_freekassa.saved_checkout_ok(row):
                raise anypay_service.ProviderUnavailable("Invalid saved KASSA checkout", reason="invalid_result")
            checkout_url = row.checkout_url
        else:
            if row.provider_create_started_at:
                db.commit()
                raise HTTPException(409, detail={"code": "checkout_uncertain", "message":
                    "The processor request was already sent. Check this invoice or contact support; it will not be created twice."})
            # Read-only availability validation may be retried; it never creates
            # an invoice. Commit the creation intent BEFORE the mutating API call.
            method = next((m for m in wallet_freekassa.available_methods() if m["id"] == row.provider_method), None)
            if method is None:
                raise anypay_service.ProviderUnavailable("KASSA method is unavailable", reason="configuration")
            wallet_freekassa.validate_amount(method, row.amount_cents)
            wallet_freekassa.method_available(row.provider_method)
            row.provider_create_started_at = now_utc()
            db.commit()
            try:
                txn, checkout_url = wallet_freekassa.create(row, user.email, payer_ip or settings.freekassa_payer_ip)
            except anypay_service.ProviderUnavailable as exc:
                logger.warning("KASSA checkout failed: %s", {
                    "topup_id": str(pay_id), "method_id": row.provider_method,
                    "reason": exc.reason, "http_status": exc.http_status,
                    "provider_error": getattr(exc, "fk_error", None)})
                ident = getattr(exc, "fk_order_id", None)
                limits = getattr(exc, "fk_amount_limits", None)
                if limits and not ident:
                    account(db, user.id)
                    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).populate_existing().with_for_update().one()
                    # Only the explicit HTTP 400 amount rejection permits this
                    # path. A timeout/unknown response must retain its intent.
                    if row.status in OPEN_TOPUPS and not row.credited_at and not row.live_notification and not row.transaction_id and row.provider_status not in MONEY_PENDING:
                        row.status = "closed"
                        row.provider_status = "amount_out_of_range"
                        db.commit()
                        raise wallet_freekassa.AmountOutsideLimits(row.provider_method, limits) from None
                if ident:
                    account(db, user.id)
                    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).populate_existing().with_for_update().one()
                    txn = "fk:" + ident
                    if row.transaction_id and row.transaction_id != txn:
                        row.status = "review"
                    else:
                        row.transaction_id = txn
                        row.checkout_url = getattr(exc, "fk_location", None)
                        row.provider_status = "checkout_invalid"
                    db.commit()
                raise
            account(db, user.id)
            row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).populate_existing().with_for_update().one()
            if row.transaction_id and row.transaction_id != txn:
                row.status = "review"
                db.commit()
                raise anypay_service.ProviderUnavailable("KASSA order conflict", reason="transaction_mismatch")
            row.transaction_id, row.checkout_url = txn, checkout_url
            if row.status == "creating":
                row.status = "pending"
            if not topup_out(row)["can_resume"]:
                db.commit()
                raise HTTPException(409, "Invoice was closed or paid while the checkout was being prepared")
    else:
        if not row.checkout_url:
            # Serialize provider creation with new/cancel requests for this user.
            # The committed local row survives a lost provider response.
            txn, checkout_url = wallet_plisio.create(row, user.email)
            row.transaction_id, row.checkout_url, row.status = txn, checkout_url, "pending"
        checkout_url = row.checkout_url
        if not wallet_plisio.checkout_ok(checkout_url):
            raise anypay_service.ProviderUnavailable("Invalid saved Plisio checkout", reason="invalid_result")
    result = topup_out(row)
    result["checkout_url"] = checkout_url
    if row.provider == "freekassa":
        result["checkout_api_verified"] = bool(wallet_freekassa.api_checkout_provenance(row) and wallet_freekassa.saved_checkout_ok(row))
    db.commit()
    return result


def cancel_topup(db, user_id, pay_id):
    account(db, user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user_id).populate_existing().with_for_update().one_or_none()
    if row is None:
        raise HTTPException(404, "Top-up not found")
    if row.provider == "stars":
        raise HTTPException(409, "Счёт Stars истекает автоматически. Подтверждённый платёж требует проверки.")
    if row.credited_at or payment_evidence(row) or row.status == "review":
        raise HTTPException(409, "A received payment is being confirmed; do not create another invoice")
    if row.status in OPEN_TOPUPS:
        row.status = "cancelled"
    db.commit()
    return topup_out(row)


def receive_notification(db, data):
    if not anypay_service.enabled():
        raise HTTPException(410, "AnyPay processing has been disabled")
    pay_id, amount = anypay_service.validate_notification(data)
    info = db.get(WalletTopup, pay_id)
    if info is None or info.provider != "anypay":
        raise HTTPException(404, "Unknown top-up")
    acct = account(db, info.user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id).populate_existing().with_for_update().one()
    if row.amount_cents != amount:
        raise HTTPException(400, "Wrong payment amount")
    if data["test"] == "1":
        # Do not persist a usable live receipt, even if the project is in test mode.
        db.rollback()
        return None
    txn = data["transaction_id"]
    conflict = db.query(WalletTopup.id).filter(WalletTopup.transaction_id == txn, WalletTopup.id != row.id).first()
    if conflict or (row.transaction_id and row.transaction_id != txn):
        row.status = "review"
        acct.frozen = True
        db.commit()
        logger.error("AnyPay top-up %s has conflicting transaction identifiers; manual review required", pay_id)
        raise HTTPException(409, "Payment requires review")
    row.transaction_id = txn
    row.provider_status = data["status"]
    row.live_notification = True
    row.checked_at = None
    if data["status"] == "refund" and row.credited_at:
        row.status = "review"
        acct.frozen = True
        logger.error("AnyPay top-up %s was reversed; balance held for review", pay_id)
    db.commit()  # A provider outage after this point is recovered by the timer.
    return row.id


def settle_topup(db, pay_id, transaction_hint=None):
    info = db.get(WalletTopup, pay_id)
    if info is None:
        return None
    if info.provider == "stars":
        return info  # Only authenticated Telegram receipt/reconciliation may credit Stars.
    if info.provider == "rollypay":
        return wallet_rollypay.settle(db, info)
    if info.provider == "plisio":
        return settle_plisio(db, info, transaction_hint)
    if info.provider == "freekassa":
        return settle_freekassa(db, info)
    if info.provider != "anypay":
        raise anypay_service.ProviderUnavailable("Unknown payment provider", reason="configuration")
    if not anypay_service.enabled():
        raise HTTPException(410, "AnyPay processing has been disabled")
    user_id = info.user_id
    provider = anypay_service.lookup(pay_id, info.transaction_id)
    acct = account(db, user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id).populate_existing().with_for_update().one()
    row.checked_at = now_utc()
    if provider is None:
        db.commit()
        return row
    try:
        matches = (str(provider["pay_id"]) == str(row.id)
                   and anypay_service.cents(provider["amount"]) == row.amount_cents
                   and str(provider["currency"]).upper() == "USD"
                   and (not row.transaction_id or str(provider["transaction_id"]) == row.transaction_id))
    except (KeyError, ValueError):
        matches = False
    if not matches:
        row.status = "review"
        if row.credited_at:
            acct.frozen = True
        db.commit()
        logger.error("AnyPay top-up %s does not match the verified invoice; manual review required", pay_id)
        return row
    state = provider.get("status")
    row.provider_status = state
    if state == "refund" and row.credited_at:
        # A refund may concern funds already spent. Never create a negative wallet
        # or silently take payment twice; hold the account for operator review.
        row.status = "review"
        acct.frozen = True
    elif row.credited_at:
        pass  # An out-of-order waiting/canceled notification cannot undo a credit.
    elif state == "paid" and row.live_notification and row.status != "review" and str(provider.get("test", "0")) == "0":
        txn = str(provider["transaction_id"])
        other = db.query(WalletTopup.id).filter(WalletTopup.transaction_id == txn, WalletTopup.id != row.id).first()
        if other:
            row.status = "review"
        else:
            row.transaction_id = txn
            entry(db, acct, row.amount_cents, "topup", f"anypay:{row.id}", "AnyPay top-up")
            growth.credit_discount(db,acct,row)
            row.status, row.credited_at = "credited", now_utc()
    elif state in ("canceled", "expired", "error", "refund"):
        row.status = "expired" if state == "expired" else "closed"
    db.commit()
    return row


def receive_freekassa_notification(db, data):
    pay_id, amount = wallet_freekassa.validate_notification(data)
    info = db.get(WalletTopup, pay_id)
    if info is None or info.provider != "freekassa":
        raise HTTPException(404, "Unknown top-up")
    account(db, info.user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id).populate_existing().with_for_update().one()
    if row.amount_cents != amount:
        raise HTTPException(400, "Wrong payment amount")
    # intid is not covered by the notification signature. Store it only as a hint;
    # crediting requires an exact independent API match.
    row.provider_hint = data["intid"]
    row.live_notification = True
    row.checked_at = None
    db.commit()
    return pay_id


def settle_freekassa(db, info):
    provider = wallet_freekassa.lookup(info.id)
    acct = account(db, info.user_id)
    row = db.query(WalletTopup).filter_by(id=info.id).populate_existing().with_for_update().one()
    row.checked_at = now_utc()
    if provider is None:
        db.commit()
        return row
    txn = "fk:" + str(provider["fk_order_id"])
    try:
        matches = (str(provider["merchant_order_id"]) == str(row.id)
                   and anypay_service.cents(provider["amount"]) == row.amount_cents
                   and provider.get("currency") == "USD"
                   and (not row.transaction_id or row.transaction_id == txn))
    except (KeyError, ValueError):
        matches = False
    test = any(str(provider.get(k, "0")).lower() not in ("0", "false", "none", "")
               for k in ("test", "is_test", "test_mode"))
    if not matches or test:
        row.status = "review"
        if row.credited_at:
            acct.frozen = True
    else:
        state = str(provider["status"])
        row.provider_status = {"0": "waiting", "1": "paid", "6": "refund", "8": "error", "9": "canceled"}[state]
        if row.status == "creating" and state in ("0", "1"):
            row.status = "pending"
        if state == "6" and row.credited_at:
            row.status = "review"
            acct.frozen = True
        elif row.credited_at:
            pass
        elif state == "1" and row.live_notification and row.status != "review":
            # A callback hint mismatch cannot authorize a different transaction.
            if row.provider_hint and row.provider_hint != str(provider["fk_order_id"]):
                db.commit()
                raise anypay_service.ProviderUnavailable("FreeKassa receipt mismatch", reason="transaction_mismatch")
            conflict = db.query(WalletTopup.id).filter(WalletTopup.transaction_id == txn, WalletTopup.id != row.id).first()
            if conflict:
                row.status = "review"
            else:
                row.transaction_id = txn
                entry(db, acct, row.amount_cents, "topup", f"freekassa:{row.id}", "FreeKassa top-up")
                growth.credit_discount(db,acct,row)
                row.status, row.credited_at = "credited", now_utc()
        elif state in ("6", "8", "9"):
            row.status = "closed"
    db.commit()
    return row


def settle_plisio(db, info, transaction_hint=None):
    transaction_hint = transaction_hint or info.provider_hint
    # A valid callback may beat the response that saved the original invoice.
    # Recover its ID only from the authenticated matching Plisio operation.
    recovered = None
    if not info.transaction_id and transaction_hint:
        candidate = wallet_plisio.operation(transaction_hint)
        signed_candidate = wallet_plisio.notification_matches(candidate, info)
        if not wallet_plisio.matches(candidate, info) and not signed_candidate:
            raise anypay_service.ProviderUnavailable("Unrelated Plisio payment", reason="transaction_mismatch")
        root_id = candidate.get("parent_id") or candidate["id"]
        root = candidate if root_id == candidate["id"] else wallet_plisio.operation(root_id)
        if not wallet_plisio.matches(root, info) and not (signed_candidate and wallet_plisio.metadata_compatible(root, info)):
            raise anypay_service.ProviderUnavailable("Unrelated Plisio parent", reason="transaction_mismatch")
        recovered = root_id
    lookup_info = (SimpleNamespace(id=info.id, amount_cents=info.amount_cents, transaction_id=recovered,
                                  provider="plisio", provider_hint=info.provider_hint)
                   if recovered else info)
    provider = wallet_plisio.lookup(lookup_info, transaction_hint)
    acct = account(db, info.user_id)
    row = db.query(WalletTopup).filter_by(id=info.id).populate_existing().with_for_update().one()
    if recovered:
        if row.transaction_id and row.transaction_id != recovered:
            raise anypay_service.ProviderUnavailable("Plisio recovery conflict", reason="transaction_mismatch")
        row.transaction_id = recovered
        row.checkout_url = "https://plisio.net/invoice/" + recovered
    row.checked_at = now_utc()
    if provider is not None:
        state = provider["status"]
        previous_state = row.provider_status
        row.provider_status = state
        if row.credited_at:
            pass
        elif state == "completed" and (row.status != "review" or previous_state in ("expired", "cancelled", "error")):
            entry(db, acct, row.amount_cents, "topup", f"plisio:{row.id}", "Plisio top-up")
            growth.credit_discount(db,acct,row)
            row.status, row.credited_at = "credited", now_utc()
        elif state in ("pending", "pending internal"):
            row.status = "pending"
        elif state == "mismatch":
            row.status = "review"
        elif state in ("expired", "cancelled", "error"):
            try:
                partial = any(Decimal(str(provider.get(key, 0) or 0)) > 0
                              for key in ("amount", "actual_sum", "pending_sum"))
            except InvalidOperation:
                partial = True
            row.status = "review" if partial else "expired" if state == "expired" else "closed"
    db.commit()
    return row


def record_plisio_notification(db, pay_id, data):
    info = db.get(WalletTopup, pay_id)
    if info is None or info.provider != "plisio":
        raise HTTPException(404, "Unknown top-up")
    try:
        if str(data.get("source_currency", "")).upper() != "USD" or wallet_plisio.cents(data.get("source_amount")) != info.amount_cents:
            raise ValueError("Wrong callback amount")
    except ValueError:
        raise HTTPException(400, "Wrong payment amount") from None
    account(db, info.user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id).populate_existing().with_for_update().one()
    # A late duplicate/cancellation callback for the old currency must not
    # overwrite the already validated completed notification for the paid ID.
    # For Plisio only, live_notification records that such a notification was
    # received; API status is still required before any wallet credit.
    completed_notice = data.get("status") == "completed"
    if not row.credited_at:
        if completed_notice and row.live_notification and row.provider_hint != data["txn_id"]:
            row.status, row.provider_status = "review", "receipt_conflict"
        elif completed_notice or not row.live_notification:
            row.provider_hint = data["txn_id"]
            if completed_notice:
                row.live_notification = True
    row.checked_at = None
    # Store the authenticated hint before the API request. It does not credit
    # funds, and a timer can recover even when the callback API lookup fails.
    db.commit()


def active_order(db, server_id):
    return db.query(WalletOrder.id).filter(WalletOrder.server_id == server_id,
                                           WalletOrder.status.in_(ACTIVE_ORDERS)).first() is not None


def ensure_idle(db, server_id):
    if active_order(db, server_id):
        raise HTTPException(409, "An operation paid from your balance is still being processed")


def fingerprint(kind, payload):
    encoded = json.dumps({"kind": kind, **payload}, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode()).hexdigest()


def purchase(db, user, request_key, kind, plan=None, image=None, months=1, server_id=None,
             quote_only=False, expected_amount_cents=None):
    from . import gift_renewal
    gift_grant = None
    if not user.is_verified:
        raise HTTPException(403, "Verify your email first")
    if kind not in ("new", "renew", "upgrade") or months not in payments_service.PERIOD_DAYS:
        raise HTTPException(400, "Invalid purchase")
    mark = fingerprint(kind, {"plan": plan, "image": image, "months": months, "server_id": server_id})
    # The same slot lock is shared with the legacy checkout. Capacity reservations
    # and wallet debits commit together, before a worker creates any resources.
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": payments_service.SLOT_LOCK})
    if kind in ("new", "upgrade"):
        capacity_lock(db)
    acct = account(db, user.id)
    old = db.query(WalletOrder).filter_by(user_id=user.id, request_key=request_key).one_or_none()
    if old:
        if old.fingerprint != mark:
            raise HTTPException(409, "This request key was already used for a different order")
        db.commit()
        return old
    if acct.frozen:
        raise HTTPException(409, "Balance is under review. Please contact support.")
    now = now_utc()
    if kind == "new":
        if plan not in PLANS or image not in IMAGES:
            raise HTTPException(400, "Unknown plan or operating system")
        spec = PLANS[plan]
        require_resources(db, spec)
        server = Server(id=uuid.uuid4(), container_name=incus_service.generate_container_name(),
                        owner_id=user.id, owner_email=user.email, plan=plan, image=image,
                        ram_mb=spec["ram_mb"], cpu_cores=spec["cpu_cores"], disk_gb=spec["disk_gb"],
                        status=ServerStatus.pending)
        db.add(server)
        amount = int(payments_service.price_usd(plan, months) * 100)
    else:
        server = db.query(Server).filter_by(id=server_id, owner_id=user.id).populate_existing().with_for_update().one_or_none()
        if server is None:
            raise HTTPException(404, "Instance not found")
        ensure_not_held(server)
        if is_trial(server):
            gift_grant = gift_renewal.prepare(db, server, kind)
        if server.ls_subscription_id or server.subscription_cancelled_at or (server.paid_until is None and gift_grant is None):
            raise HTTPException(409, "This instance uses a different billing method")
        if server.status not in (ServerStatus.running, ServerStatus.suspended):
            raise HTTPException(409, "Instance must be running or suspended")
        ensure_idle(db, server.id)
        # Do not race an outstanding externally paid invoice against a wallet order.
        pending = db.query(Payment.id).filter(Payment.server_id == server.id,
            Payment.status.in_(("created", "pending", "needs_review")),
            Payment.expires_at > now - timedelta(hours=24)).first()
        if pending or server.upgrade_target_plan:
            raise HTTPException(409, "Finish the existing payment or upgrade request first")
        if kind == "renew":
            plan = server.plan
            amount = int(payments_service.price_usd(plan, months) * 100)
        else:
            if not is_upgrade(server.plan,plan) or server.paid_until <= now or months != 1:
                raise HTTPException(409, "Renew an active instance before choosing a higher plan")
            amount = int(payments_service.upgrade_price_usd(server, plan, now) * 100)
            require_resources(db,PLANS[plan],server.container_name)
    if quote_only:
        result = {"currency": "USD", "amount_cents": amount, "balance_cents": acct.balance_cents,
                  "shortfall_cents": max(0, amount - acct.balance_cents)}
        db.rollback()
        return result
    if expected_amount_cents is None or expected_amount_cents != amount:
        raise HTTPException(409, "The price changed. Review the current price and confirm again.")
    order = WalletOrder(id=uuid.uuid4(), user_id=user.id, request_key=request_key, fingerprint=mark,
                        server_id=server.id, container_name=server.container_name,
                        kind=kind, plan=plan, months=months, amount_cents=amount)
    db.add(order)
    db.flush()
    entry(db, acct, -amount, "purchase", f"order:{order.id}:debit", f"{kind}: {server.container_name} / {plan}")
    if kind == "renew" and server.status == ServerStatus.running:
        if gift_grant is not None:
            gift_renewal.complete(server, gift_grant, now, months)
        else:
            server.paid_until = max(server.paid_until, now) + timedelta(days=payments_service.PERIOD_DAYS[months])
        server.payment_failed_at = server.last_dunning_email_sent_at = None
        order.status, order.completed_at = "completed", now
    db.commit()
    return order


def order_out(order):
    return {"id": str(order.id), "server_id": str(order.server_id) if order.server_id else None,
            "kind": order.kind, "plan": order.plan, "months": order.months,
            "amount_cents": order.amount_cents, "status": order.status,
            "error_code": order.error_code, "created_at": order.created_at, "completed_at": order.completed_at}


def topup_out(row):
    disabled = row.provider == "stars" or (row.provider == "anypay" and not anypay_service.enabled())
    payment_in_progress = not disabled and payment_evidence(row)
    open_now = not disabled and row.status in OPEN_TOPUPS and (row.expires_at > now_utc() or payment_in_progress)
    result = {"id": str(row.id), "amount_cents": row.amount_cents, "currency": "USD",
            "provider_method": row.provider_method,
            "provider": row.provider, "can_resume": bool(open_now and not payment_in_progress),
            "can_cancel": bool(open_now and not payment_in_progress), "payment_in_progress": payment_in_progress,
            "status": row.status, "provider_status": row.provider_status,
            "awaiting_notification": row.provider in ("anypay", "freekassa") and row.provider_status == "paid" and not row.live_notification,
            "created_at": row.created_at, "expires_at": row.expires_at, "credited_at": row.credited_at}

    if row.provider == "rollypay":
        result.update(wallet_rollypay.extra(row))
    result.update(growth.topup_extra(row))
    return result
