import ipaddress
import json
import re
import uuid
from email.parser import BytesParser
from email.policy import default as email_policy
from typing import Literal
from urllib.parse import parse_qsl

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field, StrictInt
from sqlalchemy.orm import Session

from .. import auth, anypay_service, wallet_service, wallet_plisio, wallet_freekassa
from ..capacity_service import StorageCapacityError
from ..config import get_settings
from ..database import get_db
from ..models import User
from ..wallet_models import WalletEntry, WalletOrder, WalletTopup

router = APIRouter(prefix="/api/wallet", tags=["wallet"])
settings = get_settings()


class TopupRequest(BaseModel):
    amount_cents: StrictInt = Field(gt=0, le=1_000_000)
    request_key: uuid.UUID
    apply_referral: bool = False
    expected_payable_cents: StrictInt | None = Field(default=None,gt=0)
    rollypay_quote: str | None = Field(default=None, max_length=2048)
    provider: Literal["anypay", "plisio", "freekassa", "rollypay"] = "anypay"
    provider_method: StrictInt | None = None


class PurchaseRequest(BaseModel):
    request_key: uuid.UUID
    kind: str
    plan: str | None = None
    image: str | None = None
    months: StrictInt = 1
    server_id: uuid.UUID | None = None
    expected_amount_cents: StrictInt | None = Field(default=None, gt=0)


@router.get("")
def get_wallet(user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return wallet_service.summary(db, user.id)


@router.get("/history")
def history(offset: int = Query(0, ge=0), limit: int = Query(30, ge=1, le=100),
            user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    rows = db.query(WalletEntry).filter_by(user_id=user.id).order_by(WalletEntry.created_at.desc(), WalletEntry.id.desc()).offset(offset).limit(limit + 1).all()
    return {"items": [{"id": str(r.id), "amount_cents": r.amount_cents,
                       "balance_after_cents": r.balance_after_cents, "kind": r.kind,
                       "label": r.label, "created_at": r.created_at} for r in rows[:limit]], "has_more": len(rows) > limit}


@router.get("/topups")
def topups(user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    wallet_service.account(db, user.id)
    wallet_service.expire_topups(db, user.id)
    rows = db.query(WalletTopup).filter_by(user_id=user.id).order_by(WalletTopup.created_at.desc()).limit(30).all()
    result = [wallet_service.topup_out(r) for r in rows]
    db.commit()
    return result


@router.post("/topups")
def create_topup(payload: TopupRequest, request: Request, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-topup:{user.id}", 20, 3600)
    pay_cents,credit_cents=wallet_service.growth.request_terms(db,user,payload)
    # Preserve existing idempotent requests, but reject an invalid new USD
    # amount before inserting even a local invoice. Metadata is server-fetched.
    previous = db.query(WalletTopup.id).filter_by(user_id=user.id, request_key=payload.request_key).first()
    if payload.provider == "freekassa" and previous is None:
        try:
            ident = payload.provider_method if payload.provider_method is not None else 44
            if ident not in wallet_freekassa.METHODS:
                raise HTTPException(400, "Unknown KASSA payment method")
            method = next((m for m in wallet_freekassa.available_methods() if m["id"] == ident), None)
            if method is None:
                raise HTTPException(503, "KASSA method is temporarily unavailable")
            wallet_freekassa.validate_amount(method, pay_cents)
        except wallet_freekassa.AmountOutsideLimits as exc:
            raise amount_limit_error(exc) from None
        except anypay_service.ProviderUnavailable:
            raise HTTPException(503, "KASSA methods are temporarily unavailable") from None
    row = wallet_service.new_topup(db, user, pay_cents, payload.request_key, payload.provider, payload.provider_method, rollypay_quote=payload.rollypay_quote,referral_credit_cents=credit_cents)
    data = wallet_service.topup_out(row)
    if data["can_resume"]:
        try:
            return wallet_service.checkout_topup(db, user, row.id, checkout_ip(request))
        except wallet_freekassa.AmountOutsideLimits as exc:
            db.rollback()
            raise amount_limit_error(exc) from None
        except anypay_service.ProviderUnavailable:
            db.rollback()
            raise HTTPException(503, "Checkout is temporarily unavailable. Your invoice is saved; try Continue payment.") from None
    return data


@router.post("/topups/{pay_id}/checkout")
def checkout_topup(pay_id: int, request: Request, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-checkout:{user.id}", 30, 300)
    try:
        return wallet_service.checkout_topup(db, user, pay_id, checkout_ip(request))
    except wallet_freekassa.AmountOutsideLimits as exc:
        db.rollback()
        raise amount_limit_error(exc) from None
    except anypay_service.ProviderUnavailable:
        db.rollback()
        raise HTTPException(503, "Checkout is temporarily unavailable. Please try again.") from None


def amount_limit_error(exc):
    return HTTPException(422, detail={"code": "payment_amount_range", "method_id": exc.method_id, "limits": exc.limits})


def checkout_ip(request):
    try:
        peer = ipaddress.ip_address(request.client.host if request.client else "")
        proxies = [ipaddress.ip_network(s.strip()) for s in settings.anypay_proxy_cidrs.split(",") if s.strip()]
        if any(peer in network for network in proxies):
            peer = ipaddress.ip_address(request.headers.get("cf-connecting-ip", ""))
        if peer.is_global:
            return str(peer)
    except ValueError:
        pass
    # The merchant explicitly permits the VPS public IP. Never use loopback or
    # an untrusted X-Forwarded-For value as the buyer's address.
    return settings.freekassa_payer_ip


@router.get("/freekassa/methods")
def freekassa_methods(user: User = Depends(auth.get_current_user)):
    auth.check_rate_limit(f"wallet-fk-methods:{user.id}", 30, 300)
    try:
        return {"methods": wallet_freekassa.available_methods()}
    except anypay_service.ProviderUnavailable:
        raise HTTPException(503, "KASSA methods are temporarily unavailable") from None


@router.post("/topups/{pay_id}/cancel")
def cancel_topup(pay_id: int, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-cancel:{user.id}", 20, 300)
    return wallet_service.cancel_topup(db, user.id, pay_id)


@router.post("/topups/{pay_id}/check")
def check_topup(pay_id: int, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-check:{user.id}", 20, 300)
    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user.id).one_or_none()
    if row is None:
        raise HTTPException(404, "Top-up not found")
    try:
        row = wallet_service.settle_topup(db, pay_id)
    except anypay_service.ProviderUnavailable:
        raise HTTPException(503, "Payment confirmation is temporarily unavailable. Please try again.") from None
    return wallet_service.topup_out(row)


@router.get("/orders")
def orders(user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return [wallet_service.order_out(r) for r in db.query(WalletOrder).filter_by(user_id=user.id)
            .order_by(WalletOrder.created_at.desc()).limit(30).all()]


@router.post("/orders")
def create_order(payload: PurchaseRequest, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-order:{user.id}", 30, 300)
    try:
        row = wallet_service.purchase(db, user, **payload.model_dump())
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code, exc.detail) from None
    return wallet_service.order_out(row)


@router.post("/quote")
def quote(payload: PurchaseRequest, user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    auth.check_rate_limit(f"wallet-quote:{user.id}", 60, 300)
    try:
        return wallet_service.purchase(db, user, **payload.model_dump(), quote_only=True)
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code, exc.detail) from None


@router.api_route("/anypay/notification", methods=["GET", "POST"], response_class=PlainTextResponse)
async def notification(request: Request, db: Session = Depends(get_db)):
    if not anypay_service.enabled():
        raise HTTPException(410, "AnyPay processing has been disabled")
    source = request.client.host if request.client else ""
    try:
        allowed = {str(ipaddress.ip_address(s.strip())) for s in settings.anypay_notification_ips.split(",") if s.strip()}
        peer = ipaddress.ip_address(source)
        proxies = [ipaddress.ip_network(s.strip()) for s in settings.anypay_proxy_cidrs.split(",") if s.strip()]
        if any(peer in network for network in proxies):
            peer = ipaddress.ip_address(request.headers.get("cf-connecting-ip", ""))
        if str(peer) not in allowed:
            raise ValueError()
    except ValueError:
        raise HTTPException(403, "Untrusted payment source") from None
    if request.method == "POST":
        if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/x-www-form-urlencoded":
            raise HTTPException(415, "Use form-urlencoded notifications")
        # Read incrementally, so Content-Length cannot bypass the size limit.
        parts, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > 16_384:
                raise HTTPException(413, "Notification is too large")
            parts.append(chunk)
        raw = b"".join(parts)
    else:
        raw = request.scope.get("query_string", b"")
    try:
        if len(raw) > 16_384:
            raise ValueError()
        pairs = parse_qsl(raw.decode("utf-8"), keep_blank_values=True, max_num_fields=64, strict_parsing=True)
        if len({k for k, _ in pairs}) != len(pairs):
            raise ValueError()
        pay_id = wallet_service.receive_notification(db, dict(pairs))
        if pay_id is not None:
            wallet_service.settle_topup(db, pay_id)
    except ValueError:
        raise HTTPException(400, "Invalid notification") from None
    except anypay_service.ProviderUnavailable:
        raise HTTPException(503, "Payment verification is temporarily unavailable") from None
    return "OK"


@router.post("/freekassa/notification", response_class=PlainTextResponse)
async def freekassa_notification(request: Request, db: Session = Depends(get_db)):
    if not wallet_freekassa.enabled():
        raise HTTPException(503, "Payment handler is not enabled")
    try:
        peer = ipaddress.ip_address(request.client.host if request.client else "")
        proxies = [ipaddress.ip_network(s.strip()) for s in settings.anypay_proxy_cidrs.split(",") if s.strip()]
        if any(peer in network for network in proxies):
            peer = ipaddress.ip_address(request.headers.get("cf-connecting-ip", ""))
        allowed = {str(ipaddress.ip_address(s.strip())) for s in settings.freekassa_notification_ips.split(",") if s.strip()}
        if str(peer) not in allowed:
            raise ValueError()
    except ValueError:
        raise HTTPException(403, "Untrusted payment source") from None
    content_type = request.headers.get("content-type", "")
    if content_type.split(";", 1)[0].strip().lower() not in ("application/x-www-form-urlencoded", "multipart/form-data"):
        raise HTTPException(415, "Use form notifications")
    parts, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > 16_384:
            raise HTTPException(413, "Notification is too large")
        parts.append(chunk)
    try:
        pairs = notification_fields(content_type, b"".join(parts))
        if len({k for k, _ in pairs}) != len(pairs):
            raise ValueError()
        pay_id = wallet_service.receive_freekassa_notification(db, dict(pairs))
        wallet_service.settle_topup(db, pay_id)
    except (ValueError, UnicodeError):
        db.rollback()
        raise HTTPException(400, "Invalid notification") from None
    except anypay_service.ProviderUnavailable:
        db.rollback()
        raise HTTPException(503, "Payment verification is temporarily unavailable") from None
    return "YES"


def notification_fields(content_type, raw):
    if content_type.split(";", 1)[0].strip().lower() == "application/x-www-form-urlencoded":
        return parse_qsl(raw.decode("utf-8"), keep_blank_values=True, max_num_fields=64, strict_parsing=True)
    if len(content_type) > 512 or "\r" in content_type or "\n" in content_type:
        raise ValueError("Invalid form header")
    message = BytesParser(policy=email_policy).parsebytes(
        b"Content-Type: " + content_type.encode("ascii") + b"\r\nMIME-Version: 1.0\r\n\r\n" + raw)
    if not message.is_multipart() or message.defects:
        raise ValueError("Invalid multipart form")
    pairs = []
    for part in message.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if (part.is_multipart() or part.defects or part.get_content_disposition() != "form-data"
                or part.get_filename() is not None or not isinstance(name, str) or len(name) > 128):
            raise ValueError("Invalid multipart field")
        payload = part.get_payload(decode=True)
        if not isinstance(payload, bytes) or len(pairs) >= 64:
            raise ValueError("Invalid multipart value")
        pairs.append((name, payload.decode("utf-8")))
    return pairs


def unique_json(pairs):
    if len({key for key, _ in pairs}) != len(pairs):
        raise ValueError("Duplicate JSON field")
    return dict(pairs)


@router.post("/plisio/notification", response_class=PlainTextResponse)
async def plisio_notification(request: Request, db: Session = Depends(get_db)):
    if not wallet_plisio.enabled():
        raise HTTPException(503, "Payment handler is not enabled")
    if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/json":
        raise HTTPException(415, "Use JSON notifications")
    parts, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > 16_384:
            raise HTTPException(413, "Notification is too large")
        parts.append(chunk)
    try:
        data = json.loads(b"".join(parts), object_pairs_hook=unique_json,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Invalid JSON constant")))
        if not isinstance(data, dict) or not wallet_plisio.verify_callback(data):
            raise ValueError("Invalid signature")
        order = data.get("order_number", "")
        txn = data.get("txn_id", "")
        if not isinstance(order, str) or not re.fullmatch(r"wallet-[0-9]{1,15}", order) or not isinstance(txn, str) or not wallet_plisio.TXN.fullmatch(txn):
            raise ValueError("Invalid wallet invoice")
        pay_id = int(order.removeprefix("wallet-"))
        wallet_service.record_plisio_notification(db, pay_id, data)
        # Never trust the status/amount in the JSON callback for crediting.
        wallet_service.settle_topup(db, pay_id, transaction_hint=txn)
    except (ValueError, TypeError, UnicodeError):
        raise HTTPException(400, "Invalid notification") from None
    except anypay_service.ProviderUnavailable:
        db.rollback()
        raise HTTPException(503, "Payment verification is temporarily unavailable") from None
    return "OK"


@router.get("/admin/review")
def review(_admin=Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    return {"orders": [wallet_service.order_out(r) for r in db.query(WalletOrder).filter_by(status="review").limit(100)],
            "topups": [wallet_service.topup_out(r) for r in db.query(WalletTopup).filter_by(status="review").limit(100)]}


@router.post("/admin/orders/{order_id}/retry")
def retry_order(order_id: uuid.UUID, _admin=Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    row = db.query(WalletOrder).filter_by(id=order_id).with_for_update().one_or_none()
    if row is None or row.status != "review":
        raise HTTPException(409, "Order is not awaiting review")
    # Keep working state for safe cleanup/recovery of an interrupted creation.
    row.status, row.attempts, row.error_code = "working", 0, None
    db.commit()
    return wallet_service.order_out(row)


# PulsarX RollyPay r1
from .wallet_rollypay import router as _rollypay_router
router.include_router(_rollypay_router)

# PulsarX referrals and two-hour Mini codes
from .growth import router as _growth_router
router.include_router(_growth_router)
