"""Authenticated referral status and activation."""
from fastapi import APIRouter,Depends
from sqlalchemy.orm import Session
from .. import auth,growth_service as growth
from ..database import get_db
from ..models import User

router=APIRouter(prefix='/growth',tags=['wallet'])


@router.get('/status')
def status(user:User=Depends(auth.get_current_user),db:Session=Depends(get_db)):
    growth.ensure_verified(user);result=growth.status(db,user.id);db.commit();return result


@router.get('/activation')
def account_activation(user:User=Depends(auth.get_current_user),db:Session=Depends(get_db)):
    return growth.activation(db,user.id)
