import json
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, Request, HTTPException
from sqlalchemy.orm import Session

from .. import lemonsqueezy_service, incus_service, email_service, payments_service, plisio_service
from ..models import Payment
from ..action_log import log_action
from ..server_access import ensure_not_held
from ..database import get_db
from ..models import Server, ServerStatus
from .servers import _provision

logger = logging.getLogger("pulsarx.webhooks")
router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


@router.post("/lemonsqueezy")
async def lemonsqueezy_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    raw_body = await request.body()
    signature = request.headers.get("X-Signature")

    if not lemonsqueezy_service.verify_signature(raw_body, signature):
        logger.warning("Rejected Lemon Squeezy webhook with invalid signature")
        raise HTTPException(status_code=401, detail="Invalid signature")

    payload = json.loads(raw_body)
    event_name = payload.get("meta", {}).get("event_name")
    custom_data = payload.get("meta", {}).get("custom_data", {}) or {}
    server_id = custom_data.get("server_id")

    logger.info("Lemon Squeezy webhook received: %s (server_id=%s)", event_name, server_id)

    if event_name == "subscription_created":
        if not server_id:
            logger.warning("subscription_created webhook with no server_id in custom_data")
            return {"status": "ignored"}

        server = db.get(Server, server_id)
        if server is None:
            logger.warning("subscription_created webhook for unknown server_id=%s", server_id)
            return {"status": "ignored"}

        if server.status != ServerStatus.pending_approval:
            # Either a duplicate delivery of the same webhook, or someone replaying
            # an old payload — never provision twice for one payment.
            logger.warning(
                "subscription_created webhook for server_id=%s but status is already %s, ignoring",
                server_id, server.status,
            )
            return {"status": "already_processed"}

        subscription_id = payload.get("data", {}).get("id")

        server.status = ServerStatus.pending
        server.ls_subscription_id = str(subscription_id) if subscription_id else None
        db.commit()

        log_action(
            db, "payment_confirmed", "server",
            f"{server.container_name} ({server.owner_email})", actor="lemonsqueezy",
        )

        background_tasks.add_task(_provision, server.id)

        return {"status": "ok"}

    if event_name in ("subscription_cancelled", "subscription_updated"):
        # Sync in case the user cancelled (or un-cancelled) directly in the
        # Lemon Squeezy customer portal instead of our dashboard button.
        subscription_id = payload.get("data", {}).get("id")
        if not subscription_id:
            return {"status": "ignored"}

        server = (
            db.query(Server)
            .filter(Server.ls_subscription_id == str(subscription_id))
            .first()
        )
        if server is None:
            logger.warning("%s webhook for unknown subscription_id=%s", event_name, subscription_id)
            return {"status": "ignored"}

        attrs = payload.get("data", {}).get("attributes", {})
        is_cancelled = bool(attrs.get("cancelled"))
        ends_at_str = attrs.get("ends_at") or attrs.get("renews_at")
        ends_at = None
        if ends_at_str:
            from datetime import datetime as _dt
            ends_at = _dt.fromisoformat(ends_at_str.replace("Z", "+00:00"))

        if is_cancelled and not server.subscription_cancelled_at:
            server.subscription_cancelled_at = datetime.now(timezone.utc)
            server.subscription_period_ends_at = ends_at
            db.commit()
            log_action(db, "subscription_cancelled", "server", f"{server.container_name} ({server.owner_email})", actor="lemonsqueezy")
        elif not is_cancelled and server.subscription_cancelled_at:
            # Un-cancelled (resubscribed) before the grace period ran out.
            server.subscription_cancelled_at = None
            server.subscription_period_ends_at = None
            db.commit()
            log_action(db, "subscription_resumed", "server", f"{server.container_name} ({server.owner_email})", actor="lemonsqueezy")

        return {"status": "ok"}

    if event_name in ("subscription_payment_failed", "subscription_payment_success"):
        subscription_id = payload.get("data", {}).get("id")
        if not subscription_id:
            return {"status": "ignored"}

        server = (
            db.query(Server)
            .filter(Server.ls_subscription_id == str(subscription_id))
            .first()
        )
        if server is None:
            logger.warning("%s webhook for unknown subscription_id=%s", event_name, subscription_id)
            return {"status": "ignored"}

        if event_name == "subscription_payment_failed":
            if server.payment_failed_at:
                # Already suspended from a previous failed attempt in this same
                # dunning cycle — don't reset the 14-day clock or re-suspend.
                return {"status": "already_processed"}

            if server.status == ServerStatus.running:
                try:
                    incus_service.stop_container(server.container_name)
                except Exception:
                    logger.exception("Failed to suspend %s after payment failure", server.container_name)
                    db.rollback()
                    raise HTTPException(503,"Instance suspension failed; retry the verified notification") from None
                server.status = ServerStatus.suspended

            server.payment_failed_at = datetime.now(timezone.utc)
            server.last_dunning_email_sent_at = datetime.now(timezone.utc)
            db.commit()

            log_action(db, "payment_failed", "server", f"{server.container_name} ({server.owner_email})", actor="lemonsqueezy")

            try:
                email_service.send_payment_failed_email(server.owner_email, server.container_name, 14)
            except Exception:
                logger.exception("Failed to send payment-failed email for %s", server.container_name)

            return {"status": "ok"}

        if event_name == "subscription_payment_success":
            if not server.payment_failed_at:
                # Normal renewal payment, nothing was suspended — nothing to do.
                return {"status": "ok"}

            db.refresh(server,with_for_update=True)
            if server.status == ServerStatus.suspended and server.admin_suspended_at is None:
                try:
                    incus_service.start_container(server.container_name)
                except Exception:
                    logger.exception("Failed to resume %s after payment recovery", server.container_name)
                    db.rollback()
                    raise HTTPException(503,"Instance recovery failed; retry the verified notification") from None
                server.status = ServerStatus.running

            server.payment_failed_at = None
            server.last_dunning_email_sent_at = None
            db.commit()

            log_action(db, "payment_recovered", "server", f"{server.container_name} ({server.owner_email})", actor="lemonsqueezy")

            try:
                email_service.send_payment_resolved_email(server.owner_email, server.container_name)
            except Exception:
                logger.exception("Failed to send payment-resolved email for %s", server.container_name)

            return {"status": "ok"}

    return {"status": "ignored"}


@router.post("/plisio")
async def plisio_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    t: str | None = None,
    db: Session = Depends(get_db),
):
    if not plisio_service.token_ok(t):
        raise HTTPException(status_code=403, detail="Forbidden")
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Bad request")
    if not isinstance(data, dict):
        raise HTTPException(status_code=400, detail="Bad request")
    if not plisio_service.verify_callback(data):
        logger.warning("Plisio callback failed the hash check (decision still comes from the API re-check)")
    txn_id = data.get("txn_id")
    pay = db.query(Payment).filter(Payment.txn_id == str(txn_id)).first() if txn_id else None
    if pay is None:
        logger.warning("Plisio callback for an unknown txn_id")
        return {"status": "ignored"}
    try:
        status, actions = payments_service.settle(db, pay.id)
    except plisio_service.PlisioError:
        logger.exception("Plisio re-check failed for payment %s", pay.id)
        raise HTTPException(status_code=502, detail="Re-check failed")
    if actions:
        background_tasks.add_task(payments_service.run_actions, pay.server_id, actions, pay.plan)
    return {"status": "ok", "payment": status}
