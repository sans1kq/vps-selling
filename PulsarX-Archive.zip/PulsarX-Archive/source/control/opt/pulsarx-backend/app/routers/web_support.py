"""Account-authenticated website support. Owner identity never comes from JSON."""
import sqlite3
from uuid import UUID
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field

from .. import auth, web_support as service

router=APIRouter(prefix='/api/support/tickets',tags=['support'])


def execute(fn,*args):
    try:return fn(*args)
    except LookupError:raise HTTPException(404,'Ticket not found') from None
    except PermissionError:raise HTTPException(403,'Verify your email first') from None
    except service.RateLimited as exc:raise HTTPException(429,str(exc),headers={'Retry-After':'60'}) from None
    except (ValueError,sqlite3.IntegrityError) as exc:raise HTTPException(409,str(exc) if isinstance(exc,ValueError) else 'Ticket state changed; refresh support') from None
    except sqlite3.Error:raise HTTPException(503,'Support is temporarily unavailable') from None


def private(response:Response):
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'


class NewTicket(BaseModel):
    subject:str=Field(min_length=3,max_length=120)
    text:str=Field(min_length=1,max_length=4000)
    language:Literal['ru','en','ro']='ru'
    request_id:UUID


class Message(BaseModel):
    text:str=Field(min_length=1,max_length=4000)
    request_id:UUID


@router.get('')
def listing(response:Response,before:int=Query(0,ge=0),user=Depends(auth.get_current_user)):
    private(response);return execute(service.listing,user,before)


@router.post('')
def create(payload:NewTicket,response:Response,user=Depends(auth.get_current_user)):
    private(response);return execute(service.create,user,payload.subject,payload.text,payload.language,str(payload.request_id))


@router.get('/{ticket_id}')
def thread(ticket_id:int,response:Response,before:int=Query(0,ge=0),user=Depends(auth.get_current_user)):
    private(response);return execute(service.thread,user,ticket_id,before)


@router.post('/{ticket_id}/messages')
def message(ticket_id:int,payload:Message,response:Response,user=Depends(auth.get_current_user)):
    private(response);return execute(service.message,user,ticket_id,payload.text,str(payload.request_id))


@router.post('/{ticket_id}/close')
def close(ticket_id:int,response:Response,user=Depends(auth.get_current_user)):
    private(response);return execute(service.close,user,ticket_id)
