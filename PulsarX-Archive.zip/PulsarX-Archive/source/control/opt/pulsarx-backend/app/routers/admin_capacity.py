from ..flex_capacity import availability
from ..flex_catalog import public_catalog,POLICY
from ..capacity_service import report
"""Read-only plan occupancy report protected by the existing admin session."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import auth, payments_service
from ..database import get_db
from ..schemas import PLAN_LIMITS

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/plan-slots")
def plan_slots(_: None = Depends(auth.get_current_admin),db: Session = Depends(get_db)):
    state=availability(db);now=datetime.now(timezone.utc);result=[]
    for name,row in state['plans'].items():
        used=int(payments_service.slots_taken(db,name,now))
        result.append({'plan':name,'used':used,'max':used+row['remaining'],'free':row['remaining'],'available':row['available']})
    return {'plans':result,'checked_at':now,'shared_capacity':True}

@router.get('/resource-pool')
def resource_pool(_: None = Depends(auth.get_current_admin),db: Session = Depends(get_db)):
    return {'catalog':public_catalog(),'policy':dict(POLICY),'resources':report(db),'availability':availability(db),'checked_at':datetime.now(timezone.utc)}
