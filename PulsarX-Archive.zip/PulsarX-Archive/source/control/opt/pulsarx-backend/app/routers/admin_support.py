"""Admin-only Telegram support inbox; no wallet or server control actions."""
import sqlite3
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .. import auth
from .. import support_store as store
from .. import web_support

router=APIRouter()


def execute(fn,*args):
    try:return fn(*args)
    except LookupError:raise HTTPException(404,'Not found') from None
    except (ValueError,sqlite3.IntegrityError):raise HTTPException(409,'Ticket state changed or request conflicts; refresh the inbox') from None
    except sqlite3.Error:raise HTTPException(503,'Support storage unavailable') from None


@router.get('/api/support/contact')
def contact():
    return execute(store.public_contact)


@router.get('/api/admin/support',dependencies=[Depends(auth.get_current_admin)])
def tickets(status:Literal['open','closed','all']='open',q:str=Query('',max_length=100),before:int=Query(None,ge=1)):
    return execute(web_support.admin_listing,status,q,before)


@router.get('/api/admin/support/{ticket_id}',dependencies=[Depends(auth.get_current_admin)])
def thread(ticket_id:int,before:int=Query(0,ge=0)):
    return execute(web_support.admin_thread,ticket_id,before)


class Reply(BaseModel):
    text:str=Field(min_length=1,max_length=4000)
    request_id:UUID


@router.post('/api/admin/support/{ticket_id}/reply',dependencies=[Depends(auth.get_current_admin)])
def reply(ticket_id:int,payload:Reply):
    body=payload.text.strip()
    if not body:raise HTTPException(422,'Reply cannot be empty')
    return execute(web_support.admin_reply,ticket_id,body,str(payload.request_id))


class Status(BaseModel):
    status:Literal['open','closed']


@router.post('/api/admin/support/{ticket_id}/status',dependencies=[Depends(auth.get_current_admin)])
def status(ticket_id:int,payload:Status):
    execute(web_support.admin_status,ticket_id,payload.status)
    return {'status':payload.status}


@router.get('/api/admin/support/files/{attachment_id}/download',dependencies=[Depends(auth.get_current_admin)])
def attachment(attachment_id:int):
    path,name=execute(store.attachment,attachment_id)
    return FileResponse(path,filename=name,media_type='application/octet-stream',
                        headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})


@router.post('/api/admin/support/messages/{message_id}/retry',dependencies=[Depends(auth.get_current_admin)])
def retry(message_id:int):
    return execute(web_support.admin_retry,message_id)
