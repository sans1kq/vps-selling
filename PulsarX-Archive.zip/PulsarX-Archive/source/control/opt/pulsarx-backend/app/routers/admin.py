from ..capacity_service import ensure_capacity_http
import csv
import io
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from sqlalchemy import func, text
from sqlalchemy.orm import Session

from .. import auth, email_service, incus_service, payments_service
from .servers import _delete_server_fully, _provision
from ..config import get_settings
from ..server_access import ensure_not_held
from ..database import get_db
from ..models import AdminActionLog, Server, ServerStatus, User
from ..schemas import (
    AdminActionLogOut,
    AdminLoginRequest,
    AdminLoginResponse,
    AdminServerOut,
    AdminUsageOut,
    AdminUserOut,
    HostUsageOut,
    IMAGES,
    PLANS,
    PLAN_LIMITS,
)

logger = logging.getLogger("pulsarx.admin")
router = APIRouter(prefix="/api/admin", tags=["admin"])
settings = get_settings()


from ..action_log import log_action as _log_action


@router.post("/login", response_model=AdminLoginResponse)
def admin_login(payload: AdminLoginRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"admin_login:ip:{auth.client_ip(request)}", max_attempts=3, window_seconds=900)
    if payload.username != settings.admin_username or not auth.verify_password(
        payload.password, settings.admin_password_hash
    ):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = auth.create_admin_session(db)
    return {"token": token}


@router.get("/users", response_model=list[AdminUserOut])
def list_users(_: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    counts = dict(
        db.query(Server.owner_id, func.count(Server.id)).group_by(Server.owner_id).all()
    )
    users = db.query(User).order_by(User.created_at.desc()).all()
    return [
        AdminUserOut(
            id=u.id, first_name=u.first_name, last_name=u.last_name, email=u.email,
            is_verified=u.is_verified, created_at=u.created_at,
            server_count=counts.get(u.id, 0), registration_ip=u.registration_ip,
        )
        for u in users
    ]


@router.get("/servers", response_model=list[AdminServerOut])
def list_all_servers(_: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    return db.query(Server).order_by(Server.created_at.desc()).all()


@router.get("/servers/{server_id}/usage", response_model=AdminUsageOut)
def server_usage(server_id: uuid.UUID, _: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    server = db.get(Server, server_id)
    if server is None:
        raise HTTPException(status_code=404, detail="Not found")
    if server.status != "running":
        raise HTTPException(status_code=409, detail="Server is not running")
    try:
        return incus_service.get_container_usage(server.container_name, server.cpu_cores, server.ram_mb, server.disk_gb)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))






@router.post("/servers/{server_id}/suspend")
def suspend_server(server_id: uuid.UUID, _: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    server=db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one_or_none()
    if server is None:raise HTTPException(404,"Not found")
    if server.status not in (ServerStatus.running,ServerStatus.suspended):raise HTTPException(409,"Instance cannot be suspended in its current state")
    # Persist the administrative decision before the fallible remote stop.
    # A user power action holds this same row lock, so an earlier start must
    # finish before this hold can be committed.
    server.admin_suspended_at=server.admin_suspended_at or datetime.now(timezone.utc)
    db.commit()
    server=db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one()
    if server.status==ServerStatus.running:
        try:incus_service.stop_container(server.container_name)
        except Exception:
            db.rollback()
            raise HTTPException(502,"The operator hold is saved, but stopping the instance failed. Retry the suspension.") from None
    server.status=ServerStatus.suspended
    _log_action(db,"suspend","server",server.container_name)
    return {"status":"suspended"}


@router.post("/servers/{server_id}/resume")
def resume_server(server_id: uuid.UUID, _: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    server=db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one_or_none()
    if server is None:raise HTTPException(404,"Not found")
    if server.status!=ServerStatus.suspended:raise HTTPException(409,"Server is not suspended")
    try:incus_service.start_container(server.container_name)
    except Exception:
        raise HTTPException(502,"Could not resume the instance; its operator hold is retained") from None
    server.status=ServerStatus.running
    server.admin_suspended_at=None
    _log_action(db,"resume","server",server.container_name)
    return {"status":"running"}


def _delete_confirm_page_html(title: str, message: str, show_form: bool, server_id, token: str) -> str:
    form_html = ""
    if show_form:
        form_html = f'''
        <form method="post" action="/api/admin/servers/{server_id}/confirm-delete?token={token}">
          <button type="submit" style="background:#dc2626;">Confirm deletion</button>
        </form>
        '''
    return f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{title} — PulsarX Cloud</title>
<style>
body{{background:#0a0a0f;color:#e6e6ef;font-family:'IBM Plex Mono',monospace;
display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;}}
.card{{max-width:420px;background:#12121b;border:1px solid #22222e;border-radius:14px;padding:32px;text-align:center;}}
h1{{font-size:20px;margin:0 0 12px;}}
p{{color:#8b8b9e;font-size:14px;line-height:1.5;}}
button{{margin-top:20px;padding:12px 20px;border:none;border-radius:8px;background:#6366f1;color:#fff;font-family:inherit;font-size:14px;cursor:pointer;}}
</style></head>
<body><div class="card"><h1>{title}</h1><p>{message}</p>{form_html}</div></body></html>'''


def _load_pending_delete(server_id: uuid.UUID, token: str, db: Session):
    server = db.get(Server, server_id)
    if server is None or not server.delete_token:
        return None, HTMLResponse(
            _delete_confirm_page_html("Not found", "This request no longer exists or was already handled.", False, server_id, token),
            status_code=404,
        )
    if not secrets.compare_digest(server.delete_token, token):
        return None, HTMLResponse(
            _delete_confirm_page_html("Invalid link", "This confirmation link is invalid.", False, server_id, token),
            status_code=403,
        )
    if server.delete_token_expires_at and server.delete_token_expires_at < datetime.now(timezone.utc):
        return None, HTMLResponse(
            _delete_confirm_page_html("Link expired", "This confirmation link has expired.", False, server_id, token),
            status_code=403,
        )
    return server, None


@router.delete("/servers/{server_id}")
def delete_server(server_id: uuid.UUID, _: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    server = db.get(Server, server_id)
    if server is None:
        raise HTTPException(status_code=404, detail="Not found")

    token = secrets.token_urlsafe(32)
    server.delete_token = token
    server.delete_token_expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
    db.commit()

    confirm_url = f"https://{settings.base_domain}/api/admin/servers/{server.id}/confirm-delete?token={token}"
    try:
        email_service.send_admin_delete_confirmation_email(
            settings.admin_notify_email, server.owner_email, server.container_name, confirm_url
        )
    except Exception:
        logger.exception("Failed to send delete confirmation email for %s", server.container_name)
        server.delete_token = None
        server.delete_token_expires_at = None
        db.commit()
        raise HTTPException(status_code=502, detail="Could not send confirmation email, please try again")

    _log_action(db, "request_delete", "server", server.container_name)
    return {"status": "confirmation_sent"}


@router.get("/servers/{server_id}/confirm-delete", response_class=HTMLResponse)
def confirm_delete_page(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_delete(server_id, token, db)
    if error:
        return error
    return HTMLResponse(_delete_confirm_page_html(
        "Confirm deletion",
        f"Permanently delete {server.container_name} ({server.owner_email})? This cannot be undone.",
        True, server_id, token,
    ))


@router.post("/servers/{server_id}/confirm-delete", response_class=HTMLResponse)
def confirm_delete_confirm(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_delete(server_id, token, db)
    if error:
        return error
    container_name = server.container_name
    owner_email = server.owner_email
    _delete_server_fully(db, server)
    _log_action(db, "delete", "server", container_name)
    return HTMLResponse(_delete_confirm_page_html(
        "Deleted", f"{container_name} ({owner_email}) has been permanently deleted.", False, server_id, token,
    ))


@router.get("/host-usage", response_model=HostUsageOut)
def host_usage(_: None = Depends(auth.get_current_admin)):
    try:
        return incus_service.get_host_usage()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@router.get("/action-logs", response_model=list[AdminActionLogOut])
def list_action_logs(_: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    return (
        db.query(AdminActionLog)
        .order_by(AdminActionLog.created_at.desc())
        .limit(200)
        .all()
    )


def _csv_cell(value):
    text=str(value or "")
    if text.lstrip().startswith(("=","+","-","@")) or text.startswith(("\t","\r","\n")):
        return "'"+text
    return text


@router.get("/users/export")
def export_users_csv(_: None = Depends(auth.get_current_admin), db: Session = Depends(get_db)):
    counts = dict(
        db.query(Server.owner_id, func.count(Server.id)).group_by(Server.owner_id).all()
    )
    users = db.query(User).order_by(User.created_at.desc()).all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["First name", "Last name", "Email", "Verified", "Servers", "Joined", "Registration IP"])
    for u in users:
        writer.writerow([
            _csv_cell(u.first_name), _csv_cell(u.last_name), _csv_cell(u.email),
            "yes" if u.is_verified else "no",
            counts.get(u.id, 0),
            u.created_at.isoformat() if u.created_at else "",
            u.registration_ip or "",
        ])
    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="pulsarx-users.csv"'},
    )


@router.post("/users/{user_id}/grant-instance", response_model=AdminServerOut)
def grant_free_instance(
    user_id: uuid.UUID,
    plan: str,
    background_tasks: BackgroundTasks,
    _: None = Depends(auth.get_current_admin),
    db: Session = Depends(get_db),
):
    """Provision a genuinely free instance directly from the admin panel.

    This path intentionally bypasses checkout/payment and the old email approval
    flow.  The admin click is the approval.  The server is created in ``pending``
    state and provisioned in the background; ``paid_until`` remains NULL, so the
    crypto billing cron does not treat the promotional instance as a paid one.
    The trial reaper handles its 72-hour expiry after readiness.
    """
    if plan != 'nano':
        raise HTTPException(status_code=400, detail="Unknown plan")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Keep the same global host-capacity accounting as paid deployments and
    # upgrades.  The advisory lock avoids two simultaneous admin/payment flows
    # oversubscribing the final slot.
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": payments_service.SLOT_LOCK})
    if plan in PLAN_LIMITS:
        used = payments_service.slots_taken(db, plan, datetime.now(timezone.utc))
        if used >= PLAN_LIMITS[plan]:
            db.rollback()
            raise HTTPException(
                status_code=409,
                detail=f"All {PLAN_LIMITS[plan]} slots for this plan are currently taken",
            )

    spec = PLANS[plan]
    server = Server(
        container_name=incus_service.generate_container_name(),
        owner_id=user.id,
        owner_email=user.email,
        plan=plan,
        image="debian13",
        ram_mb=spec["ram_mb"],
        cpu_cores=spec["cpu_cores"],
        disk_gb=spec["disk_gb"],
        status=ServerStatus.pending,
        # Promotional grants have no paid invoice/subscription; expiry is set below.
        paid_until=None,
        approval_token=None,
        approval_token_expires_at=None,
    )
    server.trial_expires_at = datetime.now(timezone.utc) + timedelta(hours=72)
    server.paid_until = None
    ensure_capacity_http(db, server.disk_gb, server.container_name, ram_mb=server.ram_mb, cpu_cores=server.cpu_cores)
    db.add(server)
    db.commit()
    db.refresh(server)

    _log_action(db, "grant_free_instance", "user", f"{user.email} ({plan})")
    background_tasks.add_task(_provision, server.id)
    return server

# PulsarX free instance lifetime v1

# PulsarX storage preflight v1

# PulsarX terminal privacy v1


# SECURITY-20261109-r1: revoke the presented bearer session, including expired ones.
@router.post("/logout")
def logout_session(request: Request, db: Session = Depends(get_db)):
    authorization = request.headers.get("authorization", "")
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.removeprefix("Bearer ").strip()
    if not token or len(token) > 256:
        raise HTTPException(401, "Invalid bearer token")
    session = db.get(auth.AdminSession, token)
    if session is not None:
        db.delete(session)
        db.commit()
    return {"status": "signed_out"}
