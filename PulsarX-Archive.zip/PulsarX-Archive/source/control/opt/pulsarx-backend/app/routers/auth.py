import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .. import auth, email_service
from ..database import get_db
from ..models import User, UserSession
from ..schemas import (
    RegisterRequest,
    VerifyRequest,
    ResendCodeRequest,
    LoginRequest,
    LoginVerifyRequest,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    AuthResponse,
    UserOut,
)

logger = logging.getLogger("pulsarx.auth")
router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/register")
def register(payload: RegisterRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"register:ip:{auth.client_ip(request)}", max_attempts=10, window_seconds=3600)
    if not payload.accepted_tos:
        raise HTTPException(status_code=400, detail="You must accept the Terms of Service")
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing and existing.is_verified:
        raise HTTPException(status_code=400, detail="Email already registered")

    code = auth.generate_otp()
    expires = auth.otp_expiry()
    ip = auth.client_ip(request)

    if existing:
        existing.first_name = payload.first_name
        existing.last_name = payload.last_name
        existing.password_hash = auth.hash_password(payload.password)
        existing.verification_code = code
        existing.verification_code_expires_at = expires
        existing.registration_ip = ip
        existing.accepted_tos_at = datetime.now(timezone.utc)
    else:
        user = User(
            registration_ip=ip,
            accepted_tos_at=datetime.now(timezone.utc),
            first_name=payload.first_name,
            last_name=payload.last_name,
            email=payload.email,
            password_hash=auth.hash_password(payload.password),
            is_verified=False,
            verification_code=code,
            verification_code_expires_at=expires,
        )
        db.add(user)
        db.flush()
        from ..growth_service import attach_invitation
        attach_invitation(db,user,payload.referral_code)
    db.commit()

    try:
        email_service.send_verification_email(payload.email, code)
    except Exception as exc:
        logger.exception("Failed to send verification email to %s", payload.email)
        raise HTTPException(status_code=502, detail="Could not send verification email") from exc

    return {"message": "Verification code sent"}


@router.post("/resend-code")
def resend_code(payload: ResendCodeRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"resend:email:{payload.email.lower()}", max_attempts=3, window_seconds=3600)
    auth.check_rate_limit(f"resend:ip:{auth.client_ip(request)}", max_attempts=10, window_seconds=3600)
    user = db.query(User).filter(User.email == payload.email).first()
    generic_response = {"message": "If that email is pending verification, a new code was sent"}
    if user is None or user.is_verified:
        return generic_response
    user.verification_code = auth.generate_otp()
    user.verification_code_expires_at = auth.otp_expiry()
    db.commit()
    try:
        email_service.send_verification_email(payload.email, user.verification_code)
    except Exception:
        logger.exception("Failed to resend verification email to %s", payload.email)
    return generic_response


@router.post("/verify", response_model=AuthResponse)
def verify(payload: VerifyRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"verify:email:{payload.email.lower()}", max_attempts=10, window_seconds=600)
    auth.check_rate_limit(f"verify:ip:{auth.client_ip(request)}", max_attempts=30, window_seconds=600)
    user = db.query(User).filter(User.email == payload.email).populate_existing().with_for_update().first()
    if user is None or user.is_verified:
        raise HTTPException(status_code=400, detail="Invalid email or code")
    if (
        user.verification_code != payload.code
        or user.verification_code_expires_at is None
        or user.verification_code_expires_at < datetime.now(timezone.utc)
    ):
        raise HTTPException(status_code=400, detail="Invalid or expired code")
    user.is_verified = True
    user.verification_code = None
    user.verification_code_expires_at = None
    db.commit()
    token = auth.create_session(db, user)
    return AuthResponse(token=token, user=UserOut.model_validate(user))


@router.post("/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"login:email:{payload.email.lower()}", max_attempts=5, window_seconds=900)
    auth.check_rate_limit(f"login:ip:{auth.client_ip(request)}", max_attempts=20, window_seconds=900)
    user = db.query(User).filter(User.email == payload.email).first()
    if user is None or not auth.verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_verified:
        raise HTTPException(status_code=403, detail="Email not verified")

    code = auth.generate_otp()
    user.login_code = code
    user.login_code_expires_at = auth.otp_expiry()
    db.commit()

    try:
        email_service.send_login_code_email(user.email, code)
    except Exception:
        logger.exception("Failed to send login code email to %s", user.email)
        raise HTTPException(status_code=502, detail="Could not send login code email")

    return {"message": "Login code sent", "requires_code": True}


@router.post("/login/verify", response_model=AuthResponse)
def login_verify(payload: LoginVerifyRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"loginverify:email:{payload.email.lower()}", max_attempts=10, window_seconds=600)
    auth.check_rate_limit(f"loginverify:ip:{auth.client_ip(request)}", max_attempts=30, window_seconds=600)
    user = db.query(User).filter(User.email == payload.email).populate_existing().with_for_update().first()
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid email or code")
    if (
        user.login_code != payload.code
        or user.login_code_expires_at is None
        or user.login_code_expires_at < datetime.now(timezone.utc)
    ):
        raise HTTPException(status_code=400, detail="Invalid or expired code")
    user.login_code = None
    user.login_code_expires_at = None
    db.commit()
    token = auth.create_session(db, user)
    return AuthResponse(token=token, user=UserOut.model_validate(user))


@router.post("/forgot-password")
def forgot_password(payload: ForgotPasswordRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"forgot:email:{payload.email.lower()}", max_attempts=3, window_seconds=3600)
    auth.check_rate_limit(f"forgot:ip:{auth.client_ip(request)}", max_attempts=10, window_seconds=3600)
    user = db.query(User).filter(User.email == payload.email).first()
    generic_response = {"message": "If that email exists, a reset code was sent"}
    if user is None or not user.is_verified:
        return generic_response
    user.reset_code = auth.generate_otp()
    user.reset_code_expires_at = auth.otp_expiry()
    db.commit()
    try:
        email_service.send_password_reset_email(payload.email, user.reset_code)
    except Exception:
        logger.exception("Failed to send password reset email to %s", payload.email)
    return generic_response


@router.post("/reset-password")
def reset_password(payload: ResetPasswordRequest, request: Request, db: Session = Depends(get_db)):
    auth.check_rate_limit(f"reset:email:{payload.email.lower()}", max_attempts=10, window_seconds=900)
    auth.check_rate_limit(f"reset:ip:{auth.client_ip(request)}", max_attempts=30, window_seconds=900)
    user = db.query(User).filter(User.email == payload.email).populate_existing().with_for_update().first()
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid email or code")
    if (
        user.reset_code != payload.code
        or user.reset_code_expires_at is None
        or user.reset_code_expires_at < datetime.now(timezone.utc)
    ):
        raise HTTPException(status_code=400, detail="Invalid or expired code")
    user.password_hash = auth.hash_password(payload.new_password)
    user.reset_code = None
    user.reset_code_expires_at = None
    user.login_code = None
    user.login_code_expires_at = None
    db.query(UserSession).filter(UserSession.user_id == user.id).delete()
    db.commit()
    return {"message": "Password updated"}


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(auth.get_current_user)):
    return current_user


# SECURITY-20261109-r1: revoke the presented bearer session, including expired ones.
@router.post("/logout")
def logout_session(request: Request, db: Session = Depends(get_db)):
    authorization = request.headers.get("authorization", "")
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.removeprefix("Bearer ").strip()
    if not token or len(token) > 256:
        raise HTTPException(401, "Invalid bearer token")
    session = db.get(auth.UserSession, token)
    if session is not None:
        db.delete(session)
        db.commit()
    return {"status": "signed_out"}
