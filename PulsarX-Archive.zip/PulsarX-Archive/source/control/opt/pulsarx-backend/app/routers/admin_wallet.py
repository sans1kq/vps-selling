"""Admin-only reporting of wallet credits; no provider calls or balance writes."""
from typing import Literal
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import String, cast, func, or_
from sqlalchemy.orm import Session

from .. import auth
from ..database import get_db
from ..models import User
from ..wallet_models import WalletEntry, WalletTopup

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/wallet-topups")
def wallet_topups(
    q: str = Query("", max_length=160),
    min_cents: int | None = Query(None, ge=0, le=1_000_000_000),
    max_cents: int | None = Query(None, ge=0, le=1_000_000_000),
    provider: Literal["anypay", "freekassa", "plisio", "rollypay"] | None = None,
    offset: int = Query(0, ge=0, le=1_000_000),
    limit: int = Query(30, ge=1, le=100),
    _: None = Depends(auth.get_current_admin),
    db: Session = Depends(get_db),
):
    if min_cents is not None and max_cents is not None and min_cents > max_cents:
        raise HTTPException(422, "Minimum amount exceeds maximum")
    # The unique ledger reference proves that the balance was actually credited.
    # Joining on the user as well prevents a malformed reference leaking another
    # user's payment. A later review does not erase a historical credit.
    rows = db.query(WalletEntry, WalletTopup, User).join(
        WalletTopup,
        (WalletEntry.reference == WalletTopup.provider + ":" + cast(WalletTopup.id, String))
        & (WalletEntry.user_id == WalletTopup.user_id),
    ).join(User, User.id == WalletEntry.user_id).filter(
        WalletEntry.kind == "topup", WalletEntry.amount_cents > 0,
        WalletTopup.credited_at.isnot(None),
    )
    q = q.strip()
    if q:
        literal = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        search = [
            User.email.ilike(literal, escape="\\"),
            (func.coalesce(User.first_name, "") + " " + func.coalesce(User.last_name, "")).ilike(literal, escape="\\"),
        ]
        try:
            search.append(User.id == uuid.UUID(q))
        except ValueError:
            pass
        rows = rows.filter(or_(*search))
    if min_cents is not None:
        rows = rows.filter(WalletEntry.amount_cents >= min_cents)
    if max_cents is not None:
        rows = rows.filter(WalletEntry.amount_cents <= max_cents)
    if provider is not None:
        rows = rows.filter(WalletTopup.provider == provider)
    count, amount, users = rows.with_entities(
        func.count(WalletEntry.id), func.coalesce(func.sum(WalletEntry.amount_cents), 0),
        func.count(func.distinct(WalletEntry.user_id)),
    ).one()
    page = rows.order_by(WalletEntry.created_at.desc(), WalletEntry.id.desc()).offset(offset).limit(limit).all()
    return {
        "currency": "USD", "total": count, "total_cents": int(amount), "user_count": users,
        "offset": offset, "limit": limit, "has_more": offset + len(page) < count,
        "items": [{
            "entry_id": str(entry.id), "topup_id": str(topup.id),
            "invoice_number": str(topup.id - 86000000000000 + 50) if topup.id >= 86000000000000 else str(topup.id),
            "user_id": str(user.id), "email": user.email,
            "name": " ".join(x for x in (user.first_name, user.last_name) if x),
            "amount_cents": entry.amount_cents, "provider": topup.provider,
            "method_id": topup.provider_method, "credited_at": topup.credited_at,
            "needs_review": topup.status == "review",
        } for entry, topup, user in page],
    }
