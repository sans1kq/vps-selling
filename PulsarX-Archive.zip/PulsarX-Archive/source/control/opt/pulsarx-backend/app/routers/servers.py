from ..flex_catalog import is_upgrade,public_catalog
from ..flex_capacity import availability,require_resources
from ..capacity_service import StorageCapacityError
from ..trial_service import ensure_upgrade_allowed, ensure_not_trial, ensure_trial_active
import logging
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from .. import auth, domain_service, incus_service, email_service, lemonsqueezy_service, payments_service
from ..idmap_service import allocate_idmap_slot, raw_idmap_config
from ..action_log import log_action
from ..config import get_settings
from ..database import get_db, SessionLocal
from ..models import DomainStatus, Payment, Server, ServerStatus, User
from ..wallet_models import WalletOrder, ACTIVE_ORDERS
from ..growth_models import GiftCode
from ..wallet_service import ensure_idle
from ..server_access import ensure_user_start_allowed
from ..schemas import (
    AdminUsageOut,
    ConfirmSshResetRequest,
    RequestSshResetRequest,
    ServerCreateRequest,
    ServerCreateResponse,
    ServerOut,
    SetDomainRequest,
    SetSubdomainPrefixRequest,
    SetServerPasswordRequest,
    UpgradePlanRequest,
    CheckoutRequest,
    UpgradeCheckoutRequest,
    PLANS,
    IMAGES,
    PLAN_LIMITS,
)

DOMAIN_RE = re.compile(
    r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$"
)

logger = logging.getLogger("pulsarx.servers")
router = APIRouter(prefix="/api/servers", tags=["servers"])
settings = get_settings()


def _provision(server_id: uuid.UUID) -> None:
    db: Session = SessionLocal()
    try:
        server = db.get(Server, server_id)
        if server is None:
            return

        container_name = server.container_name
        ensure_trial_active(server)
        server.status = ServerStatus.provisioning
        db.commit()

        username = "admin"
        resources_started = False

        try:
            image_alias = IMAGES[server.image]["alias"]
            resources_started = True
            incus_service.create_container(
                server.container_name,
                server.cpu_cores,
                server.ram_mb,
                server.disk_gb,
                image_alias,
            )
            incus_service.wait_for_running(server.container_name)
            ip = incus_service.get_ipv4(server.container_name)
            incus_service.enable_isolation(server.container_name)
            incus_service.provision_user(server.container_name, username)
            ssh_port = incus_service.allocate_ssh_forward(server.container_name)
            web_port = incus_service.allocate_web_forward(server.container_name)
            extra_ports = incus_service.allocate_extra_ports(server.container_name)

            server.ip_address = ip
            server.ssh_username = username
            server.ssh_port = ssh_port
            server.web_port = web_port
            server.extra_ports = ",".join(str(p) for p in extra_ports)
            server.status = ServerStatus.running
            from ..growth_service import start_trial_clock
            start_trial_clock(db,server)
            db.commit()

            try:
                incus_service.write_ports_motd(
                    server.container_name, ssh_port, web_port, extra_ports, settings.direct_domain
                )
            except Exception:
                logger.exception(
                    "Server %s is running but failed to write ports MOTD",
                    server.container_name,
                )

            try:
                email_service.send_credentials_email(
                    server.owner_email,
                    server.container_name,
                    settings.direct_domain,
                    ssh_port,
                    username,
                    web_port,
                )
            except Exception:
                logger.exception(
                    "Server %s is running but failed to email credentials",
                    server.container_name,
                )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Provisioning failed for %s", container_name)
            original_error = f"{type(exc).__name__}: {exc}"
            cleanup_error = None
            # Failed commits leave SQLAlchemy sessions unusable until rollback.
            # Cleanup must still run even if the database itself is unavailable.
            try:
                db.rollback()
            finally:
                if resources_started:
                    try:
                        incus_service.delete_container(container_name)
                    except Exception as cleanup_exc:
                        cleanup_error = f"{type(cleanup_exc).__name__}: {cleanup_exc}"
                        logger.exception(
                            "Cleanup failed for %s; resources may remain",
                            container_name,
                        )
            server = db.get(Server, server_id)
            if server is not None:
                server.status = ServerStatus.failed
                if cleanup_error:
                    server.error_message = (
                        original_error[:300] + " | Cleanup failed: " + cleanup_error
                    )[:500]
                else:
                    server.error_message = original_error[:500]
                db.commit()
    finally:
        db.close()


def reap_stuck_servers() -> None:
    """Run once at startup: any server still 'pending' or 'provisioning' at this
    point was interrupted by a service restart/crash mid-provision, not a normal
    in-flight request (FastAPI's startup hook runs before new requests are
    accepted). Mark it failed and attempt to remove the container and pool.
    """
    db: Session = SessionLocal()
    try:
        stuck = (
            db.query(Server)
            .filter(Server.status.in_([ServerStatus.pending, ServerStatus.provisioning]),
                    ~Server.id.in_(db.query(WalletOrder.server_id).filter(
                        WalletOrder.server_id.isnot(None), WalletOrder.status.in_(ACTIVE_ORDERS))),
                    ~Server.id.in_(db.query(GiftCode.server_id).filter(GiftCode.server_id.isnot(None),GiftCode.state.in_(("queued","working","review")))))
            .all()
        )
        for server in stuck:
            logger.warning(
                "Reaping stuck server %s (was %s)", server.container_name, server.status
            )
            cleanup_error = None
            try:
                incus_service.delete_container(server.container_name)
            except Exception as exc:
                cleanup_error = f"{type(exc).__name__}: {exc}"
                logger.exception("Cleanup failed while reaping %s", server.container_name)
            server.status = ServerStatus.failed
            if cleanup_error:
                server.error_message = (
                    "Provisioning was interrupted by a service restart. "
                    "Cleanup failed: " + cleanup_error
                )[:500]
            else:
                server.error_message = (
                    "Provisioning was interrupted by a service restart and was "
                    "cleaned up automatically."
                )
            db.commit()
    finally:
        db.close()


@router.get("/stats/count")
def running_server_count(db: Session = Depends(get_db)):
    """Public counter for the landing page — how many mini servers are actually up."""
    count = db.query(Server).filter(Server.status == ServerStatus.running).count()
    return {"count": count}


@router.get("/stats/plan-slots")
def plan_slot_usage(db: Session = Depends(get_db)):
    state=availability(db);now=datetime.now(timezone.utc)
    result={}
    for name,row in state['plans'].items():
        used=payments_service.slots_taken(db,name,now)
        result[name]={'used':used,'max':used+row['remaining'],**row,'shared_capacity':True}
    return result


@router.get("/payments/open")
def list_open_payments(
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Unpaid, unexpired invoices of the current user (for the dashboard)."""
    now = datetime.now(timezone.utc)
    rows = (
        db.query(Payment)
        .join(Server, Server.id == Payment.server_id)
        .filter(
            Server.owner_id == current_user.id,
            Payment.status.in_(payments_service.OPEN),
            Payment.expires_at > now,
        )
        .order_by(Payment.id.desc())
        .all()
    )
    return [
        {
            "server_id": str(p.server_id), "kind": p.kind, "plan": p.plan, "months": p.months,
            "amount_usd": str(p.amount_usd), "checkout_url": p.invoice_url, "expires_at": p.expires_at,
        }
        for p in rows
    ]


@router.get("/pricing")
def get_pricing():
    return {'prices':{p:{str(m):str(payments_service.price_usd(p,m)) for m in payments_service.PERIOD_DAYS} for p in PLANS},'discount_pct':{str(m):d for m,d in payments_service.DISCOUNT_PCT.items()},**public_catalog()}


@router.get("/limits")
def get_plan_limits(current_user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return plan_slot_usage(db)


@router.post("", response_model=ServerCreateResponse)
def create_server(
    payload: ServerCreateRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    if payload.plan not in PLANS:
        raise HTTPException(status_code=400, detail="Unknown plan")
    if payload.image not in IMAGES:
        raise HTTPException(status_code=400, detail="Unknown image")

    existing_pending = (
        db.query(Server)
        .filter(Server.owner_id == current_user.id, Server.status == ServerStatus.pending_approval)
        .count()
    )
    if existing_pending > 0:
        raise HTTPException(
            status_code=400,
            detail="You already have an instance waiting for payment. Pay for it or wait for it to expire before creating another.",
        )

    months = payload.months
    if months not in payments_service.PERIOD_DAYS:
        raise HTTPException(status_code=400, detail="Unknown billing period")

    spec = PLANS[payload.plan]
    server = Server(
        container_name=incus_service.generate_container_name(),
        owner_id=current_user.id,
        owner_email=current_user.email,
        plan=payload.plan,
        image=payload.image,
        ram_mb=spec["ram_mb"],
        cpu_cores=spec["cpu_cores"],
        disk_gb=spec["disk_gb"],
        status=ServerStatus.pending_approval,
    )
    db.add(server)
    db.commit()
    db.refresh(server)

    log_action(db, "request_instance", "server", f"{server.container_name} ({payload.plan})", actor=current_user.email)

    try:
        pay = payments_service.start_payment(
            db, server, "new", payload.plan, months,
            payments_service.price_usd(payload.plan, months),
        )
    except StorageCapacityError as exc:
        db.rollback()
        db.delete(server)
        db.commit()
        raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
    except payments_service.SlotsFull:
        db.delete(server)
        db.commit()
        raise HTTPException(
            status_code=400,
            detail=f"All {PLAN_LIMITS[payload.plan]} slots for this plan are currently taken",
        )
    except Exception:
        logger.exception("Server %s created but failed to create a payment invoice", server.id)
        server.status = ServerStatus.failed
        server.error_message = "Could not start checkout, please try again"
        db.commit()
        raise HTTPException(status_code=502, detail="Could not start checkout, please try again")

    checkout_url = pay.invoice_url
    try:
        email_service.send_checkout_link_email(current_user.email, payload.plan, checkout_url)
    except Exception:
        logger.exception("Checkout created for %s but failed to email the link", server.id)

    return ServerCreateResponse(server_id=server.id, checkout_url=checkout_url)


def _approve_page_html(title: str, message: str, show_form: bool, server_id, token: str) -> str:
    form_html = ""
    if show_form:
        form_html = f'''
        <form method="post" action="/api/servers/{server_id}/approve?token={token}">
          <button type="submit">Confirm and create server</button>
        </form>
        '''
    return f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{title} — PulsarX Cloud</title>
<style>
body{{background:#0a0a0f;color:#e6e6ef;font-family:'IBM Plex Mono',monospace;
display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;}}
.card{{max-width:420px;background:#12121b;border:1px solid #22222e;border-radius:14px;padding:32px;text-align:center;}}
h1{{font-size:20px;margin:0 0 12px;}}
p{{color:#8b8b9e;font-size:14px;line-height:1.5;}}
button{{margin-top:20px;padding:12px 20px;border:none;border-radius:8px;background:#6366f1;color:#fff;font-family:inherit;font-size:14px;cursor:pointer;}}
button:hover{{background:#4338ca;}}
</style></head>
<body><div class="card"><h1>{title}</h1><p>{message}</p>{form_html}</div></body></html>'''


def _load_pending_approval(server_id: uuid.UUID, token: str, db: Session):
    server = db.get(Server, server_id)
    if server is None or server.status != ServerStatus.pending_approval:
        return None, HTMLResponse(
            _approve_page_html(
                "Not found",
                "This request no longer exists or was already handled.",
                False, server_id, token,
            ),
            status_code=404,
        )
    if not server.approval_token or not secrets.compare_digest(server.approval_token, token):
        return None, HTMLResponse(
            _approve_page_html("Invalid link", "This approval link is invalid.", False, server_id, token),
            status_code=403,
        )
    if server.approval_token_expires_at and server.approval_token_expires_at < datetime.now(timezone.utc):
        return None, HTMLResponse(
            _approve_page_html("Link expired", "This approval link has expired.", False, server_id, token),
            status_code=403,
        )
    ensure_trial_active(server)
    return server, None


@router.get("/{server_id}/approve", response_class=HTMLResponse)
def approve_server_page(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_approval(server_id, token, db)
    if error:
        return error
    return HTMLResponse(
        _approve_page_html(
            "Approve instance",
            f"Create a {server.plan} instance ({server.image}) for {server.owner_email}?",
            True, server_id, token,
        )
    )


@router.post("/{server_id}/approve", response_class=HTMLResponse)
def approve_server_confirm(
    server_id: uuid.UUID,
    token: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    server, error = _load_pending_approval(server_id, token, db)
    if error:
        return error

    if server.plan in PLAN_LIMITS:
        existing_count = (
            db.query(Server)
            .filter(
                Server.plan == server.plan,
                Server.status.in_([ServerStatus.running, ServerStatus.provisioning, ServerStatus.pending]),
                Server.id != server.id,
            )
            .count()
        )
        if existing_count >= PLAN_LIMITS[server.plan]:
            return HTMLResponse(
                _approve_page_html(
                    "Cannot approve",
                    f"All {PLAN_LIMITS[server.plan]} slots for the {server.plan} plan are already taken by "
                    f"approved instances. Reject or wait for one to free up before approving this one.",
                    False, server_id, token,
                ),
                status_code=409,
            )

    server.status = ServerStatus.pending
    server.approval_token = None
    server.approval_token_expires_at = None
    db.commit()

    log_action(db, "approve_instance", "server", f"{server.container_name} ({server.owner_email})", actor="admin")

    background_tasks.add_task(_provision, server.id)

    return HTMLResponse(
        _approve_page_html(
            "Approved",
            f"Instance for {server.owner_email} is now being created.",
            False, server_id, token,
        )
    )


def _upgrade_approve_page_html(title: str, message: str, show_form: bool, server_id, token: str) -> str:
    form_html = ""
    if show_form:
        form_html = f'''
        <form method="post" action="/api/servers/{server_id}/upgrade/approve?token={token}">
          <button type="submit">Confirm and upgrade</button>
        </form>
        '''
    return f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{title} — PulsarX Cloud</title>
<style>
body{{background:#0a0a0f;color:#e6e6ef;font-family:'IBM Plex Mono',monospace;
display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;}}
.card{{max-width:420px;background:#12121b;border:1px solid #22222e;border-radius:14px;padding:32px;text-align:center;}}
h1{{font-size:20px;margin:0 0 12px;}}
p{{color:#8b8b9e;font-size:14px;line-height:1.5;}}
button{{margin-top:20px;padding:12px 20px;border:none;border-radius:8px;background:#6366f1;color:#fff;font-family:inherit;font-size:14px;cursor:pointer;}}
button:hover{{background:#4338ca;}}
</style></head>
<body><div class="card"><h1>{title}</h1><p>{message}</p>{form_html}</div></body></html>'''


def _load_pending_upgrade(server_id: uuid.UUID, token: str, db: Session):
    server = db.get(Server, server_id)
    if server is None or not server.upgrade_target_plan:
        return None, HTMLResponse(
            _upgrade_approve_page_html(
                "Not found",
                "This request no longer exists or was already handled.",
                False, server_id, token,
            ),
            status_code=404,
        )
    if not server.upgrade_token or not secrets.compare_digest(server.upgrade_token, token):
        return None, HTMLResponse(
            _upgrade_approve_page_html("Invalid link", "This approval link is invalid.", False, server_id, token),
            status_code=403,
        )
    if server.upgrade_token_expires_at and server.upgrade_token_expires_at < datetime.now(timezone.utc):
        return None, HTMLResponse(
            _upgrade_approve_page_html("Link expired", "This approval link has expired.", False, server_id, token),
            status_code=403,
        )
    ensure_upgrade_allowed(server)
    return server, None


@router.get("/{server_id}/upgrade/preview")
def preview_upgrade(
    server_id: uuid.UUID,
    target_plan: str,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Rough estimate only — Lemon Squeezy computes the real prorated amount
    (and any tax) at the moment of the actual charge. This just gives the
    user a ballpark before they confirm, based on days left in the current
    billing period times the price difference between plans.
    """
    server = _get_owned_server(server_id, current_user, db)
    ensure_upgrade_allowed(server)
    if target_plan not in PLANS:
        raise HTTPException(status_code=400, detail="Unknown plan")
    if server.paid_until is not None and not server.ls_subscription_id:
        now = datetime.now(timezone.utc)
        try:
            amount = payments_service.upgrade_price_usd(server, target_plan, now)
        except ValueError:
            raise HTTPException(status_code=400, detail="Upgrade is not available for this instance")
        return {
            "estimated_cents": int(amount * 100),
            "estimated_formatted": f"${amount:.2f}",
            "currency": "USD",
            "days_left": max((server.paid_until - now).days, 0),
        }
    if not server.ls_subscription_id:
        raise HTTPException(status_code=400, detail="This instance has no active subscription")

    try:
        sub = lemonsqueezy_service.get_subscription(server.ls_subscription_id)
    except Exception:
        logger.exception("Failed to fetch subscription for upgrade preview, server %s", server.id)
        raise HTTPException(status_code=502, detail="Could not estimate the upgrade cost right now")

    renews_at_str = sub.get("renews_at")
    if not renews_at_str:
        return {"estimated_cents": None, "currency": "USD"}

    renews_at = datetime.fromisoformat(renews_at_str.replace("Z", "+00:00"))
    days_left = max((renews_at - datetime.now(timezone.utc)).days, 0)

    current_price = PLANS[server.plan]["price_cents"]
    target_price = PLANS[target_plan]["price_cents"]
    price_diff = target_price - current_price

    estimated_cents = round(price_diff * days_left / 30)
    estimated_cents = max(estimated_cents, 0)

    return {
        "estimated_cents": estimated_cents,
        "estimated_formatted": f"${estimated_cents / 100:.2f}",
        "currency": "USD",
        "days_left": days_left,
    }


@router.post("/{server_id}/upgrade", response_model=ServerOut)
def request_upgrade(
    server_id: uuid.UUID,
    payload: UpgradePlanRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db)
    ensure_idle(db, server.id)
    ensure_upgrade_allowed(server)
    if payload.target_plan not in PLANS:
        raise HTTPException(status_code=400, detail="Unknown plan")
    if not is_upgrade(server.plan,payload.target_plan):
        raise HTTPException(status_code=400, detail="Choose a higher plan")
    if server.status not in (ServerStatus.running, ServerStatus.suspended):
        raise HTTPException(status_code=409, detail="Server must be running or suspended to request an upgrade")
    if server.upgrade_target_plan:
        raise HTTPException(status_code=409, detail="An upgrade request is already pending for this instance")
    if server.subscription_cancelled_at:
        raise HTTPException(status_code=400, detail="Can't upgrade a cancelled subscription — resubscribe first")

    if payload.target_plan in PLAN_LIMITS:
        existing_count = (
            db.query(Server)
            .filter(
                Server.plan == payload.target_plan,
                Server.status.in_([ServerStatus.running, ServerStatus.provisioning]),
            )
            .count()
        )
        if existing_count >= PLAN_LIMITS[payload.target_plan]:
            raise HTTPException(
                status_code=400,
                detail=f"All {PLAN_LIMITS[payload.target_plan]} slots for this plan are currently taken",
            )

    if server.paid_until is not None and not server.ls_subscription_id:
        raise HTTPException(status_code=400, detail="Use the upgrade checkout for this instance")
    if not server.ls_subscription_id:
        # Legacy instance created before the Lemon Squeezy switch — fall back
        # to the old manual admin-approval-by-email flow.
        token = secrets.token_urlsafe(32)
        server.upgrade_target_plan = payload.target_plan
        server.upgrade_token = token
        server.upgrade_token_expires_at = datetime.now(timezone.utc) + timedelta(hours=72)
        db.commit()

        approve_url = (
            f"https://{settings.base_domain}/api/servers/{server.id}/upgrade/approve?token={token}"
        )
        try:
            email_service.send_upgrade_approval_email(
                settings.admin_notify_email,
                current_user.email,
                server.container_name,
                server.plan,
                payload.target_plan,
                approve_url,
            )
        except Exception:
            logger.exception("Upgrade requested for %s but failed to email admin", server.id)

        db.refresh(server)
        return server

    require_resources(db,PLANS[payload.target_plan],server.container_name)

    # Normal case: paid subscription via Lemon Squeezy — charge the prorated
    # difference immediately and resize on the spot, no manual approval needed.
    try:
        lemonsqueezy_service.change_subscription_plan(server.ls_subscription_id, payload.target_plan)
    except Exception:
        logger.exception("Failed to change Lemon Squeezy plan for server %s", server.id)
        raise HTTPException(status_code=502, detail="Could not process the upgrade charge, please try again")

    spec = PLANS[payload.target_plan]
    try:
        incus_service.resize_container(server.container_name, spec["cpu_cores"], spec["ram_mb"], spec["disk_gb"])
    except Exception as exc:
        logger.exception("Charged for upgrade but failed to resize container %s", server.container_name)
        raise HTTPException(
            status_code=502,
            detail="Payment succeeded but resizing the instance failed — contact support, you won't be charged again.",
        )

    old_plan = server.plan
    server.plan = payload.target_plan
    server.cpu_cores = spec["cpu_cores"]
    server.ram_mb = spec["ram_mb"]
    server.disk_gb = spec["disk_gb"]
    db.commit()

    log_action(
        db, "upgrade_plan", "server",
        f"{server.container_name} ({old_plan} -> {payload.target_plan})",
        actor=current_user.email,
    )

    try:
        email_service.send_upgrade_confirmation_email(
            current_user.email, server.container_name, old_plan, payload.target_plan
        )
    except Exception:
        logger.exception("Upgraded %s but failed to send confirmation email", server.container_name)

    db.refresh(server)
    return server


@router.get("/{server_id}/upgrade/approve", response_class=HTMLResponse)
def upgrade_approve_page(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_upgrade(server_id, token, db)
    if error:
        return error
    return HTMLResponse(
        _upgrade_approve_page_html(
            "Approve upgrade",
            f"Upgrade {server.container_name} ({server.owner_email}) from {server.plan} to {server.upgrade_target_plan}?",
            True, server_id, token,
        )
    )


@router.post("/{server_id}/upgrade/approve", response_class=HTMLResponse)
def upgrade_approve_confirm(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_upgrade(server_id, token, db)
    if error:
        return error

    target_plan = server.upgrade_target_plan
    spec = PLANS[target_plan]
    require_resources(db,spec,server.container_name)

    try:
        incus_service.resize_container(server.container_name, spec["cpu_cores"], spec["ram_mb"], spec["disk_gb"])
    except Exception as exc:
        logger.exception("Failed to resize container %s for upgrade", server.container_name)
        return HTMLResponse(
            _upgrade_approve_page_html(
                "Upgrade failed",
                f"Could not resize the container: {exc}",
                False, server_id, token,
            ),
            status_code=502,
        )

    old_plan = server.plan
    server.plan = target_plan
    server.cpu_cores = spec["cpu_cores"]
    server.ram_mb = spec["ram_mb"]
    server.disk_gb = spec["disk_gb"]
    server.upgrade_target_plan = None
    server.upgrade_token = None
    server.upgrade_token_expires_at = None
    log_action(
        db, "upgrade_plan", "server",
        f"{server.container_name} ({old_plan} -> {target_plan})",
        actor=server.owner_email,
    )
    db.commit()

    return HTMLResponse(
        _upgrade_approve_page_html(
            "Upgraded",
            f"{server.container_name} is now on the {target_plan} plan.",
            False, server_id, token,
        )
    )


@router.get("/{server_id}", response_model=ServerOut)
def get_server(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.get(Server, server_id)
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    return server


@router.get("", response_model=list[ServerOut])
def list_servers(
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(Server)
        .filter(Server.owner_id == current_user.id)
        .order_by(Server.created_at.desc())
        .all()
    )


@router.get("/{server_id}/usage", response_model=AdminUsageOut)
def get_server_usage(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.get(Server, server_id)
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    if server.status != ServerStatus.running:
        raise HTTPException(status_code=409, detail="Server is not running")
    try:
        return incus_service.get_container_usage(
            server.container_name, server.cpu_cores, server.ram_mb, server.disk_gb
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))


def _configure_domain(server_id: uuid.UUID, domain: str) -> None:
    db: Session = SessionLocal()
    try:
        server = db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one_or_none()
        if server is None or server.custom_domain != domain:
            # Domain was changed or removed before this background task ran.
            return
        try:
            result = domain_service.add_domain(domain, server.ip_address)
            server.domain_status = (
                DomainStatus.active if result == "active" else DomainStatus.http_only
            )
        except domain_service.DomainError as exc:
            logger.exception("Failed to configure domain %s for server %s", domain, server_id)
            server.domain_status = DomainStatus.failed
            server.error_message = f"Domain setup failed: {exc}"[:500]
        db.commit()
    finally:
        db.close()


@router.post("/{server_id}/domain", response_model=ServerOut)
def set_custom_domain(
    server_id: uuid.UUID,
    payload: SetDomainRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one_or_none()
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    if server.status != ServerStatus.running or not server.ip_address:
        raise HTTPException(status_code=409, detail="Server must be running before you can attach a domain")

    domain = payload.domain.strip().lower()
    if server.custom_domain and server.custom_domain != domain:
        raise HTTPException(409,"Remove the current domain successfully before attaching a replacement")
    if not DOMAIN_RE.match(domain):
        raise HTTPException(status_code=400, detail="That doesn't look like a valid domain")
    if domain == settings.base_domain or domain.endswith(f".{settings.base_domain}"):
        raise HTTPException(
            status_code=400,
            detail="Platform domains are reserved; use a domain you own",
        )

    existing = (
        db.query(Server)
        .filter(Server.custom_domain == domain, Server.id != server.id)
        .first()
    )
    if existing:
        raise HTTPException(status_code=409, detail="This domain is already in use by another instance")

    server.custom_domain = domain
    server.domain_status = DomainStatus.pending
    db.commit()

    background_tasks.add_task(_configure_domain, server.id, domain)
    return server


@router.post("/{server_id}/domain/subdomain", response_model=ServerOut)
def set_free_subdomain(
    server_id: uuid.UUID,
    payload: SetSubdomainPrefixRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.get(Server, server_id)
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    raise HTTPException(status_code=410, detail="Free platform subdomains are no longer available. Use your own domain.")


@router.delete("/{server_id}/domain", response_model=ServerOut)
def delete_domain(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.query(Server).filter_by(id=server_id).populate_existing().with_for_update().one_or_none()
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    if not server.custom_domain:
        raise HTTPException(status_code=400, detail="No domain configured on this instance")

    try:
        domain_service.remove_domain(server.custom_domain)
    except domain_service.DomainError:
        logger.exception("Failed to clean up domain %s for server %s", server.custom_domain, server_id)
        raise HTTPException(502,"Domain cleanup failed. The domain record was retained for retry.") from None

    server.custom_domain = None
    server.domain_status = None
    db.commit()
    return server


def _get_owned_server(server_id: uuid.UUID, current_user: User, db: Session, lock=False) -> Server:
    query=db.query(Server).filter_by(id=server_id,owner_id=current_user.id)
    if lock:query=query.populate_existing().with_for_update()
    server=query.one_or_none()
    if server is None:raise HTTPException(404,"Not found")
    ensure_trial_active(server)
    return server


@router.post("/{server_id}/stop", response_model=ServerOut)
def stop_server(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    ensure_idle(db, server.id)
    if server.status != ServerStatus.running:
        raise HTTPException(status_code=409, detail="Server is not running")
    try:
        incus_service.stop_container(server.container_name)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))
    server.status = ServerStatus.suspended
    db.commit()
    db.refresh(server)
    return server


@router.post("/{server_id}/start", response_model=ServerOut)
def start_server(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    ensure_idle(db, server.id)
    ensure_user_start_allowed(server)
    if server.status != ServerStatus.suspended:
        raise HTTPException(status_code=409, detail="Server is not stopped")
    try:
        incus_service.start_container(server.container_name)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))
    server.status = ServerStatus.running
    db.commit()
    db.refresh(server)
    return server


@router.post("/{server_id}/restart", response_model=ServerOut)
def restart_server(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    ensure_idle(db, server.id)
    ensure_user_start_allowed(server)
    if server.status != ServerStatus.running:
        raise HTTPException(status_code=409, detail="Server is not running")
    try:
        incus_service.restart_container(server.container_name)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))
    return server


@router.post("/{server_id}/reset-ssh-password/request")
def request_ssh_password_reset(
    server_id: uuid.UUID,
    payload: RequestSshResetRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    auth.check_rate_limit(f"sshreset:user:{current_user.id}", max_attempts=5, window_seconds=900)

    if not auth.verify_password(payload.account_password, current_user.password_hash):
        raise HTTPException(status_code=403, detail="Incorrect account password")
    if server.status not in (ServerStatus.running, ServerStatus.suspended):
        raise HTTPException(status_code=409, detail="Server must be running or suspended")
    if not server.ssh_username:
        raise HTTPException(status_code=409, detail="Server has no user provisioned yet")

    code = auth.generate_otp()
    server.reset_ssh_code = code
    server.reset_ssh_code_expires_at = auth.otp_expiry()
    db.commit()

    try:
        email_service.send_ssh_reset_code_email(current_user.email, server.container_name, code)
    except Exception:
        logger.exception("Failed to send SSH reset code email for %s", server.container_name)
        raise HTTPException(status_code=502, detail="Could not send confirmation email")

    return {"message": "Confirmation code sent to your account email"}


@router.post("/{server_id}/reset-ssh-password/confirm", response_model=ServerOut)
def confirm_ssh_password_reset(
    server_id: uuid.UUID,
    payload: ConfirmSshResetRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    auth.check_rate_limit(f"sshresetconfirm:user:{current_user.id}", max_attempts=10, window_seconds=900)

    if (
        server.reset_ssh_code != payload.code
        or server.reset_ssh_code_expires_at is None
        or server.reset_ssh_code_expires_at < datetime.now(timezone.utc)
    ):
        raise HTTPException(status_code=400, detail="Invalid or expired code")

    try:
        incus_service.lock_user_password(server.container_name, server.ssh_username)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))

    server.reset_ssh_code = None
    server.reset_ssh_code_expires_at = None
    server.password_set = False
    log_action(db, "reset_ssh_password", "server", server.container_name, actor=current_user.email)
    db.commit()
    db.refresh(server)
    return server


@router.post("/{server_id}/set-password", response_model=ServerOut)
def set_server_password(
    server_id: uuid.UUID,
    payload: SetServerPasswordRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = _get_owned_server(server_id, current_user, db, lock=True)
    if server.password_set:
        raise HTTPException(status_code=409, detail={"code": "ssh_password_confirmation_required",
            "message": "Confirm your account password and emailed code before changing the SSH password"})
    if server.status not in (ServerStatus.running, ServerStatus.suspended):
        raise HTTPException(status_code=409, detail="Server must be running or suspended")
    if not server.ssh_username:
        raise HTTPException(status_code=409, detail="Server has no user provisioned yet")
    try:
        incus_service.set_user_password(
            server.container_name, server.ssh_username, payload.password
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc))
    server.password_set = True
    log_action(db, "set_ssh_password", "server", server.container_name, actor=current_user.email)
    db.commit()
    db.refresh(server)
    return server


@router.delete("/{server_id}")
def delete_server(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    server = db.get(Server, server_id)
    if server is None or server.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Not found")
    _delete_server_fully(db, server)
    return {"status": "deleted"}


def _sub_action_page_html(title: str, message: str, show_form: bool, server_id, token: str, button_label: str = "") -> str:
    form_html = ""
    if show_form:
        form_html = f'''
        <form method="post" action="/api/servers/{server_id}/subscription-action?token={token}">
          <button type="submit">{button_label}</button>
        </form>
        '''
    return f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{title} — PulsarX Cloud</title>
<style>
body{{background:#0a0a0f;color:#e6e6ef;font-family:'IBM Plex Mono',monospace;
display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;}}
.card{{max-width:420px;background:#12121b;border:1px solid #22222e;border-radius:14px;padding:32px;text-align:center;}}
h1{{font-size:20px;margin:0 0 12px;}}
p{{color:#8b8b9e;font-size:14px;line-height:1.5;}}
button{{margin-top:20px;padding:12px 20px;border:none;border-radius:8px;background:#6366f1;color:#fff;font-family:inherit;font-size:14px;cursor:pointer;}}
button:hover{{background:#4338ca;}}
</style></head>
<body><div class="card"><h1>{title}</h1><p>{message}</p>{form_html}</div></body></html>'''


def _request_subscription_action(server_id: uuid.UUID, action: str, current_user: User, db: Session) -> dict:
    """Step 1: nothing changes in Lemon Squeezy yet — just email the owner a
    confirmation link. The action only happens when they confirm via the link.
    """
    server = _get_owned_server(server_id, current_user, db)
    auth.check_rate_limit(f"subtoggle:server:{server.id}", max_attempts=3, window_seconds=3600)
    if not server.ls_subscription_id:
        raise HTTPException(status_code=400, detail="This server has no active subscription")
    if action == "cancel" and server.subscription_cancelled_at:
        raise HTTPException(status_code=400, detail="Subscription is already cancelled")
    if action == "resume" and not server.subscription_cancelled_at:
        raise HTTPException(status_code=400, detail="Subscription is not cancelled")

    token = secrets.token_urlsafe(32)
    server.sub_action_pending = action
    server.sub_action_token = token
    server.sub_action_token_expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
    db.commit()

    confirm_url = f"https://{settings.base_domain}/api/servers/{server.id}/subscription-action?token={token}"
    try:
        email_service.send_subscription_action_email(current_user.email, server.container_name, action, confirm_url)
    except Exception:
        logger.exception("Failed to send subscription %s confirmation email for %s", action, server.container_name)
        server.sub_action_pending = None
        server.sub_action_token = None
        server.sub_action_token_expires_at = None
        db.commit()
        raise HTTPException(status_code=502, detail="Could not send the confirmation email, please try again")

    return {"status": "confirmation_sent"}


@router.post("/{server_id}/cancel-subscription")
def cancel_subscription(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return _request_subscription_action(server_id, "cancel", current_user, db)


@router.post("/{server_id}/resume-subscription")
def resume_subscription(
    server_id: uuid.UUID,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return _request_subscription_action(server_id, "resume", current_user, db)


def _load_pending_sub_action(server_id: uuid.UUID, token: str, db: Session):
    server = db.get(Server, server_id)
    if server is None or not server.sub_action_pending:
        return None, HTMLResponse(
            _sub_action_page_html("Not found", "This request no longer exists or was already handled.", False, server_id, token),
            status_code=404,
        )
    if not server.sub_action_token or not secrets.compare_digest(server.sub_action_token.encode(), token.encode()):
        return None, HTMLResponse(
            _sub_action_page_html("Invalid link", "This confirmation link is invalid.", False, server_id, token),
            status_code=403,
        )
    if server.sub_action_token_expires_at and server.sub_action_token_expires_at < datetime.now(timezone.utc):
        return None, HTMLResponse(
            _sub_action_page_html("Link expired", "This confirmation link has expired. Request a new one from your dashboard.", False, server_id, token),
            status_code=403,
        )
    return server, None


@router.get("/{server_id}/subscription-action", response_class=HTMLResponse)
def subscription_action_page(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_sub_action(server_id, token, db)
    if error:
        return error
    if server.sub_action_pending == "cancel":
        return HTMLResponse(_sub_action_page_html(
            "Cancel subscription",
            f"Cancel the subscription for {server.container_name}? It stays usable until the end of the paid period, then you get 1 extra day to back up data or resubscribe before it is deleted.",
            True, server_id, token, "Confirm cancellation",
        ))
    return HTMLResponse(_sub_action_page_html(
        "Resume subscription",
        f"Resume the subscription for {server.container_name}? It will renew as normal.",
        True, server_id, token, "Confirm resume",
    ))


@router.post("/{server_id}/subscription-action", response_class=HTMLResponse)
def subscription_action_confirm(server_id: uuid.UUID, token: str, db: Session = Depends(get_db)):
    server, error = _load_pending_sub_action(server_id, token, db)
    if error:
        return error
    if not server.ls_subscription_id:
        return HTMLResponse(
            _sub_action_page_html("Nothing to do", "This server has no active subscription.", False, server_id, token),
            status_code=400,
        )

    action = server.sub_action_pending
    try:
        if action == "cancel":
            lemonsqueezy_service.cancel_subscription(server.ls_subscription_id)
            sub = lemonsqueezy_service.get_subscription(server.ls_subscription_id)
            ends_at_str = sub.get("ends_at") or sub.get("renews_at")
            ends_at = datetime.fromisoformat(ends_at_str.replace("Z", "+00:00")) if ends_at_str else None
            server.subscription_cancelled_at = datetime.now(timezone.utc)
            server.subscription_period_ends_at = ends_at
        else:
            lemonsqueezy_service.resume_subscription(server.ls_subscription_id)
            server.subscription_cancelled_at = None
            server.subscription_period_ends_at = None
    except Exception:
        logger.exception("Failed to %s Lemon Squeezy subscription for server %s", action, server.id)
        return HTMLResponse(
            _sub_action_page_html(
                "Something went wrong",
                "Could not update the subscription. If you were trying to resume and the paid period has already ended, please start a new subscription.",
                False, server_id, token,
            ),
            status_code=502,
        )

    server.sub_action_pending = None
    server.sub_action_token = None
    server.sub_action_token_expires_at = None
    db.commit()

    log_action(
        db, "cancel_subscription" if action == "cancel" else "resume_subscription", "server",
        f"{server.container_name} ({server.owner_email})", actor=server.owner_email,
    )

    if action == "cancel":
        until = server.subscription_period_ends_at.strftime("%Y-%m-%d") if server.subscription_period_ends_at else "the end of the current period"
        done_msg = f"Subscription cancelled. {server.container_name} stays active until {until}, then you get 1 extra day to back up data or resubscribe before it is deleted."
    else:
        done_msg = f"Subscription resumed. {server.container_name} will renew as normal."
    return HTMLResponse(_sub_action_page_html("Done", done_msg, False, server_id, token))


def _delete_server_fully(db: Session, server: Server) -> None:
    """Keep ownership and billing records until remote cleanup is confirmed."""
    db.refresh(server,with_for_update=True)
    ensure_idle(db,server.id)
    # Remove routes before freeing an address that another tenant could receive.
    if server.custom_domain:
        try:domain_service.remove_domain(server.custom_domain)
        except Exception:
            db.rollback()
            logger.exception("Domain cleanup failed; keeping the instance and its ownership record")
            raise HTTPException(502,"Domain cleanup failed. The instance was retained; retry deletion later.") from None
    try:incus_service.delete_container(server.container_name)
    except Exception:
        db.rollback()
        logger.exception("Instance cleanup failed; keeping its database record")
        raise HTTPException(502,"Instance deletion could not be confirmed. The record was retained; retry later.") from None
    db.delete(server)
    db.commit()


@router.post("/{server_id}/checkout")
def create_server_checkout(
    server_id: uuid.UUID,
    payload: CheckoutRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Invoice for a first payment (pending_approval) or a renewal (running/suspended)."""
    server = _get_owned_server(server_id, current_user, db)
    ensure_idle(db, server.id)
    ensure_not_trial(server)
    if payload.months not in payments_service.PERIOD_DAYS:
        raise HTTPException(status_code=400, detail="Unknown billing period")
    if server.ls_subscription_id:
        raise HTTPException(status_code=400, detail="This instance is billed through Lemon Squeezy")
    if server.status == ServerStatus.pending_approval:
        kind = "new"
    elif server.status in (ServerStatus.running, ServerStatus.suspended) and server.paid_until is not None:
        kind = "renew"
    else:
        raise HTTPException(status_code=409, detail="Nothing to pay for on this instance")
    plan = server.plan
    try:
        pay = payments_service.start_payment(
            db, server, kind, plan, payload.months, payments_service.price_usd(plan, payload.months)
        )
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
    except payments_service.SlotsFull:
        raise HTTPException(status_code=400, detail=f"All {PLAN_LIMITS[plan]} slots for this plan are currently taken")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payment request")
    except Exception:
        logger.exception("Could not create invoice for server %s", server_id)
        raise HTTPException(status_code=502, detail="Could not start checkout, please try again")
    return {"checkout_url": pay.invoice_url, "amount_usd": str(pay.amount_usd), "expires_at": pay.expires_at}


@router.post("/{server_id}/upgrade/checkout")
def create_upgrade_checkout(
    server_id: uuid.UUID,
    payload: UpgradeCheckoutRequest,
    current_user: User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Invoice for the prorated top-up; the resize happens after the payment is confirmed."""
    server = _get_owned_server(server_id, current_user, db)
    ensure_idle(db, server.id)
    ensure_upgrade_allowed(server)
    if payload.target_plan not in PLANS:
        raise HTTPException(status_code=400, detail="Unknown plan")
    if server.ls_subscription_id or server.paid_until is None:
        raise HTTPException(status_code=400, detail="Upgrade is not available for this instance")
    if server.status not in (ServerStatus.running, ServerStatus.suspended):
        raise HTTPException(status_code=409, detail="Server must be running or suspended to upgrade")
    now = datetime.now(timezone.utc)
    if server.paid_until <= now:
        raise HTTPException(status_code=409, detail="Renew this instance before upgrading it")
    try:
        amount = payments_service.upgrade_price_usd(server, payload.target_plan, now)
        pay = payments_service.start_payment(db, server, "upgrade", payload.target_plan, 1, amount)
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code,exc.detail) from exc
    except payments_service.SlotsFull:
        raise HTTPException(status_code=400, detail=f"All {PLAN_LIMITS[payload.target_plan]} slots for this plan are currently taken")
    except ValueError:
        raise HTTPException(status_code=400, detail="Upgrade is not available for this instance")
    except Exception:
        logger.exception("Could not create upgrade invoice for server %s", server_id)
        raise HTTPException(status_code=502, detail="Could not start checkout, please try again")
    return {"checkout_url": pay.invoice_url, "amount_usd": str(pay.amount_usd), "expires_at": pay.expires_at}

# PulsarX provisioning rollback v1

# PulsarX free instance lifetime v1

# PulsarX storage preflight v1

# PulsarX terminal privacy v1


@router.get("/catalog/availability")
def flex_catalog_availability(db: Session = Depends(get_db)):
    return availability(db)
