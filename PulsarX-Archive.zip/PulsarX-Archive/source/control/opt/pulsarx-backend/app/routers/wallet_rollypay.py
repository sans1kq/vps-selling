"""RollyPay authenticated quotes and a bounded, durable webhook inbox."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from .. import auth, wallet_rollypay as provider
from ..anypay_service import ProviderUnavailable
from ..database import get_db
from ..models import User

router = APIRouter(prefix="/rollypay", tags=["wallet"])


@router.get("/quote")
def quote(amount_cents: int = Query(..., ge=1, le=1_000_000),
          user: User = Depends(auth.get_current_user), db: Session = Depends(get_db), apply_referral: bool = False):
    auth.check_rate_limit(f"rollypay-quote:{user.id}", 90, 300)
    try:
        from .. import growth_service as growth
        pay=growth.quote_terms(db,user.id,amount_cents,apply_referral)
        result=provider.quote(user.id,pay)
        result.update(amount_cents=amount_cents,payable_cents=pay,discount_cents=amount_cents-pay)
        return result
    except ProviderUnavailable:
        raise HTTPException(503, "RollyPay quote is temporarily unavailable") from None


@router.post("/notification", response_class=PlainTextResponse)
async def notification(request: Request, db: Session = Depends(get_db)):
    if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
        raise HTTPException(415, "Use JSON notifications")
    parts, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > 65536:
            raise HTTPException(413, "Notification is too large")
        parts.append(chunk)
    raw = b"".join(parts)
    timestamp = request.headers.get("x-timestamp", "")
    data = provider.verify_event(raw, timestamp, request.headers.get("x-signature", ""),
                                 request.headers.get("x-test-mode", ""))
    if data is not None:
        await run_in_threadpool(provider.receive, db, data, raw, timestamp)
    return "OK"
