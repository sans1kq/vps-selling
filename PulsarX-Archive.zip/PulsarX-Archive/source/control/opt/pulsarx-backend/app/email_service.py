import requests

from .config import get_settings
from .email_templates import render_email

settings = get_settings()

RESEND_URL = "https://api.resend.com/emails"


def _send(to_email: str, subject: str, text: str) -> None:
    resp = requests.post(
        RESEND_URL,
        headers={"Authorization": f"Bearer {settings.resend_api_key}"},
        json={
            "from": settings.email_from,
            "to": [to_email],
            "subject": subject,
            "text": text,
            "html": render_email(subject, text, settings.frontend_base_url),
        },
        timeout=10,
    )
    resp.raise_for_status()


def send_verification_email(to_email: str, code: str) -> None:
    _send(
        to_email,
        f"Your PulsarX verification code: {code}",
        "Welcome to PulsarX Cloud.\n\n"
        f"Your verification code is: {code}\n\n"
        "It expires in 10 minutes. If you didn't request this, ignore this email.\n\n"
        "- PulsarX Cloud",
    )


def send_credentials_email(
    to_email: str,
    container_name: str,
    host: str,
    ssh_port: int,
    username: str,
    web_port: int | None = None,
) -> None:
    web_block = ""
    if web_port:
        web_block = (
            f"\nHosting a website or app on port 80 inside the instance? "
            f"It's reachable from the internet at:\n"
            f"http://{host}:{web_port}\n"
        )

    _send(
        to_email,
        f"Your PulsarX instance ({container_name}) is ready",
        "Your PulsarX server is ready.\n\n"
        f"Host:     {host}\n"
        f"Port:     {ssh_port}\n"
        f"Username: {username}\n\n"
        "One last step: set a password for this instance from your dashboard "
        "before you can connect over SSH.\n"
        f"{web_block}\n"
        "- PulsarX Cloud",
    )


def send_admin_notification_email(admin_email: str, user_email: str, plan: str) -> None:
    _send(
        admin_email,
        "New PulsarX instance requested",
        f"{user_email} just requested a {plan} instance.\n\n"
        "- PulsarX Cloud",
    )


def send_admin_approval_email(
    admin_email: str, user_email: str, plan: str, image: str, approve_url: str
) -> None:
    _send(
        admin_email,
        f"Approve new PulsarX instance ({user_email})",
        f"{user_email} requested a new instance.\n\n"
        f"Plan:  {plan}\n"
        f"Image: {image}\n\n"
        f"Approve it here (expires in 72 hours):\n{approve_url}\n\n"
        "If you don't recognize this or don't want to approve it, just ignore this email.\n\n"
        "- PulsarX Cloud",
    )


def send_login_code_email(to_email: str, code: str) -> None:
    _send(
        to_email,
        f"Your PulsarX login code: {code}",
        "Someone (hopefully you) is trying to log in to your PulsarX account.\n\n"
        f"Your login code is: {code}\n\n"
        "It expires in 10 minutes. If you didn't request this, you can ignore this email "
        "and change your password just to be safe.\n\n"
        "- PulsarX Cloud",
    )


def send_upgrade_approval_email(
    admin_email: str, user_email: str, container_name: str, current_plan: str, target_plan: str, approve_url: str
) -> None:
    _send(
        admin_email,
        f"Approve plan upgrade ({user_email})",
        f"{user_email} requested to upgrade instance {container_name}.\n\n"
        f"Current plan: {current_plan}\n"
        f"Target plan:  {target_plan}\n\n"
        f"Approve it here (expires in 72 hours):\n{approve_url}\n\n"
        "If you don't recognize this or don't want to approve it, just ignore this email.\n\n"
        "- PulsarX Cloud",
    )


def send_ssh_reset_code_email(to_email: str, container_name: str, code: str) -> None:
    _send(
        to_email,
        f"Reset SSH password code for {container_name}: {code}",
        f"You (or someone with your account password) asked to reset the SSH "
        f"password for your instance {container_name}.\n\n"
        f"Your confirmation code is: {code}\n\n"
        "It expires in 10 minutes. Once confirmed, the instance's SSH password "
        "will be locked and you'll be asked to set a new one from the dashboard, "
        "the same way as when it was first created.\n\n"
        "If you didn't request this, ignore this email — nothing will change.\n\n"
        "- PulsarX Cloud",
    )


def send_payment_failed_email(to_email: str, container_name: str, days_left: int) -> None:
    _send(
        to_email,
        f"Action needed: payment failed for {container_name} ({days_left} days left)",
        f"We couldn't charge your card for {container_name}.\n\n"
        f"Your instance has been suspended and you have {days_left} day(s) left to update "
        "your payment method before it's permanently deleted.\n\n"
        "Update your payment method from your dashboard, or from the link in your original "
        "Lemon Squeezy receipt email, and your instance will come back online automatically "
        "once the payment goes through.\n\n"
        "- PulsarX Cloud",
    )


def send_payment_resolved_email(to_email: str, container_name: str) -> None:
    _send(
        to_email,
        f"Your instance {container_name} is back online",
        f"Good news — your payment for {container_name} went through and your instance "
        "has been resumed automatically.\n\n"
        "- PulsarX Cloud",
    )


def send_subscription_action_email(to_email: str, container_name: str, action: str, confirm_url: str) -> None:
    verb = "cancel" if action == "cancel" else "resume"
    _send(
        to_email,
        f"Confirm: {verb} the subscription for {container_name}",
        f"We received a request to {verb} the subscription for {container_name}.\n\n"
        f"To confirm, open this link (valid for 1 hour):\n{confirm_url}\n\n"
        "If you didn't request this, ignore this email - nothing will change.\n\n"
        "- PulsarX Cloud",
    )


def send_upgrade_confirmation_email(to_email: str, container_name: str, old_plan: str, new_plan: str) -> None:
    _send(
        to_email,
        f"Your instance {container_name} is now on {new_plan}",
        f"Your top-up payment was confirmed and {container_name} was upgraded from {old_plan} "
        f"to {new_plan}.\n\n"
        "Your paid period did not change. When you renew, the price of the new plan applies.\n\n"
        "- PulsarX Cloud",
    )


def send_checkout_link_email(to_email: str, plan: str, checkout_url: str) -> None:
    _send(
        to_email,
        "Finish setting up your PulsarX instance",
        f"You started creating a {plan} instance but have not paid yet.\n\n"
        f"Here is your payment link (valid for {settings.invoice_expire_min} minutes):\n{checkout_url}\n\n"
        "Send the full amount shown on the payment page, in one or several transfers, before "
        "the timer runs out. A partial payment is not credited, anything sent after the timer "
        "expires is not credited, and an overpayment is not refunded.\n\n"
        "If you did not mean to do this, ignore this email - nothing will be created.\n\n"
        "- PulsarX Cloud",
    )


def send_renewal_reminder_email(to_email: str, container_name: str, amount_formatted: str) -> None:
    _send(
        to_email,
        f"Your {container_name} subscription renews tomorrow",
        f"Heads up — your subscription for {container_name} renews tomorrow, "
        f"and {amount_formatted} will be charged automatically to the card on file.\n\n"
        "If you want to cancel before then, you can do it from your dashboard under "
        "Settings → Manage subscription.\n\n"
        "- PulsarX Cloud",
    )


def send_password_reset_email(to_email: str, code: str) -> None:
    _send(
        to_email,
        f"Your PulsarX password reset code: {code}",
        "Someone (hopefully you) requested a password reset for your PulsarX account.\n\n"
        f"Your reset code is: {code}\n\n"
        "It expires in 10 minutes. If you didn't request this, you can ignore this email "
        "and your password will stay the same.\n\n"
        "- PulsarX Cloud",
    )


def send_crypto_reminder_email(to_email: str, container_name: str, days_left: int, paid_until: str) -> None:
    _send(
        to_email,
        f"{container_name} is paid until {paid_until} UTC ({days_left} day(s) left)",
        f"Your instance {container_name} is paid until {paid_until} UTC.\n\n"
        "PulsarX Cloud does not charge anything automatically. To keep the instance running, "
        f"renew it from your dashboard ({settings.frontend_base_url}/dashboard/) before that time. "
        "You can pay for 1, 3, 6 or 12 months, and longer periods are cheaper.\n\n"
        "If the date passes, the instance is frozen (your data is kept) and it is permanently "
        "deleted if it stays unpaid for 14 days.\n\n"
        "- PulsarX Cloud",
    )


def send_crypto_suspended_email(to_email: str, container_name: str, days_left: int) -> None:
    _send(
        to_email,
        f"{container_name} is frozen - {days_left} day(s) left to renew",
        f"The paid period of {container_name} has ended, so the instance is frozen. "
        f"Your data is kept for {days_left} more day(s) and then permanently deleted.\n\n"
        f"Renew it from your dashboard ({settings.frontend_base_url}/dashboard/) and it comes "
        "back online automatically once the payment is confirmed.\n\n"
        "- PulsarX Cloud",
    )


def send_admin_delete_confirmation_email(
    admin_email: str, owner_email: str, container_name: str, confirm_url: str
) -> None:
    _send(
        admin_email,
        f"Confirm deletion of {container_name} ({owner_email})",
        f"A deletion was requested for instance {container_name}, owned by {owner_email}.\n\n"
        "This permanently deletes the container and its database record. This cannot be undone.\n\n"
        f"Confirm here (expires in 1 hour):\n{confirm_url}\n\n"
        "If you don't recognize this or don't want to delete it, just ignore this email.\n\n"
        "- PulsarX Cloud",
    )


def send_boosty_code_email(to_email: str, code: str, plan: str, months: int) -> None:
    _send(
        to_email,
        f"Your PulsarX activation code: {code}",
        f"Thanks for your payment on Boosty!\n\n"
        f"Plan:  {plan}\n"
        f"Period: {months} month(s)\n\n"
        f"Your activation code is: {code}\n\n"
        "Enter it on the \"Activate code\" tab in your dashboard to create your instance. "
        "The code is valid for 7 days.\n\n"
        "- PulsarX Cloud",
    )
