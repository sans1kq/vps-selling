"""Named Nano VPS promotions, separate from wallet top-ups."""
from datetime import datetime, timezone
import re
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from . import auth, growth_service as growth, wallet_service
from .capacity_service import StorageCapacityError, capacity_lock
from .database import get_db
from .growth_models import GiftCode, VpsPromo

router = APIRouter(prefix='/api')
NAMESPACE = uuid.UUID('b5ef019e-263e-4689-b361-659cf952dee0')


class PromoName(BaseModel):
    name: str = Field(min_length=1, max_length=64)


class PromoCreate(PromoName):
    duration_hours: int = Field(strict=True, ge=1, le=87600)
    ends_at: datetime | None = None


def normalized(name):
    key = name.strip().upper()
    if not re.fullmatch(r'[A-ZА-ЯЁ0-9_-]{1,64}', key):
        raise HTTPException(422, 'Use letters, numbers, dashes or underscores')
    return key


def describe(row):
    return {k: getattr(row,k) for k in ('name','duration_hours','ends_at','closed_at')}


@router.get('/admin/promotions')
def admin_list(_=Depends(auth.get_current_admin), db: Session=Depends(get_db)):
    return [describe(row) for row in db.query(VpsPromo).order_by(VpsPromo.created_at.desc()).all()]


@router.post('/admin/promotions')
def create(body: PromoCreate, _=Depends(auth.get_current_admin), db: Session=Depends(get_db)):
    if body.ends_at and (not body.ends_at.tzinfo or body.ends_at<=datetime.now(timezone.utc)):
        raise HTTPException(422, 'Choose a future expiry time with a timezone')
    key=normalized(body.name)
    inserted=db.execute(insert(VpsPromo).values(name=key,duration_hours=body.duration_hours,
        ends_at=body.ends_at).on_conflict_do_nothing().returning(VpsPromo.name)).scalar()
    if not inserted:
        raise HTTPException(409,'This promotion name is already in use')
    db.commit()
    return describe(db.get(VpsPromo,key))


@router.post('/admin/promotions/close')
def close(body: PromoName, _=Depends(auth.get_current_admin), db: Session=Depends(get_db)):
    row=db.query(VpsPromo).filter_by(name=normalized(body.name)).with_for_update().one_or_none()
    if row is None:
        raise HTTPException(404,'Unknown promotion')
    row.closed_at=row.closed_at or growth.now()
    db.commit()
    return describe(row)


@router.post('/promotions/deploy')
def deploy(body: PromoName, user=Depends(auth.get_current_user), db: Session=Depends(get_db)):
    growth.ensure_verified(user)
    auth.check_rate_limit('promo-deploy:'+str(user.id),15,300)
    key=normalized(body.name)
    capacity_lock(db)
    if wallet_service.account(db,user.id).frozen:
        raise HTTPException(403,'Account under review')
    promo=db.query(VpsPromo).filter_by(name=key).with_for_update().one_or_none()
    if not promo or promo.closed_at or promo.ends_at and promo.ends_at<=growth.now():
        raise HTTPException(409,'Promotion unavailable')
    request_key=uuid.uuid5(NAMESPACE,f'{user.id}:{key}')
    existing=db.query(GiftCode).filter_by(request_key=request_key).first()
    if existing:
        if existing.state not in ('active','queued','working'):
            raise HTTPException(409,'Promotion already redeemed')
        return {'server_id':str(existing.server_id),'state':existing.state,'replayed':True}
    ident=uuid.uuid4()
    grant=GiftCode(id=ident,request_key=request_key,digest=ident.hex+uuid.uuid4().hex,
                   hint='',label=key,plan='nano',duration_hours=promo.duration_hours)
    db.add(grant)
    try:
        return growth.queue_grant(db,user,grant)
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code,'No capacity available') from None
