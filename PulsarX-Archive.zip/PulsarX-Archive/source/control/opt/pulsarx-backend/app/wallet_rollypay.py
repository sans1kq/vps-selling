"""RollyPay one-time wallet top-ups. Signed receipts plus authenticated API checks.

RUB checkout prices use the merchant's RollyPay quote; USD wallet credits are
fixed before checkout. No payouts, recurring payments or automatic refunds.
"""
import base64
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_UP
import hashlib
import hmac
import json
import re
import threading
import time
import uuid
from urllib.parse import urlsplit

import requests
from fastapi import HTTPException
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import BigInteger, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import insert

from .database import Base
from .wallet_models import WalletTopup
from .anypay_service import ProviderUnavailable


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ROLLYPAY_", env_file=".env", extra="ignore")
    enabled: bool = False
    api_key: str = ""
    signing_secret: str = ""
    terminal_id: str = ""


settings = Settings()
_rate_cache = {}
_cache_lock = threading.Lock()
BASE_URL = "https://rollypay.io"
CALLBACK_URL = "https://pulsarx.example.invalid/api/wallet/rollypay/notification"
RETURN_URL = "https://pulsarx.example.invalid/dashboard/?tab=wallet"
IDENT = re.compile(r"[A-Za-z0-9_-]{1,96}\Z")
STATUSES = {"created", "processing", "paid", "expired", "canceled", "refunded", "chargeback"}
EVENTS = {"payment." + s: s for s in STATUSES}
EVENTS["refund_request.completed"] = "refunded"


class RollyInvoice(Base):
    __tablename__ = "wallet_rollypay_invoices"
    topup_id = Column(BigInteger().with_variant(Integer, "sqlite"),
                      ForeignKey("wallet_topups.id"), primary_key=True)
    rub_minor = Column(BigInteger, nullable=False)
    quote_rate = Column(String(40), nullable=False)
    terminal_id = Column(String(96), nullable=False)
    payment_id = Column(String(96), nullable=True, unique=True)
    create_started_at = Column(DateTime(timezone=True), nullable=True)
    signed_status = Column(String(24), nullable=True)
    signed_at = Column(DateTime(timezone=True), nullable=True)
    review_reason = Column(String(48), nullable=True)


class RollyReceipt(Base):
    __tablename__ = "wallet_rollypay_receipts"
    digest = Column(String(64), primary_key=True)
    topup_id = Column(BigInteger().with_variant(Integer, "sqlite"),
                      ForeignKey("wallet_topups.id"), nullable=False, index=True)
    payment_id = Column(String(96), nullable=False)
    status = Column(String(24), nullable=False)
    sent_at = Column(DateTime(timezone=True), nullable=False)
    received_at = Column(DateTime(timezone=True), nullable=False)


def now():
    return datetime.now(timezone.utc)


def enabled():
    return bool(settings.enabled and settings.api_key and settings.signing_secret and settings.terminal_id)


def require_enabled():
    if not enabled():
        raise HTTPException(503, "RollyPay is temporarily unavailable")


def strict_json(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError("Duplicate field")
            result[key] = value
        return result
    value = json.loads(raw, object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite number")))
    if not isinstance(value, dict):
        raise ValueError("Expected an object")
    return value


def request(method, path, payload=None):
    if method not in {"GET", "POST", "PUT"} or not re.fullmatch(
            r"/(?:(?:balance|rate)(?:\?terminal_id=[A-Za-z0-9_-]{1,96})?|payments(?:/[A-Za-z0-9_-]{1,96})?|terminals/[A-Za-z0-9_-]{1,96})", path):
        raise ValueError("Unsupported RollyPay endpoint")
    headers = {"X-API-Key": settings.api_key, "X-Nonce": str(uuid.uuid4()),
               "Accept": "application/json", "Content-Type": "application/json"}
    try:
        with requests.Session() as client:
            client.trust_env = False
            with client.request(method, BASE_URL + "/api/v1" + path, headers=headers,
                                json=payload, timeout=(3, 6), allow_redirects=False, stream=True) as response:
                content = bytearray()
                for part in response.iter_content(16384):
                    content.extend(part)
                    if len(content) > 524288:
                        raise ValueError("Response too large")
                if not 200 <= response.status_code < 300:
                    exc = ProviderUnavailable("RollyPay request failed", reason="http_error")
                    exc.http_status = response.status_code
                    raise exc
                return strict_json(bytes(content))
    except ProviderUnavailable:
        raise
    except (requests.RequestException, ValueError, TypeError, UnicodeError):
        raise ProviderUnavailable("RollyPay is temporarily unavailable", reason="invalid_result") from None


def decimal(value):
    if isinstance(value, (bool, dict, list)) or len(str(value)) > 64:
        raise ValueError("Invalid amount")
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        raise ValueError("Invalid amount") from None
    if not result.is_finite():
        raise ValueError("Invalid amount")
    return result


def minor(value):
    amount = decimal(value) * 100
    if amount != amount.to_integral_value() or amount <= 0 or amount > 10**12:
        raise ValueError("Invalid amount")
    return int(amount)


def checkout_ok(value):
    if not isinstance(value, str) or len(value) > 2048 or re.search(r"[\x00-\x20\x7f\\]", value):
        return False
    try:
        url = urlsplit(value)
        return (url.scheme == "https" and url.hostname == "pay.rollypay.io"
                and url.username is None and url.password is None and url.port is None
                and not url.query and not url.fragment
                and re.fullmatch(r"/pay/[A-Za-z0-9_-]{1,256}", url.path) is not None)
    except ValueError:
        return False


def production(data):
    return (data.get("test", False) is False
            and data.get("environment", "prod") in ("prod", "production"))


def rate():
    key = hashlib.sha256((settings.api_key + ":" + settings.terminal_id).encode()).hexdigest()
    with _cache_lock:
        cached = _rate_cache.get(key)
        if cached and cached[0] > time.monotonic():
            return cached[1]
        data = request("GET", "/rate?terminal_id=" + settings.terminal_id)
        try:
            value = decimal(data["rate"])
            if not Decimal("0.01") <= value <= Decimal("100000"):
                raise ValueError()
        except (KeyError, ValueError):
            raise ProviderUnavailable("RollyPay quote is unavailable", reason="invalid_result") from None
        _rate_cache.clear()
        _rate_cache[key] = (time.monotonic() + 60, value)
        return value


def _sign_quote(value):
    return hmac.new(settings.signing_secret.encode(), b"pulsarx-rollypay-quote-v1." + value,
                    hashlib.sha256).hexdigest()


def quote(user_id, amount_cents):
    from . import wallet_service as w
    require_enabled()
    if type(amount_cents) is not int or not w.settings.wallet_min_topup_cents <= amount_cents <= w.settings.wallet_max_topup_cents:
        raise HTTPException(422, "Amount is outside the permitted top-up range")
    current_rate = rate()
    rub_minor = int((Decimal(amount_cents) * current_rate).to_integral_value(rounding=ROUND_UP))
    payload = {"v": 1, "user": str(user_id), "usd": amount_cents, "rub": rub_minor,
               "rate": str(current_rate), "terminal": settings.terminal_id, "exp": int(time.time()) + 300}
    body = base64.urlsafe_b64encode(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).rstrip(b"=")
    token = body.decode() + "." + _sign_quote(body)
    return {"amount_cents": amount_cents, "payment_amount": f"{Decimal(rub_minor)/100:.2f}",
            "payment_currency": "RUB", "quote_token": token,
            "expires_at": datetime.fromtimestamp(payload["exp"], timezone.utc),
            "pricing": "RUB checkout quote for the selected USD wallet credit"}


def validate_quote(token, user_id, amount_cents):
    try:
        if not isinstance(token, str) or len(token) > 2048:
            raise ValueError()
        encoded, signature = token.split(".")
        body = encoded.encode("ascii")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", encoded) or not hmac.compare_digest(_sign_quote(body), signature):
            raise ValueError()
        data = strict_json(base64.urlsafe_b64decode(body + b"=" * (-len(body) % 4)))
        if (data.get("v") != 1 or data.get("user") != str(user_id) or data.get("terminal") != settings.terminal_id
                or type(data.get("usd")) is not int or data["usd"] != amount_cents
                or type(data.get("rub")) is not int or data["rub"] <= 0
                or type(data.get("exp")) is not int or not time.time() < data["exp"] <= time.time() + 301):
            raise ValueError()
        expected = int((Decimal(amount_cents) * decimal(data["rate"])).to_integral_value(rounding=ROUND_UP))
        if expected != data["rub"]:
            raise ValueError()
        return data
    except (ValueError, KeyError, TypeError, UnicodeError):
        raise HTTPException(409, detail={"code": "rollypay_quote_expired"}) from None


def new_topup(db, user, amount_cents, request_key, quote_token, referral_credit_cents=None):
    from . import wallet_service as w
    require_enabled()
    if not user.is_verified:
        raise HTTPException(403, "Verify your email first")
    if type(amount_cents) is not int or not w.settings.wallet_min_topup_cents <= amount_cents <= w.settings.wallet_max_topup_cents:
        raise HTTPException(422, "Amount is outside the permitted top-up range")
    acct = w.account(db, user.id)
    if acct.frozen:
        raise HTTPException(409, "Balance is under review. Please contact support.")
    previous = db.query(WalletTopup).filter_by(user_id=user.id, request_key=request_key).one_or_none()
    if previous:
        w.growth.verify_terms(db,previous,referral_credit_cents)
        if previous.amount_cents != amount_cents or previous.provider != "rollypay":
            raise HTTPException(409, "Request key was already used")
        db.commit()
        return previous
    w.expire_topups(db, user.id)
    active = w.open_topups(db, user.id).order_by(WalletTopup.created_at.desc()).first()
    if active:
        w.growth.verify_terms(db,active,referral_credit_cents)
        if active.provider == "rollypay" and active.amount_cents == amount_cents:
            db.commit()
            return active
        raise HTTPException(409, detail={"code": "active_topup", "topup_id": str(active.id)})
    data = validate_quote(quote_token, user.id, amount_cents)
    row = WalletTopup(user_id=user.id, amount_cents=amount_cents, request_key=request_key,
                      provider="rollypay", status="creating", expires_at=now() + timedelta(minutes=30))
    db.add(row)
    db.flush()
    w.growth.bind_topup(db,row,referral_credit_cents)
    db.add(RollyInvoice(topup_id=row.id, rub_minor=data["rub"], quote_rate=data["rate"],
                        terminal_id=data["terminal"]))
    db.commit()
    return row


def _locked(db, user_id, pay_id):
    from . import wallet_service as w
    acct = w.account(db, user_id)
    row = db.query(WalletTopup).filter_by(id=pay_id, user_id=user_id, provider="rollypay").populate_existing().with_for_update().one_or_none()
    invoice = db.query(RollyInvoice).filter_by(topup_id=pay_id).populate_existing().with_for_update().one_or_none()
    if row is None or invoice is None:
        raise HTTPException(404, "RollyPay top-up not found")
    return acct, row, invoice


def matches(data, row, invoice):
    try:
        ident = data.get("payment_id")
        return (isinstance(ident, str) and IDENT.fullmatch(ident) is not None
                and (invoice.payment_id is None or invoice.payment_id == ident)
                and data.get("order_id") == "pxw_" + str(row.id)
                and minor(data.get("amount")) == invoice.rub_minor
                and data.get("payment_currency", data.get("currency")) == "RUB"
                and data.get("terminal_id", invoice.terminal_id) == invoice.terminal_id
                and data.get("status") in STATUSES and production(data))
    except (ValueError, TypeError):
        return False


def _save_identity(row, invoice, ident):
    if invoice.payment_id and invoice.payment_id != ident:
        return False
    invoice.payment_id = ident
    row.transaction_id = "rp:" + hashlib.sha256(ident.encode()).hexdigest()[:28]
    return True


def checkout(db, user, pay_id):
    from . import wallet_service as w
    require_enabled()
    acct, row, invoice = _locked(db, user.id, pay_id)
    w.expire_topups(db, user.id)
    if acct.frozen or not w.topup_out(row)["can_resume"]:
        db.commit()
        raise HTTPException(409, "This invoice is no longer open for payment")
    if row.checkout_url:
        if not checkout_ok(row.checkout_url) or not invoice.payment_id:
            raise ProviderUnavailable("Invalid saved RollyPay checkout", reason="invalid_result")
        result = w.topup_out(row)
        result["checkout_url"] = row.checkout_url
        db.commit()
        return result
    if invoice.create_started_at:
        db.commit()
        raise HTTPException(409, detail={"code": "checkout_uncertain"})
    invoice.create_started_at = now()
    payload = {"amount": f"{Decimal(invoice.rub_minor)/100:.2f}", "payment_currency": "RUB",
               "terminal_id": invoice.terminal_id,
               "order_id": "pxw_" + str(row.id), "description": "PulsarX balance top-up",
               "success_redirect_url": RETURN_URL, "fail_redirect_url": RETURN_URL, "test": False}
    db.commit()  # Creation intent survives a timeout; never repeat an uncertain POST.
    try:
        data = request("POST", "/payments", payload)
    except ProviderUnavailable as exc:
        if exc.http_status == 400:
            _, row, invoice = _locked(db, user.id, pay_id)
            if not invoice.payment_id and not row.live_notification:
                row.status, row.provider_status = "closed", "amount_rejected"
            db.commit()
            raise HTTPException(422, detail={"code": "rollypay_rejected"}) from None
        raise
    _, row, invoice = _locked(db, user.id, pay_id)
    if not matches(data, row, invoice):
        row.status, invoice.review_reason = "review", "create_response_mismatch"
        db.commit()
        raise ProviderUnavailable("RollyPay response does not match this invoice", reason="invalid_result")
    _save_identity(row, invoice, data["payment_id"])
    if not checkout_ok(data.get("pay_url")):
        row.provider_status = "checkout_invalid"
        db.commit()
        raise ProviderUnavailable("Invalid RollyPay checkout URL", reason="invalid_result")
    row.checkout_url = data["pay_url"]
    try:
        expires = datetime.fromisoformat(str(data["expires_at"]).replace("Z", "+00:00"))
        if expires.tzinfo is None or not now() < expires <= now() + timedelta(days=1):
            raise ValueError()
    except (KeyError, ValueError, TypeError):
        row.provider_status = "checkout_invalid"
        db.commit()
        raise ProviderUnavailable("RollyPay expiry is unavailable", reason="invalid_result") from None
    row.expires_at = expires
    if row.status == "creating":
        row.status = "pending"
    result = w.topup_out(row)
    if not result["can_resume"]:
        db.commit()
        raise HTTPException(409, "Invoice was closed or paid while checkout was being prepared")
    result["checkout_url"] = row.checkout_url
    db.commit()
    return result


def verify_event(raw, timestamp, signature, test_header=""):
    require_enabled()
    try:
        if len(raw) > 65536 or not isinstance(timestamp, str) or not re.fullmatch(r"\d{10,12}", timestamp):
            raise ValueError()
        # Keep the documented hour of webhook retries valid even if the
        # original timestamp is retained. Ledger uniqueness handles replays.
        if (int(timestamp) > time.time() + 300 or time.time() - int(timestamp) > 86400
                or not re.fullmatch(r"[a-fA-F0-9]{64}", signature or "")):
            raise ValueError()
        expected = hmac.new(settings.signing_secret.encode(), timestamp.encode() + b"." + raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature.lower()):
            raise ValueError()
        data = strict_json(raw)
        if data.get("test") is True or str(test_header).lower() == "true":
            return None  # Sandbox can never change a real wallet, including its freeze state.
        if data.get("test") is not False or not production(data):
            raise ValueError()
        if data.get("event_type") not in EVENTS:
            return None
        if EVENTS[data["event_type"]] != data.get("status"):
            raise ValueError()
        if not isinstance(data.get("payment_id"), str) or not IDENT.fullmatch(data["payment_id"]):
            raise ValueError()
        if not re.fullmatch(r"pxw_\d{1,16}", str(data.get("order_id", ""))):
            return None  # Another application/order in this terminal is not a wallet invoice.
        return data
    except (ValueError, TypeError, UnicodeError):
        raise HTTPException(403, "Invalid RollyPay notification") from None


def receive(db, data, raw, timestamp):
    from . import wallet_service as w
    pay_id = int(data["order_id"][4:])
    info = db.get(WalletTopup, pay_id)
    if info is None or info.provider != "rollypay":
        db.rollback()
        return
    acct, row, invoice = _locked(db, info.user_id, pay_id)
    if not matches(data, row, invoice):
        db.rollback()
        raise HTTPException(400, "RollyPay invoice mismatch")
    _save_identity(row, invoice, data["payment_id"])
    digest = hashlib.sha256(raw).hexdigest()
    db.execute(insert(RollyReceipt).values(digest=digest, topup_id=pay_id,
        payment_id=data["payment_id"], status=data["status"], sent_at=datetime.fromtimestamp(int(timestamp), timezone.utc),
        received_at=now()).on_conflict_do_nothing(index_elements=["digest"]))
    sent_at = datetime.fromtimestamp(int(timestamp), timezone.utc)
    if invoice.signed_at is None or sent_at >= invoice.signed_at:
        invoice.signed_status, invoice.signed_at = data["status"], sent_at
        if not row.credited_at and row.status != "review":
            row.provider_status = data["status"]
    row.live_notification = True
    if data["status"] in {"chargeback", "refunded"}:
        row.provider_status = data["status"]
        if row.credited_at:
            row.status, acct.frozen = "review", True
            invoice.review_reason = "provider_reversal"
        elif row.status != "review":
            row.status = "closed"
    db.commit()  # Acknowledge only after the signed receipt is durable. Worker verifies by API.


def settle(db, info):
    from . import wallet_service as w
    require_enabled()
    inv = db.get(RollyInvoice, info.id)
    if inv is None or not inv.payment_id:
        info.checked_at = now()
        db.commit()
        return info
    data = request("GET", "/payments/" + inv.payment_id)
    acct, row, invoice = _locked(db, info.user_id, info.id)
    row.checked_at = now()
    if not matches(data, row, invoice):
        row.status, invoice.review_reason = "review", "api_invoice_mismatch"
        if row.credited_at:
            acct.frozen = True
        db.commit()
        return row
    state = data["status"]
    row.provider_status = state
    if state in {"refunded", "chargeback"}:
        if row.credited_at:
            row.status, acct.frozen = "review", True
            invoice.review_reason = "provider_reversal"
        elif row.status != "review":
            row.status = "closed"
    elif row.credited_at:
        pass
    elif state == "paid" and row.live_notification and row.status != "review":
        # Require a matching paid receipt, not just a created/expired notification.
        paid_receipt = db.query(RollyReceipt.digest).filter_by(topup_id=row.id,
                          payment_id=invoice.payment_id, status="paid").first()
        reversal = db.query(RollyReceipt.digest).filter(RollyReceipt.topup_id == row.id,
                         RollyReceipt.status.in_(("refunded", "chargeback"))).first()
        if reversal:
            row.status, invoice.review_reason = "review", "conflicting_reversal"
        elif paid_receipt:
            w.entry(db, acct, row.amount_cents, "topup", "rollypay:" + str(row.id), "RollyPay top-up")
            w.growth.credit_discount(db,acct,row)
            row.status, row.credited_at = "credited", now()
    elif state in {"expired", "canceled"} and row.status != "review":
        row.status = "expired" if state == "expired" else "closed"
    db.commit()
    return row


def paid_evidence(row):
    """QR activation is not proof of funds; retain authenticated paid receipts."""
    if row.credited_at or row.provider_status == "paid":
        return True
    from sqlalchemy.orm import object_session
    db = object_session(row)
    return bool(db is not None and db.query(RollyReceipt.digest).filter_by(
        topup_id=row.id, status="paid").first())


def extra(row):
    from sqlalchemy.orm import object_session
    db = object_session(row)
    invoice = db.get(RollyInvoice, row.id) if db is not None else None
    if invoice is None:
        return {}
    received = paid_evidence(row)
    return {"payment_amount": f"{Decimal(invoice.rub_minor)/100:.2f}", "payment_currency": "RUB",
            "payment_in_progress": bool(received and not row.credited_at),
            "awaiting_notification": row.provider_status == "paid" and not row.live_notification,
            "can_resume": bool(enabled() and row.status in {"pending", "creating"}
                and row.expires_at > now() and not received and row.provider_status != "checkout_invalid"),
            "can_cancel": bool(row.status in {"pending", "creating"} and row.expires_at > now()
                and not received)}
