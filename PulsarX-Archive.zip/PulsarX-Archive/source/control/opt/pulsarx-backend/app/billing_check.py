"""Run daily (via systemd timer) to enforce billing lifecycle rules.

Two independent things happen here:
1. Self-cancel grace period: if a subscription was cancelled and the paid
   period ended, the user gets 1 extra day (not suspended) to back up data
   or resubscribe. If that day passes, delete the server.
2. Payment-failure dunning: if a payment failed, the server was already
   suspended immediately by the webhook. From there we send a reminder
   email every 2 days, and delete the server once 14 days have passed
   with no successful payment.
"""
import logging
from datetime import datetime, timedelta, timezone

from . import email_service, lemonsqueezy_service
from .database import SessionLocal
from .models import Server, ServerStatus
from .routers.servers import _delete_server_fully
from .wallet_service import active_order
from .schemas import PLANS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pulsarx.billing_check")

GRACE_PERIOD = timedelta(days=1)
DUNNING_EMAIL_INTERVAL = timedelta(days=2)
DUNNING_DELETE_AFTER = timedelta(days=14)


def _check_self_cancel_grace(db, now) -> None:
    ids=[row[0] for row in db.query(Server.id).filter(Server.subscription_cancelled_at.isnot(None),Server.subscription_period_ends_at.isnot(None)).all()]
    db.rollback()
    for ident in ids:
        server=db.query(Server).filter_by(id=ident).populate_existing().with_for_update().one_or_none()
        if (server is None or active_order(db,ident) or server.subscription_cancelled_at is None
                or server.subscription_period_ends_at is None or now<server.subscription_period_ends_at+GRACE_PERIOD):
            db.rollback();continue
        _delete_server_fully(db,server)


def _check_abandoned_checkouts(db, now) -> None:
    cutoff=now-timedelta(hours=24)
    ids=[row[0] for row in db.query(Server.id).filter(Server.status==ServerStatus.pending_approval,Server.created_at<cutoff).all()]
    db.rollback()
    for ident in ids:
        server=db.query(Server).filter_by(id=ident).populate_existing().with_for_update().one_or_none()
        if (server is None or server.status!=ServerStatus.pending_approval or server.created_at>=cutoff
                or active_order(db,ident)):
            db.rollback();continue
        _delete_server_fully(db,server)


def _check_payment_dunning(db, now) -> None:
    ids=[row[0] for row in db.query(Server.id).filter(Server.payment_failed_at.isnot(None)).all()]
    db.rollback()
    for ident in ids:
        server=db.query(Server).filter_by(id=ident).populate_existing().with_for_update().one_or_none()
        if server is None or active_order(db,ident) or server.payment_failed_at is None:
            db.rollback();continue
        if not server.ls_subscription_id and server.paid_until is not None and server.paid_until>now:
            db.rollback();continue
        elapsed=now-server.payment_failed_at
        if elapsed>=DUNNING_DELETE_AFTER:
            _delete_server_fully(db,server);continue
        last_sent=server.last_dunning_email_sent_at or server.payment_failed_at
        if now-last_sent>=DUNNING_EMAIL_INTERVAL:
            days_left=max(1,(DUNNING_DELETE_AFTER-elapsed).days)
            try:
                if server.ls_subscription_id is None and server.paid_until is not None:
                    email_service.send_crypto_suspended_email(server.owner_email,server.container_name,days_left)
                else:email_service.send_payment_failed_email(server.owner_email,server.container_name,days_left)
                server.last_dunning_email_sent_at=now;db.commit()
            except Exception:
                db.rollback();logger.exception("Failed to send dunning reminder")
        else:db.rollback()


def _check_upcoming_renewals(db, now) -> None:
    """Email a reminder the day before a subscription renews.

    We don't store renews_at locally for active subscriptions (only for
    cancelled ones, where it becomes subscription_period_ends_at), so this
    checks live against Lemon Squeezy for each active subscriber. Fine at
    current scale; would need batching/caching if the subscriber count grows
    a lot.
    """
    candidates = (
        db.query(Server)
        .filter(
            Server.ls_subscription_id.isnot(None),
            Server.subscription_cancelled_at.is_(None),
            Server.payment_failed_at.is_(None),
        )
        .all()
    )
    for server in candidates:
        if active_order(db, server.id):
            continue
        try:
            sub = lemonsqueezy_service.get_subscription(server.ls_subscription_id)
        except Exception:
            logger.exception("Failed to fetch subscription for renewal check, server %s", server.id)
            continue

        renews_at_str = sub.get("renews_at")
        if not renews_at_str:
            continue
        renews_at = datetime.fromisoformat(renews_at_str.replace("Z", "+00:00"))

        if renews_at <= now or renews_at - now > timedelta(hours=36):
            continue
        if server.renewal_reminder_for == renews_at:
            continue

        price_cents = PLANS.get(server.plan, {}).get("price_cents")
        amount_formatted = f"${price_cents / 100:.2f}" if price_cents else "your plan's price"

        try:
            email_service.send_renewal_reminder_email(server.owner_email, server.container_name, amount_formatted)
            server.renewal_reminder_for = renews_at
            db.commit()
            logger.info("Sent renewal reminder to %s for %s", server.owner_email, server.container_name)
        except Exception:
            logger.exception("Failed to send renewal reminder for %s", server.container_name)


def run() -> None:
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        _check_self_cancel_grace(db, now)
        _check_payment_dunning(db, now)
        # abandoned checkouts are cleaned up by app.payments_cron (invoice-aware)
        _check_upcoming_renewals(db, now)
    finally:
        db.close()


if __name__ == "__main__":
    run()
