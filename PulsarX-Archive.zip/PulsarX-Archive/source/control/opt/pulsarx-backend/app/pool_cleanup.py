"""Remove only cached image volumes from an otherwise unused tenant pool."""
import json
import re
from urllib.parse import parse_qs, urlsplit

DISKS = "/var/lib/incus/disks"


class PoolCleanupError(RuntimeError):
    pass


def validate_container_name(name):
    if not isinstance(name, str) or not re.fullmatch(r"mini-[0-9a-f]{10}", name):
        raise PoolCleanupError("Unexpected tenant container name")


def image_reference(value):
    if not isinstance(value, str):
        raise PoolCleanupError("Invalid Incus dependency")
    url = urlsplit(value)
    match = re.fullmatch(r"/1\.0/images/([0-9a-f]{64})", url.path)
    query = parse_qs(url.query, keep_blank_values=True)
    if url.scheme or url.netloc or url.fragment or not match or any(
        key != "project" or values != ["default"] for key, values in query.items()
    ):
        raise PoolCleanupError("A storage pool still has a non-image dependency: " + value)
    return match[1]


class Incus:
    def __init__(self, run):
        self.run = run

    def json(self, args, expected):
        try:
            value = json.loads(self.run(["incus"] + args, timeout=30))
        except (ValueError, TypeError) as exc:
            raise PoolCleanupError("Invalid Incus JSON while checking pool ownership") from exc
        if not isinstance(value, expected):
            raise PoolCleanupError("Unexpected Incus response while checking pool ownership")
        return value

    def capability(self):
        info = self.json(["query", "/1.0"], dict)
        if "metadata" in info:
            info = info["metadata"]
        if not isinstance(info, dict) or info.get("environment", {}).get("server_clustered") is not False:
            raise PoolCleanupError("This cleanup requires a standalone Incus host")
        extensions = info.get("api_extensions")
        if not isinstance(extensions, list) or "storage_images_delete" not in extensions:
            raise PoolCleanupError("Incus does not advertise per-pool image-volume deletion")
        return info["environment"].get("server_name")

    def pools(self):
        rows = self.json(["storage", "list", "--format", "json"], list)
        if any(not isinstance(row, dict) or not isinstance(row.get("name"), str) for row in rows):
            raise PoolCleanupError("Invalid Incus storage pool list")
        if len({row["name"] for row in rows}) != len(rows):
            raise PoolCleanupError("Duplicate Incus storage pool names")
        return {row["name"]: row for row in rows}

    def instances(self):
        rows = self.json(["list", "--all-projects", "--format", "json"], list)
        if any(not isinstance(row, dict) or not isinstance(row.get("name"), str)
               or not isinstance(row.get("project"), str)
               or not isinstance(row.get("expanded_devices"), dict) for row in rows):
            raise PoolCleanupError("Incomplete all-projects instance list")
        return rows

    def volumes(self, pool):
        rows = self.json(["storage", "volume", "list", pool, "--all-projects", "--format", "json"], list)
        if any(not isinstance(row, dict) for row in rows):
            raise PoolCleanupError("Invalid all-projects volume list")
        return rows

    def inspect(self, name):
        validate_container_name(name)
        pool_name = name + "-pool"
        pool = self.pools().get(pool_name)
        if pool is None:
            return None
        config = pool.get("config")
        if pool.get("driver") != "btrfs" or not isinstance(config, dict) or config.get("source") != DISKS + "/" + pool_name + ".img":
            raise PoolCleanupError("Tenant pool ownership/source did not match: " + pool_name)
        if str(pool.get("status", "")).lower() != "created":
            raise PoolCleanupError("Tenant pool is not in Created state: " + pool_name)
        if "used_by" not in pool:
            raise PoolCleanupError("Missing pool dependency list: " + pool_name)
        refs = pool["used_by"]
        if refs is None:  # Go JSON can encode an empty slice as null.
            refs = []
        if not isinstance(refs, list):
            raise PoolCleanupError("Missing pool dependency list: " + pool_name)
        pool["used_by"] = refs
        referenced_images = {image_reference(ref) for ref in refs}
        for instance in self.instances():
            if instance["name"] == name:
                raise PoolCleanupError("The tenant instance still exists: " + name)
            for device in instance["expanded_devices"].values():
                if not isinstance(device, dict):
                    raise PoolCleanupError("Invalid expanded instance device")
                if device.get("pool") == pool_name:
                    raise PoolCleanupError("Another instance still uses the tenant pool: " + pool_name)
        volumes = self.volumes(pool_name)
        seen = set()
        for volume in volumes:
            fingerprint = volume.get("name")
            if volume.get("type") != "image" or volume.get("project") != "default" or not isinstance(fingerprint, str) or not re.fullmatch(r"[0-9a-f]{64}", fingerprint):
                raise PoolCleanupError("Tenant pool contains a non-cache volume: " + pool_name)
            if volume.get("content_type") != "filesystem":
                raise PoolCleanupError("Unexpected tenant image content type: " + pool_name)
            if "used_by" not in volume:
                raise PoolCleanupError("Missing image-volume dependency list: " + pool_name)
            dependencies = volume["used_by"]
            if dependencies is None:
                dependencies = []
            if not isinstance(dependencies, list) or any(image_reference(ref) != fingerprint for ref in dependencies):
                raise PoolCleanupError("An image volume has unexpected dependencies: " + pool_name)
            volume["used_by"] = dependencies
            if fingerprint in seen:
                raise PoolCleanupError("Duplicate cached image volume")
            seen.add(fingerprint)
        if seen != referenced_images:
            raise PoolCleanupError("Pool and volume references changed; retry the cleanup: " + pool_name)
        return {"pool": pool, "volumes": volumes}

    def purge_images(self, name):
        self.capability()
        initial = self.inspect(name)
        if initial is None:
            return
        pool_name = name + "-pool"
        for volume in initial["volumes"]:
            # Re-read ownership, all projects and dependencies before each delete.
            current = self.inspect(name)
            if current is None:
                return
            fingerprint = volume["name"]
            if not any(v["name"] == fingerprint for v in current["volumes"]):
                continue
            try:
                self.run(["incus", "--project", "default", "storage", "volume", "delete",
                          pool_name, "image/" + fingerprint], timeout=90)
            except Exception:
                after = self.inspect(name)
                if after is not None and any(v["name"] == fingerprint for v in after["volumes"]):
                    raise
            after = self.inspect(name)
            if after is not None and any(v["name"] == fingerprint for v in after["volumes"]):
                raise PoolCleanupError("Image deletion could not be verified: " + pool_name)
        final = self.inspect(name)
        if final is not None and (final["volumes"] or final["pool"]["used_by"]):
            raise PoolCleanupError("Tenant pool is not empty after image-cache cleanup")


def prepare_dedicated_pool_cleanup(name, run):
    Incus(run).purge_images(name)
