"""Read-only, paginated administration reports. Existing mutation routes are retained."""
from datetime import datetime, timedelta, timezone
from typing import Literal
import subprocess
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from sqlalchemy import case, func, or_
from sqlalchemy.orm import Session

from . import auth, growth_service
from .database import get_db
from .growth_models import GiftCode
from .models import AdminSession, Server, ServerStatus, User
from .wallet_models import WalletAccount, WalletEntry, WalletOrder, WalletTopup

def private_response(response:Response):
    response.headers['Cache-Control']='no-store'
    response.headers['Pragma']='no-cache'
    response.headers['X-Content-Type-Options']='nosniff'


router = APIRouter(prefix='/api/admin/desk', tags=['admin'], dependencies=[Depends(auth.get_current_admin),Depends(private_response)])
PROVIDERS = ('anypay', 'freekassa', 'plisio', 'rollypay', 'stars')


def now_utc():
    return datetime.now(timezone.utc)


def literal(value):
    return '%' + value.strip().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'


def monetary_topups(db):
    return db.query(WalletTopup.user_id).filter(WalletTopup.amount_cents > 0,
        WalletTopup.credited_at.isnot(None), WalletTopup.provider.in_(PROVIDERS))


def day_column(db, column):
    return func.date(func.timezone('UTC', column)) if db.get_bind().dialect.name == 'postgresql' else func.date(column)


@router.get('/session')
def session(request: Request, db: Session = Depends(get_db)):
    # The router dependency has already validated an ADMIN session. No token is returned.
    token = request.headers.get('authorization', '').removeprefix('Bearer ').strip()
    row = db.get(AdminSession, token)
    if row is None:
        raise HTTPException(401, 'Invalid administrator session')
    return {'created_at': row.created_at, 'expires_at': row.expires_at,
            'server_time': now_utc(), 'role': 'admin'}


@router.get('/summary')
def summary(days: int = Query(30,ge=7,le=90), db: Session = Depends(get_db)):
    if days not in (7,30,90): raise HTTPException(422,'Choose 7, 30 or 90 days')
    now = now_utc()
    start = (now - timedelta(days=days-1)).replace(hour=0, minute=0, second=0, microsecond=0)
    end = now
    completed = db.query(WalletOrder).filter(WalletOrder.status == 'completed',
        WalletOrder.completed_at >= start, WalletOrder.completed_at <= end)
    purchases = int(completed.with_entities(func.coalesce(func.sum(WalletOrder.amount_cents), 0)).scalar())
    credits = db.query(WalletTopup).filter(WalletTopup.credited_at >= start,
        WalletTopup.credited_at <= end, WalletTopup.provider.in_(PROVIDERS))
    credited = int(credits.with_entities(func.coalesce(func.sum(WalletTopup.amount_cents), 0)).scalar())
    chart = {str(start.date()+timedelta(days=i)): {'date': str(start.date()+timedelta(days=i)),
              'orders_cents': 0, 'topups_cents': 0} for i in range(days)}
    for query, date, amount, key in [(completed, WalletOrder.completed_at, WalletOrder.amount_cents, 'orders_cents'),
                                    (credits, WalletTopup.credited_at, WalletTopup.amount_cents, 'topups_cents')]:
        day = day_column(db, date)
        for stamp, value in query.with_entities(day, func.sum(amount)).group_by(day).all():
            if str(stamp) in chart:
                chart[str(stamp)][key] = int(value or 0)
    live = db.query(Server).filter(Server.status != ServerStatus.deleted)
    plan_counts = dict(live.with_entities(Server.plan, func.count(Server.id)).group_by(Server.plan).all())
    counts = dict(live.with_entities(Server.status, func.count(Server.id)).group_by(Server.status).all())
    review_orders = db.query(WalletOrder).filter(WalletOrder.status == 'review').count()
    review_topups = db.query(WalletTopup).filter(WalletTopup.status == 'review').count()
    gifts_soon = live.filter(Server.trial_expires_at > now, Server.trial_expires_at <= now+timedelta(hours=24)).count()
    overdue = live.filter(Server.paid_until.isnot(None), Server.paid_until <= now).count()
    due_soon=live.filter(Server.paid_until>now,Server.paid_until<=now+timedelta(days=3)).count()
    failed = int(counts.get(ServerStatus.failed, 0))
    return {'currency': 'USD', 'period': {'days': days, 'from': start, 'to': end, 'timezone': 'UTC'},
        'users': db.query(User).count(), 'activated_users': monetary_topups(db).distinct().count(),
        'servers': live.count(), 'running_servers': int(counts.get(ServerStatus.running, 0)),
        'plans': plan_counts, 'completed_order_cents': purchases, 'credited_topup_cents': credited,
        'wallet_balance_cents': int(db.query(func.coalesce(func.sum(WalletAccount.balance_cents), 0)).scalar()),
        'attention': {'order_review': review_orders, 'topup_review': review_topups,
                      'failed_servers': failed, 'expiring_gifts': gifts_soon, 'overdue_servers': overdue,'due_soon':due_soon},
        'chart': list(chart.values()), 'checked_at': now}


@router.get('/users')
def users(q: str = Query('', max_length=160), activation: Literal['all','yes','no'] = 'all',
          offset: int = Query(0, ge=0, le=1_000_000), limit: int = Query(30, ge=1, le=100),
          db: Session = Depends(get_db)):
    rows = db.query(User)
    if q.strip():
        value = literal(q)
        predicates = [User.email.ilike(value, escape='\\'),
            (User.first_name+' '+User.last_name).ilike(value, escape='\\')]
        try: predicates.append(User.id == uuid.UUID(q.strip()))
        except ValueError: pass
        rows = rows.filter(or_(*predicates))
    active = monetary_topups(db)
    if activation != 'all':
        rows = rows.filter(User.id.in_(active) if activation == 'yes' else ~User.id.in_(active))
    total = rows.count()
    page = rows.order_by(User.created_at.desc(), User.id.desc()).offset(offset).limit(limit).all()
    ids = [u.id for u in page]
    accounts = {a.user_id:a for a in db.query(WalletAccount).filter(WalletAccount.user_id.in_(ids)).all()} if ids else {}
    activated = {u[0] for u in active.filter(WalletTopup.user_id.in_(ids)).distinct().all()} if ids else set()
    counts = dict(db.query(Server.owner_id,func.count(Server.id)).filter(Server.owner_id.in_(ids),
        Server.status != ServerStatus.deleted).group_by(Server.owner_id).all()) if ids else {}
    return {'items': [{'id':str(u.id), 'name':' '.join(x for x in (u.first_name,u.last_name) if x),
        'email':u.email, 'verified':u.is_verified, 'activated':u.id in activated,
        'balance_cents':accounts[u.id].balance_cents if u.id in accounts else 0,
        'frozen':bool(u.id in accounts and accounts[u.id].frozen), 'servers':counts.get(u.id,0),
        'created_at':u.created_at} for u in page], 'total':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


def server_out(server):
    return {key:getattr(server,key) for key in ('id','container_name','owner_email','plan','image',
        'ram_mb','cpu_cores','disk_gb','ssh_port','ssh_username','web_port','custom_domain',
        'status','created_at','paid_until','trial_expires_at','admin_suspended_at')} | {
        'has_subscription':bool(server.ls_subscription_id)}


@router.get('/servers')
def servers(q: str = Query('', max_length=160), plan: Literal['','nano','mini','plus'] = '',
            status: Literal['','running','suspended','pending_approval','pending','provisioning','failed','deleted','trial','overdue','soon'] = '', offset: int = Query(0, ge=0, le=1_000_000),
            limit: int = Query(30, ge=1, le=100), db: Session = Depends(get_db)):
    rows=db.query(Server)
    if q.strip():
        value=literal(q)
        filters=[Server.owner_email.ilike(value,escape='\\'),Server.container_name.ilike(value,escape='\\')]
        try: filters.append(Server.id==uuid.UUID(q.strip()))
        except ValueError: pass
        rows=rows.filter(or_(*filters))
    if plan: rows=rows.filter(Server.plan==plan)
    if status=='trial': rows=rows.filter(Server.trial_expires_at.isnot(None),Server.status!=ServerStatus.deleted)
    elif status=='overdue': rows=rows.filter(Server.paid_until<=now_utc(),Server.status!=ServerStatus.deleted)
    elif status=='soon': rows=rows.filter(Server.paid_until>now_utc(),Server.paid_until<=now_utc()+timedelta(days=3),Server.status!=ServerStatus.deleted)
    elif status: rows=rows.filter(Server.status==status)
    else: rows=rows.filter(Server.status!=ServerStatus.deleted)
    total=rows.count()
    page=rows.order_by(Server.created_at.desc(),Server.id.desc()).offset(offset).limit(limit).all()
    return {'items':[server_out(s) for s in page], 'total':total,'offset':offset,
            'limit':limit,'has_more':offset+len(page)<total}


@router.get('/servers/{server_id}')
def server_detail(server_id:uuid.UUID,db:Session=Depends(get_db)):
    row=db.get(Server,server_id)
    if row is None: raise HTTPException(404,'Server not found')
    return server_out(row)


@router.get('/orders')
def orders(q: str = Query('', max_length=160), status: str = Query('', max_length=24),
           offset: int = Query(0, ge=0, le=1_000_000), limit: int = Query(30, ge=1, le=100),
           db: Session = Depends(get_db)):
    rows = db.query(WalletOrder, User.email).outerjoin(User, User.id == WalletOrder.user_id)
    if q.strip():
        value = literal(q)
        rows = rows.filter(or_(User.email.ilike(value, escape='\\'), WalletOrder.container_name.ilike(value,escape='\\')))
    if status: rows = rows.filter(WalletOrder.status == status)
    total = rows.count()
    page = rows.order_by(WalletOrder.created_at.desc(),WalletOrder.id.desc()).offset(offset).limit(limit).all()
    return {'items':[{'id':str(o.id),'email':email,'server_id':str(o.server_id) if o.server_id else None,
        'server_name':o.container_name,'kind':o.kind,'plan':o.plan,'months':o.months,
        'amount_cents':o.amount_cents,'status':o.status,'error_code':o.error_code,
        'created_at':o.created_at,'completed_at':o.completed_at} for o,email in page],
        'total':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


@router.get('/ledger')
def ledger(q: str = Query('', max_length=160), offset: int = Query(0, ge=0, le=1_000_000),
           limit: int = Query(30, ge=1, le=100), db: Session = Depends(get_db)):
    rows = db.query(WalletEntry,User.email).outerjoin(User,User.id==WalletEntry.user_id)
    if q.strip(): rows=rows.filter(User.email.ilike(literal(q),escape='\\'))
    total=rows.count()
    page=rows.order_by(WalletEntry.created_at.desc(),WalletEntry.id.desc()).offset(offset).limit(limit).all()
    return {'items':[{'id':str(e.id),'email':email,'amount_cents':e.amount_cents,
        'balance_after_cents':e.balance_after_cents,'kind':e.kind,'label':e.label,
        'reference':e.reference,'created_at':e.created_at} for e,email in page],
        'total':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


@router.get('/topups')
def topups(q: str = Query('', max_length=160), status: str = Query('', max_length=24),
           offset: int = Query(0, ge=0, le=1_000_000), limit: int = Query(30, ge=1, le=100),
           db: Session = Depends(get_db)):
    rows=db.query(WalletTopup,User.email).outerjoin(User,User.id==WalletTopup.user_id)
    if q.strip(): rows=rows.filter(User.email.ilike(literal(q),escape='\\'))
    if status: rows=rows.filter(WalletTopup.status==status)
    total=rows.count()
    page=rows.order_by(WalletTopup.created_at.desc(),WalletTopup.id.desc()).offset(offset).limit(limit).all()
    return {'items':[{'id':str(t.id),'email':email,'provider':t.provider,'amount_cents':t.amount_cents,
        'status':t.status,'credited_at':t.credited_at,'created_at':t.created_at,'expires_at':t.expires_at}
        for t,email in page], 'total':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


@router.get('/gifts')
def gifts(q: str = Query('', max_length=160), status: str = Query('', max_length=24),
          offset: int = Query(0, ge=0, le=1_000_000), limit: int = Query(30, ge=1, le=100),
          db: Session = Depends(get_db)):
    now=now_utc()
    display=case(((GiftCode.state=='active') & (GiftCode.expires_at<=now),'expired'),
                 ((GiftCode.state=='active') & GiftCode.server_id.is_(None),'deleted'),else_=GiftCode.state)
    rows=db.query(GiftCode).outerjoin(User,User.id==GiftCode.redeemed_by)
    if q.strip():
        value=literal(q)
        rows=rows.filter(or_(GiftCode.label.ilike(value,escape='\\'),GiftCode.hint.ilike(value,escape='\\'),User.email.ilike(value,escape='\\')))
    if status: rows=rows.filter(display==status)
    total=rows.count()
    page=rows.order_by(GiftCode.created_at.desc(),GiftCode.id.desc()).offset(offset).limit(limit).all()
    return {'items':[{**growth_service.code_out(db,g), 'review_reference':g.review_reference} for g in page],
        'total':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


def unit_report(unit):
    # A fixed read-only systemd query. No caller-supplied unit or shell command.
    try:
        out=subprocess.run(['systemctl','show',unit,'--no-pager',
            '-p','LoadState','-p','ActiveState','-p','Result','-p','ExecMainStatus',
            '-p','ExecMainExitTimestamp','-p','NextElapseUSecRealtime'],capture_output=True,text=True,timeout=3)
        if out.returncode: return {'available':False}
        values=dict(line.split('=',1) for line in out.stdout.splitlines() if '=' in line)
        if values.get('LoadState')!='loaded': return {'available':False}
        return {'available':True,**values}
    except (OSError,subprocess.TimeoutExpired): return {'available':False}


@router.get('/backups')
def backups():
    return {'control':{'service':unit_report('pulsarx-backup.service'),
                       'timer':unit_report('pulsarx-backup.timer')},
            'compute':{'available':False,
                       'message':'Прямая телеметрия резервных копий узла не подключена. Успех бэкапов VPS здесь не подтверждён.'},
            'checked_at':now_utc()}
