"""Additive migration from the already installed AnyPay wallet schema."""
from sqlalchemy import text

from .database import Base, engine
from . import models, wallet_models


def migrate():
    Base.metadata.create_all(bind=engine)
    with engine.begin() as connection:
        connection.execute(text("SET LOCAL lock_timeout = '10s'"))
        connection.execute(text("ALTER TABLE wallet_topups ADD COLUMN IF NOT EXISTS provider VARCHAR(16) NOT NULL DEFAULT 'anypay'"))
        connection.execute(text("ALTER TABLE wallet_topups ADD COLUMN IF NOT EXISTS checkout_url TEXT"))
        connection.execute(text("ALTER TABLE wallet_topups ADD COLUMN IF NOT EXISTS provider_hint VARCHAR(32)"))
        connection.execute(text("ALTER TABLE wallet_topups ADD COLUMN IF NOT EXISTS provider_method INTEGER"))
        connection.execute(text("ALTER TABLE wallet_topups ADD COLUMN IF NOT EXISTS provider_create_started_at TIMESTAMPTZ"))


if __name__ == "__main__":
    migrate()
