import hashlib
import hmac
import logging

import requests

from .config import get_settings

settings = get_settings()
logger = logging.getLogger("pulsarx.lemonsqueezy")

API_BASE = "https://api.lemonsqueezy.com/v1"

PLAN_VARIANTS = {
    "mini": None,  # filled in below, keeps this importable before settings load in tests
    "plus": None,
}


def _variant_for_plan(plan: str) -> str:
    if plan == "mini":
        return settings.ls_variant_mini
    if plan == "plus":
        return settings.ls_variant_plus
    raise ValueError(f"No Lemon Squeezy variant configured for plan {plan!r}")


def create_checkout(server_id: str, plan: str, user_email: str) -> str:
    """Create a Lemon Squeezy checkout session and return its URL.

    server_id is embedded in checkout_data.custom so the webhook can find
    the matching pending Server row without trusting anything else in the
    payload.
    """
    from datetime import datetime, timedelta, timezone

    variant_id = _variant_for_plan(plan)
    expires_at = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()

    resp = requests.post(
        f"{API_BASE}/checkouts",
        headers={
            "Authorization": f"Bearer {settings.ls_api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
        },
        json={
            "data": {
                "type": "checkouts",
                "attributes": {
                    "expires_at": expires_at,
                    "checkout_data": {
                        "email": user_email,
                        "custom": {"server_id": str(server_id)},
                    },
                    "product_options": {
                        "redirect_url": f"{settings.frontend_base_url}/deploy/?server_id={server_id}",
                    },
                },
                "relationships": {
                    "store": {"data": {"type": "stores", "id": str(settings.ls_store_id)}},
                    "variant": {"data": {"type": "variants", "id": str(variant_id)}},
                },
            }
        },
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()["data"]["attributes"]["url"]


def verify_signature(raw_body: bytes, signature_header: str | None) -> bool:
    if not signature_header:
        return False
    digest = hmac.new(
        settings.ls_webhook_secret.encode(), raw_body, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(digest, signature_header)


def get_subscription(subscription_id: str) -> dict:
    resp = requests.get(
        f"{API_BASE}/subscriptions/{subscription_id}",
        headers={
            "Authorization": f"Bearer {settings.ls_api_key}",
            "Accept": "application/vnd.api+json",
        },
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()["data"]["attributes"]


def change_subscription_plan(subscription_id: str, new_plan: str) -> None:
    """Switch a subscription to a different plan's variant, charging the
    prorated difference immediately (invoice_immediately=True) rather than
    waiting for the next renewal.
    """
    variant_id = _variant_for_plan(new_plan)
    resp = requests.patch(
        f"{API_BASE}/subscriptions/{subscription_id}",
        headers={
            "Authorization": f"Bearer {settings.ls_api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
        },
        json={
            "data": {
                "type": "subscriptions",
                "id": str(subscription_id),
                "attributes": {
                    "variant_id": int(variant_id),
                    "invoice_immediately": True,
                },
            }
        },
        timeout=15,
    )
    resp.raise_for_status()


def resume_subscription(subscription_id: str) -> None:
    """Undo a pending cancellation (subscription was set to end at period end)."""
    resp = requests.patch(
        f"{API_BASE}/subscriptions/{subscription_id}",
        headers={
            "Authorization": f"Bearer {settings.ls_api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
        },
        json={
            "data": {
                "type": "subscriptions",
                "id": str(subscription_id),
                "attributes": {"cancelled": False},
            }
        },
        timeout=15,
    )
    resp.raise_for_status()


def cancel_subscription(subscription_id: str) -> None:
    resp = requests.patch(
        f"{API_BASE}/subscriptions/{subscription_id}",
        headers={
            "Authorization": f"Bearer {settings.ls_api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
        },
        json={
            "data": {
                "type": "subscriptions",
                "id": str(subscription_id),
                "attributes": {"cancelled": True},
            }
        },
        timeout=15,
    )
    resp.raise_for_status()
