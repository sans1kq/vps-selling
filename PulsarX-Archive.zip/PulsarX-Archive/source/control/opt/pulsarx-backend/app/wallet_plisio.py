"""Plisio wallet invoices, using the existing VPS key and authenticated API reads.

Protocol: plisio.net/documentation/endpoints/create-an-invoice and
/transaction-details. A browser return or callback status never credits funds.
"""
import hashlib
import hmac
import html
import json
import math
import re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit

import requests

from .anypay_service import ProviderUnavailable
from .config import get_settings

settings = get_settings()
TXN = re.compile(r"[a-f0-9]{24}")
STATES = {"new", "pending", "pending internal", "completed", "mismatch", "expired", "cancelled", "cancelled duplicate", "error"}


def enabled():
    return bool(settings.plisio_api_key.strip())


def order_number(pay_id):
    return "wallet-" + str(pay_id)


def cents(value):
    if isinstance(value, bool) or not re.fullmatch(r"[0-9]{1,10}(?:\.[0-9]{1,12})?", str(value)):
        raise ValueError("Invalid USD amount")
    try:
        amount = Decimal(str(value)) * 100
        if not amount.is_finite() or amount != amount.to_integral_value():
            raise ValueError("Fractional USD cent")
        return int(amount)
    except InvalidOperation:
        raise ValueError("Invalid USD amount") from None


def checkout_ok(value):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    parsed = urlsplit(value)
    return (parsed.scheme == "https" and parsed.netloc == "plisio.net"
            and re.fullmatch(r"/invoice/[a-f0-9]{24}", parsed.path) is not None
            and not parsed.query and not parsed.fragment)


def canonical_checkout(txn, value):
    """Use the documented HTTPS invoice URL for the authenticated invoice ID.

    The API may return a relative URL or a different origin. Never follow that
    origin: keep only its exact matching invoice path and build our fixed URL.
    This preserves the strict browser/saved-URL allowlist.
    """
    if not isinstance(txn, str) or not TXN.fullmatch(txn) or not isinstance(value, str) or len(value) > 2048:
        raise ProviderUnavailable("Invalid Plisio invoice", reason="invalid_result")
    try:
        parsed = urlsplit(value)
    except ValueError:
        raise ProviderUnavailable("Invalid Plisio invoice URL", reason="invalid_result") from None
    if parsed.scheme not in ("", "http", "https") or parsed.query or parsed.fragment:
        raise ProviderUnavailable("Invalid Plisio invoice URL", reason="invalid_result")
    if parsed.path != "/invoice/" + txn:
        raise ProviderUnavailable("Plisio invoice mismatch", reason="transaction_mismatch")
    return "https://plisio.net/invoice/" + txn


def _get(path, parameters):
    if not enabled():
        raise ProviderUnavailable("Plisio is not configured", reason="configuration")
    try:
        response = requests.get("https://api.plisio.net/api/v1" + path,
                                params={**parameters, "api_key": settings.plisio_api_key},
                                headers={"Accept": "application/json"}, timeout=(5, 20), allow_redirects=False)
        if len(response.content) > 2_000_000:
            raise ProviderUnavailable("Plisio response is too large", reason="response_too_large")
        if response.status_code != 200:
            raise ProviderUnavailable("Plisio request failed", reason="http_error", http_status=response.status_code)
        body = response.json()
    except requests.exceptions.Timeout:
        raise ProviderUnavailable("Plisio timed out", reason="timeout") from None
    except requests.RequestException:
        raise ProviderUnavailable("Plisio is temporarily unavailable", reason="network") from None
    except ValueError:
        raise ProviderUnavailable("Invalid Plisio response", reason="invalid_json") from None
    if not isinstance(body, dict) or body.get("status") != "success" or not isinstance(body.get("data"), dict):
        raise ProviderUnavailable("Invalid Plisio result", reason="invalid_result")
    return body["data"]


def create(row, email):
    origin = settings.frontend_base_url.rstrip("/")
    if origin != "https://pulsarx.example.invalid":
        raise ProviderUnavailable("Invalid payment return origin", reason="configuration")
    # The unique order number and return_existing recover an accepted request
    # whose response was lost. Never mint a second order on an uncertain retry.
    remaining = max(1, math.ceil((row.expires_at - datetime.now(timezone.utc)).total_seconds() / 60))
    data = _get("/invoices/new", {
        "source_currency": "USD", "source_amount": f"{Decimal(row.amount_cents) / 100:.2f}",
        "order_number": order_number(row.id), "order_name": "PulsarX balance",
        "email": email, "expire_min": remaining, "return_existing": "true",
        "callback_url": origin + "/api/wallet/plisio/notification?json=true",
        "success_invoice_url": origin + f"/dashboard/?wallet_payment=success&topup={row.id}",
        "fail_invoice_url": origin + f"/dashboard/?wallet_payment=fail&topup={row.id}",
    })
    txn = data.get("txn_id")
    return txn, canonical_checkout(txn, data.get("invoice_url"))


def operation(txn):
    if not isinstance(txn, str) or not TXN.fullmatch(txn):
        raise ProviderUnavailable("Invalid Plisio transaction", reason="transaction_mismatch")
    data = _get("/operations/" + txn, {})
    if data.get("id") != txn or data.get("type") != "invoice" or data.get("status") not in STATES:
        raise ProviderUnavailable("Invalid Plisio transaction details", reason="transaction_mismatch")
    return data


def matches(data, row):
    params = data.get("params")
    if not isinstance(params, dict):
        return False
    try:
        return (params.get("order_number") == order_number(row.id)
                and str(params.get("source_currency", "")).upper() == "USD"
                and cents(params.get("source_amount")) == row.amount_cents
                and str(data.get("test", "0")).lower() in ("0", "false")
                and str(data.get("is_test", "0")).lower() in ("0", "false"))
    except ValueError:
        return False


def metadata_compatible(data, row):
    """Missing White-label fields are allowed; a supplied contradiction is not."""
    if not isinstance(data, dict) or data.get("type") != "invoice":
        return False
    if any(str(data.get(k, "0")).lower() not in ("0", "false") for k in ("test", "is_test", "test_mode")):
        return False
    params = data.get("params")
    if params is not None and not isinstance(params, dict):
        return False
    for fields in (data, params or {}):
        if "order_number" in fields and fields["order_number"] != order_number(row.id):
            return False
        if "source_currency" in fields and fields["source_currency"] != "USD":
            return False
        if "source_amount" in fields:
            try:
                if cents(fields["source_amount"]) != row.amount_cents:
                    return False
            except ValueError:
                return False
    return True


def notification_matches(data, row):
    # provider_hint is persisted ONLY after the notification HMAC, local order
    # number, USD currency and exact USD amount have been checked by the route.
    # A URL, browser-return ID or caller-supplied lookup hint cannot opt in.
    hint = getattr(row, "provider_hint", None)
    return bool(isinstance(data, dict) and getattr(row, "provider", None) == "plisio" and isinstance(hint, str)
                and TXN.fullmatch(hint) and data.get("id") == hint
                and metadata_compatible(data, row))


def lookup(row, hint=None):
    if not row.transaction_id:
        return None
    root = operation(row.transaction_id)
    if not metadata_compatible(root, row):
        raise ProviderUnavailable("Plisio invoice details do not match", reason="transaction_mismatch")
    receipt = getattr(row, "provider_hint", None)
    if getattr(row, "provider", None) == "plisio" and isinstance(receipt, str) and TXN.fullmatch(receipt):
        # Normal (non-White-label) API replies omit params and child_ids. Use
        # the authenticated notification's ID, then independently read its
        # payment status through the API. Never credit 'cancelled duplicate'.
        candidate = root if receipt == row.transaction_id else operation(receipt)
        if not notification_matches(candidate, row):
            raise ProviderUnavailable("Plisio receipt details do not match", reason="transaction_mismatch")
        if receipt != row.transaction_id and candidate.get("parent_id") not in (None, row.transaction_id):
            raise ProviderUnavailable("Unrelated Plisio receipt", reason="transaction_mismatch")
        if candidate["status"] == "completed":
            if receipt != row.transaction_id and root["status"] == "completed":
                raise ProviderUnavailable("Multiple completed Plisio invoices need review", reason="transaction_mismatch")
            return candidate
        if not matches(root, row):
            # No completed, independently verified receipt: keep waiting.
            # In particular a duplicate/cancelled root is never payment proof.
            return candidate
    if not matches(root, row):
        raise ProviderUnavailable("Plisio invoice details do not match", reason="transaction_mismatch")
    # Plisio creates child invoices when the customer switches currency. Read
    # only authenticated, bounded relations to the original invoice, then
    # credit the wallet order once even when multiple callbacks arrive.
    children = root.get("child_ids") or []
    if not isinstance(children, list) or len(children) > 20 or any(not isinstance(t, str) or not TXN.fullmatch(t) for t in children):
        raise ProviderUnavailable("Invalid Plisio child invoices", reason="invalid_result")
    candidates = list(dict.fromkeys(children))
    if hint and hint != row.transaction_id and hint not in candidates:
        candidate = operation(hint)
        if candidate.get("parent_id") != row.transaction_id or not matches(candidate, row):
            raise ProviderUnavailable("Unrelated Plisio invoice", reason="transaction_mismatch")
        candidates.append(hint)
    rows = [root]
    for txn in candidates:
        child = operation(txn)
        if not matches(child, row) or (child.get("parent_id") not in (None, row.transaction_id)):
            raise ProviderUnavailable("Plisio child invoice mismatch", reason="transaction_mismatch")
        rows.append(child)
    paid = [r for r in rows if r["status"] == "completed"]
    if len(paid) > 1:
        raise ProviderUnavailable("Multiple completed Plisio invoices need review", reason="transaction_mismatch")
    if paid:
        return paid[0]
    for row_data in rows:
        if row_data["status"] in ("pending", "pending internal", "mismatch"):
            return row_data
    return root


def verify_callback(data):
    received = data.get("verify_hash")
    if not enabled() or not isinstance(received, str) or not re.fullmatch(r"[a-f0-9]{40}", received):
        return False
    body = {k: v for k, v in data.items() if k != "verify_hash"}
    # Official JSON callbacks preserve field order; older integrations sort
    # fields and normalize expire_utc/tx_urls. Both remain authenticated by the
    # same secret, and settlement separately verifies the API operation.
    normalized = dict(sorted(body.items()))
    if "expire_utc" in normalized:
        normalized["expire_utc"] = str(normalized["expire_utc"])
    if isinstance(normalized.get("tx_urls"), str):
        normalized["tx_urls"] = html.unescape(normalized["tx_urls"])
    for candidate in (body, normalized):
        message = json.dumps(candidate, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        expected = hmac.new(settings.plisio_api_key.encode(), message.encode(), hashlib.sha1).hexdigest()
        if hmac.compare_digest(received, expected):
            return True
    return False
