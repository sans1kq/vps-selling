import logging

logging.basicConfig(level=logging.INFO)
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import admin, auth, servers, webhooks, wallet, admin_wallet
from . import wallet_models

Base.metadata.create_all(bind=engine)

app = FastAPI(title="PulsarX Cloud API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://pulsarx.example.invalid"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(servers.router)
app.include_router(admin.router)
app.include_router(webhooks.router)
app.include_router(wallet.router)
app.include_router(admin_wallet.router)


@app.on_event("startup")
def on_startup():
    servers.reap_stuck_servers()

    from .trial_service import start_trial_reaper
    start_trial_reaper()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/health")
def api_health():
    return {"status": "ok"}

# PulsarX free instance lifetime v1

# PulsarX admin plan slots r1
from .routers import admin_capacity as _px_admin_capacity
app.include_router(_px_admin_capacity.router)

# PulsarX Telegram support r1
from .routers import admin_support as _px_admin_support
app.include_router(_px_admin_support.router)

# PulsarX website support r1
from .routers import web_support as _px_web_support
app.include_router(_px_web_support.router)

@app.on_event("startup")
def _px_web_support_startup():
    from .web_support import initialize
    initialize()

# PulsarX gift retention r1: authenticated owner-only overview.
from .gift_renewal import router as _px_gift_retention_router
app.include_router(_px_gift_retention_router)

# PulsarX admin desk r1: additive read-only authenticated reports.
from .admin_desk import router as _px_admin_desk_router
app.include_router(_px_admin_desk_router)

# PulsarX portal release 20261117
from .vps_promotions import router as _px_promotions
from . import telegram_stars as _px_stars
app.include_router(_px_promotions)
app.include_router(_px_stars.router)
@app.on_event('startup')
async def _px_stars_start():
    import asyncio
    app.state.px_stars_task=asyncio.create_task(_px_stars.reconciliation_loop())
@app.on_event('shutdown')
async def _px_stars_stop():
    import asyncio
    task=getattr(app.state,'px_stars_task',None)
    if task:
        task.cancel()
        try:await task
        except asyncio.CancelledError:pass
