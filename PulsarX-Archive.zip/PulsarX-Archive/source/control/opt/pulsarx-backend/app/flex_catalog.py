"""Maintenance-versioned catalog; existing services keep their resource rows."""
import json
from pathlib import Path
from types import MappingProxyType
GB=10**9
GIB=1024**3
MIB=1024**2
ORDER=('nano','mini','plus')

def validate_catalog(value):
    if not isinstance(value,dict) or set(value)!={'version','currency','ram_budget_gib','cpu_overcommit','plans'} or value['version']!=1 or value['currency']!='USD':raise ValueError('Invalid catalog')
    for key,low,high in [('ram_budget_gib',4,1048576),('cpu_overcommit',1,4)]:
        if type(value[key]) is not int or not low<=value[key]<=high:raise ValueError('Invalid resource policy')
    if set(value['plans'])!=set(ORDER):raise ValueError('Expected Nano, Mini and Plus')
    before=None
    for name in ORDER:
        spec=value['plans'][name]
        if set(spec)!={'ram_mb','cpu_cores','disk_gb','price_cents'}:raise ValueError('Invalid plan fields')
        for field,low,high in [('ram_mb',256,1048576),('cpu_cores',1,256),('disk_gb',4,1048576),('price_cents',1,10000000)]:
            if type(spec[field]) is not int or not low<=spec[field]<=high:raise ValueError('Invalid plan integer')
        if before and (any(spec[k]<=before[k] for k in ('ram_mb','disk_gb','price_cents')) or spec['cpu_cores']<before['cpu_cores']):raise ValueError('Plans must increase without reducing CPU')
        before=spec
    return value

CATALOG=validate_catalog(json.loads(Path(__file__).with_name('flex_catalog.json').read_text()))
PLANS=MappingProxyType({n:MappingProxyType(dict(CATALOG['plans'][n])) for n in ORDER})
POLICY=MappingProxyType({k:v for k,v in CATALOG.items() if k!='plans'})
def is_upgrade(current,target):return current in ORDER and target in ORDER and ORDER.index(target)>ORDER.index(current)
def server_spec(server):return {k:int(getattr(server,k)) for k in ('ram_mb','cpu_cores','disk_gb')}
def public_catalog():return {'version':2,'disk_unit':'GB','disk_bytes_per_gb':GB,'ram_bytes_per_gb':GIB,'currency':'USD','cpu_shared':True,'plans':[{'id':n,'name':n.capitalize(),**dict(PLANS[n]),'upgrade_targets':list(ORDER[i+1:])} for i,n in enumerate(ORDER)]}
