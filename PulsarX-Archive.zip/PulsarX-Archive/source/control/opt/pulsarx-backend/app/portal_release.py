"""Owner-authorized promotional grants. Uses the existing durable gift worker."""
import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import func
from sqlalchemy.orm import Session
from . import auth, growth_service as growth
from .capacity_service import StorageCapacityError
from .database import get_db
from .models import User, AdminActionLog

router = APIRouter(prefix='/api/admin/gifts', tags=['admin'])

class Lookup(BaseModel):
    email: EmailStr

class Grant(Lookup):
    request_key: uuid.UUID
    expected_user_id: uuid.UUID

def recipient(db, email):
    rows = db.query(User).filter(func.lower(User.email)==str(email).strip().lower()).limit(2).all()
    if len(rows)!=1:
        raise HTTPException(404,'Аккаунт с таким email не найден или требует проверки.')
    user=rows[0]
    if not user.is_verified:
        raise HTTPException(409,'Сначала клиент должен подтвердить email.')
    return user

@router.post('/lookup')
def lookup(body:Lookup, _=Depends(auth.get_current_admin),db:Session=Depends(get_db)):
    auth.check_rate_limit('gift-admin-lookup',60,300)
    user=recipient(db,body.email)
    return {'id':str(user.id),'email':user.email,'name':user.first_name+' '+user.last_name}

@router.post('/grant')
def grant(body:Grant,_=Depends(auth.get_current_admin),db:Session=Depends(get_db)):
    auth.check_rate_limit('gift-admin-grant',30,3600)
    user=recipient(db,body.email)
    if user.id!=body.expected_user_id:
        raise HTTPException(409,'Получатель изменился. Найдите аккаунт заново.')
    code=growth.create_code(db,body.request_key,'Email grant: '+str(user.id),'Administrator gift by verified account email')
    try:
        result=growth.redeem_code(db,user,code['code'])
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code,'Нет свободных ресурсов. Подарок не выдан; повторите позже.') from None
    if not result.get('replayed'):
        db.add(AdminActionLog(action='grant_nano_by_email',target_type='server',target_label=result['server_id'],actor='admin'))
        db.commit()
    return {**result,'email':user.email,'plan':'nano','duration_hours':72}
