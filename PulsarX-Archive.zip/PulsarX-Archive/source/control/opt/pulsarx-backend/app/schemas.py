import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

from .models import ServerStatus, DomainStatus

from .flex_catalog import PLANS
PLAN_LIMITS = {}  # Compatibility only; admission uses shared resources.

IMAGES = {
    "debian12": {"alias": "images:debian/12", "label": "Debian 12"},
    "debian13": {"alias": "images:debian/13", "label": "Debian 13"},
    "debian14": {"alias": "images:debian/14", "label": "Debian 14"},
    "ubuntu2204": {"alias": "images:ubuntu/22.04", "label": "Ubuntu 22.04 LTS"},
    "ubuntu2404": {"alias": "images:ubuntu/24.04", "label": "Ubuntu 24.04 LTS"},
    "fedora43": {"alias": "images:fedora/43", "label": "Fedora 43"},
    "fedora44": {"alias": "images:fedora/44", "label": "Fedora 44"},
    "archlinux": {"alias": "images:archlinux", "label": "Arch Linux (rolling)"},
    "alma9": {"alias": "images:almalinux/9", "label": "AlmaLinux 9"},
    "alma10": {"alias": "images:almalinux/10", "label": "AlmaLinux 10"},
    "rocky9": {"alias": "images:rockylinux/9", "label": "Rocky Linux 9"},
    "rocky10": {"alias": "images:rockylinux/10", "label": "Rocky Linux 10"},
    "alpine322": {"alias": "images:alpine/3.22", "label": "Alpine 3.22"},
    "alpine323": {"alias": "images:alpine/3.23", "label": "Alpine 3.23"},
    "opensuse": {"alias": "images:opensuse/tumbleweed", "label": "openSUSE Tumbleweed (rolling)"},
}


class RegisterRequest(BaseModel):
    referral_code: str | None = Field(default=None,max_length=48)
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    accepted_tos: bool

class VerifyRequest(BaseModel):
    email: EmailStr
    code: str = Field(min_length=6, max_length=6)


class ResendCodeRequest(BaseModel):
    email: EmailStr


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LoginVerifyRequest(BaseModel):
    email: EmailStr
    code: str = Field(min_length=6, max_length=6)


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    email: EmailStr
    code: str = Field(min_length=6, max_length=6)
    new_password: str = Field(min_length=8, max_length=128)


class UserOut(BaseModel):
    id: uuid.UUID
    first_name: str
    last_name: str
    email: EmailStr
    is_verified: bool

    class Config:
        from_attributes = True


class AuthResponse(BaseModel):
    token: str
    user: UserOut


class ServerCreateResponse(BaseModel):
    server_id: uuid.UUID
    checkout_url: str

class ServerCreateRequest(BaseModel):
    plan: str = Field(..., description="One of: " + ", ".join(PLANS.keys()))
    image: str = Field(default="debian12", description="One of: " + ", ".join(IMAGES.keys()))
    months: int = Field(default=1, description="Billing period: 1, 3, 6 or 12 months")


class ServerOut(BaseModel):
    id: uuid.UUID
    container_name: str
    plan: str
    image: str
    ram_mb: int
    cpu_cores: int
    disk_gb: int
    ip_address: str | None
    ssh_port: int | None
    web_port: int | None = None
    extra_ports: list[int] = []
    custom_domain: str | None = None
    domain_status: DomainStatus | None = None
    status: ServerStatus
    error_message: str | None = None
    password_set: bool = False
    upgrade_pending: bool = False
    has_subscription: bool = False
    subscription_cancelled: bool = False
    subscription_period_ends_at: datetime | None = None
    paid_until: datetime | None = None
    trial_expires_at: datetime | None = None
    is_trial: bool = False
    admin_suspended_at: datetime | None = None

    @field_validator("extra_ports", mode="before")
    @classmethod
    def _parse_extra_ports(cls, v):
        if isinstance(v, str):
            return [int(p) for p in v.split(",") if p.strip()]
        return v or []

    class Config:
        from_attributes = True


class UpgradePlanRequest(BaseModel):
    target_plan: str = Field(..., description="One of: " + ", ".join(PLANS.keys()))


class RequestSshResetRequest(BaseModel):
    account_password: str


class ConfirmSshResetRequest(BaseModel):
    code: str = Field(min_length=6, max_length=6)


class SetServerPasswordRequest(BaseModel):
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def _single_password_record(cls, value):
        if any(ord(c) in (0,10,13) for c in value):
            raise ValueError("Use a single-line password without NUL characters")
        return value


class AdminLoginRequest(BaseModel):
    username: str
    password: str


class AdminLoginResponse(BaseModel):
    token: str


class AdminUserOut(BaseModel):
    id: uuid.UUID
    first_name: str
    last_name: str
    email: EmailStr
    is_verified: bool
    created_at: datetime
    server_count: int
    registration_ip: str | None = None


class AdminServerOut(BaseModel):
    id: uuid.UUID
    container_name: str
    owner_email: str
    plan: str
    image: str
    ram_mb: int
    cpu_cores: int
    disk_gb: int
    ip_address: str | None
    ssh_port: int | None
    status: ServerStatus
    created_at: datetime
    paid_until: datetime | None = None
    trial_expires_at: datetime | None = None
    is_trial: bool = False
    has_subscription: bool = False

    class Config:
        from_attributes = True


class SetDomainRequest(BaseModel):
    domain: str = Field(..., min_length=3, max_length=253)


class SetSubdomainPrefixRequest(BaseModel):
    prefix: str = Field(..., min_length=3, max_length=40, pattern=r"^[a-z0-9-]+$")


class HostUsageOut(BaseModel):
    cpu_cores: int
    load_1m: float
    load_5m: float
    load_15m: float
    load_pct: float
    memory_used_mb: float
    memory_total_mb: float
    memory_pct: float
    disk_used_gb: float
    disk_total_gb: float
    disk_pct: float


class AdminActionLogOut(BaseModel):
    id: uuid.UUID
    action: str
    target_type: str
    target_label: str
    actor: str
    created_at: datetime

    class Config:
        from_attributes = True


class AdminUsageOut(BaseModel):
    cpu_pct: float
    memory_used_mb: float
    memory_limit_mb: int
    memory_pct: float
    disk_used_gb: float | None = None
    disk_limit_gb: float
    disk_usage_available: bool = True
    disk_pct: float
    network_rx_kbps: float = 0.0
    network_tx_kbps: float = 0.0


class CheckoutRequest(BaseModel):
    months: int = Field(default=1, description="Billing period: 1, 3, 6 or 12 months")


class UpgradeCheckoutRequest(BaseModel):
    target_plan: str = Field(..., description="One of: " + ", ".join(PLANS.keys()))

# PulsarX free instance lifetime v1
