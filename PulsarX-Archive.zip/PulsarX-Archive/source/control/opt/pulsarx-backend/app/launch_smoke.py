"""Real Nano checkout/provision/SSH smoke with one disposable owned test account.

No provider payment, customer charge, live mail, customer password or existing
instance operation. Saved IDs allow cleanup after a disconnected/failed run.
"""
import fcntl,json,os,socket,uuid,time
from datetime import datetime,timezone
from pathlib import Path
from sqlalchemy import text
from .database import SessionLocal,engine
from .models import User,Server
from .wallet_models import WalletAccount,WalletEntry,WalletOrder
from . import auth,wallet_service,wallet_worker,incus_service,email_service,flex_capacity
from .capacity_service import StorageCapacityError,storage_size

STATE=Path('/home/pulsarx/.local/state/pulsarx-launch-smoke')

def save(data):
 p=STATE/'state.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data));tmp.chmod(0o600);os.replace(tmp,p)

def own(db,s):
 u=db.get(User,uuid.UUID(s['user_id']))
 if u is None:return None
 if u.email!=s['email'] or not u.email.endswith('@example.invalid') or u.first_name!='PulsarXLaunchSmoke':raise RuntimeError('Smoke ownership differs')
 return u

def wait_owned_operations(name):
 deadline=time.monotonic()+120
 while True:
  response=json.loads(incus_service._run(['incus','query','--raw','/1.0/operations?recursion=1&project=default']))
  if response.get('type')!='sync' or response.get('status_code')!=200 or not isinstance(response.get('metadata'),dict):raise RuntimeError('Cannot verify smoke operations before cleanup')
  rows=[op for group in response['metadata'].values() for op in group]
  urls=('/1.0/instances/'+name,'/1.0/storage-pools/'+name+'-pool')
  active=False
  for op in rows:
   resources=[str(v).split('?')[0] for values in op.get('resources',{}).values() for v in values]
   if 100<=op.get('status_code',0)<200 and any(v in urls for v in resources):active=True
  if not active:return
  if time.monotonic()>deadline:raise RuntimeError('An owned smoke operation is still active; cleanup retained for retry')
  time.sleep(1)

def cleanup(s):
 db=SessionLocal()
 try:
  u=own(db,s)
  if u is None:return
  rows=db.query(Server).filter(Server.owner_id==u.id).all()
  if len(rows)>1:raise RuntimeError('Unexpected smoke instance scope')
  for row in rows:
   if not s.get('server_id') and row.plan=='nano' and row.owner_email==s['email'] and not row.custom_domain:
    s.update(server_id=str(row.id),container_name=row.container_name);save(s)
   if str(row.id)!=s.get('server_id') or row.container_name!=s.get('container_name') or row.owner_email!=s['email'] or row.custom_domain:raise RuntimeError('Smoke instance ownership differs')
   # The existing cleanup verifies instance, dedicated pool and cached volumes.
   wait_owned_operations(row.container_name)
   incus_service.delete_container(row.container_name)
  db.query(WalletOrder).filter(WalletOrder.user_id==u.id).delete(synchronize_session=False)
  for row in rows:db.delete(row)
  db.flush()
  db.query(WalletEntry).filter(WalletEntry.user_id==u.id).delete(synchronize_session=False)
  acct=db.get(WalletAccount,u.id)
  if acct:
   db.delete(acct)
   # There is deliberately no ORM relationship between these models.
   # Flush the child DELETE before scheduling its parent; otherwise the
   # unit of work may delete users first and PostgreSQL rejects the commit.
   db.flush()
  db.delete(u);db.commit()
 finally:db.close()

def _main():
 STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
 with open(STATE/'worker.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  p=STATE/'state.json';saved=json.loads(p.read_text()) if p.exists() else None
  if saved and not saved.get('cleanup'):
   cleanup(saved);saved['cleanup']=True;save(saved)
   if saved.get('passed') is True:
    print('SMOKE VERIFIED: the previously recorded real Nano passed checkout, quotas, isolation, metrics and public SSH.',flush=True)
    print('SMOKE CLEANED: recovered the recorded disposable account and resources; no second Nano was created.',flush=True)
    return
   print('SMOKE RECOVERY: previous owned test account/resources removed; rerun to start a fresh check.',flush=True);return
  ident=uuid.uuid4();s={'user_id':str(ident),'email':'launch-smoke-'+ident.hex+'@example.invalid','cleanup':False,'passed':False};save(s)
  # Suppress notification functions only in this isolated smoke process.
  for name in dir(email_service):
   if name.startswith('send_'):setattr(email_service,name,lambda *args,**kwargs:None)
  try:
   db=SessionLocal()
   try:
    u=User(id=ident,first_name='PulsarXLaunchSmoke',last_name='Disposable',email=s['email'],password_hash=auth.hash_password(uuid.uuid4().hex+uuid.uuid4().hex),is_verified=True)
    db.add(u);db.flush();db.add(WalletAccount(user_id=u.id,balance_cents=200,frozen=False));db.flush()
    db.add(WalletEntry(user_id=u.id,amount_cents=200,balance_after_cents=200,kind='smoke',reference='smoke:'+ident.hex,label='Temporary isolated smoke fixture'));db.commit()
    # Exercise the real checkout refusal against an artificial zero-free-RAM
    # report only in this process; production availability is never modified.
    report=flex_capacity.capacity_report
    usage=report(db);db.rollback()
    def full(*args,**kwargs):return {**usage,'memory_available_bytes':0}
    flex_capacity.capacity_report=full
    try:
     try:wallet_service.purchase(db,u,request_key=uuid.uuid4(),kind='new',plan='nano',image='debian13',months=1,expected_amount_cents=175)
     except StorageCapacityError:db.rollback()
     else:raise RuntimeError('A full-capacity checkout was not rejected')
    finally:flex_capacity.capacity_report=report
    if db.get(WalletAccount,ident).balance_cents!=200 or db.query(WalletOrder).filter_by(user_id=ident).count():raise RuntimeError('Capacity refusal changed the test wallet')
    key=uuid.uuid4();args=dict(request_key=key,kind='new',plan='nano',image='debian13',months=1,expected_amount_cents=175)
    order=wallet_service.purchase(db,u,**args);s.update(order_id=str(order.id),server_id=str(order.server_id),container_name=order.container_name);save(s)
    again=wallet_service.purchase(db,u,**args)
    if again.id!=order.id or db.get(WalletAccount,ident).balance_cents!=25:raise RuntimeError('Checkout idempotency differs')
   finally:db.close()
   print('SMOKE: full-capacity refusal and one-time Nano checkout verified; provisioning disposable Nano.',flush=True)
   wallet_worker.process_order(uuid.UUID(s['order_id']))
   db=SessionLocal()
   try:
    order=db.get(WalletOrder,uuid.UUID(s['order_id']));server=db.get(Server,uuid.UUID(s['server_id']))
    if order.status!='completed' or server.status.value!='running':raise RuntimeError('Nano provisioning did not complete; test cleanup will run')
    pool=json.loads(incus_service._run(['incus','query','/1.0/storage-pools/'+server.container_name+'-pool?project=default']))
    pool=pool.get('metadata',pool)
    info=json.loads(incus_service._run(['incus','query','/1.0/instances/'+server.container_name+'?project=default']))
    info=info.get('metadata',info);cfg=info['expanded_config']
    if storage_size(pool['config']['size'])!=8_000_000_000 or storage_size(cfg['limits.memory'])!=1024**3 or cfg.get('limits.cpu')!='1':raise RuntimeError('Actual Nano quotas differ')
    if cfg.get('security.privileged','false')!='false' or info['expanded_devices'].get('eth0',{}).get('security.port_isolation')!='true':raise RuntimeError('Nano isolation differs')
    with socket.create_connection(('192.0.2.12',server.ssh_port),timeout=10) as sock:
     sock.settimeout(10)
     if not sock.recv(256).startswith(b'SSH-2.0-'):raise RuntimeError('Nano public SSH banner differs')
    usage=incus_service.get_container_usage(server.container_name,1,1024,8)
    if usage['memory_limit_mb']!=1024 or usage['disk_limit_gb']<8:raise RuntimeError('Nano metrics/limits differ')
    s['passed']=True;save(s)
    print('SMOKE VERIFIED: real Nano order, idempotent debit, 8 GB disk, 1 GiB RAM, 1 vCPU, isolation and public SSH.',flush=True)
   finally:db.close()
  finally:
   cleanup(s);s['cleanup']=True;save(s)
   print('SMOKE CLEANED: only the recorded disposable test account, order, ledger and dedicated Incus resources removed.',flush=True)

def main():
 lock=engine.connect()
 try:
  if not lock.execute(text('SELECT pg_try_advisory_lock(:k)'),{'k':wallet_worker.WORKER_LOCK}).scalar():raise RuntimeError('An ordinary wallet worker is active; retry smoke later')
  lock.commit();_main()
 finally:lock.close()

if __name__=='__main__':main()
