"""Shared helper for writing to admin_action_logs, used by both the admin
router (actor="admin") and user-facing routers (actor=<user email>) so both
sides of an action show up in the same audit trail."""

from sqlalchemy.orm import Session

from .models import AdminActionLog


def log_action(db: Session, action: str, target_type: str, target_label: str, actor: str = "admin") -> None:
    db.add(AdminActionLog(action=action, target_type=target_type, target_label=target_label, actor=actor))
    db.commit()
