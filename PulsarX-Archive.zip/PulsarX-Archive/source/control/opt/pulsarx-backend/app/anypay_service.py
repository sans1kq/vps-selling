"""AnyPay SCI SHA256 + authenticated transaction lookup.

Protocol: https://anypay.io/doc/sci and /doc/sci/notification,
https://anypay.io/doc/api/payments. No redirect is a payment confirmation.
"""
import hashlib
import hmac
import re
from decimal import Decimal
from urllib.parse import urlencode, urlsplit

import requests

from .config import get_settings

settings = get_settings()
STATUSES = ("paid", "partially-paid", "waiting", "refund", "canceled", "expired", "error")
PAYMENT_FORMATS = ("missing", "null", "object", "array", "string", "number", "boolean", "unknown")


class ProviderUnavailable(RuntimeError):
    def __init__(self, message, *, reason="unavailable", code=None, http_status=None,
                 payment_format=None, record_count=None):
        super().__init__(message)
        # Structured diagnostics never contain provider text, URLs or credentials.
        allowed = {"unavailable", "configuration", "timeout", "tls", "network", "api_error",
                   "http_error", "response_too_large", "invalid_json", "invalid_result",
                   "invalid_records", "transaction_mismatch", "api_key_invalid", "merchant_inactive"}
        self.reason = reason if reason in allowed else "unavailable"
        self.code = str(code) if re.fullmatch(r"[0-9]{3}", str(code)) else None
        self.http_status = http_status if type(http_status) is int and 100 <= http_status <= 599 else None
        self.payment_format = payment_format if isinstance(payment_format,str) and payment_format in PAYMENT_FORMATS else None
        self.record_count = record_count if type(record_count) is int and 0 <= record_count <= 2_000_000 else None


def enabled():
    return bool(settings.anypay_enabled and all((settings.anypay_project_id,
                settings.anypay_secret_key, settings.anypay_api_id, settings.anypay_api_key)))


def digest(parts, delimiter=":"):
    return hashlib.sha256(delimiter.join(str(p) for p in parts).encode("utf-8")).hexdigest()


def cents(value):
    raw = str(value)
    if not re.fullmatch(r"[0-9]{1,10}(?:\.[0-9]{1,2})?", raw):
        raise ValueError("Invalid payment amount")
    return int(Decimal(raw) * 100)


def checkout(topup, email):
    if not enabled():
        raise ProviderUnavailable("AnyPay is not configured")
    origin = settings.frontend_base_url.rstrip("/")
    parsed = urlsplit(origin)
    if parsed.scheme != "https" or parsed.netloc != "pulsarx.example.invalid" or parsed.path:
        raise ProviderUnavailable("Invalid payment return origin")
    data = {"merchant_id": settings.anypay_project_id, "pay_id": str(topup.id),
            "amount": f"{topup.amount_cents / 100:.2f}", "currency": "USD",
            "desc": "PulsarX account balance", "email": email,
            "success_url": f"{origin}/dashboard/?wallet_payment=success&topup={topup.id}",
            "fail_url": f"{origin}/dashboard/?wallet_payment=fail&topup={topup.id}"}
    data["sign"] = digest([data[k] for k in ("merchant_id", "pay_id", "amount", "currency",
                                           "desc", "success_url", "fail_url")] + [settings.anypay_secret_key])
    return "https://anypay.io/merchant?" + urlencode(data)


def validate_notification(data):
    required = ("merchant_id", "transaction_id", "pay_id", "amount", "currency", "status", "sign", "test")
    if any(not isinstance(data.get(k), str) or len(data[k]) > 256 for k in required):
        raise ValueError("Invalid notification")
    if data["merchant_id"] != str(settings.anypay_project_id):
        raise ValueError("Wrong project")
    if not re.fullmatch(r"[0-9]{1,15}", data["pay_id"]) or not re.fullmatch(r"[0-9]{1,24}", data["transaction_id"]):
        raise ValueError("Invalid payment identifier")
    expected = digest([data[k] for k in ("currency", "amount", "pay_id", "merchant_id", "status")]
                      + [settings.anypay_secret_key])
    if not re.fullmatch(r"[a-fA-F0-9]{64}", data["sign"]) or not hmac.compare_digest(expected, data["sign"].lower()):
        raise ValueError("Invalid signature")
    if data["currency"].upper() != "USD" or data["test"] not in ("0", "1") or data["status"] not in STATUSES:
        raise ValueError("Invalid currency or test mode")
    return int(data["pay_id"]), cents(data["amount"])


def _payments(parameters):
    """Read the documented project payments endpoint; keep response bodies private."""
    if not enabled():
        raise ProviderUnavailable("AnyPay is not configured", reason="configuration")
    params = {"project_id": str(settings.anypay_project_id), **parameters}
    params["sign"] = digest(["payments", settings.anypay_api_id, settings.anypay_project_id,
                             settings.anypay_api_key], delimiter="")
    try:
        response = requests.post("https://anypay.io/api/payments/" + str(settings.anypay_api_id),
                                 files={k: (None, v) for k, v in params.items()},
                                 headers={"Accept": "application/json"}, timeout=(5, 20), allow_redirects=False)
    except requests.exceptions.Timeout:
        raise ProviderUnavailable("Could not verify the payment with AnyPay", reason="timeout") from None
    except requests.exceptions.SSLError:
        raise ProviderUnavailable("Could not verify the payment with AnyPay", reason="tls") from None
    except requests.RequestException:
        raise ProviderUnavailable("Could not verify the payment with AnyPay", reason="network") from None
    status = response.status_code
    def failed(reason, code=None, payment_format=None, record_count=None):
        return ProviderUnavailable("Could not verify the payment with AnyPay", reason=reason,
                                   code=code, http_status=status,
                                   payment_format=payment_format, record_count=record_count)
    if len(response.content) > 2_000_000:
        raise failed("response_too_large")
    try:
        body = response.json()
    except (ValueError, TypeError):
        raise failed("invalid_json") from None
    if isinstance(body, dict) and isinstance(body.get("error"), dict):
        raise failed("api_error", body["error"].get("code"))
    if status != 200:
        raise failed("http_error")
    if not isinstance(body, dict) or not isinstance(body.get("result"), dict):
        raise failed("invalid_result")
    result = body["result"]
    total = result.get("total")
    records = result.get("payments")
    if "payments" not in result:
        kind = "missing"
    elif records is None:
        kind = "null"
    else:
        kind = {dict:"object",list:"array",str:"string",int:"number",float:"number",bool:"boolean"}.get(type(records),"unknown")
    count = len(records) if isinstance(records,(dict,list)) else None
    # A pay_id-filtered reply can have null or omitted pagination metadata.
    # The live no-match reply was {total:null,payments:null}. The count is not
    # payment evidence; an actual credit still needs the exact signed receipt
    # and an authenticated matching transaction, amount, currency and status.
    if total is None and "payments" in result:
        if records is None:total=0
        elif isinstance(records,(dict,list)):total=len(records)
    if type(total) is not int or total < 0:
        raise failed("invalid_result",payment_format=kind,record_count=count)
    # Null or an omitted field with an explicit zero total means no transactions.
    # It can never authorize credit: lookup returns None for every empty result.
    if records is None and total == 0:
        records = {}
    elif isinstance(records,list):
        # Preserve every item, including duplicate transaction IDs; lookup must
        # reject ambiguous matches instead of deduplicating them into one credit.
        records = {str(index):record for index,record in enumerate(records)}
    if (not isinstance(records,dict) or len(records)>1000
            or any(not isinstance(record,dict) for record in records.values())
            or (records and total==0)):
        raise failed("invalid_records",payment_format=kind,record_count=count)
    return records,{"payment_format":kind,"record_count":len(records),"total":total}


def verify_access():
    """Authenticate a read-only project lookup without inventing a payment ID."""
    _,summary = _payments({})
    return summary


def lookup(pay_id, transaction_id=None):
    """Return at most one exact project-scoped transaction; no implicit first item."""
    params = {"pay_id": str(pay_id)}
    if transaction_id is not None:
        params["trans_id"] = str(transaction_id)
    records,_ = _payments(params)
    if not records:
        return None
    exact = [r for r in records.values() if isinstance(r, dict) and str(r.get("pay_id")) == str(pay_id)
             and (transaction_id is None or str(r.get("transaction_id")) == str(transaction_id))]
    if len(exact) != 1:
        raise ProviderUnavailable("Could not verify the payment with AnyPay", reason="transaction_mismatch")
    record = exact[0]
    if not re.fullmatch(r"[0-9]{1,24}", str(record.get("transaction_id", ""))) or record.get("status") not in STATUSES:
        raise ProviderUnavailable("Could not verify the payment with AnyPay", reason="transaction_mismatch")
    return record
