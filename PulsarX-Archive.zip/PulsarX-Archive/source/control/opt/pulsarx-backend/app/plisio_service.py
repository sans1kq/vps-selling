import hashlib
import hmac
import html
import json
import logging

import requests

from .config import get_settings

settings = get_settings()
logger = logging.getLogger("pulsarx.plisio")

API_BASE = "https://api.plisio.net/api/v1"


class PlisioError(Exception):
    pass


def _get(path: str, params: dict) -> dict:
    # api_key travels in the query string, so never let requests' own error
    # text (it contains the full URL) reach the logs.
    try:
        resp = requests.get(
            f"{API_BASE}{path}",
            params={**params, "api_key": settings.plisio_api_key},
            timeout=15,
        )
        body = resp.json()
    except (requests.RequestException, ValueError):
        raise PlisioError(f"Plisio request to {path} failed") from None
    if resp.status_code != 200 or body.get("status") != "success":
        detail = body.get("data") if isinstance(body, dict) else None
        detail = (detail.get("message") or detail.get("name")) if isinstance(detail, dict) else None
        raise PlisioError(f"Plisio {path} returned an error (HTTP {resp.status_code}): {str(detail)[:200]}")
    return body["data"]


def create_invoice(order_number: int, plan: str, amount_usd: str, email: str,
                   expire_min: int | None = None) -> dict:
    callback = (
        f"{settings.webhook_base_url or settings.frontend_base_url}/api/webhooks/plisio"
        f"?json=true&t={settings.plisio_webhook_token}"
    )
    data = _get("/invoices/new", {
        "source_currency": "USD",
        "source_amount": amount_usd,
        "order_number": order_number,
        "order_name": f"PulsarX {plan}",
        "email": email,
        "callback_url": callback,
        "expire_min": expire_min or settings.invoice_expire_min,
    })
    return {"txn_id": data["txn_id"], "invoice_url": data["invoice_url"]}


def get_operation(txn_id: str) -> dict:
    return _get(f"/operations/{txn_id}", {})


def token_ok(token: str | None) -> bool:
    if not token or not settings.plisio_webhook_token:
        return False
    return hmac.compare_digest(token, settings.plisio_webhook_token)


def verify_callback(data: dict) -> bool:
    """First-line filter only: the real decision is made from get_operation()."""
    received = data.get("verify_hash")
    if not received or not settings.plisio_api_key:
        return False
    body = {k: v for k, v in data.items() if k != "verify_hash"}
    ordered = dict(sorted(body.items()))
    if "expire_utc" in ordered:
        ordered["expire_utc"] = str(ordered["expire_utc"])
    if isinstance(ordered.get("tx_urls"), str):
        ordered["tx_urls"] = html.unescape(ordered["tx_urls"])
    msg = json.dumps(ordered, separators=(",", ":"), ensure_ascii=False)
    digest = hmac.new(settings.plisio_api_key.encode(), msg.encode(), hashlib.sha1).hexdigest()
    return hmac.compare_digest(digest, received)
