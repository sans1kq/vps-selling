from .flex_capacity import require_resources
"""Owner-bound referral discounts and durable one-use promotional entitlements."""
import base64
from datetime import datetime,timedelta,timezone
import hashlib
import hmac
import re
import secrets
import uuid
import logging

from fastapi import HTTPException
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import object_session
from sqlalchemy import text,or_
from .database import SessionLocal
from .growth_models import ReferralProfile,ReferralBenefit,ReferralTopup,GiftCode,FirstTopupOffer
from .models import User,Server,ServerStatus,AdminActionLog

REF_RE=re.compile(r'[A-Za-z0-9_-]{20,48}\Z')
CODE_RE=re.compile(r'PX(?:[A-Z2-7]{12}|[A-Z2-7]{20})\Z')


def now():return datetime.now(timezone.utc)


def ensure_verified(user):
    if not user.is_verified:raise HTTPException(403,'Verify your email first')


def profile(db,user_id):
    db.execute(insert(ReferralProfile).values(user_id=user_id,token=secrets.token_urlsafe(24))
        .on_conflict_do_nothing(index_elements=['user_id']))
    return db.get(ReferralProfile,user_id)


def activation(db,user_id):
    from .wallet_models import WalletTopup,WalletAccount
    first=db.query(WalletTopup).filter(WalletTopup.user_id==user_id,
        WalletTopup.amount_cents>0,WalletTopup.credited_at.isnot(None),
        WalletTopup.provider.in_(('anypay','freekassa','plisio','rollypay','stars'))).order_by(WalletTopup.credited_at,WalletTopup.id).first()
    acct=db.get(WalletAccount,user_id)
    active=first is not None
    return {'activated':active,'activated_at':first.credited_at if first else None,
            'referral_enabled':active and not (acct and acct.frozen)}


def status(db,user_id):
    state=activation(db,user_id);benefit=db.get(ReferralBenefit,user_id)
    p=profile(db,user_id) if state['referral_enabled'] else None
    invited = db.query(ReferralBenefit.user_id).filter_by(inviter_id=user_id).count()
    first = not state['activated']
    friend = bool(benefit and benefit.consumed_topup_id is None)
    return {**state,'first_topup':first,'link':'https://pulsarx.example.invalid/register/?ref='+p.token if p and not invited else None,
        'invited':invited,
        'available':bool(benefit is not None and benefit.consumed_topup_id is None),
        'used':bool(benefit is not None and benefit.consumed_topup_id is not None),'discount_percent':10 * (int(first) + int(friend))}


def attach_invitation(db,user,token):
    if not token:return
    if not REF_RE.fullmatch(token):raise HTTPException(400,'Invalid referral link')
    inviter=db.query(ReferralProfile).filter_by(token=token).with_for_update().one_or_none()
    if inviter is None or inviter.user_id==user.id:raise HTTPException(400,'Invalid referral link')
    if not activation(db,inviter.user_id)['referral_enabled']:raise HTTPException(400,'This invitation is not active')
    if db.query(ReferralBenefit.user_id).filter_by(inviter_id=inviter.user_id).first():
        raise HTTPException(409, 'This invitation has already been used')
    db.add(ReferralBenefit(user_id=user.id,inviter_id=inviter.user_id))


def discounted_topup_cents(credit_cents, *, first_topup, referral):
    if type(credit_cents) is not int or credit_cents <= 0:
        raise HTTPException(422, 'Invalid top-up amount')
    percent = 100 - 10 * first_topup - 10 * referral
    return (credit_cents * percent + 99) // 100


def payable(credit_cents):
    # Legacy referral-only invoices keep their original payment terms.
    return discounted_topup_cents(credit_cents, first_topup=False, referral=True)


def eligible(db,user_id):
    benefit=db.get(ReferralBenefit,user_id)
    return benefit is not None and benefit.consumed_topup_id is None


def quote_terms(db,user_id,credit_cents,apply):
    from . import wallet_service as w
    if type(credit_cents) is not int or not w.settings.wallet_min_topup_cents<=credit_cents<=w.settings.wallet_max_topup_cents:
        raise HTTPException(422,'Amount is outside the permitted top-up range')
    if apply and not eligible(db,user_id):
        raise HTTPException(409,detail={'code':'referral_changed','message':'Referral discount is unavailable. Review the updated amount.'})
    first = not activation(db,user_id)['activated']
    pay=discounted_topup_cents(credit_cents, first_topup=first, referral=apply or (first and eligible(db,user_id)))
    if not w.settings.wallet_min_topup_cents<=pay<=w.settings.wallet_max_topup_cents:
        raise HTTPException(422,detail={'code':'referral_minimum','message':'The discounted payment is below the provider minimum.'})
    return pay


def request_terms(db,user,payload):
    from .wallet_models import WalletTopup
    previous=db.query(WalletTopup).filter_by(user_id=user.id,request_key=payload.request_key).one_or_none()
    if previous:
        verify_terms(db,previous,payload.amount_cents if db.get(ReferralTopup,previous.id) or payload.apply_referral else None)
        pay=previous.amount_cents
    else:pay=quote_terms(db,user.id,payload.amount_cents,payload.apply_referral)
    if payload.apply_referral and payload.expected_payable_cents!=pay:
        raise HTTPException(409,detail={'code':'referral_changed','message':'Review the discounted amount before paying.'})
    if payload.expected_payable_cents is not None and payload.expected_payable_cents!=pay:
        raise HTTPException(409,detail={'code':'referral_changed','message':'The payment amount changed. Review it again.'})
    return pay,payload.amount_cents if pay != payload.amount_cents else None


def verify_terms(db,row,credit_cents):
    promotion=db.get(ReferralTopup,row.id)
    if (promotion is None)!=(credit_cents is None) or (promotion is not None and promotion.credit_cents!=credit_cents):
        raise HTTPException(409,'This request belongs to different top-up terms')


def bind_topup(db,row,credit_cents):
    if credit_cents is None:return
    from . import wallet_service as w
    if type(credit_cents) is not int or not w.settings.wallet_min_topup_cents<=credit_cents<=w.settings.wallet_max_topup_cents:
        raise HTTPException(422,'Amount is outside the permitted top-up range')
    benefit=db.query(ReferralBenefit).filter_by(user_id=row.user_id).populate_existing().with_for_update().one_or_none()
    first = not activation(db,row.user_id)['activated']
    friend = benefit is not None and benefit.consumed_topup_id is None
    if first and row.amount_cents == discounted_topup_cents(credit_cents, first_topup=True, referral=False):
        friend = False
    if row.amount_cents != discounted_topup_cents(credit_cents, first_topup=first, referral=friend):
        raise HTTPException(409,detail={'code':'referral_changed','message':'Refresh the discount quote'})
    if first:
        db.add(FirstTopupOffer(topup_id=row.id, includes_referral=friend))
    db.add(ReferralTopup(topup_id=row.id,pay_cents=row.amount_cents,credit_cents=credit_cents,discount_cents=credit_cents-row.amount_cents))
    db.flush()


def credit_discount(db,acct,row):
    """Called in the original verified-credit transaction under the wallet lock.

    The provider amount remains the amount actually paid. The subsidy has its
    own ledger entry so payment revenue is not inflated by a referral benefit.
    A late second invoice still credits its actual money, never a second perk.
    """
    from . import wallet_service as w
    promotion=db.get(ReferralTopup,row.id)
    if promotion is None or promotion.applied_at is not None:return
    first_offer = db.get(FirstTopupOffer,row.id)
    friend = first_offer is None or first_offer.includes_referral
    expected = discounted_topup_cents(promotion.credit_cents, first_topup=bool(first_offer), referral=friend)
    if expected != row.amount_cents or promotion.pay_cents != expected or promotion.credit_cents-expected != promotion.discount_cents:
        raise RuntimeError('Top-up terms need review')
    if first_offer and activation(db,row.user_id)['activated']:
        promotion.skipped_reason='already_used'
        return
    if friend:
        benefit=db.query(ReferralBenefit).filter_by(user_id=row.user_id).populate_existing().with_for_update().one_or_none()
        if not benefit or benefit.consumed_topup_id not in (None,row.id):
            promotion.skipped_reason='already_used'
            return
        benefit.consumed_topup_id=row.id
        benefit.consumed_at=now()
    w.entry(db,acct,promotion.discount_cents,'referral',f'referral:{row.id}','First top-up discount' if first_offer else 'Referral discount')
    promotion.applied_at=now()
    from .wallet_models import WalletTopup
    others=db.query(ReferralTopup).join(WalletTopup,WalletTopup.id==ReferralTopup.topup_id).filter(
        WalletTopup.user_id==row.user_id,ReferralTopup.topup_id!=row.id,ReferralTopup.applied_at.is_(None)).all()
    for other in others:other.skipped_reason='already_used'


def topup_extra(row):
    db=object_session(row)
    p=db.get(ReferralTopup,row.id) if db is not None else None
    if p is None:return {}
    valid=p.skipped_reason is None
    return {'requested_amount_cents':p.credit_cents,'payable_cents':p.pay_cents,
        'discount_cents':p.discount_cents if valid else 0,'discount_applied':p.applied_at is not None,
        'credit_cents':p.credit_cents if valid else row.amount_cents,
        'discount_status':'applied' if p.applied_at is not None else p.skipped_reason or 'pending'}


def secret():
    from .config import get_settings
    value=get_settings().api_key
    if not value:raise HTTPException(503,'Gift codes are temporarily unavailable')
    return value.encode()


def legacy_code_value(ident):
    raw=hmac.new(secret(),b'pulsarx-mini-2h:'+ident.hex.encode(),hashlib.sha256).digest()
    text=base64.b32encode(raw).decode()[:20]
    return 'PX-'+'-'.join(text[n:n+5] for n in range(0,20,5))


def code_value(ident):
    raw=hmac.new(secret(),b'pulsarx-nano-30d-v1:'+ident.hex.encode(),hashlib.sha256).digest()
    value=base64.b32encode(raw).decode()[:12]
    return 'PX-'+'-'.join(value[n:n+4] for n in range(0,12,4))


def activation_deadline(row):
    # Distinguish new codes by their signed digest; preserve old code terms.
    if not hmac.compare_digest(digest_code(code_value(row.id)),row.digest):return None
    created=row.created_at
    if created.tzinfo is None:created=created.replace(tzinfo=timezone.utc)
    return created+timedelta(days=30)


def normalize_code(value):
    result=re.sub(r'[-\s]','',value.upper())
    if not CODE_RE.fullmatch(result):raise HTTPException(400,'Invalid or unavailable code')
    return result


def digest_code(value):return hashlib.sha256(normalize_code(value).encode()).hexdigest()


def code_out(db,row,reveal=False):
    owner=db.get(User,row.redeemed_by) if row.redeemed_by is not None else None
    server=db.get(Server,row.server_id) if row.server_id else None
    state=row.state
    deadline=activation_deadline(row)
    if not row.redeemed_at and deadline and deadline<=now():state='expired'
    if state=='active' and row.expires_at and row.expires_at<=now():state='expired'
    elif state=='active' and server is None:state='deleted'
    out={'id':str(row.id),'hint':row.hint,'label':row.label,'state':state,'created_at':row.created_at,
        'redeemed_at':row.redeemed_at,'user_email':owner.email if owner else None,
        'server_id':str(row.server_id) if row.server_id else None,'server_name':server.container_name if server else None,
        'expires_at':row.expires_at,'activation_expires_at':deadline,'error_code':row.error_code,'plan':row.plan,'hours':row.duration_hours}
    if reveal:
        raw=code_value(row.id)
        if not hmac.compare_digest(digest_code(raw),row.digest):raw=legacy_code_value(row.id)
        out['code']=raw if hmac.compare_digest(digest_code(raw),row.digest) else None
    return out


def create_code(db,request_key,label,review_reference=''):
    db.execute(text('SELECT pg_advisory_xact_lock(:key)'),{'key':771903})
    row=db.query(GiftCode).filter_by(request_key=request_key).one_or_none()
    if row is not None:
        if row.label!=label:raise HTTPException(409,'Creation request already used with another label')
        return code_out(db,row,True)
    review_reference=(review_reference or label).strip()
    if not 3<=len(review_reference)<=2048:raise HTTPException(422,'Record the honest review reference before issuing a Nano code')
    ident=uuid.uuid4();raw=code_value(ident)
    row=GiftCode(id=ident,request_key=request_key,digest=digest_code(raw),hint=normalize_code(raw)[-6:],label=label,state='unused',plan='nano',duration_hours=72,review_reference=review_reference)
    db.add(row);db.add(AdminActionLog(action='create_mini_gift',target_type='gift_code',target_label=str(ident),actor='admin'))
    db.commit();db.refresh(row)
    return code_out(db,row,True)


def redeem_code(db,user,value):
    from . import wallet_service as w,incus_service
    from .capacity_service import capacity_lock,require_capacity
    from .schemas import PLANS,PLAN_LIMITS
    ensure_verified(user)
    capacity_lock(db)  # Same lock order as paid wallet purchases.
    acct=w.account(db,user.id)
    if acct.frozen:raise HTTPException(409,'Account is under review. Contact support.')
    row=db.query(GiftCode).filter_by(digest=digest_code(value)).populate_existing().with_for_update().one_or_none()
    if row is None or row.revoked_at:raise HTTPException(400,'Invalid or unavailable code')
    if row.redeemed_at:
        if row.redeemed_by==user.id:return {'state':row.state,'server_id':str(row.server_id) if row.server_id else None,'expires_at':row.expires_at,'replayed':True}
        raise HTTPException(409,'This code has already been used')
    deadline=activation_deadline(row)
    if deadline and deadline<=now():raise HTTPException(400,'Срок активации кода истёк (30 дней).')
    if row.plan not in PLANS or row.duration_hours not in (2,72):raise HTTPException(409,'Gift terms need review')
    if row.plan=='nano' and db.query(GiftCode.id).filter(GiftCode.redeemed_by==user.id,GiftCode.id!=row.id,or_(GiftCode.activated_at.isnot(None),GiftCode.state.in_(('queued','working','review')))).first():raise HTTPException(409,'The one-time review gift was already claimed')
    return queue_grant(db, user, row)


def queue_grant(db, user, row):
    from . import incus_service
    from .schemas import PLANS
    spec=PLANS[row.plan];name=incus_service.generate_container_name()
    require_resources(db,spec,name)
    server=Server(id=uuid.uuid4(),container_name=name,owner_id=user.id,owner_email=user.email,
        plan=row.plan,image='debian13',ram_mb=spec['ram_mb'],cpu_cores=spec['cpu_cores'],disk_gb=spec['disk_gb'],
        status=ServerStatus.pending,trial_expires_at=now()+timedelta(hours=row.duration_hours),paid_until=None)
    db.add(server);db.flush()
    row.server_id=server.id;row.redeemed_by=user.id;row.redeemed_at=now();row.state='queued'
    db.add(AdminActionLog(action='redeem_mini_gift',target_type='server',target_label=name,actor='user'))
    db.commit()
    return {'state':'queued','server_id':str(server.id),'expires_at':None,'replayed':False}


def process_gift(ident):
    from .routers.servers import _provision
    db=SessionLocal();start=False;server_id=None
    try:
        row=db.query(GiftCode).filter_by(id=ident).with_for_update().one_or_none()
        if row is None or row.state not in ('queued','working'):return
        server=db.get(Server,row.server_id) if row.server_id else None
        if server is None:row.state='failed';row.error_code='instance_missing';db.commit();return
        if server.status==ServerStatus.running:
            if row.activated_at is None:
                row.activated_at=now();row.expires_at=row.activated_at+timedelta(hours=row.duration_hours);server.trial_expires_at=row.expires_at
            row.state='active';db.commit();return
        if row.state=='working':
            row.state='review';row.error_code='provision_interrupted';db.commit();return
        row.state='working';server_id=server.id;start=True;db.commit()
    finally:db.close()
    if start:
        _provision(server_id)
        db=SessionLocal()
        try:
            row=db.query(GiftCode).filter_by(id=ident).with_for_update().one();server=db.get(Server,server_id)
            if server is not None and server.status==ServerStatus.running:
                row.activated_at=now();row.expires_at=row.activated_at+timedelta(hours=row.duration_hours);server.trial_expires_at=row.expires_at;row.state='active'
            else:row.state='failed';row.error_code='provision_failed'
            db.commit()
        finally:db.close()


def process_pending():
    db=SessionLocal()
    try:ids=[x[0] for x in db.query(GiftCode.id).filter(GiftCode.state.in_(('queued','working'))).order_by(GiftCode.redeemed_at).limit(10)]
    finally:db.close()
    for ident in ids:
        try:process_gift(ident)
        except Exception:logging.getLogger('pulsarx.gifts').exception('Gift provisioning needs review: %s',ident)


def start_trial_clock(db,server):
    if server.trial_expires_at is None:return
    grant=db.query(GiftCode).filter(GiftCode.server_id==server.id).one_or_none()
    server.trial_expires_at=now()+timedelta(hours=grant.duration_hours if grant else 72)
