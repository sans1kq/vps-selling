"""PulsarX 24-hour admin grants. No billing extension or upgrade is allowed."""
import json
import logging
import threading
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import inspect, or_, text
from sqlalchemy.orm import Session

from .database import SessionLocal, engine
from .models import AdminActionLog, Payment, Server, ServerStatus

logger = logging.getLogger("pulsarx.trials")
_thread = None
_start_lock = threading.Lock()
INTERVAL_SECONDS = 30


def utc(value):
    if value is not None and value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def is_trial(server):
    return getattr(server, "trial_expires_at", None) is not None


def ensure_trial_active(server):
    deadline = utc(getattr(server, "trial_expires_at", None))
    if deadline is not None and deadline <= datetime.now(timezone.utc):
        raise HTTPException(410, "The temporary free instance has expired and is scheduled for deletion")


def ensure_not_trial(server):
    if is_trial(server):
        raise HTTPException(403, "Unavailable for a temporary free instance")


def ensure_upgrade_allowed(server):
    # Also closes the old unbilled/manual approval route before migration.
    if is_trial(server) or (not server.ls_subscription_id and server.paid_until is None):
        raise HTTPException(409, "Renew this server before upgrading")
    paid_until = utc(getattr(server, "paid_until", None))
    if paid_until is not None and paid_until <= datetime.now(timezone.utc):
        raise HTTPException(409, "Renew this server before upgrading")


def initialize_storage(now=None):
    """Add an optional deadline; give existing unbilled instances a fresh day.

    Subscription/prepaid servers and any server with a successful or unsettled
    payment are excluded. Running this again never extends a grant.
    """
    now = utc(now) if now is not None else datetime.now(timezone.utc)
    deadline = now + timedelta(hours=24)
    records = []
    with engine.begin() as connection:
        columns = {c["name"] for c in inspect(connection).get_columns("servers")}
        if "trial_expires_at" not in columns:
            connection.execute(text("ALTER TABLE servers ADD COLUMN trial_expires_at TIMESTAMP WITH TIME ZONE NULL"))
        connection.execute(text("CREATE INDEX IF NOT EXISTS ix_servers_trial_expires_at ON servers (trial_expires_at) WHERE trial_expires_at IS NOT NULL"))
        with Session(bind=connection, join_transaction_mode="create_savepoint") as db:
            protected_payment = db.query(Payment.id).filter(
                Payment.server_id == Server.id,
                or_(Payment.credited_at.isnot(None), Payment.status.in_(("credited", "pending", "needs_review")),
                    (Payment.status == "created") & (Payment.expires_at > now)),
            ).exists()
            rows = db.query(Server).filter(
                Server.trial_expires_at.is_(None), Server.paid_until.is_(None),
                Server.ls_subscription_id.is_(None), ~protected_payment,
                or_(Server.status.in_((ServerStatus.running, ServerStatus.suspended,
                                      ServerStatus.pending, ServerStatus.provisioning)),
                    (Server.status == ServerStatus.pending_approval) & Server.approval_token.isnot(None)),
            ).with_for_update().all()
            for server in rows:
                server.trial_expires_at = deadline
                server.upgrade_target_plan = None
                server.upgrade_token = None
                server.upgrade_token_expires_at = None
                records.append({"id": str(server.id), "container_name": server.container_name,
                                "trial_expires_at": deadline.isoformat()})
            db.commit()
    return {"existing_free_instances": records, "deadline": deadline.isoformat()}


def expire_trials(now=None):
    """Remove resources first and keep the row for a retry after any failure."""
    from . import domain_service, incus_service
    now = utc(now) if now is not None else datetime.now(timezone.utc)
    db = SessionLocal()
    deleted = []
    try:
        ids = [row[0] for row in db.query(Server.id).filter(
            Server.trial_expires_at.isnot(None), Server.trial_expires_at <= now,
            Server.status != ServerStatus.deleted,
        ).limit(100).all()]
        db.rollback()
        for server_id in ids:
            try:
                # Skip rows another worker or an API operation has locked.
                server = db.query(Server).filter(
                    Server.id == server_id, Server.trial_expires_at <= now,
                    Server.status != ServerStatus.deleted,
                ).with_for_update(skip_locked=True).one_or_none()
                if server is None:
                    db.rollback(); continue
                paid = db.query(Payment.id).filter(
                    Payment.server_id == server.id,
                    or_(Payment.credited_at.isnot(None), Payment.status == "credited"),
                ).first()
                if server.ls_subscription_id or server.paid_until is not None or paid:
                    logger.error("Refusing trial cleanup for an instance with payment entitlement: %s", server.id)
                    db.rollback(); continue
                name = server.container_name
                # The provisioning rollback patch verifies absence of both the
                # instance and its dedicated pool. Failure must retain the row.
                incus_service.delete_container(name)
                if server.custom_domain:
                    domain_service.remove_domain(server.custom_domain)
                db.add(AdminActionLog(action="trial_expired", target_type="server",
                                      target_label=name, actor="system"))
                db.delete(server)
                db.commit()
                deleted.append(name)
                logger.info("24-hour free instance removed: %s", name)
            except Exception:
                db.rollback()
                logger.exception("Free-instance cleanup will retry: %s", server_id)
    finally:
        db.close()
    return deleted


def _loop():
    while True:
        try:
            expire_trials()
        except Exception:
            logger.exception("Free-instance sweep failed; it will retry")
        threading.Event().wait(INTERVAL_SECONDS)


def start_trial_reaper():
    """Uses the API process's existing Incus credentials and environment."""
    global _thread
    with _start_lock:
        if _thread is None or not _thread.is_alive():
            _thread = threading.Thread(target=_loop, name="pulsarx-trial-reaper", daemon=True)
            _thread.start()


if __name__ == "__main__":
    print(json.dumps(initialize_storage()))
