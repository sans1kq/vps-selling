"""Additive referral and two-hour Mini grant records."""
import uuid
from sqlalchemy import (Boolean, BigInteger, CheckConstraint, Column, DateTime, ForeignKey,
                        Integer, String, UniqueConstraint, func)
from sqlalchemy.dialects.postgresql import UUID
from .database import Base


class ReferralProfile(Base):
    __tablename__='wallet_referral_profiles'
    user_id=Column(UUID(as_uuid=True),ForeignKey('users.id',ondelete='CASCADE'),primary_key=True)
    token=Column(String(48),nullable=False,unique=True)
    created_at=Column(DateTime(timezone=True),nullable=False,server_default=func.now())


class ReferralBenefit(Base):
    __tablename__='wallet_referral_benefits'
    user_id=Column(UUID(as_uuid=True),ForeignKey('users.id',ondelete='CASCADE'),primary_key=True)
    inviter_id=Column(UUID(as_uuid=True),ForeignKey('users.id',ondelete='SET NULL'),nullable=True,index=True)
    consumed_topup_id=Column(BigInteger().with_variant(Integer,'sqlite'),ForeignKey('wallet_topups.id'),nullable=True,unique=True)
    created_at=Column(DateTime(timezone=True),nullable=False,server_default=func.now())
    consumed_at=Column(DateTime(timezone=True),nullable=True)


class ReferralTopup(Base):
    __tablename__='wallet_referral_topups'
    topup_id=Column(BigInteger().with_variant(Integer,'sqlite'),ForeignKey('wallet_topups.id',ondelete='CASCADE'),primary_key=True)
    pay_cents=Column(Integer,nullable=False)
    credit_cents=Column(Integer,nullable=False)
    discount_cents=Column(Integer,nullable=False)
    applied_at=Column(DateTime(timezone=True),nullable=True)
    skipped_reason=Column(String(32),nullable=True)
    __table_args__=(CheckConstraint('pay_cents > 0'),CheckConstraint('discount_cents > 0'),
                   CheckConstraint('credit_cents = pay_cents + discount_cents'))


class GiftCode(Base):
    __tablename__='wallet_mini_gift_codes'
    id=Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    request_key=Column(UUID(as_uuid=True),nullable=False,unique=True)
    digest=Column(String(64),nullable=False,unique=True)
    hint=Column(String(10),nullable=False)
    label=Column(String(100),nullable=False,default='')
    created_at=Column(DateTime(timezone=True),nullable=False,server_default=func.now())
    revoked_at=Column(DateTime(timezone=True),nullable=True)
    redeemed_at=Column(DateTime(timezone=True),nullable=True)
    redeemed_by=Column(UUID(as_uuid=True),ForeignKey('users.id',ondelete='SET NULL'),nullable=True,index=True)
    server_id=Column(UUID(as_uuid=True),ForeignKey('servers.id',ondelete='SET NULL'),nullable=True,unique=True)
    state=Column(String(16),nullable=False,default='unused')
    activated_at=Column(DateTime(timezone=True),nullable=True)
    expires_at=Column(DateTime(timezone=True),nullable=True)
    error_code=Column(String(40),nullable=True)
    plan=Column(String(16),nullable=False,default='nano',server_default='mini')
    duration_hours=Column(Integer,nullable=False,default=72,server_default='2')
    review_reference=Column(String(2048),nullable=True)


class FirstTopupOffer(Base):
    __tablename__ = 'wallet_first_topup_offers'
    topup_id = Column(BigInteger, ForeignKey('wallet_topups.id'), primary_key=True)
    includes_referral = Column(Boolean, nullable=False)


class VpsPromo(Base):
    __tablename__ = 'vps_promotions'
    name = Column(String(64), primary_key=True)
    duration_hours = Column(Integer, nullable=False)
    ends_at = Column(DateTime(timezone=True))
    closed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), nullable=False, server_default=func.now())


TABLES=[FirstTopupOffer.__table__, VpsPromo.__table__,ReferralProfile.__table__,ReferralBenefit.__table__,ReferralTopup.__table__,GiftCode.__table__]
