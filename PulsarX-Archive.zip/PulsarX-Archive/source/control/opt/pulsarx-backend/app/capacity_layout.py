"""Pure per-filesystem admission accounting for one operator-relocated pool."""
import re
import time

GIB = 1024 ** 3
GB = 10 ** 9
DATA = '/var/lib/incus/disks'
SYSTEM = '/var/lib/pulsarx-root-disks'
TARGET = 'mini-0f419f50e2'
IMAGE = TARGET + '-pool.img'
MAINTENANCE = 'user.pulsarx.storage_maintenance'
GC = 'user.pulsarx.storage_gc'


def integer(value, positive=False):
    if type(value) is not int or value < int(positive) or value > 2**63-1:
        raise ValueError('Invalid storage integer')
    return value


def bytesize(value):
    match = re.fullmatch(r'([0-9]+)(B|kB|MB|GB|TB|KiB|MiB|GiB|TiB)?', str(value))
    if not match:
        raise ValueError('Invalid pool size')
    units = {None: 1, 'B': 1, 'kB': 1000, 'MB': 1000**2, 'GB': 1000**3,
             'TB': 1000**4, 'KiB': 1024, 'MiB': 1024**2, 'GiB': GIB, 'TiB': 1024**4}
    return integer(int(match[1])*units[match[2]], True)


def calculate_v2(data, pools, intended=(), exclude_container=None, now=None):
    now = time.time() if now is None else now
    if type(data.get('version')) is not int or data['version'] != 2 or data.get('path') != DATA:
        raise ValueError('Invalid split capacity snapshot')
    sampled = integer(data.get('sampled_at'), True)
    if now-sampled > 60 or sampled-now > 10:
        raise ValueError('Stale storage sample')
    source = data.get('filesystems')
    if not isinstance(source, dict) or set(source) != {'data', 'system'}:
        raise ValueError('Both storage filesystems are required')
    placements = data.get('placements')
    if not isinstance(placements, dict) or placements not in ({}, {IMAGE: 'system'}):
        raise ValueError('Unexpected relocated pool')
    stats = {}; promised = {}; locations = {}; devices = set()
    for key, path in [('data', DATA), ('system', SYSTEM)]:
        fs = source[key]
        if not isinstance(fs, dict) or fs.get('path') != path:
            raise ValueError('Unexpected filesystem path')
        device = integer(fs.get('device'))
        if device in devices:
            raise ValueError('Duplicate physical filesystem')
        devices.add(device)
        total, free = integer(fs.get('total'), True), integer(fs.get('free'))
        if free > total:
            raise ValueError('Free storage exceeds capacity')
        images = fs.get('images')
        if not isinstance(images, dict) or (key == 'system' and set(images) - {IMAGE}):
            raise ValueError('Unexpected image inventory')
        stats[key] = {'total_bytes': total, 'physical_free_bytes': free,
                      'unfilled_existing_bytes': 0, 'new_pool_bytes': 0,
                      'pending_reservations_bytes': 0,
                      'system_reserve_bytes': max(20*GIB, (total+4)//5) if key == 'system'
                          else max(8*GIB, (total+9)//10)}
        for name, row in images.items():
            if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_.-]+\.img', name) or not isinstance(row, dict) or name in promised:
                raise ValueError('Invalid or duplicated image')
            size = integer(row.get('size'), True); allocated = integer(row.get('allocated'))
            if key == 'system' and size > 50*GIB:
                raise ValueError('Relocated pool exceeds the allowed maximum')
            promised[name] = size; locations[name] = key
            stats[key]['unfilled_existing_bytes'] += max(0, size-allocated)
    if placements != {name: key for name, key in locations.items() if key == 'system'}:
        raise ValueError('Placement does not match the image inventory')
    seen = set()
    if not isinstance(pools, list):
        raise ValueError('Invalid pool list')
    for pool in pools:
        if not isinstance(pool, dict) or not isinstance(pool.get('name'), str) or not isinstance(pool.get('config'), dict):
            raise ValueError('Invalid pool record')
        name = pool['name']; config = pool['config']; source_path = config.get('source', '')
        if name in seen or not isinstance(source_path, str):
            raise ValueError('Duplicate or invalid storage pool')
        seen.add(name)
        if not source_path.startswith(DATA+'/'):
            if re.fullmatch(r'mini-[a-z0-9]+-pool', name):
                raise ValueError('Unexpected tenant source')
            continue
        image = source_path[len(DATA)+1:]
        if '/' in image or not image.endswith('.img') or pool.get('driver') != 'btrfs':
            raise ValueError('Unsupported loop-backed pool')
        key = placements.get(image, 'data')
        size = bytesize(config.get('size'))
        if key == 'system' and (image != IMAGE or name != TARGET+'-pool' or size > 50*GIB):
            raise ValueError('Unexpected system pool')
        stats[key]['new_pool_bytes'] += max(0, size-promised.get(image, 0))
        promised[image] = max(size, promised.get(image, 0))
    for container, disk_gb in intended:
        if not isinstance(container, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', container):
            raise ValueError('Invalid reserved instance')
        size = integer(disk_gb, True)*GB
        if container == exclude_container:
            continue
        image = container+'-pool.img'; key = placements.get(image, 'data')
        if key == 'system' and size > 50*GIB:
            raise ValueError('Unexpected system reservation')
        stats[key]['pending_reservations_bytes'] += max(0, size-promised.get(image, 0))
        promised[image] = max(size, promised.get(image, 0))
    for row in stats.values():
        row['available_for_new_bytes'] = max(0, row['physical_free_bytes']-row['unfilled_existing_bytes']
            -row['new_pool_bytes']-row['pending_reservations_bytes']-row['system_reserve_bytes'])
    selected = placements.get(str(exclude_container)+'-pool.img', 'data')
    return dict(stats[selected], host=data['host'], filesystem=selected,
                sample_age_seconds=max(0, int(now-sampled)), filesystems=stats)
