"""Admission control for new loop-backed pools; reads the existing remote API."""
import json
import logging
import re
import time
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import and_, or_, text

from .database import SessionLocal
from .models import Payment, Server, ServerStatus

KEY = "user.pulsarx.storage_capacity"
DISK = "/var/lib/incus/disks"
GIB = 1024 ** 3
GB = 10 ** 9
LOCK = 7001  # Same PostgreSQL lock as payment slot reservations.
MAX_AGE = 60
logger = logging.getLogger("pulsarx.capacity")


class StorageCapacityError(RuntimeError):
    def __init__(self, status_code, detail):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


def number(value, positive=False):
    if type(value) is not int or value < (1 if positive else 0) or value > 2 ** 63 - 1:
        raise ValueError("Invalid capacity integer")
    return value


def storage_size(value):
    match = re.fullmatch(r"([0-9]+)(B|kB|MB|GB|TB|KiB|MiB|GiB|TiB)?", str(value))
    if not match:
        raise ValueError("Unsupported Incus pool size")
    powers = {None: 1, "B": 1, "kB": 1000, "MB": 1000 ** 2,
              "GB": 1000 ** 3, "TB": 1000 ** 4, "KiB": 1024,
              "MiB": 1024 ** 2, "GiB": GIB, "TiB": 1024 ** 4}
    return number(int(match[1]) * powers[match[2]], positive=True)


def remote_state():
    from .incus_service import _run
    root = json.loads(_run(["incus", "query", "/1.0"], timeout=15))
    if isinstance(root, dict) and "metadata" in root:
        root = root["metadata"]
    if not isinstance(root, dict) or root.get("environment", {}).get("server_clustered") is not False:
        raise ValueError("A standalone Incus host is required")
    data = json.loads(root["config"][KEY])
    host = root["environment"]["server_name"]
    if not isinstance(host, str) or not isinstance(data, dict) or data.get("host") != host:
        raise ValueError("Incus capacity host does not match the API host")
    data["_maintenance"] = bool(root.get("config", {}).get("user.pulsarx.storage_maintenance"))
    pools = json.loads(_run(["incus", "storage", "list", "--format", "json"], timeout=15))
    if not isinstance(pools, list):
        raise ValueError("Invalid Incus storage list")
    return data, pools


def reservations(db, now):
    from .flex_capacity import reservation_resources
    return [(r['name'], r['disk_gb']) for r in reservation_resources(db, now)]


def _calculate_v1(data, pools, intended=(), exclude_container=None, now=None):
    now = time.time() if now is None else now
    if data.get("version") != 1 or type(data.get("version")) is not int or data.get("path") != DISK:
        raise ValueError("Invalid capacity snapshot")
    sampled = number(data.get("sampled_at"), positive=True)
    if now - sampled > MAX_AGE or sampled - now > 10:
        raise ValueError("Capacity snapshot is stale or from the future")
    total, free = number(data.get("total"), True), number(data.get("free"))
    if free > total:
        raise ValueError("Invalid filesystem free space")
    images = data.get("images")
    if not isinstance(images, dict):
        raise ValueError("Invalid image list")
    promised = {}
    unfilled = 0
    for name, info in images.items():
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+\.img", name) or not isinstance(info, dict):
            raise ValueError("Invalid image record")
        size, allocated = number(info.get("size")), number(info.get("allocated"))
        promised[name] = size
        unfilled += max(0, size - allocated)
    since_sample = 0
    seen = set()
    for pool in pools:
        if not isinstance(pool, dict) or not isinstance(pool.get("name"), str) or not isinstance(pool.get("config"), dict):
            raise ValueError("Invalid pool record")
        name, config = pool["name"], pool["config"]
        if name in seen:
            raise ValueError("Duplicate Incus storage pool")
        seen.add(name)
        source = config.get("source", "")
        if not isinstance(source, str):
            raise ValueError("Invalid pool source")
        image = source.removeprefix(DISK + "/")
        if not source.startswith(DISK + "/"):
            if re.fullmatch(r"mini-[a-z0-9]+-pool", name):
                raise ValueError("A tenant pool uses an unexpected storage source")
            continue
        if "/" in image or not image.endswith(".img") or pool.get("driver") != "btrfs":
            raise ValueError("Unsupported Incus disk layout")
        size = storage_size(config.get("size"))
        since_sample += max(0, size - promised.get(image, 0))
        promised[image] = max(size, promised.get(image, 0))
    outstanding = 0
    for container, disk_gb in intended:
        if container == exclude_container:
            continue
        if not isinstance(container, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", container):
            raise ValueError("Invalid reserved container name")
        size = number(disk_gb, True) * GB
        image = container + "-pool.img"
        outstanding += max(0, size - promised.get(image, 0))
        promised[image] = max(size, promised.get(image, 0))
    reserve = max(8 * GIB, (total + 9) // 10)
    available = max(0, free - unfilled - since_sample - outstanding - reserve)
    return {"host": data["host"], "sample_age_seconds": max(0, int(now - sampled)),
            "total_bytes": total, "physical_free_bytes": free,
            "unfilled_existing_bytes": unfilled, "new_pool_bytes": since_sample,
            "pending_reservations_bytes": outstanding, "system_reserve_bytes": reserve,
            "available_for_new_bytes": available}



def calculate(data, pools, intended=(), exclude_container=None, now=None):
    from .capacity_layout import calculate_v2
    if type(data.get('version')) is int and data['version'] == 2:
        usage = calculate_v2(data, pools, intended, exclude_container, now)
    else:
        usage = _calculate_v1(data, pools, intended, exclude_container, now)
        usage['filesystem'] = 'data'
    usage['maintenance'] = bool(data.get('_maintenance'))
    return usage


def report(db, exclude_container=None):
    from .flex_capacity import capacity_report
    return capacity_report(db, exclude_container)


def require_capacity(db, disk_gb, exclude_container=None):
    requested = number(disk_gb, True) * GB
    usage = report(db, exclude_container)
    if usage.get("maintenance"):
        raise StorageCapacityError(503, "Storage maintenance is in progress. Please try again later.")
    if requested > usage["available_for_new_bytes"]:
        raise StorageCapacityError(409, "Not enough storage capacity for this plan. Please try again later.")
    return usage


def capacity_lock(db):
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": LOCK})


def ensure_capacity_http(db, disk_gb, container_name, ram_mb=None, cpu_cores=None):
    from .flex_capacity import require_resources
    try:
        if ram_mb is None or cpu_cores is None:
            raise StorageCapacityError(503, 'A complete resource reservation is required')
        return require_resources(db, {'disk_gb':disk_gb,'ram_mb':ram_mb,'cpu_cores':cpu_cores},container_name)
    except StorageCapacityError as exc:
        db.rollback()
        raise HTTPException(exc.status_code,exc.detail) from exc


def guarded_pool_create(name, disk_gb, create, ram_mb=None, cpu_cores=None):
    from .flex_capacity import require_resources
    db=SessionLocal()
    try:
        if ram_mb is None or cpu_cores is None:
            raise StorageCapacityError(503, 'A complete resource reservation is required')
        require_resources(db, {'disk_gb':disk_gb,'ram_mb':ram_mb,'cpu_cores':cpu_cores},name)
        result=create();db.commit();return result
    except BaseException:
        db.rollback();raise
    finally:db.close()


if __name__ == "__main__":
    db = SessionLocal()
    try:
        print(json.dumps(report(db), sort_keys=True))
    finally:
        db.close()
