"""Private support inbox; independent of wallet/instance data."""
import contextlib
import hashlib
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path

STATE = Path(os.environ.get('PULSARX_SUPPORT_STATE', '/var/lib/pulsarx-support'))


@contextlib.contextmanager
def connect():
    db = sqlite3.connect(str(STATE / 'support.sqlite3'), timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    try:
        yield db
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()


def initialize():
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    (STATE / 'files').mkdir(mode=0o700, exist_ok=True)
    with connect() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tickets(
          id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL,
          name TEXT NOT NULL, username TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
          created REAL NOT NULL, updated REAL NOT NULL, unread INTEGER NOT NULL DEFAULT 1);
        CREATE UNIQUE INDEX IF NOT EXISTS one_open_ticket ON tickets(chat_id) WHERE status='open';
        CREATE TABLE IF NOT EXISTS messages(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id),
          direction TEXT NOT NULL, body TEXT NOT NULL, created REAL NOT NULL,
          delivery TEXT NOT NULL DEFAULT 'received', tg_message_id INTEGER,
          request_id TEXT UNIQUE, attempts INTEGER NOT NULL DEFAULT 0,
          retry_at REAL NOT NULL DEFAULT 0, error TEXT);
        CREATE INDEX IF NOT EXISTS thread ON messages(ticket_id,id);
        CREATE TABLE IF NOT EXISTS updates(id INTEGER PRIMARY KEY, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS attachments(
          id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER NOT NULL REFERENCES messages(id),
          file_id TEXT NOT NULL, name TEXT NOT NULL, size INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending', local_name TEXT,
          attempts INTEGER NOT NULL DEFAULT 0, retry_at REAL NOT NULL DEFAULT 0);
        ''')
    os.chmod(STATE / 'support.sqlite3', 0o600)


def meta(db, key, default=''):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row['value'] if row else default


def put(db, key, value):
    db.execute('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, str(value)))


def enqueue(db, ticket_id, body, request_id, direction='out', now=None):
    now = time.time() if now is None else now
    db.execute('INSERT OR IGNORE INTO messages(ticket_id,direction,body,created,delivery,request_id) VALUES(?,?,?,?,?,?)',
               (ticket_id, direction, body, now, 'queued', request_id))
    return db.execute('SELECT id,ticket_id,body,delivery FROM messages WHERE request_id=?', (request_id,)).fetchone()


def public_contact():
    with connect() as db:
        username = meta(db, 'bot_username')
        return {'username': username, 'url': 'https://t.me/' + username if username else None,
                'email': 'contact@example.invalid'}


def notification_link(now=None):
    """Called only from the server console; a one-use credential, never a public API."""
    now=time.time() if now is None else now
    code=secrets.token_urlsafe(24)
    with connect() as db:
        username=meta(db,'bot_username')
        if not username:raise ValueError('Bot identity is not configured')
        put(db,'notify_setup_hash',hashlib.sha256(code.encode()).hexdigest())
        put(db,'notify_setup_expires',now+900)
    return 'https://t.me/'+username+'?start=notify_'+code


def technical_reply(db,chat_id,name,username,body,key,now):
    row=db.execute("SELECT id FROM tickets WHERE chat_id=? AND status='intro' ORDER BY id DESC LIMIT 1",(chat_id,)).fetchone()
    if row:ticket_id=row['id']
    else:ticket_id=db.execute("INSERT INTO tickets(chat_id,name,username,status,created,updated,unread) VALUES(?,?,?,'intro',?,?,0)",(chat_id,name,username,now,now)).lastrowid
    enqueue(db,ticket_id,body,key,'system',now)


def cancel_alerts(db,chat_id):
    # A recipient change or opt-out also cancels notifications still in the queue.
    db.execute("UPDATE messages SET delivery='cancelled',error='recipient_changed_or_disabled' WHERE direction='notify' AND delivery='queued' AND request_id LIKE ?",('notify:'+str(chat_id)+':%',))


def receive(update, now=None):
    """Commit incoming text, ack, and cursor together, before acknowledging Telegram."""
    now = time.time() if now is None else now
    uid = update.get('update_id')
    if not isinstance(uid, int):
        return
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute('SELECT 1 FROM updates WHERE id=?', (uid,)).fetchone():
            return
        db.execute('INSERT INTO updates VALUES(?,?)', (uid, now))
        msg = update.get('message') or {}
        chat, sender = msg.get('chat') or {}, msg.get('from') or {}
        if chat.get('type') == 'private' and isinstance(chat.get('id'), int) and sender.get('id') == chat['id'] and not sender.get('is_bot'):
            chat_id = chat['id']
            name = ' '.join(str(sender.get(k) or '') for k in ('first_name', 'last_name')).strip()[:160] or str(chat_id)
            username = str(sender.get('username') or '')[:64]
            body = str(msg.get('text') or msg.get('caption') or '')[:16384]
            existing = db.execute("SELECT * FROM tickets WHERE chat_id=? AND status='open'", (chat_id,)).fetchone()
            parts=body.split(maxsplit=1);command=parts[0].split('@')[0] if parts else '';payload=parts[1].strip() if len(parts)>1 else ''
            lang_key = 'support_lang:' + str(chat_id)
            language = meta(db, lang_key)
            if not language:
                language = 'ru' if str(sender.get('language_code','')).lower().split('-')[0]=='ru' else 'en'
                put(db, lang_key, language)
            english = language == 'en'
            awaiting_description=now<float(meta(db,'compose_until:'+str(chat_id),'0'))
            if command=='/start' and not payload:
                put(db,'compose_until:'+str(chat_id),'0');awaiting_description=False
            if command in ('/en','/ru'):
                put(db, lang_key, command[1:])
                reply = ('English selected. Send /ticket to open a request, then send your message. Русский: /ru'
                         if command == '/en' else 'Выбран русский. Отправьте /ticket, затем текст обращения. English: /en')
                technical_reply(db,chat_id,name,username,reply,'language:'+str(uid),now)
            elif command=='/start' and payload.startswith('notify_'):
                digest=hashlib.sha256(payload.removeprefix('notify_').encode()).hexdigest()
                expected=meta(db,'notify_setup_hash')
                valid=bool(expected) and now<float(meta(db,'notify_setup_expires','0')) and secrets.compare_digest(digest,expected)
                if valid:
                    previous=meta(db,'notify_chat_id')
                    if previous and previous!=str(chat_id):cancel_alerts(db,previous)
                    put(db,'notify_chat_id',chat_id);put(db,'notify_name',name);put(db,'notify_username',username)
                    put(db,'notify_setup_hash','');put(db,'notify_setup_expires','0')
                    technical_reply(db,chat_id,name,username,'Личные уведомления включены. Новые тикеты будут приходить сюда с номером и ссылкой на админку.\n\nОтветы клиентам отправляйте из Admin → Support. Отключить уведомления: /stopalerts','notify-bound:'+str(uid),now)
                elif now-float(meta(db,'notify_invalid:'+str(chat_id),'0'))>=60:
                    put(db,'notify_invalid:'+str(chat_id),now)
                    technical_reply(db,chat_id,name,username,'Ссылка привязки недействительна, уже использована или истекла. Создайте новую ссылку в консоли сервера.','notify-invalid:'+str(uid),now)
            elif command=='/stopalerts' and meta(db,'notify_chat_id')==str(chat_id):
                put(db,'notify_chat_id','');put(db,'notify_setup_hash','');put(db,'notify_setup_expires','0');cancel_alerts(db,chat_id)
                technical_reply(db,chat_id,name,username,'Личные уведомления отключены. Клиентская поддержка продолжает работать.','notify-stopped:'+str(uid),now)
            elif command in ('/tiket','/ticket'):
                put(db,'compose_until:'+str(chat_id),'0' if existing else now+1800)
                if now-float(meta(db,'compose_prompt:'+str(chat_id),'0'))>=3:
                    put(db,'compose_prompt:'+str(chat_id),now)
                    prompt=('У вас уже открыто обращение #'+str(existing['id'])+'. Напишите сообщение — мы добавим его в это обращение.' if existing else
                            'Опишите проблему следующим сообщением. Можно приложить скриншот или документ до 10 МБ.\n\nОтменить создание: /cancel')
                    if english:
                        prompt = (f"You already have ticket #{existing['id']}. Send a message to add it to that ticket." if existing else 'Send your request in your next message. You can attach a screenshot or document up to 10 MB. To cancel, send /cancel.')
                    technical_reply(db,chat_id,name,username,prompt,'compose-prompt:'+str(uid),now)
            elif command=='/cancel':
                put(db,'compose_until:'+str(chat_id),'0')
                if now-float(meta(db,'cancel_prompt:'+str(chat_id),'0'))>=3:
                    put(db,'cancel_prompt:'+str(chat_id),now)
                    prompt=('Открытое обращение #'+str(existing['id'])+' сохранено. Сообщения будут добавляться в него.' if existing else
                            'Создание обращения отменено. Чтобы начать заново, отправьте /tiket.')
                    if english:
                        prompt = (f"Ticket #{existing['id']} stays open. Your next message will be added to it." if existing else 'Request cancelled. Send /ticket to start again.')
                    technical_reply(db,chat_id,name,username,prompt,'compose-cancel:'+str(uid),now)
            elif body.split(' ', 1)[0].split('@')[0] in ('/start', '/help') and now-float(meta(db,'welcome:'+str(chat_id),'0'))<60:
                pass
            elif body.split(' ', 1)[0].split('@')[0] in ('/start', '/help'):
                # A technical welcome is not an issue ticket and is not exposed as a customer complaint.
                put(db, 'welcome:' + str(chat_id), now)
                # System delivery also uses the durable queue. Hidden ticket stores this private chat.
                if not existing:
                    cur = db.execute("INSERT INTO tickets(chat_id,name,username,status,created,updated,unread) VALUES(?,?,?,'intro',?,?,0)", (chat_id,name,username,now,now))
                    ticket_id = cur.lastrowid
                else:
                    ticket_id = existing['id']
                welcome = ('Здравствуйте! Это поддержка PulsarX Cloud.\n\n'
                           'Чтобы создать обращение:\n1. Отправьте /tiket.\n2. Следующим сообщением опишите проблему.\n\n'
                           'Можно приложить скриншот или документ до 10 МБ. После отправки описания появится номер обращения. Ответ придёт сюда.\n\n'
                           'Email: contact@example.invalid\nУсловия: https://pulsarx.example.invalid/terms/?lang=ru\n'
                           'Конфиденциальность: https://pulsarx.example.invalid/privacy/?lang=ru\n\n'
                           'Не присылайте пароли, платёжные ключи и коды входа. Telegram сам по себе не подтверждает владение аккаунтом PulsarX.')
                if english:
                    welcome = ('Welcome to PulsarX Cloud support! Send /ticket, then describe your request in your next message. '
                               'For the free VPS trial, send “Free VPS” after /ticket. You will receive a ticket number and our reply in this chat.\n\n'
                               'You can attach a screenshot or document up to 10 MB. Please keep passwords, payment keys and login codes private.\n'
                               'Email: contact@example.invalid\nTerms: https://pulsarx.example.invalid/terms/?lang=en\nPrivacy: https://pulsarx.example.invalid/privacy/?lang=en\n\nРусский: /ru')
                else:
                    welcome += '\n\nEnglish: /en'
                enqueue(db,ticket_id,welcome,'welcome:'+str(uid),'system',now)
            elif not existing and not awaiting_description:
                if now-float(meta(db,'ticket_hint:'+str(chat_id),'0'))>=30:
                    put(db,'ticket_hint:'+str(chat_id),now)
                    technical_reply(db,chat_id,name,username,('Send /ticket first, then send your request as a separate message. Русский: /ru' if english else 'Чтобы создать новое обращение, сначала отправьте /tiket, а затем отдельным сообщением опишите проблему.'),'ticket-hint:'+str(uid),now)
            elif not body.strip() and not msg.get('document') and not msg.get('photo'):
                if now-float(meta(db,'format_hint:'+str(chat_id),'0'))>=30:
                    put(db,'format_hint:'+str(chat_id),now)
                    technical_reply(db,chat_id,name,username,('Send a text description, screenshot or document up to 10 MB.' if english else 'Пришлите описание проблемы текстом, скриншотом или документом до 10 МБ.'),'format-hint:'+str(uid),now)
            else:
                recent = db.execute("SELECT COUNT(*) FROM messages m JOIN tickets t ON t.id=m.ticket_id WHERE t.chat_id=? AND m.direction='in' AND m.created>?", (chat_id,now-60)).fetchone()[0]
                if recent < 20:
                    doc = msg.get('document') or (msg.get('photo') or [{}])[-1]
                    has_file = isinstance(doc.get('file_id'), str)
                    if not body and not has_file:
                        body = '[Неподдерживаемое сообщение. Попросите клиента прислать текст, фото или документ.]'
                    new = not existing
                    if new:
                        cur=db.execute('INSERT INTO tickets(chat_id,name,username,created,updated) VALUES(?,?,?,?,?)',(chat_id,name,username,now,now))
                        ticket_id=cur.lastrowid
                        put(db,'compose_until:'+str(chat_id),'0')
                    else:
                        ticket_id=existing['id']
                        put(db,'compose_until:'+str(chat_id),'0')
                        db.execute('UPDATE tickets SET name=?,username=?,updated=?,unread=1 WHERE id=?',(name,username,now,ticket_id))
                    cur=db.execute("INSERT INTO messages(ticket_id,direction,body,created,tg_message_id) VALUES(?,'in',?,?,?)",(ticket_id,body,now,msg.get('message_id')))
                    if has_file:
                        size=doc.get('file_size')
                        size=size if isinstance(size,int) and size>=0 else 0
                        filename=Path(str(doc.get('file_name') or 'screenshot.jpg').replace('\\','/')).name[:160] or 'attachment'
                        db.execute('INSERT INTO attachments(message_id,file_id,name,size,status) VALUES(?,?,?,?,?)',(cur.lastrowid,doc['file_id'],filename,size,'pending' if size<=10*1024*1024 else 'too_large'))
                    if new:
                        enqueue(db,ticket_id,('Ticket #'+str(ticket_id)+' received. Support will reply here.' if english else 'Обращение #'+str(ticket_id)+' принято. Ответ поддержки придёт сюда.'),'ack:'+str(uid),'system',now)
                        recipient=meta(db,'notify_chat_id')
                        if recipient.isdecimal() and int(recipient)>0:
                            alert='Новое обращение #'+str(ticket_id)+'\nОт: '+name+(' (@'+username+')' if username else '')+'\n\nОткрыть и ответить:\nhttps://pulsarx.example.invalid/admin/?support_ticket='+str(ticket_id)+'&ui=support-r2'
                            enqueue(db,ticket_id,alert,'notify:'+recipient+':'+str(uid),'notify',now)
        put(db, 'offset', max(int(meta(db, 'offset', '0')), uid + 1))


def listing(status='open', query='', before=None):
    where="status IN ('open','closed')"
    params=[]
    if status in ('open','closed'):
        where+=' AND status=?';params.append(status)
    if query:
        where+=' AND (name LIKE ? ESCAPE \'\\\' OR username LIKE ? ESCAPE \'\\\' OR CAST(id AS TEXT)=?)'
        escaped=query.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
        params.extend(['%'+escaped+'%','%'+escaped+'%',query])
    if before:
        where+=' AND id<?';params.append(before)
    with connect() as db:
        rows=db.execute('SELECT id,name,username,status,created,updated,unread FROM tickets WHERE '+where+' ORDER BY id DESC LIMIT 51',params).fetchall()
        unread=db.execute("SELECT COUNT(*) FROM tickets WHERE status IN ('open','closed') AND unread=1").fetchone()[0]
        alert=db.execute("SELECT delivery,error FROM messages WHERE direction='notify' ORDER BY id DESC LIMIT 1").fetchone()
        return {'tickets':[dict(r) for r in rows[:50]],'next_before':rows[49]['id'] if len(rows)>50 else None,
                'unread':unread,'poll_at':float(meta(db,'poll_at','0')),'worker_error':meta(db,'worker_error'),
                'notifications':{'enabled':bool(meta(db,'notify_chat_id')),'name':meta(db,'notify_name'),'username':meta(db,'notify_username'),
                                 'last_delivery':alert['delivery'] if alert else None,'last_error':alert['error'] if alert else None}}


def thread(ticket_id, before=0):
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket=db.execute("SELECT id,name,username,status,created,updated,unread FROM tickets WHERE id=? AND status IN ('open','closed')",(ticket_id,)).fetchone()
        if not ticket: raise LookupError('Ticket not found')
        rows=db.execute("SELECT id,direction,body,created,delivery,error FROM messages WHERE ticket_id=? AND direction!='notify' AND (?=0 OR id<?) ORDER BY id DESC LIMIT 201",(ticket_id,before,before)).fetchall()
        messages=[]
        for row in reversed(rows[:200]):
            item=dict(row)
            item['attachments']=[dict(r) for r in db.execute('SELECT id,name,size,status FROM attachments WHERE message_id=?',(row['id'],))]
            messages.append(item)
        if not before:
            db.execute('UPDATE tickets SET unread=0 WHERE id=?',(ticket_id,))
        return {'ticket':dict(ticket),'messages':messages,'next_before':rows[199]['id'] if len(rows)>200 else None}


def reply(ticket_id, body, request_id):
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket=db.execute("SELECT status FROM tickets WHERE id=? AND status IN ('open','closed')",(ticket_id,)).fetchone()
        if not ticket: raise LookupError('Ticket not found')
        if ticket['status']!='open':raise ValueError('Reopen the ticket before replying')
        previous=db.execute('SELECT * FROM messages WHERE request_id=?',(request_id,)).fetchone()
        if previous and (previous['ticket_id']!=ticket_id or previous['body']!=body):raise ValueError('Request identifier already used')
        row=enqueue(db,ticket_id,body,request_id)
        db.execute('UPDATE tickets SET updated=? WHERE id=?',(time.time(),ticket_id))
        return dict(row)


def retry_reply(message_id):
    """Explicit admin retry of a definitely rejected reply; never an ambiguous send."""
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute("SELECT m.id,m.ticket_id,m.direction,m.delivery,t.status FROM messages m JOIN tickets t ON t.id=m.ticket_id WHERE m.id=?",(message_id,)).fetchone()
        if not row or row['direction']!='out':raise LookupError('Reply not found')
        if row['status']!='open':raise ValueError('Reopen the ticket before retrying')
        if row['delivery'] in ('queued','sending'):return {'id':row['id'],'delivery':row['delivery']}
        if row['delivery']!='failed':raise ValueError('Only definitely rejected replies can be retried')
        db.execute("UPDATE messages SET delivery='queued',error=NULL,retry_at=0,attempts=0 WHERE id=?",(message_id,))
        return {'id':row['id'],'delivery':'queued'}


def set_status(ticket_id, status):
    import uuid
    if status not in ('open', 'closed'):
        raise ValueError('Invalid ticket status')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        ticket = db.execute(
            "SELECT status,chat_id FROM tickets WHERE id=? AND status IN ('open','closed')",
            (ticket_id,),
        ).fetchone()
        if not ticket:
            raise LookupError('Ticket not found')
        if ticket['status'] == status:
            return
        now = time.time()
        db.execute('UPDATE tickets SET status=?,updated=? WHERE id=?', (status, now, ticket_id))
        if status == 'closed':
            put(db,'compose_until:'+str(ticket['chat_id']),'0')
            body = (
                'Ваше обращение #' + str(ticket_id) + ' закрыто.\n\n'
                'Если нужна помощь, отправьте /tiket, а затем следующим сообщением опишите проблему.'
            )
            if meta(db,'support_lang:'+str(ticket['chat_id'])) == 'en':
                body = f'Ticket #{ticket_id} is closed. If you need help, send /ticket followed by your message.'
            # Closing and queuing the customer notice are one transaction.
            # A repeated close is a no-op; reopening and closing is a new event.
            enqueue(db, ticket_id, body, 'closed:' + str(ticket_id) + ':' + uuid.uuid4().hex, 'system', now)


def attachment(attachment_id):
    with connect() as db:
        row=db.execute("SELECT name,local_name FROM attachments WHERE id=? AND status='ready'",(attachment_id,)).fetchone()
    if not row or not row['local_name']:raise LookupError('Attachment unavailable')
    path=STATE/'files'/row['local_name']
    if path.is_symlink() or path.parent.resolve()!=(STATE/'files').resolve() or not path.is_file():raise LookupError('Attachment unavailable')
    return path,row['name']
