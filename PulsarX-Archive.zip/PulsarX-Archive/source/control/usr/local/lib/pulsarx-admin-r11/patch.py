"""Only the admin entry page and a new read-only report router are installed."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(raw):return hashlib.sha256(raw).hexdigest()


def function_text(source,name):
    nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name]
    if len(nodes)!=1:raise ValueError('Function inventory differs: '+name)
    node=nodes[0]
    return ''.join(source.splitlines(keepends=True)[node.lineno-1:node.end_lineno])


def changes(root,web):
    root,web=Path(root),Path(web)
    manifest=json.loads((HERE/'manifest.json').read_text())
    # Auth remains the installed server-side guard, with no new password store.
    actual=function_text((root/'app/auth.py').read_text(),'get_current_admin')
    if sha(actual.encode())!=manifest['admin_guard_sha256']:
        raise ValueError('Administrator authentication differs; review before applying')
    support=web/manifest['support_source']
    if sha(support.read_bytes())!=manifest['support_source_sha256']:
        raise ValueError('Support controller changed; preserve the newer version before applying')
    output={}
    for relative,payload in manifest['assets'].items():
        path=web/relative;raw=(HERE/'payload'/payload).read_bytes()
        if path.exists():
            if path.read_bytes()!=raw:raise ValueError('Admin asset already exists with different content: '+relative)
        else:output[path]=raw
    path=web/'admin/index.html';raw=(HERE/'payload/admin.html').read_bytes()
    if path.read_bytes()!=raw:
        if sha(path.read_bytes()) not in (manifest['admin_before_sha256'],manifest['admin_upgrade_sha256']):
            raise ValueError('Admin entry page changed since verified Security Fix; no application edits made')
        output[path]=raw
    path=root/'app/admin_desk.py';raw=(HERE/'payload/admin_desk.py').read_bytes()
    if path.exists():
        if path.read_bytes()!=raw:raise ValueError('An existing admin report module needs review')
    else:output[path]=raw
    path=root/'app/main.py';source=path.read_text()
    if '_px_admin_desk_router' not in source:
        if '_px_gift_retention_router' not in source or 'app.include_router(admin.router)' not in source:
            raise ValueError('Verified Gift Renewal/Admin router installation required first')
        source+='\n# PulsarX admin desk r1: additive read-only authenticated reports.\nfrom .admin_desk import router as _px_admin_desk_router\napp.include_router(_px_admin_desk_router)\n'
        ast.parse(source);output[path]=source.encode()
    return output
