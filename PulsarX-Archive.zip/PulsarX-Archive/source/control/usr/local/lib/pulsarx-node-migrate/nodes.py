"""Fixed-scope node RPC. Never accepts arbitrary commands, paths, or instance names."""
import base64
import configparser
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import socket
import stat
import time
from common import *
from firewall import apply_management,apply_scoped,relay_rules

JOURNAL=STATE/'node.json'
TUNNEL='pxwg0'
WG_PORT=51821


def state():
    s=read_json(JOURNAL)
    if not s or s.get('release')!=RELEASE:raise Failure('Node was not enrolled for this release')
    check_host(s['role']);return s


def check_inventory(s,empty=False):
    items=query('/1.0/instances?recursion=1&all-projects=true')
    if empty:
        if items:raise Failure('Destination is no longer empty')
        return items
    if {v['name'] for v in items}!=set(names()):raise Failure('Source instance inventory changed')
    for item in items:
        r=row(item['name'])
        if item.get('project','default')!='default' or item.get('type')!='container':raise Failure('Unsupported project/type')
        if item.get('profiles')!=r['profiles'] or item.get('devices')!=r['devices']:
            raise Failure('Source instance devices/profiles changed: '+r['name'])
        if any(item['config'].get(k)!=v for k,v in r['config'].items()):raise Failure('Source limits/security changed')
        if int(item['config'].get('volatile.idmap.base','0'))!=r['idmap_base']:raise Failure('Source UID mapping changed')
        if item['status'] not in ('Running','Stopped'):raise Failure('Source is transitioning')
        if item['status']=='Running':
            st=query('/1.0/instances/'+r['name']+'/state')
            ips={a.get('address') for dev in (st.get('network') or {}).values() for a in dev.get('addresses',[])}
            if r['ip'] not in ips:raise Failure('Source IP differs from the application record')
    return items


def inspect(s):
    root=query('/1.0')
    if root.get('environment',{}).get('server_clustered') is not False:raise Failure('Standalone Incus required')
    if root['environment']['certificate_fingerprint']!=PLAN['fingerprints'][s['role']]:raise Failure('Server certificate changed')
    ops=query('/1.0/operations?recursion=1')
    groups=ops.values() if isinstance(ops,dict) else [ops]
    if any(v.get('status') in ('Running','Pending') for group in groups if isinstance(group,list) for v in group if isinstance(v,dict)):
        raise Failure('An Incus operation is active; let it complete')
    if s['role']=='old':
        check_inventory(s);busy_backup().close()
        for p,h in PLAN['backup_sources'].items():
            if sha(regular(p))!=h:raise Failure('Backup program changed since audit')
    return {'host':root['environment']['server_name'],'certificate':root['environment']['certificate'],
        'fingerprint':root['environment']['certificate_fingerprint'],
        'instances':query('/1.0/instances?recursion=1&all-projects=true'),
        'pools':query('/1.0/storage-pools?recursion=1'),'role':s['role'],
        'preparing':bool(s.get('preparing')),'prepared':bool(s.get('prepared')),'build':BUILD}


def timer_guard(unit,hold):
    d=Path('/etc/systemd/system')/(unit+'.d');d.mkdir(exist_ok=True,mode=0o755)
    atomic(d/'pulsarx-migrate.conf','[Unit]\nConditionPathExists=!'+str(hold)+'\n',mode=0o644)


def old_pause(s):
    if s.get('paused'):return {'paused':True}
    items=check_inventory(s);lock=busy_backup()
    try:
        timers=['pulsarx-container-backup.timer','pulsarx-capacity-publish.timer']
        s.setdefault('timers',{u:active(u) for u in timers})
        s.setdefault('old_configs',{v['name']:{'autostart':v['config'].get('boot.autostart'),
            'running':v['status']=='Running'} for v in items})
        write_json(JOURNAL,s)
        atomic(OLD_HOLD,'Migration '+s['nonce']+'\n')
        for u in timers:timer_guard(u.removesuffix('.timer')+'.service',OLD_HOLD)
        run(['systemctl','daemon-reload'],'Load backup hold')
        for u in timers:set_unit(u,'stop')
        if prop('pulsarx-container-backup.service','ActiveState') in ('active','activating'):
            raise Failure('A backup started while its timer was being paused')
        maintenance(s['nonce'],'copying')
        # Survives a source reboot; prevents two active copies even after a crash.
        for name in names():local(['config','set',name,'boot.autostart=false'])
        s['paused']=True;write_json(JOURNAL,s)
        return {'paused':True}
    finally:lock.close()


def old_stop(s):
    if not s.get('paused'):raise Failure('Source was not paused')
    for r in PLAN['containers']:
        ct=query('/1.0/instances/'+r['name'])
        if ct['status']=='Running':local(['stop',r['name'],'--timeout','120'],label='Graceful stop '+r['name'],timeout=150)
        if query('/1.0/instances/'+r['name'])['status']!='Stopped':raise Failure('Source stop not confirmed')
    return {'stopped':names()}


def restore_old(s):
    if s.get('detached'):raise Failure('Detached source cannot be automatically resumed')
    for name,old in s.get('old_configs',{}).items():
        if old['autostart'] is None:local(['config','unset',name,'boot.autostart'])
        else:local(['config','set',name,'boot.autostart='+old['autostart']])
        if old['running'] and query('/1.0/instances/'+name)['status']=='Stopped':local(['start',name],timeout=120)
    maintenance(s['nonce'])
    OLD_HOLD.unlink(missing_ok=True)
    for u,was in s.get('timers',{}).items():
        if was:set_unit(u,'start')
    s['paused']=False;write_json(JOURNAL,s)
    return {'restored':True}


def file_digest(s,name):
    r=row(name)
    if query('/1.0/instances/'+name)['status']!='Stopped':raise Failure('Digest requires a stopped instance')
    root=Path('/var/lib/incus/storage-pools')/(name+'-pool')/'containers'/name/'rootfs'
    if not root.is_dir() or root.is_symlink():raise Failure('Expected mounted Btrfs rootfs for verification')
    return root_digest(root)


def root_digest(root):
    root=Path(root)
    digest=hashlib.sha256();count=0;size=0;links={}
    def emit(value):digest.update(json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()+b'\n')
    for folder,dirs,files in os.walk(root,followlinks=False):
        dirs.sort();files.sort()
        for leaf in [*dirs,*files]:
            p=Path(folder)/leaf;rel=str(p.relative_to(root));st=p.lstat();mode=stat.S_IMODE(st.st_mode)
            if stat.S_ISLNK(st.st_mode):emit([rel,'symlink',mode,os.readlink(p)])
            elif stat.S_ISDIR(st.st_mode):emit([rel,'dir',mode])
            elif stat.S_ISREG(st.st_mode):
                key=(st.st_dev,st.st_ino)
                if st.st_nlink>1 and key in links:emit([rel,'hardlink',mode,links[key]])
                else:
                    links[key]=rel;h=hashlib.sha256()
                    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
                    with os.fdopen(fd,'rb') as stream:
                        if os.fstat(stream.fileno()).st_ino!=st.st_ino:raise Failure('File changed during digest')
                        for chunk in iter(lambda:stream.read(4*1024**2),b''):h.update(chunk)
                    emit([rel,'file',mode,st.st_size,h.hexdigest()]);size+=st.st_size
            else:emit([rel,'special',stat.S_IFMT(st.st_mode),mode,st.st_rdev])
            count+=1
    return {'sha256':digest.hexdigest(),'entries':count,'regular_bytes':size}


def backup_bundle(s):
    if s['role']!='old':raise Failure('Only source may export backup configuration')
    cp=configparser.ConfigParser(interpolation=None);cp.read_string(regular('/home/debian/.config/rclone/rclone.conf').decode())
    if not cp.has_section('b2backup') or cp['b2backup'].get('type')!='b2':raise Failure('Backup remote changed')
    # Only the existing B2 backup section travels over encrypted host-to-host SSH.
    selected=configparser.ConfigParser(interpolation=None);selected['b2backup']=dict(cp['b2backup'])
    import io
    text=io.StringIO();selected.write(text)
    out={'rclone':text.getvalue()}
    for name in ('backup_manager.py','backup_containers.sh'):
        p='/opt/pulsarx-backup/'+name;raw=regular(p)
        if sha(raw)!=PLAN['backup_sources'][p]:raise Failure('Source backup program changed')
        out[name]=base64.b64encode(raw).decode()
    return out


def install_backup(s,bundle):
    private_dir('/opt/pulsarx-backup');private_dir('/opt/pulsarx-backup/local')
    private_dir('/root/.config');private_dir('/root/.config/rclone')
    cfg=bundle['rclone']
    if len(cfg)>65536:raise Failure('Backup config exceeds limit')
    cp=configparser.ConfigParser(interpolation=None);cp.read_string(cfg)
    if cp.sections()!=['b2backup'] or cp['b2backup'].get('type')!='b2':raise Failure('Unexpected backup section')
    atomic('/root/.config/rclone/rclone.conf',cfg)
    for name in ('backup_manager.py','backup_containers.sh'):
        raw=base64.b64decode(bundle[name],validate=True)
        if sha(raw)!=PLAN['backup_sources']['/opt/pulsarx-backup/'+name]:raise Failure('Backup source checksum mismatch')
        text=raw.decode().replace('/home/debian/.config/rclone/rclone.conf','/root/.config/rclone/rclone.conf')
        if name.endswith('.py'):
            if text.count("HOST = 'demo-node'")!=1:raise Failure('Backup host guard changed')
            text=text.replace("HOST = 'demo-node'","HOST = 'pulsar2'").replace('VPS2 192.0.2.13','new compute 192.0.2.12')
            compile(text,name,'exec')
        else:run(['/bin/bash','-n'],'Backup syntax',input=text.encode())
        atomic('/opt/pulsarx-backup/'+name,text,mode=0o700)
    unit='[Unit]\nDescription=PulsarX verified container backup\nAfter=incus.service network-online.target\n[Service]\nType=oneshot\nUMask=0077\nExecStart=/opt/pulsarx-backup/backup_containers.sh\nTimeoutStartSec=4h\n'
    atomic('/etc/systemd/system/pulsarx-container-backup.service',unit,mode=0o644)
    atomic('/etc/systemd/system/pulsarx-container-backup.timer','[Unit]\nDescription=PulsarX daily container backup\n[Timer]\nOnCalendar=*-*-* 03:30:00\nPersistent=true\n[Install]\nWantedBy=timers.target\n',mode=0o644)
    return {'installed':True}


def prepare_new(s,args):
    if s['role']!='new':raise Failure('Destination operation on wrong node')
    if s.get('prepared'):return {'prepared':True,'wireguard_public':regular('/etc/wireguard/pxwg0.pub').decode().strip()}
    check_inventory(s,empty=True)
    pools=query('/1.0/storage-pools?recursion=1')
    networks=[v for v in query('/1.0/networks?recursion=1') if v.get('managed')]
    profile_before=query('/1.0/profiles/default')
    if not s.get('preparing'):
        if pools or networks or profile_before['config'] or profile_before['devices']:
            raise Failure('Destination is no longer pristine')
        s['preparing']=True;write_json(JOURNAL,s)
    if any(v.get('name') not in {r['name']+'-pool' for r in PLAN['containers']} or
           v.get('config',{}).get('user.pulsarx.migration')!=s['nonce'] for v in pools):
        raise Failure('Destination pool is not owned by this migration')
    if any(v.get('name')!='incusbr0' or v.get('config',{}).get('user.pulsarx.migration')!=s['nonce'] for v in networks):
        raise Failure('Destination network is not owned by this migration')
    expected_devices={k:dict(v) for k,v in PLAN['profile']['devices'].items()}
    expected_devices['eth0'].update({'security.mac_filtering':'true','security.ipv4_filtering':'true'})
    if profile_before['config'] or profile_before['devices']:
        if profile_before['config']!=PLAN['profile']['config'] or profile_before['devices']!=expected_devices:
            raise Failure('Destination profile was changed outside this migration')
    if os.statvfs('/').f_bavail*os.statvfs('/').f_frsize<120*1024**3:raise Failure('Destination free disk below safe staging threshold')
    run(['apt-get','update'],'Destination package index',timeout=300)
    run(['apt-get','install','-y','wireguard-tools','rclone','btrfs-progs','uidmap','nftables'],
        'Destination dependencies',timeout=600,env={'DEBIAN_FRONTEND':'noninteractive'})
    # Preserve old mapping bases below one million while retaining future allocation range.
    for p in ('/etc/subuid','/etc/subgid'):
        original=Path(p).read_text()
        if not (STATE/(Path(p).name+'.before')).exists():atomic(STATE/(Path(p).name+'.before'),original)
        lines=[v for v in original.splitlines() if not v.startswith('root:')]
        atomic(p,'\n'.join([*lines,'root:200000:1000800000'])+'\n',mode=0o644)
    # Incus must reload subordinate mappings before any customer import.
    set_unit('incus.service','restart')
    private_dir('/var/lib/incus/disks')
    bridge={k:v for k,v in PLAN['network']['config'].items()}
    # The provider issued IPv4 only; do not advertise an IPv6 default route without egress.
    bridge['ipv6.address']='none';bridge.pop('ipv6.nat',None)
    bridge['user.pulsarx.migration']=s['nonce']
    if not networks:local(['network','create','incusbr0',*[k+'='+v for k,v in bridge.items()]],timeout=120)
    profile={'config':dict(PLAN['profile']['config']),'description':'PulsarX compute profile',
             'devices':{k:dict(v) for k,v in PLAN['profile']['devices'].items()}}
    profile['devices']['eth0'].update({'security.mac_filtering':'true','security.ipv4_filtering':'true'})
    local(['profile','edit','default'],input=json.dumps(profile).encode())
    for r in PLAN['containers']:
        if not any(v['name']==r['name']+'-pool' for v in pools):
            local(['storage','create',r['name']+'-pool','btrfs','size='+str(r['disk_gib'])+'GiB',
                   'user.pulsarx.migration='+s['nonce']],timeout=120)
    private_dir('/usr/local/lib/pulsarx-capacity')
    atomic('/usr/local/lib/pulsarx-capacity/publish.py',regular(Path(__file__).parent/'publish.py'),mode=0o700)
    atomic('/etc/systemd/system/pulsarx-capacity-publish.service','[Unit]\nDescription=PulsarX single-filesystem capacity\nAfter=incus.service local-fs.target\n[Service]\nType=oneshot\nExecStart=/usr/bin/python3 /usr/local/lib/pulsarx-capacity/publish.py\nTimeoutStartSec=40\nNoNewPrivileges=true\nPrivateTmp=true\n',mode=0o644)
    atomic('/etc/systemd/system/pulsarx-capacity-publish.timer','[Unit]\nDescription=PulsarX capacity sample\n[Timer]\nOnBootSec=5s\nOnUnitActiveSec=15s\nAccuracySec=1s\n[Install]\nWantedBy=timers.target\n',mode=0o644)
    reserved=run(['sysctl','-n','net.ipv4.ip_local_reserved_ports'],'Read reserved ports').decode().strip()
    ranges=[p for p in reserved.split(',') if p]+['20000-49999']
    atomic('/etc/sysctl.d/91-pulsarx-compute.conf','net.ipv4.ip_forward=1\nnet.ipv4.ip_local_reserved_ports='+','.join(dict.fromkeys(ranges))+'\n',mode=0o644)
    run(['sysctl','-p','/etc/sysctl.d/91-pulsarx-compute.conf'],'Compute network settings')
    private_dir('/etc/wireguard')
    key=regular('/etc/wireguard/pxwg0.key').strip() if Path('/etc/wireguard/pxwg0.key').exists() else run(['wg','genkey'],'Create private node tunnel key').strip()
    pub=run(['wg','pubkey'],'Node tunnel public key',input=key+b'\n').decode().strip()
    atomic('/etc/wireguard/pxwg0.key',key+b'\n');atomic('/etc/wireguard/pxwg0.pub',pub+'\n')
    control_pub=args['wireguard_public']
    if not re.fullmatch(r'[A-Za-z0-9+/]{43}=',control_pub):raise Failure('Invalid tunnel public key')
    cfg='[Interface]\nAddress=198.51.100.2/30\nListenPort=51821\nPrivateKey='+key.decode()+'\n\n[Peer]\nPublicKey='+control_pub+'\nAllowedIPs=198.51.100.1/32\nEndpoint=192.0.2.11:51821\nPersistentKeepalive=25\n'
    atomic('/etc/wireguard/pxwg0.conf',cfg)
    run(['systemctl','daemon-reload'],'Load destination services')
    set_unit('wg-quick@pxwg0.service','enable');set_unit('wg-quick@pxwg0.service','start')
    cert=args['client_certificate']
    if cert_fp(cert)!=PLAN['client_fingerprint']:raise Failure('Unexpected API client certificate')
    certpath=STATE/'api-client.crt';atomic(certpath,cert)
    if not any(v['fingerprint']==PLAN['client_fingerprint'] for v in query('/1.0/certificates?recursion=1')):
        local(['config','trust','add-certificate',str(certpath),'--name','pulsarx-control'])
    maintenance(s['nonce'],'receiving')
    # Source-restricted management API. Existing SSH and customer ports remain available.
    apply_management()
    atomic('/etc/systemd/system/pulsarx-management-filter.service','[Unit]\nDescription=PulsarX management source filter\nAfter=network-online.target nftables.service\nWants=network-online.target\nBefore=incus.service\n[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/usr/bin/python3 /usr/local/lib/pulsarx-node-migrate/entry.py --management-filter\n[Install]\nWantedBy=multi-user.target\n',mode=0o644)
    run(['systemctl','daemon-reload'],'Load management filter');set_unit('pulsarx-management-filter.service','enable')
    local(['config','set','core.https_address','192.0.2.12:8443'])
    run(['/usr/bin/python3','/usr/local/lib/pulsarx-capacity/publish.py'],'Initial capacity sample')
    set_unit('pulsarx-capacity-publish.timer','enable');set_unit('pulsarx-capacity-publish.timer','start')
    s['prepared']=True;write_json(JOURNAL,s)
    return {'prepared':True,'wireguard_public':pub}


def configure_instance(s,name):
    r=row(name);ct=query('/1.0/instances/'+name)
    if ct['config'].get('user.pulsarx.migration')!=s['nonce']:raise Failure('Destination instance is not owned by this migration')
    if ct['status']!='Stopped':raise Failure('Instance configuration requires stopped destination')
    # This is the same VPS relocated, so avoid clone-time image templates replacing guest identity files.
    if ct['config'].get('volatile.apply_template') in ('copy','create'):
        local(['config','unset',name,'volatile.apply_template'])
    local(['config','device','set',name,'eth0','ipv4.address='+r['ip']])
    local(['config','device','set',name,'eth0','security.mac_filtering=true','security.ipv4_filtering=true'])
    local(['config','set',name,'security.idmap.base='+str(r['idmap_base']),'security.idmap.size=65536'])
    return {'configured':name}


def start_instance(s,name):
    r=row(name);ct=query('/1.0/instances/'+name)
    if ct['config'].get('user.pulsarx.migration')!=s['nonce']:raise Failure('Destination ownership mismatch')
    local(['config','set',name,'boot.autostart=true'])
    if ct['status']=='Stopped':local(['start',name],timeout=180)
    wait_for(lambda:query('/1.0/instances/'+name)['status']=='Running','Destination instance start',120)
    # Read actual interfaces through the API; no customer command or login is needed.
    def ready():
        st=query('/1.0/instances/'+name+'/state')
        return r['ip'] in {a.get('address') for v in (st.get('network') or {}).values() for a in v.get('addresses',[])}
    wait_for(ready,'Preserved DHCP address',120)
    current=query('/1.0/instances/'+name)
    config=current.get('expanded_config',current['config'])
    if config.get('limits.cpu')!=str(r['cpu']) or config.get('limits.memory')!=str(r['ram_mb'])+'MB' or config.get('security.privileged')!='false':
        raise Failure('Destination resource/security limits differ')
    maps=json.loads(current['config']['volatile.idmap.current'])
    for flag in ('Isuid','Isgid'):
        if not any(v.get(flag) and v.get('Nsid')==0 and v.get('Hostid')==r['idmap_base'] and v.get('Maprange')==65536 for v in maps):
            raise Failure('Destination UID/GID map differs from the source')
    return {'running':name}


def ports():return sorted({p for r in PLAN['containers'] for p in [r['ssh_port'],r['web_port'],*r['extra_ports']]})


def relay(s,enable):
    if enable:
        if any(v['status']!='Stopped' for v in query('/1.0/instances?recursion=1')):raise Failure('Source containers must remain stopped')
        p=','.join(map(str,ports()))
        apply_scoped('ip','pulsarx_migrate_relay',relay_rules(ports()),'Temporary compatibility relay')
        # UFW's existing FORWARD policy is DROP; use one bounded, tagged chain.
        try:run(['iptables','-nL','PX_MIGRATE'],'Check compatibility chain')
        except Failure:run(['iptables','-N','PX_MIGRATE'],'Create compatibility chain')
        run(['iptables','-F','PX_MIGRATE'],'Reset owned compatibility chain')
        run(['iptables','-A','PX_MIGRATE','-d',PLAN['hosts']['new'],'-p','tcp','-m','multiport','--dports',p,'-j','ACCEPT'],'Relay outgoing permit')
        run(['iptables','-A','PX_MIGRATE','-s',PLAN['hosts']['new'],'-p','tcp','-m','conntrack','--ctstate','ESTABLISHED,RELATED','-j','ACCEPT'],'Relay return permit')
        try:run(['iptables','-C','FORWARD','-j','PX_MIGRATE'],'Check compatibility jump')
        except Failure:run(['iptables','-I','FORWARD','1','-j','PX_MIGRATE'],'Install compatibility jump')
        atomic('/etc/systemd/system/pulsarx-old-port-relay.service','[Unit]\nDescription=PulsarX temporary old-address relay\nAfter=network-online.target ufw.service incus.service\n[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/usr/bin/python3 /usr/local/lib/pulsarx-node-migrate/entry.py --relay\n[Install]\nWantedBy=multi-user.target\n',mode=0o644)
        run(['systemctl','daemon-reload'],'Load compatibility relay');set_unit('pulsarx-old-port-relay.service','enable')
        s['relay']=True
    else:
        if s.get('relay'):
            try:run(['nft','list','table','ip','pulsarx_migrate_relay'],'Check relay exists')
            except Failure:pass
            else:run(['nft','delete','table','ip','pulsarx_migrate_relay'],'Remove compatibility relay')
            try:run(['iptables','-C','FORWARD','-j','PX_MIGRATE'],'Check compatibility jump')
            except Failure:pass
            else:run(['iptables','-D','FORWARD','-j','PX_MIGRATE'],'Remove compatibility jump')
            try:run(['iptables','-nL','PX_MIGRATE'],'Check compatibility chain')
            except Failure:pass
            else:
                run(['iptables','-F','PX_MIGRATE'],'Flush compatibility chain');run(['iptables','-X','PX_MIGRATE'],'Remove compatibility chain')
            set_unit('pulsarx-old-port-relay.service','disable');s['relay']=False
    write_json(JOURNAL,s);return {'relay':enable}


def detach(s):
    if any(v['status']!='Stopped' for v in query('/1.0/instances?recursion=1')):raise Failure('Old instances unexpectedly running')
    for unit in ('pulsarx-container-backup.timer','pulsarx-capacity-publish.timer'):
        set_unit(unit,'stop');set_unit(unit,'disable')
    local(['config','unset','core.https_address'])
    trust=query('/1.0/certificates?recursion=1')
    if any(v['fingerprint']==PLAN['client_fingerprint'] for v in trust):
        local(['config','trust','remove',PLAN['client_fingerprint']])
    # This node's old backbone is no longer part of the production data path.
    if prop('wg-quick@wg0.service','LoadState')=='loaded':
        if 'wg0' in run(['wg','show','interfaces'],'Read source tunnel interfaces').decode().split():
            endpoints=run(['wg','show','wg0','endpoints'],'Check source tunnel peer').decode().splitlines()
            if len(endpoints)!=1 or PLAN['hosts']['control'] not in endpoints[0]:raise Failure('Source tunnel has unrelated peers')
        set_unit('wg-quick@wg0.service','stop');set_unit('wg-quick@wg0.service','disable')
        if 'wg0' in run(['wg','show','interfaces'],'Confirm source tunnel retirement').decode().split():
            run(['ip','link','delete','dev','wg0'],'Retire source tunnel')
    s['detached']=True;write_json(JOURNAL,s)
    return {'detached':True,'offline_copies_retained':True}


def rpc(request):
    s=state()
    if request.get('nonce')!=s['nonce']:raise Failure('Migration identity mismatch')
    op=request.get('op');a=request.get('args') or {}
    old={'pause':old_pause,'stop':old_stop,'restore':restore_old,'backup_bundle':backup_bundle,'detach':detach}
    if op=='inspect':return inspect(s)
    if op=='digest':return file_digest(s,a['name'])
    if op=='disarm':
        import pwd
        user=pwd.getpwnam(s['auth_user']);path=Path(user.pw_dir)/'.ssh/authorized_keys'
        text=regular(path).decode();tag=AUTH_TAG+s['nonce']
        atomic(path,'\n'.join(line for line in text.splitlines() if tag not in line)+'\n',uid=user.pw_uid,gid=user.pw_gid)
        s['disarmed']=True;write_json(JOURNAL,s);return {'disarmed':True}
    if s['role']=='old':
        if op in old:return old[op](s)
        if op=='relay':return relay(s,bool(a['enabled']))
    if s['role']=='new':
        if op=='prepare':return prepare_new(s,a)
        if op=='install_backup':return install_backup(s,a['bundle'])
        if op=='configure':return configure_instance(s,a['name'])
        if op=='start':return start_instance(s,a['name'])
        if op=='ready':
            run(['/usr/bin/python3','/usr/local/lib/pulsarx-capacity/publish.py'],'Refresh capacity')
            maintenance(s['nonce']);return {'ready':True}
        if op=='backup_start':
            set_unit('pulsarx-container-backup.timer','enable');set_unit('pulsarx-container-backup.timer','start')
            run(['systemctl','start','--no-block','pulsarx-container-backup.service'],'Start destination backup');return {'started':True}
        if op=='backup_status':return {'active':prop('pulsarx-container-backup.service','ActiveState'),
            'sub':prop('pulsarx-container-backup.service','SubState'),'result':prop('pulsarx-container-backup.service','Result'),
            'exit':prop('pulsarx-container-backup.service','ExecMainStatus')}
    raise Failure('Operation is not permitted for this node')
