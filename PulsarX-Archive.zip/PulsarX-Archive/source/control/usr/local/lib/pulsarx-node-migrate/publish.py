"""Single-filesystem capacity feed, compatible with the deployed v1 admission checker."""
import json
import os
from pathlib import Path
import stat
import subprocess
import time

DATA=Path('/var/lib/incus/disks')


def sample():
    p=DATA
    if p.is_symlink() or not p.is_dir() or p.stat().st_uid!=0 or p.stat().st_mode&0o022:
        raise RuntimeError('Unsafe Incus image directory')
    if p.stat().st_dev!=Path('/').stat().st_dev:raise RuntimeError('Expected the new single root filesystem')
    images={}
    for f in p.glob('*.img'):
        s=f.lstat()
        if not stat.S_ISREG(s.st_mode) or s.st_uid!=0 or s.st_mode&0o077 or s.st_nlink!=1:
            raise RuntimeError('Unsafe backing image')
        images[f.name]={'size':s.st_size,'allocated':s.st_blocks*512}
    fs=os.statvfs(p)
    return {'version':1,'host':os.uname().nodename,'path':str(p),'sampled_at':int(time.time()),
        'total':fs.f_blocks*fs.f_frsize,'free':fs.f_bavail*fs.f_frsize,'images':images}


def main():
    v=sample()
    subprocess.run(['/usr/bin/incus','--force-local','config','set','user.pulsarx.storage_capacity',
                    json.dumps(v,sort_keys=True)],check=True,stdin=subprocess.DEVNULL,timeout=25)


if __name__=='__main__':main()
