"""Checked atomic replacements of the migration's own two nftables tables."""
import json
from common import Failure, PLAN, STATE, atomic, run

OWN_TABLES={('inet','pulsarx_management'),('ip','pulsarx_migrate_relay')}


def management_rules():
    return '''table inet pulsarx_management {
    chain input {
        type filter hook input priority -20; policy accept;
        tcp dport 8443 ip saddr != 192.0.2.11 drop
        iifname "incusbr0" tcp dport 22 drop
    }
}
'''


def relay_rules(ports):
    if not ports or any(type(p) is not int or not 1<=p<=65535 for p in ports):
        raise Failure('Invalid compatibility relay ports')
    values=', '.join(str(p) for p in sorted(set(ports)))
    return '''table ip pulsarx_migrate_relay {
    chain prerouting {
        type nat hook prerouting priority -101; policy accept;
        ip daddr 192.0.2.13 tcp dport { PORTS } dnat to 192.0.2.12
    }
    chain postrouting {
        type nat hook postrouting priority 99; policy accept;
        ip daddr 192.0.2.12 tcp dport { PORTS } masquerade
    }
}
'''.replace('PORTS',values)


def apply_scoped(family,table,body,label,persist=None):
    if (family,table) not in OWN_TABLES:raise Failure('Firewall table outside migration scope')
    if not body.startswith('table '+family+' '+table+' {\n'):
        raise Failure('Firewall body does not match its owned table')
    listing=json.loads(run(['nft','--json','list','tables'],'Read firewall table inventory'))
    if not isinstance(listing,dict) or not isinstance(listing.get('nftables'),list):
        raise Failure('Unexpected firewall inventory')
    exists=any(r.get('table',{}).get('family')==family and r['table'].get('name')==table
               for r in listing['nftables'] if isinstance(r,dict))
    # One checked transaction; never flush or replace any Incus/UFW/system tables.
    batch=(('delete table '+family+' '+table+'\n') if exists else '')+body
    raw=batch.encode()
    run(['nft','--check','--file','-'],label+' validation',input=raw)
    if persist is not None:atomic(persist,body)
    run(['nft','--file','-'],label,input=raw)


def apply_management():
    apply_scoped('inet','pulsarx_management',management_rules(),'Management source filter',STATE/'management.nft')
