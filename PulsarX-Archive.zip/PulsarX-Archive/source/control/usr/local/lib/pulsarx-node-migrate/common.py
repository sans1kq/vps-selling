"""Private on-host state and bounded process helpers for the PulsarX migration."""
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import ssl
import stat
import subprocess
import tempfile
import time

LIB=Path('/usr/local/lib/pulsarx-node-migrate')
STATE=Path('/var/lib/pulsarx-node-migrate')
PLAN=json.loads((Path(__file__).parent/'plan.json').read_text())
RELEASE=PLAN['release']
# Keep the migration identity stable so existing journals, pins and grants resume in place.
BUILD='NODE-MIGRATE-20261108-r1.2'
# This patch changes control-host SQL only; the fixed r1.1 node RPC remains compatible.
NODE_BUILDS=frozenset({'NODE-MIGRATE-20261108-r1.1',BUILD})
HOLD=STATE/'api.hold'
OLD_HOLD=STATE/'old-detached'
AUTH_TAG='pulsarx-node-migrate:'


class Failure(RuntimeError):pass


def private_dir(path):
    path=Path(path)
    path.mkdir(parents=True,exist_ok=True,mode=0o700)
    st=path.lstat()
    if path.is_symlink() or not stat.S_ISDIR(st.st_mode) or st.st_uid!=0 or st.st_mode&0o022:
        raise Failure('Unsafe private directory: '+str(path))
    path.chmod(0o700)
    return path


def atomic(path,data,mode=0o600,uid=0,gid=0):
    path=Path(path)
    if path.is_symlink():raise Failure('Symlink write target rejected')
    raw=data.encode() if isinstance(data,str) else data
    fd,tmp=tempfile.mkstemp(prefix='.px-migrate-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as out:
            os.fchmod(out.fileno(),mode);os.fchown(out.fileno(),uid,gid)
            out.write(raw);out.flush();os.fsync(out.fileno())
        os.replace(tmp,path)
        d=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(d)
        finally:os.close(d)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def write_json(path,value):atomic(path,json.dumps(value,sort_keys=True,indent=2)+'\n')


def read_json(path,default=None):
    p=Path(path)
    if not p.exists():return default
    if p.is_symlink() or p.stat().st_size>4*1024**2:raise Failure('Invalid state file')
    return json.loads(p.read_text())


def sha(data):return hashlib.sha256(data).hexdigest()


def run(args,label,timeout=60,input=None,env=None):
    safe_env={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root','LC_ALL':'C'}
    if env:safe_env.update(env)
    try:
        r=subprocess.run([str(a) for a in args],input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            timeout=timeout,env=safe_env,cwd='/',stdin=None if input is not None else subprocess.DEVNULL)
    except subprocess.TimeoutExpired:raise Failure(label+' timed out; inspect status before retrying') from None
    except OSError:raise Failure(label+' is unavailable') from None
    if r.returncode:
        detail=''
        if STATE.is_dir() and not STATE.is_symlink():
            fd,path=tempfile.mkstemp(prefix='private-error-',suffix='.log',dir=STATE)
            with os.fdopen(fd,'wb') as out:
                os.fchmod(out.fileno(),0o600)
                out.write((label+'\n').encode()+r.stderr[-65536:])
            detail='; private diagnostic: '+path
        raise Failure(label+' failed (exit '+str(r.returncode)+'); values hidden'+detail)
    return r.stdout


def local(args,label='Local Incus',timeout=60,input=None):
    return run(['/usr/bin/incus','--force-local',*args],label,timeout,input)


def query(path):
    raw=local(['query',path])
    if not raw.strip():
        if any(x in path for x in ('recursion=','/operations')):return []
        raise Failure('Empty Incus response: '+path.split('?')[0])
    v=json.loads(raw);return v.get('metadata',v) if isinstance(v,dict) else v


def prop(unit,key):
    try:
        r=subprocess.run(['systemctl','show',unit,'-p',key,'--value'],capture_output=True,
                         timeout=15,stdin=subprocess.DEVNULL)
    except (OSError,subprocess.TimeoutExpired):raise Failure('Service property is unavailable') from None
    value=r.stdout.decode().strip()
    if r.returncode and not value:
        return {'ActiveState':'inactive','SubState':'dead','LoadState':'not-found'}.get(key,'')
    return value


def active(unit):return prop(unit,'ActiveState')=='active'


def set_unit(unit,verb):run(['systemctl',verb,unit],verb+' '+unit,timeout=160)


def regular(path,limit=3*1024**2):
    p=Path(path);st=p.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_size>limit:raise Failure('Expected regular bounded file: '+str(p))
    return p.read_bytes()


def check_host(role):
    if os.geteuid()!=0:raise Failure('Run as root/sudo')
    v=json.loads(run(['ip','-json','address','show'],'Host identity',10))
    ips={a.get('local') for link in v for a in link.get('addr_info',[])}
    if PLAN['hosts'][role] not in ips:raise Failure('Wrong host for '+role+' role')


def cert_fp(pem):
    return sha(ssl.PEM_cert_to_DER_cert(pem))


def parse_pubkey(value):
    parts=value.strip().split()
    if len(parts)<2 or parts[0]!='ssh-ed25519' or not re.fullmatch(r'[A-Za-z0-9+/=]+',parts[1]):
        raise Failure('Expected an Ed25519 public key')
    raw=base64.b64decode(parts[1],validate=True)
    if len(raw)!=51:raise Failure('Invalid public key length')
    return 'ssh-ed25519 '+parts[1]


def names():return [v['name'] for v in PLAN['containers']]


def row(name):
    for r in PLAN['containers']:
        if r['name']==name:return r
    raise Failure('Instance outside migration scope')


def compact_inventory(items):
    return [{k:v.get(k) for k in ('name','status','profiles','devices','config')} for v in items]


def busy_backup():
    state=prop('pulsarx-container-backup.service','ActiveState')
    sub=prop('pulsarx-container-backup.service','SubState')
    if state in ('active','activating','deactivating','reloading') and sub!='exited':
        raise Failure('An active container backup must finish before migration')
    lock=open('/run/lock/pulsarx-container-backup.lock','a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:lock.close();raise Failure('A backup/rotation lock is held') from None
    return lock


def marker(nonce,phase):return json.dumps({'release':RELEASE,'nonce':nonce,'phase':phase},sort_keys=True)


def maintenance(nonce,phase=None):
    key='user.pulsarx.storage_maintenance';current=query('/1.0').get('config',{}).get(key)
    if current:
        try:owner=json.loads(current).get('nonce')
        except (ValueError,AttributeError):owner=None
        if owner!=nonce:raise Failure('Another storage maintenance is active')
    if phase:local(['config','set',key,marker(nonce,phase)])
    elif current:local(['config','unset',key])


def wait_for(predicate,label,seconds=90):
    deadline=time.monotonic()+seconds
    while True:
        if predicate():return
        if time.monotonic()>=deadline:raise Failure(label+' did not become ready')
        time.sleep(2)
