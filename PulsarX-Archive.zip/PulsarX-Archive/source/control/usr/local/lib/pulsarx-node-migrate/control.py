"""Control-host cutover with persistent checkpoints and a no-data-loss rollback boundary."""
import base64
import json
import os
from pathlib import Path
import pwd
import shutil
import socket
import time
import urllib.error
import urllib.request
from common import *

JOURNAL=STATE/'control.json'
CLIENT=STATE/'incus'
API_CONF=Path('/home/pulsarx/.config/incus')
API_USER='pulsarx'
ROUTE_DROPIN=Path('/etc/systemd/system/wg-quick@pxwg0.service.d')
APP_TIMERS=['pulsarx-wallet.timer','pulsarx-payments.timer','pulsarx-billing-check.timer',
            'pulsarx-error-alert.timer','pulsarx-host-alert.timer']


def state():
    check_host('control');s=read_json(JOURNAL)
    if not s or s.get('release')!=RELEASE:raise Failure('Bootstrap control first')
    return s


def save(s,phase=None,message=None):
    if phase:s['phase']=phase
    if message:s['message']=message
    s['build']=BUILD;s['updated_at']=int(time.time());write_json(JOURNAL,s)
    if message:print(message,flush=True)


def rpc(s,role,op,args=None,timeout=180):
    if role not in s.get('nodes',{}):raise Failure('Missing enrollment for '+role)
    login=('debian@' if role=='old' else 'root@')+PLAN['hosts'][role]
    cmd=['ssh','-i',str(STATE/'id_ed25519'),'-o','IdentitiesOnly=yes','-o','BatchMode=yes',
        '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(STATE/'known_hosts'),
        '-o','ConnectTimeout=10','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=8',login,'pulsarx-rpc']
    raw=run(cmd,role+' '+op,timeout=timeout,input=json.dumps({'nonce':s['nonce'],'op':op,'args':args or {}}).encode())
    if len(raw)>4*1024**2:raise Failure('RPC response exceeds limit')
    try:v=json.loads(raw)
    except ValueError:raise Failure('Invalid node response; values hidden') from None
    if not v.get('ok'):raise Failure(role+' '+op+': '+str(v.get('error','operation failed')))
    return v['result']


def cli(args,label='Migration Incus',timeout=60):
    return run(['/usr/bin/incus',*args],label,timeout,env={'INCUS_CONF':str(CLIENT)})


def api_cli(args,label='Application Incus',timeout=40):
    return run(['runuser','-u',API_USER,'-g',API_USER,'--','/usr/bin/incus',*args],label,timeout,
        env={'HOME':'/home/pulsarx','INCUS_CONF':str(API_CONF),'INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})


def remote_query(remote,path):
    raw=cli(['query',remote+':'+path])
    if not raw.strip():return []
    v=json.loads(raw);return v.get('metadata',v) if isinstance(v,dict) else v


def pg(select,label='Read-only database check'):
    sql="BEGIN READ ONLY; SET LOCAL statement_timeout='15s'; SET LOCAL lock_timeout='3s'; SET LOCAL search_path=pg_catalog; "+select+'; ROLLBACK;'
    raw=run(['runuser','-u','postgres','--','/usr/bin/psql','-X','-q','-A','-t','-v','ON_ERROR_STOP=1',
        '--dbname=pulsarx','-c',sql],label,timeout=25)
    return json.loads(raw)


def db_inventory():
    cols=list(PLAN['db_inventory'][0])
    return pg("SELECT COALESCE(json_agg(row_to_json(s)),'[]'::json) FROM (SELECT "+
        ','.join('"'+c+'"' for c in cols)+' FROM public.servers ORDER BY container_name) s',label='Database server inventory')


def active_orders():
    return pg("SELECT count(*) FROM public.wallet_orders WHERE status IN ('queued','working','review')",
              label='Database active order count')


def finance_digest():
    tables=('servers','payments','wallet_accounts','wallet_entries','wallet_orders','wallet_topups')
    parts=[]
    for table in tables:
        parts+= ["'"+table+"'", "(SELECT md5(COALESCE(string_agg(h,'' ORDER BY h),'')) FROM "
            '(SELECT md5(row_to_json(t)::text) AS h FROM public.'+table+' AS t) v)']
    return pg('SELECT json_build_object('+','.join(parts)+')',label='Database financial fingerprint')


def database_preflight():
    if db_inventory()!=PLAN['db_inventory']:raise Failure('Server inventory changed after the audit')
    if active_orders():raise Failure('Active wallet operations must complete first')
    # Exercise the exact aggregate before any API pause. The actual baseline is taken afresh after pausing.
    finance_digest()


def health():
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for path,expected in (('/api/health',200),('/api/auth/me',401)):
        req=urllib.request.Request('http://127.0.0.1:8000'+path,headers={
            'Authorization':'Bearer invalid-pulsarx-migration-health-session','Cache-Control':'no-cache'})
        try:
            with opener.open(req,timeout=5) as r:
                code=r.status;raw=r.read(16384)
        except urllib.error.HTTPError as e:code=e.code;raw=b''
        except (urllib.error.URLError,OSError):return False
        if code!=expected:return False
        if expected==200:
            try:
                if json.loads(raw).get('status')!='ok':return False
            except ValueError:return False
    return True


def preflight(s,initial=True):
    for path,expected in PLAN['control_sources'].items():
        if sha(regular(path))!=expected:raise Failure('Backend source changed since audit: '+path)
    if prop('pulsarx-api.service','User')!=API_USER or prop('pulsarx-api.service','WorkingDirectory')!='/opt/pulsarx-backend':
        raise Failure('Application service identity changed')
    for exe in ('incus','ssh','ssh-keygen','psql','pg_dump','wg','wg-quick','ufw'):
        if not shutil.which(exe):raise Failure('Required control command missing: '+exe)
    if cert_fp(regular(API_CONF/'client.crt').decode())!=PLAN['client_fingerprint']:raise Failure('API TLS client changed')
    if not all(role in s.get('nodes',{}) for role in ('old','new')):raise Failure('Enroll both nodes first')
    if initial:
        if not health():raise Failure('API health/private authentication check failed')
        database_preflight()
        for u in [v.removesuffix('.timer')+'.service' for v in APP_TIMERS]+['pulsarx-backup.service']:
            if prop(u,'ActiveState') in ('active','activating','deactivating') and prop(u,'SubState')!='exited':
                raise Failure('Wait for the running application job: '+u)
        old=rpc(s,'old','inspect')
        if old.get('build') not in NODE_BUILDS:raise Failure('Update both node scripts with the normal Migrate stage before continuing')
        if {v['name'] for v in old['instances']}!=set(names()):raise Failure('Source instance list changed')
        if any(v['status']!='Running' for v in old['instances']):raise Failure('Expected both audited instances running')
        new=rpc(s,'new','inspect')
        if new.get('build') not in NODE_BUILDS:raise Failure('Destination still runs the old script; rerun the normal Migrate stage')
        if not s.get('destination_prepared'):
            if new['instances'] or (new['pools'] and not new.get('preparing')):raise Failure('Destination is not empty')
        endpoints=run(['wg','show','wg0','endpoints'],'Check old private tunnel').decode().splitlines()
        if len(endpoints)!=1 or PLAN['hosts']['old'] not in endpoints[0]:raise Failure('Old tunnel peers differ from the expected node')
        root=json.loads(api_cli(['query','/1.0']))
        root=root.get('metadata',root)
        if root['environment']['certificate_fingerprint']!=PLAN['fingerprints']['old']:raise Failure('Application is not connected to the audited source')
        if root.get('config',{}).get('user.pulsarx.storage_maintenance'):raise Failure('Another maintenance is active')
    return True


def tunnel_prepare(s):
    keypath=Path('/etc/wireguard/pxwg0.key')
    if not s.get('tunnel_owned'):
        if keypath.exists() or Path('/etc/wireguard/pxwg0.conf').exists():raise Failure('pxwg0 already exists outside this migration')
        s['tunnel_owned']=True;save(s)
    private_dir('/etc/wireguard')
    key=regular(keypath).strip() if keypath.exists() else run(['wg','genkey'],'Create private control tunnel key').strip()
    atomic(keypath,key+b'\n')
    return run(['wg','pubkey'],'Control tunnel public key',input=key+b'\n').decode().strip()


def tunnel_configure(s,new_pub):
    if not re.fullmatch(r'[A-Za-z0-9+/]{43}=',new_pub):raise Failure('Invalid peer public key')
    key=regular('/etc/wireguard/pxwg0.key').decode().strip()
    text='[Interface]\nAddress=198.51.100.1/30\nListenPort=51821\nPrivateKey='+key+'\nTable=off\n\n[Peer]\nPublicKey='+new_pub+'\nAllowedIPs=198.51.100.2/32,203.0.113.0/24\nEndpoint=192.0.2.12:51821\nPersistentKeepalive=25\n'
    atomic('/etc/wireguard/pxwg0.conf',text)
    run(['ufw','allow','proto','udp','from',PLAN['hosts']['new'],'to','any','port','51821','comment','pulsarx-new-node'],'Permit new private tunnel')
    set_unit('wg-quick@pxwg0.service','enable')
    if not active('wg-quick@pxwg0.service'):set_unit('wg-quick@pxwg0.service','start')
    def handshake():
        values=run(['wg','show','pxwg0','latest-handshakes'],'Check encrypted tunnel').decode().split()
        return len(values)==2 and values[0]==new_pub and int(values[1])>int(time.time())-100
    wait_for(handshake,'New private tunnel handshake',90)


def isolated_client(s,new_cert):
    if cert_fp(new_cert)!=PLAN['fingerprints']['new']:raise Failure('Destination certificate pin failed')
    if not CLIENT.exists():
        private_dir(CLIENT)
        for rel in ('config.yml','client.crt','client.key','servercerts/vps2.crt'):
            dest=CLIENT/rel;dest.parent.mkdir(exist_ok=True,mode=0o700)
            atomic(dest,regular(API_CONF/rel))
    certdir=CLIENT/'servercerts';certdir.mkdir(exist_ok=True,mode=0o700)
    atomic(certdir/'pxnew.crt',new_cert)
    remotes=json.loads(cli(['remote','list','--format','json']))
    if 'pxnew' not in remotes:
        # Seed the independently verified certificate before CLI remote enrollment.
        cli(['remote','add','pxnew','https://192.0.2.12:8443','--auth-type','tls'],'Enroll pinned destination',timeout=60)
    new=remote_query('pxnew','/1.0')
    if new['environment']['certificate_fingerprint']!=PLAN['fingerprints']['new']:raise Failure('Destination TLS identity mismatch')


def pause(s):
    if not s.get('app_paused'):
        s.setdefault('timers',{u:active(u) for u in APP_TIMERS})
        s.setdefault('api_was_active',active('pulsarx-api.service'))
        # A prior source rollback resumed the OLD API. It does not mean the NEW API is already resumed.
        s['api_resumed']=False;s['app_pause_started']=True;save(s)
        atomic(HOLD,s['nonce']+'\n')
        for unit in ['pulsarx-api.service',*[u.removesuffix('.timer')+'.service' for u in APP_TIMERS]]:
            d=Path('/etc/systemd/system')/(unit+'.d');d.mkdir(exist_ok=True,mode=0o755)
            atomic(d/'pulsarx-migrate.conf','[Unit]\nConditionPathExists=!'+str(HOLD)+'\n',mode=0o644)
        run(['systemctl','daemon-reload'],'Load persistent API maintenance hold')
        for u in APP_TIMERS:set_unit(u,'stop')
        # Never kill an in-flight operation: its service must already be inactive.
        for u in [v.removesuffix('.timer')+'.service' for v in APP_TIMERS]:
            if prop(u,'ActiveState') in ('active','activating','deactivating') and prop(u,'SubState')!='exited':
                raise Failure('An application job started during pause; retry after it finishes')
        set_unit('pulsarx-api.service','stop')
        if prop('pulsarx-api.service','ActiveState')!='inactive':raise Failure('API stop not confirmed')
        if db_inventory()!=PLAN['db_inventory'] or active_orders():
            raise Failure('Services changed while pause was being acquired')
        s['finance_before']=finance_digest();save(s)
        dump=run(['runuser','-u','postgres','--','pg_dump','--format=custom','--dbname=pulsarx'],'Private pre-cutover DB backup',timeout=120)
        if not dump.startswith(b'PGDMP'):raise Failure('Database backup header verification failed')
        private_dir(STATE/'backup');atomic(STATE/'backup/database-before.dump',dump)
        for rel in ('config.yml','servercerts/vps2.crt'):
            p=STATE/'backup'/rel;p.parent.mkdir(exist_ok=True,mode=0o700);atomic(p,regular(API_CONF/rel))
        s['app_paused']=True;save(s)
    rpc(s,'old','pause')


def route_new(s):
    # Replace old per-instance routes, which otherwise override the subnet route.
    routes=json.loads(run(['ip','-json','route','show'],'Read existing routes'))
    if 'routes_before' not in s:
        s['routes_before']=[r for r in routes if str(r.get('dst','')).startswith('203.0.113.')];save(s)
    for r in routes:
        dst=str(r.get('dst',''))
        if dst.startswith('203.0.113.') and dst!='203.0.113.0/24' and r.get('dev')=='wg0':
            run(['ip','route','del',dst,'dev','wg0'],'Retire old per-instance route')
    run(['ip','route','replace','203.0.113.0/24','dev','pxwg0','src','198.51.100.1'],'Route application traffic to new node')
    # Persist the route after the encrypted link is ready on reboot.
    d=ROUTE_DROPIN;d.mkdir(exist_ok=True,mode=0o755)
    atomic(d/'pulsarx-route.conf','[Unit]\nAfter=incus.service\n[Service]\nExecStartPost=/usr/sbin/ip route replace 203.0.113.0/24 dev pxwg0 src 198.51.100.1\n',mode=0o644)
    run(['systemctl','daemon-reload'],'Persist application route')


def switch_client(s,new_cert):
    user=pwd.getpwnam(API_USER)
    atomic(API_CONF/'servercerts/vps2.crt',new_cert,uid=user.pw_uid,gid=user.pw_gid)
    helptext=api_cli(['remote','--help']).decode()
    command='set-url' if re.search(r'\bset-url\s',helptext) else 'set-urls' if 'set-urls' in helptext else None
    if command is None:raise Failure('CLI remote URL command is unavailable')
    api_cli(['remote',command,'vps2','https://192.0.2.12:8443'],'Switch production Incus remote')
    root=json.loads(api_cli(['query','/1.0']));root=root.get('metadata',root)
    if root['environment']['certificate_fingerprint']!=PLAN['fingerprints']['new']:raise Failure('Application destination verification failed')
    d=Path('/etc/systemd/system/pulsarx-api.service.d');d.mkdir(exist_ok=True,mode=0o755)
    atomic(d/'new-compute.conf','[Unit]\nAfter=wg-quick@pxwg0.service\nWants=wg-quick@pxwg0.service\n',mode=0o644)
    route_new(s);s['client_switched']=True;save(s)


def capacity():
    code="""import os,sys,json
os.chdir('/opt/pulsarx-backend');sys.path.insert(0,os.getcwd())
from dotenv import load_dotenv
load_dotenv('/opt/pulsarx-backend/.env')
from app.database import SessionLocal
from app.capacity_service import report
from sqlalchemy import text
db=SessionLocal()
try:
 db.execute(text('SET TRANSACTION READ ONLY'))
 print(json.dumps(report(db)))
finally: db.rollback();db.close()
"""
    raw=run(['runuser','-u',API_USER,'-g',API_USER,'--','/opt/pulsarx-backend/venv/bin/python3','-c',code],
        'Existing read-only capacity calculation',timeout=45,env={'HOME':'/home/pulsarx','INCUS_CONF':str(API_CONF),
        'INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})
    return json.loads(raw)


def verify_ssh(host,port):
    try:
        with socket.create_connection((host,port),timeout=6) as sock:
            sock.settimeout(6);return sock.recv(256).startswith(b'SSH-2.0-')
    except OSError:return False


def resume_api(s):
    HOLD.unlink(missing_ok=True)
    if s.get('api_was_active'):set_unit('pulsarx-api.service','start')
    wait_for(health,'API health and private authentication',60)
    for u,was in s.get('timers',{}).items():
        if was:set_unit(u,'start')
    s['api_resumed']=True;save(s)


def rollback_uncommitted(s):
    if s.get('target_may_write'):raise Failure('Automatic source rollback blocked after destination may have written data')
    rpc(s,'old','restore')
    if s.get('app_pause_started'):resume_api(s)
    s['app_paused']=False;s['app_pause_started']=False;s['copy_complete']=[];s['verified']=[]
    s['rolled_back']=True;save(s,'rolled_back','Source restored. Destination copies remain stopped; retry refreshes them.')


def worker():
    s=state()
    try:
        if s.get('phase') in ('finished','awaiting_dns'):
            print(s.get('message','Already completed.'),flush=True);return
        if not s.get('app_paused') and not s.get('target_may_write'):
            preflight(s)
        if not s.get('destination_prepared'):
            save(s,'preparing','Preparing the empty destination; existing VPS continue running.')
            pub=tunnel_prepare(s)
            result=rpc(s,'new','prepare',{'wireguard_public':pub,'client_certificate':regular(API_CONF/'client.crt').decode()},timeout=1500)
            tunnel_configure(s,result['wireguard_public'])
            new=rpc(s,'new','inspect');isolated_client(s,new['certificate'])
            bundle=rpc(s,'old','backup_bundle')
            rpc(s,'new','install_backup',{'bundle':bundle})
            s['destination_prepared']=True;save(s)
        if not s.get('target_may_write'):
            # Fresh check after package installation and staging, before customer downtime.
            if not s.get('app_paused'):preflight(s)
            save(s,'pausing','Pausing API writes and the two source VPS for a consistent copy.')
            pause(s);rpc(s,'old','stop')
            save(s,'copying','Copying over pinned Incus TLS through the control host.')
            for r in PLAN['containers']:
                name=r['name']
                if name in s.get('verified',[]):continue
                before=rpc(s,'old','digest',{'name':name},timeout=1800)
                existing=remote_query('pxnew','/1.0/instances?recursion=1')
                target=next((v for v in existing if v['name']==name),None)
                if target and (target['status']!='Stopped' or target['config'].get('user.pulsarx.migration')!=s['nonce']):
                    raise Failure('Destination ownership/state conflict')
                args=['copy','vps2:'+name,'pxnew:'+name,'--mode=relay','--storage',name+'-pool',
                    '--config','boot.autostart=false','--config','user.pulsarx.migration='+s['nonce']]
                if target:args+=['--refresh']
                cli(args,'Copy '+name,timeout=5400)
                rpc(s,'new','configure',{'name':name})
                after=rpc(s,'new','digest',{'name':name},timeout=1800)
                if before!=after:raise Failure('Offline file content/mode/hardlink verification failed: '+name)
                s.setdefault('digests',{})[name]=after;s.setdefault('verified',[]).append(name)
                save(s,message='Verified filesystem: '+name+' ('+str(after['entries'])+' entries).')
            # Persist before issuing a start. A crash after this point must never revive stale originals.
            s['target_may_write']=True;save(s,'starting','Both filesystems verified. Starting destination instances; source remains offline.')
        source=rpc(s,'old','inspect')
        if any(v['status']!='Stopped' for v in source['instances']):raise Failure('An original instance is running; destination start blocked')
        for r in PLAN['containers']:
            if s.get('api_resumed') and r['name'] in s.get('started',[]):continue
            rpc(s,'new','start',{'name':r['name']})
            wait_for(lambda r=r:verify_ssh(PLAN['hosts']['new'],r['ssh_port']),'Public SSH banner '+r['name'],90)
            if r['name'] not in s.setdefault('started',[]):s['started'].append(r['name']);save(s)
        if not s.get('client_switched'):
            save(s,'switching','Switching backend remote and private application routes.')
            new=rpc(s,'new','inspect');switch_client(s,new['certificate'])
        rpc(s,'new','ready')
        usage=capacity()
        if usage.get('maintenance') or usage.get('host')=='demo-node':raise Failure('Capacity is not ready on destination')
        if not s.get('api_resumed'):
            for r in PLAN['containers']:
                if not verify_ssh(r['ip'],22):raise Failure('Private application path failed for '+r['name'])
            if finance_digest()!=s['finance_before']:raise Failure('Financial/server rows changed while application was paused')
            s['capacity_available_gib']=round(usage['available_for_new_bytes']/1024**3,2);save(s)
            resume_api(s)
        rpc(s,'old','relay',{'enabled':True})
        for r in PLAN['containers']:
            if not verify_ssh(PLAN['hosts']['old'],r['ssh_port']):raise Failure('Old-address compatibility path failed')
        if not s.get('source_detached'):
            rpc(s,'old','detach')
            # Retire the old dedicated control-side tunnel only if its sole peer is the old node.
            if not s.get('old_peer_verified'):
                endpoints=run(['wg','show','wg0','endpoints'],'Inspect old tunnel').decode().splitlines()
                if len(endpoints)!=1 or PLAN['hosts']['old'] not in endpoints[0]:raise Failure('Old tunnel has unexpected peers; not detached')
                s['old_peer_verified']=True;save(s)
            set_unit('wg-quick@wg0.service','stop');set_unit('wg-quick@wg0.service','disable')
            if 'wg0' in run(['wg','show','interfaces'],'Confirm old tunnel retirement').decode().split():
                run(['ip','link','delete','dev','wg0'],'Retire manually created old tunnel')
            route_new(s)
            live=rpc(s,'new','inspect')
            for r in PLAN['containers']:
                ct=next(v for v in live['instances'] if v['name']==r['name'])
                if ct['status']=='Running' and not verify_ssh(r['ip'],22):raise Failure('New private route failed after old tunnel retirement')
            s['source_detached']=True;save(s)
        if not s.get('backup_verified'):
            save(s,'backup','Production is on the new node. Verifying its ordinary backup job.')
            rpc(s,'new','backup_start');deadline=time.monotonic()+7200
            while True:
                b=rpc(s,'new','backup_status')
                if b['active'] not in ('active','activating','deactivating'):
                    if b['result']!='success' or b['exit']!='0':raise Failure('Destination backup failed; production stays on new node, offline originals retained')
                    break
                if time.monotonic()>deadline:raise Failure('Backup is still running; check status before retry')
                time.sleep(10)
            s['backup_verified']=True;save(s)
        save(s,'awaiting_dns','MIGRATED: two VPS and backend are on 192.0.2.12; verified backup complete. Change direct.pulsarx.example.invalid A to 192.0.2.12 (DNS only), then run --finish.')
    except Exception as exc:
        reason=str(exc) if isinstance(exc,Failure) else type(exc).__name__
        s['error']=reason;save(s,'failed','STOPPED: '+reason)
        if not s.get('target_may_write') and s.get('app_pause_started'):
            try:rollback_uncommitted(s)
            except Exception:save(s,'recovery_required','Automatic recovery could not finish. Run --continue; do not start source instances manually.')
        raise Failure('Migration stopped; run --status for the saved checkpoint') from None


def dns_new():
    try:
        ips={v[4][0] for v in socket.getaddrinfo('direct.pulsarx.example.invalid',None,socket.AF_UNSPEC,socket.SOCK_STREAM)}
    except OSError:return False
    return ips=={PLAN['hosts']['new']}


def finish():
    s=state()
    if s.get('phase')=='finished':print('Already finalized. Old node detached.',flush=True);return
    if not s.get('source_detached') or not s.get('backup_verified') or not s.get('api_resumed'):
        raise Failure('Complete --continue before finalizing')
    if not dns_new():raise Failure('direct.pulsarx.example.invalid still resolves elsewhere. Set A=192.0.2.12, remove obsolete AAAA, use DNS-only mode, then retry --finish')
    if not health():raise Failure('Application is not healthy')
    live=rpc(s,'new','inspect')
    for r in PLAN['containers']:
        ct=next(v for v in live['instances'] if v['name']==r['name'])
        if ct['status']=='Running' and not verify_ssh('direct.pulsarx.example.invalid',r['ssh_port']):raise Failure('New DNS SSH path failed')
    if not s.get('relay_removed'):
        rpc(s,'old','relay',{'enabled':False});s['relay_removed']=True;save(s)
    for role in ('old','new'):
        if not s.get('disarmed_'+role):
            rpc(s,role,'disarm');s['disarmed_'+role]=True;save(s)
    (STATE/'id_ed25519').unlink(missing_ok=True)
    if CLIENT.is_dir() and not CLIENT.is_symlink():shutil.rmtree(CLIENT)
    for unit in ['pulsarx-api.service',*[u.removesuffix('.timer')+'.service' for u in APP_TIMERS]]:
        (Path('/etc/systemd/system')/(unit+'.d')/'pulsarx-migrate.conf').unlink(missing_ok=True)
    run(['systemctl','daemon-reload'],'Remove temporary application holds')
    save(s,'finished','FINISHED: old node detached; DNS, backend, private routes, VPS and backups use the new node. Offline originals retained.')


def status():
    s=state()
    public={k:s.get(k) for k in ('release','phase','message','error','updated_at','verified','target_may_write',
        'api_resumed','source_detached','backup_verified','capacity_available_gib')}
    public['build']=BUILD
    print(json.dumps(public,ensure_ascii=False,indent=2),flush=True)
