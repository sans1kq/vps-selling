import argparse,ast,fcntl,hashlib,json,os,pwd,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
class Stop(RuntimeError): pass
ROOT=Path("/opt/pulsarx-backend"); WEB=Path("/var/www/html"); STATE=Path("/var/lib/pulsarx-admin")

def sha(raw):return hashlib.sha256(raw).hexdigest()


def atomic(path,raw,mode=0o600,uid=0,gid=0):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():raise Stop('Symlink target rejected: '+str(p))
 raw=raw.encode() if isinstance(raw,str) else raw;fd,tmp=tempfile.mkstemp(prefix='.launch-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),mode);os.fchown(f.fileno(),uid,gid);f.write(raw);f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)


def read(path):
 p=Path(path);s=p.lstat()
 if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
 return p.read_bytes()


def run(args,label,timeout=60,data=None,env=None):
 e={**os.environ,'LC_ALL':'C','HOME':'/root'};e.update(env or {})
 try:p=subprocess.run(list(map(str,args)),input=data,capture_output=True,timeout=timeout,env=e,cwd='/')
 except subprocess.TimeoutExpired:raise Stop(label+' timed out') from None
 if p.returncode:
  STATE.mkdir(mode=0o700,exist_ok=True);fd,name=tempfile.mkstemp(prefix='private-error-',suffix='.log',dir=STATE)
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),0o600);f.write(p.stdout[-64000:]+p.stderr[-64000:])
  raise Stop(label+' failed; private diagnostic: '+name)
 return p.stdout


def unit(name,key='ActiveState'):return run(['systemctl','show',name,'-p',key,'--value'],'Read service state').decode().strip()


def health():
 import urllib.request,urllib.error
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open('http://127.0.0.1:8000/api/health',timeout=5) as r:
   if r.status!=200 or json.loads(r.read()).get('status')!='ok':return False
  try:opener.open(urllib.request.Request('http://127.0.0.1:8000/api/auth/me',headers={'Authorization':'Bearer invalid-launch-test'}),timeout=5)
  except urllib.error.HTTPError as e:return e.code==401
  return False
 except Exception:return False


def check_host():
 if os.geteuid()!=0:raise Stop('Use sudo on the application host')
 addresses=json.loads(run(['ip','-json','address','show'],'Host identity'))
 if '192.0.2.11' not in {a.get('local') for x in addresses for a in x.get('addr_info',[])}:raise Stop('Wrong host: application host 192.0.2.11 required')
 if unit('pulsarx-api.service','User')!='pulsarx' or unit('pulsarx-api.service','WorkingDirectory')!=str(ROOT):raise Stop('API service identity differs')


def pg(sql,write=False):
 tx='BEGIN'+('' if write else ' READ ONLY')+"; SET LOCAL statement_timeout='30s'; SET LOCAL lock_timeout='5s'; "+sql+';'+('COMMIT' if write else 'ROLLBACK')+';'
 return run(['runuser','-u','postgres','--','psql','-X','-qAt','-v','ON_ERROR_STOP=1','--dbname=pulsarx'],'Private database check/migration',45,data=tx.encode()).decode().strip()


def quiet():
 result=json.loads(pg("SELECT json_build_object('orders',(SELECT count(*) FROM wallet_orders WHERE status IN ('queued','working','review')),'gifts',(SELECT count(*) FROM wallet_mini_gift_codes WHERE state IN ('queued','working')),'invoices',(SELECT count(*) FROM payments WHERE status='needs_review' OR (status IN ('created','pending') AND expires_at>now())))"))
 if any(result.values()):raise Stop('Let pending orders, gifts and payment invoices finish before applying; no service was changed by this check')


def service_code(code,label,timeout=90):
 prefix="import os,sys;os.chdir('/opt/pulsarx-backend');sys.path.insert(0,os.getcwd());from dotenv import load_dotenv;load_dotenv('/opt/pulsarx-backend/.env');\n"
 return run(['runuser','-u','pulsarx','-g','pulsarx','--',ROOT/'venv/bin/python3','-c',prefix+code],label,timeout,env={'HOME':'/home/pulsarx','INCUS_CONF':'/home/pulsarx/.config/incus','INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})


def restore_timers(s):
 for name,was in s.get('timers',{}).items():
  if was:run(['systemctl','start',name],'Restore application timer')


def ready():
 deadline=time.time()+60
 while not health():
  if time.time()>deadline:raise Stop('API health/private authentication did not recover')
  time.sleep(2)

