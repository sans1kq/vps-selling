"""Bounded live process caps for the two already audited instances."""
import argparse,fcntl,json,os,re,subprocess,tempfile,time
from pathlib import Path
from urllib.parse import quote
from limits import for_pid

RELEASE='SECURITY-FIX-20261109-r1.1'
STATE=Path('/var/lib/pulsarx-security-fix');JOURNAL=STATE/'host.json'
EXPECTED={'mini-0f419f50e2':2048,'mini-eeed8e64f0':4096}
class Stop(RuntimeError):pass
def run(args):
    p=subprocess.run(args,capture_output=True,text=True,timeout=30,env={**os.environ,'LC_ALL':'C'})
    if p.returncode:raise Stop('Command failed: '+str(args[0])+' '+str(args[1])+'; private command output withheld')
    return p.stdout
def query(path):
    raw=json.loads(run(['incus','--force-local','query','--raw',path]))
    if raw.get('status_code')!=200 or raw.get('type')!='sync':raise Stop('Unexpected Incus query result')
    return raw['metadata']
def host():
    if os.geteuid()!=0:raise Stop('Run as root on compute 192.0.2.12')
    addresses=json.loads(run(['ip','-json','address','show']))
    if '192.0.2.12' not in {a.get('local') for x in addresses for a in x.get('addr_info',[])}:raise Stop('Wrong compute host')
def save(s):
    STATE.mkdir(mode=0o700,exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o022:raise Stop('Unsafe checkpoint directory')
    fd,tmp=tempfile.mkstemp(prefix='.host-',dir=STATE)
    with os.fdopen(fd,'w') as f:
        os.fchmod(f.fileno(),0o600);json.dump(s,f,indent=2);f.flush();os.fsync(f.fileno())
    os.replace(tmp,JOURNAL)
def inventory():
    rows=json.loads(run(['incus','--force-local','list','--all-projects','--format','json']))
    if {r.get('name') for r in rows}!=set(EXPECTED) or any(r.get('project','default')!='default' for r in rows):
        raise Stop('Instance inventory changed since audit; no unreviewed guest will be modified')
    server=query('/1.0')
    if server.get('config',{}).get('user.pulsarx.storage_maintenance'):raise Stop('Another storage maintenance is in progress')
    result=[]
    for row in rows:
        name=row['name'];cfg=row['expanded_config']
        if row.get('status')!='Running':raise Stop('Guest state changed; inspect before setting live limits: '+name)
        if cfg.get('security.privileged','false')!='false' or cfg.get('security.nesting','false')!='false' or cfg.get('raw.lxc') or cfg.get('raw.idmap'):
            raise Stop('Guest security contract changed: '+name)
        match=re.fullmatch(r'(\d+)(MiB|MB)',cfg.get('limits.memory',''))
        expected=EXPECTED[name]*1024**2
        configured=int(match[1])*({'MiB':1024**2,'MB':10**6}[match[2]]) if match else None
        if configured!=expected:raise Stop('Configured RAM differs from the audited entitlement: '+name)
        state=query('/1.0/instances/'+quote(name,safe='')+'/state?project=default');pid=state.get('pid')
        runtime=for_pid(name,pid)
        again=query('/1.0/instances/'+quote(name,safe='')+'/state?project=default')
        if again.get('pid')!=pid:raise Stop('Guest restarted during inspection; retry: '+name)
        cap=runtime.get('instance_memory_max')
        memory='PASS' if cap==expected else 'UNKNOWN' if not runtime.get('instance_scope') else 'FAIL'
        target=max(1024,EXPECTED[name]);old=cfg.get('limits.processes')
        if old is not None and (not old.isdigit() or int(old)<=0):raise Stop('Custom process-limit policy needs review: '+name)
        desired=min(int(old),target) if old else target
        pids=runtime.get('instance_pids_max')
        result.append({'name':name,'memory_check':memory,'expected_memory_bytes':expected,
            'configured_process_limit':old,'desired_process_limit':desired,
            'process_check':'PASS' if pids is not None and pids<=desired else 'REVIEW',
            'runtime':runtime})
    return result
def show(rows):
    for row in rows:
        r=row['runtime'];print('RAM '+row['memory_check']+': '+row['name']+' configured='+str(row['expected_memory_bytes'])+'B instance-cgroup='+str(r.get('instance_memory_max'))+'B; scope='+str(r.get('instance_scope')),flush=True)
        print('PIDS '+row['process_check']+': '+row['name']+' current='+str(r.get('instance_pids_current'))+' cap='+str(r.get('instance_pids_max'))+' target='+str(row['desired_process_limit']),flush=True)
def preflight(rows):
    for row in rows:
        if row['memory_check']!='PASS':raise Stop('RAM enforcement is not confirmed; no process-limit mutation attempted. Read the printed cgroup ancestry.')
        current=row['runtime'].get('instance_pids_current')
        if current is None or current>=row['desired_process_limit']*0.7:raise Stop('Process count is too close to the proposed cap; manual workload review required')
def apply():
    STATE.mkdir(mode=0o700,exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o022:raise Stop('Unsafe checkpoint directory')
    with open(STATE/'host.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        rows=inventory();show(rows);preflight(rows)
        s=json.loads(JOURNAL.read_text()) if JOURNAL.exists() else {'release':RELEASE,'before':{}}
        s.update(phase='applying',updated_at=int(time.time()))
        for row in rows:s['before'].setdefault(row['name'],row['configured_process_limit'])
        save(s)
        for row in rows:
            name=row['name'];wanted=str(row['desired_process_limit'])
            if row['configured_process_limit']!=wanted:
                run(['incus','--force-local','config','set',name,'limits.processes='+wanted])
            s.setdefault('applied',{})[name]=wanted;save(s)
        verified=inventory();show(verified)
        if any(r['memory_check']!='PASS' or r['process_check']!='PASS' for r in verified):
            raise Stop('Live controller verification incomplete; safe applied caps retained for inspection. No guest restart or resource restore was attempted.')
        s.update(phase='complete',updated_at=int(time.time()),verified=verified);save(s)
        print('HOST VERIFIED: scoped RAM and process caps; guests stayed running. No disk, network, password, package or SSH setting changed.',flush=True)
def main():
    p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');p.add_argument('--check',action='store_true');p.add_argument('--verify',action='store_true');p.add_argument('--status',action='store_true');a=p.parse_args()
    host();print('RELEASE: '+RELEASE,flush=True)
    if a.status:
        s=json.loads(JOURNAL.read_text()) if JOURNAL.exists() else {};print(json.dumps({k:s.get(k) for k in ('phase','updated_at','applied')},indent=2));return
    if a.apply:return apply()
    rows=inventory();show(rows)
    if a.check or a.verify:
        try:
            preflight(rows)
            if a.verify and any(r['process_check']!='PASS' for r in rows):raise Stop('Process caps not verified')
        except Stop:
            # Safe diagnostic details appear only when the compact result needs review.
            print(json.dumps({'read_only':True,'instances':rows},indent=2),flush=True)
            raise
        print('READ ONLY: inherited container RAM boundary verified; no guest or service change.',flush=True)
        return
    p.error('Choose --check, --apply, --verify or --status')
if __name__=='__main__':
    try:main()
    except Exception as e:print('STOPPED: '+str(e),flush=True);raise SystemExit(1)
