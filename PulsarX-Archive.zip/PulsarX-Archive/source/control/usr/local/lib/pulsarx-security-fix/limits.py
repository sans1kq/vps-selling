"""Read cgroup v2 ancestry; never treat an unlimited leaf as an unlimited guest."""
from pathlib import Path
import os,re

FIELDS=('memory.max','memory.current','memory.swap.max','pids.max','pids.current','cpu.max','cpuset.cpus.effective')
def ancestry(v2_path,mount=Path('/sys/fs/cgroup')):
    mount=Path(mount).resolve()
    if not v2_path.startswith('/') or '..' in Path(v2_path).parts:raise ValueError('Unsafe cgroup path')
    leaf=(mount/v2_path.lstrip('/')).resolve()
    if not leaf.is_relative_to(mount) or not leaf.is_dir():raise ValueError('Cgroup outside host mount')
    rows=[];node=leaf
    while True:
        values={}
        for key in FIELDS:
            p=node/key
            if p.exists():values[key]=p.read_text().strip()[:200]
        rows.append({'path':'/' if node==mount else '/'+node.relative_to(mount).as_posix(),'values':values})
        if node==mount:break
        node=node.parent
    return rows

def minimum(rows,key):
    values=[int(r['values'][key]) for r in rows if re.fullmatch(r'[0-9]+',r['values'].get(key,''))]
    return min(values) if values else None

def summarize(name,rows):
    # All these names include the exact instance name, not a substring prefix.
    names={name,'lxc.payload.'+name,'default_'+name,'lxc.payload.default_'+name}
    scoped=[r for r in rows if set(Path(r['path']).parts)&names]
    boundary=min(scoped,key=lambda r:len(Path(r['path']).parts)) if scoped else None
    def boundary_limit(key):
        value=boundary['values'].get(key,'') if boundary else ''
        return int(value) if value.isdigit() else None
    return {'ancestry':rows,'instance_scope':boundary['path'] if boundary else None,
        'effective_memory_max':minimum(rows,'memory.max'),
        'instance_memory_max':boundary_limit('memory.max'),
        'effective_pids_max':minimum(rows,'pids.max'),
        'instance_pids_max':boundary_limit('pids.max'),
        'instance_pids_current':int(boundary['values']['pids.current']) if boundary and boundary['values'].get('pids.current','').isdigit() else None}

def for_pid(name,pid,proc=Path('/proc'),mount=Path('/sys/fs/cgroup')):
    if type(pid) is not int or pid<=1:raise ValueError('Invalid instance init PID')
    proc=Path(proc)
    if proc==Path('/proc') and os.readlink('/proc/self/ns/cgroup')!=os.readlink('/proc/1/ns/cgroup'):
        raise ValueError('Collector must use the host cgroup namespace')
    raw=(proc/str(pid)/'cgroup').read_text()
    paths=[line.split(':',2)[2] for line in raw.splitlines() if line.startswith('0::')]
    if len(paths)!=1:raise ValueError('Unified cgroup membership unavailable')
    result=summarize(name,ancestry(paths[0],mount))
    if (proc/str(pid)/'cgroup').read_text()!=raw:raise ValueError('Instance moved cgroups while reading')
    return result
