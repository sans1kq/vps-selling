#!/usr/bin/env python3
"""Read-only PulsarX runtime evidence. Prints sanitized JSON; changes no services.

Run with --role control on 192.0.2.11 or --role host on 192.0.2.12.
No disk export/import, customer command, payment, mail, package upgrade,
firewall write, service restart, or credential value is included.
"""
import argparse,hashlib,ipaddress,json,os,re,ssl,stat,subprocess,time,urllib.error,urllib.parse,urllib.request
from pathlib import Path
from limits import for_pid

RELEASE='SECURITY-CHECK-20261109-r1.1'
ROLES={'control':'192.0.2.11','host':'192.0.2.12'}
ROOT=Path('/opt/pulsarx-backend');WEB=Path('/var/www/html')
report={'release':RELEASE,'read_only':True,'checked_at':int(time.time()),'checks':[],'facts':{}}
def check(key,status,detail):report['checks'].append({'check':key,'status':status,'detail':detail})
def cmd(args,timeout=25):
 try:
  p=subprocess.run(args,capture_output=True,text=True,timeout=timeout,env={**os.environ,'LC_ALL':'C'})
  return p.returncode,p.stdout[:3_000_000]
 except (OSError,subprocess.TimeoutExpired) as e:return -1,type(e).__name__
def json_cmd(args,timeout=25):
 code,out=cmd(args,timeout)
 if code:raise RuntimeError('command unavailable')
 return json.loads(out)
def mode(path):
 p=Path(path)
 try:
  s=p.lstat();return {'path':str(p),'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'symlink':p.is_symlink(),'group_writable':bool(s.st_mode&0o020),'world_readable':bool(s.st_mode&0o004),'world_writable':bool(s.st_mode&0o002)}
 except OSError:return {'path':str(p),'present':False}
def unit(name,properties):
 code,out=cmd(['systemctl','show',name,*sum((['-p',p] for p in properties),[])])
 return {k:v for line in out.splitlines() if '=' in line for k,v in [line.split('=',1)] if k in properties} if not code else {'unavailable':True}
def safe_json(fn,key):
 try:report['facts'][key]=fn()
 except Exception as e:report['facts'][key]={'unavailable':type(e).__name__};check(key,'UNKNOWN','Could not collect this observation; not a pass.')
def incus(path):
 value=json_cmd(['incus','--force-local','query','--raw',path],40)
 if value.get('type')!='sync' or value.get('status_code')!=200:raise RuntimeError('unexpected Incus reply')
 return value.get('metadata')

def common():
 report['facts']['running_kernel']=cmd(['uname','-r'])[1].strip()
 code,out=cmd(['dpkg-query','-W','-f=${binary:Package}\t${Version}\n','incus','incus-base','lxcfs','openssh-server','openssl','linux-image-amd64','linux-image-[0-9]*'])
 packages={line.split('\t')[0]:line.split('\t')[1] for line in out.splitlines() if '\t' in line and line.split('\t')[1]}
 report['facts']['packages']=packages
 version=packages.get('incus-base') or packages.get('incus','');match=re.fullmatch(r'6\.0\.4-2\+deb13u([0-9]+)',version)
 if match:check('incus_debian_security_revision','PASS' if int(match[1])>=12 else 'FAIL','Known Debian trixie security reference: 6.0.4-2+deb13u12. Installed '+version)
 elif version:check('incus_debian_security_revision','UNKNOWN','Different package branch; needs its own advisory comparison: '+version)
 else:check('incus_debian_security_revision','INFO','Incus package not reported on this role.')
 safe_json(lambda:{'synchronized':cmd(['timedatectl','show','-p','NTPSynchronized','--value'])[1].strip()},'clock')
 code,out=cmd(['sshd','-T']);wanted={'passwordauthentication','kbdinteractiveauthentication','pubkeyauthentication','permitrootlogin','maxauthtries','authenticationmethods','permitemptypasswords','x11forwarding'}
 report['facts']['sshd_defaults']={line.split(' ',1)[0]:line.split(' ',1)[1] for line in out.splitlines() if ' ' in line and line.split(' ',1)[0] in wanted} if not code else {'unavailable':True}
 report['facts']['failed_units']=cmd(['systemctl','--failed','--no-legend','--no-pager'])[1].strip().splitlines()[:30]
 report['facts']['fail2ban']=unit('fail2ban.service',['ActiveState'])
 code,out=cmd(['ss','-H','-lntup']);listeners=[]
 for line in out.splitlines():
  fields=line.split()
  if len(fields)<5:continue
  address=fields[4] if fields[0] in ('tcp','udp') else fields[3]
  # Keep addresses/ports and process executable names, never command arguments.
  process=re.findall(r'\("([^"\n]{1,80})",pid=',line)
  listeners.append({'protocol':fields[0],'address':address,'processes':process})
 report['facts']['listeners']=listeners[:300]
 if code:check('listener_inventory','UNKNOWN','ss output unavailable; empty list is not a security pass.')
 def firewall():
  data=json_cmd(['nft','--json','list','ruleset']);chains=[];rules=[]
  for item in data.get('nftables',[]):
   if 'chain' in item:
    c=item['chain'];chains.append({k:c[k] for k in ('family','table','name','type','hook','policy') if k in c})
   if 'rule' in item:
    row=item['rule'];text=json.dumps(row.get('expr',[]));chain=str(row.get('chain',''))
    if '8443' in text or 'input' in chain.lower() or 'forward' in chain.lower():
     rules.append({k:row[k] for k in ('family','table','chain','expr') if k in row})
  return {'chains':chains,'selected_filter_rules':rules[:1000],'truncated':len(rules)>1000}
 safe_json(firewall,'firewall')

def control():
 props=['User','Group','WorkingDirectory','ActiveState','NoNewPrivileges','ProtectSystem','ProtectHome','PrivateTmp','PrivateDevices','CapabilityBoundingSet','RestrictAddressFamilies','UMask','Restart']
 report['facts']['api_service']=unit('pulsarx-api.service',props)
 def dependencies():
  return json_cmd([str(ROOT/'venv/bin/python3'),'-I','-c',"import importlib.metadata as m,json;print(json.dumps(sorted([{'name':d.metadata.get('Name',''),'version':d.version} for d in m.distributions()],key=lambda x:x['name'].lower())))"],30)
 safe_json(dependencies,'python_dependencies')
 sensitive=[ROOT,ROOT/'app',ROOT/'scripts',ROOT/'.env',ROOT/'scripts/add_domain.sh',ROOT/'scripts/remove_domain.sh',Path('/home/pulsarx/.config/incus'),Path('/home/pulsarx/.config/incus/client.key'),Path('/var/lib/pulsarx-support')]
 report['facts']['permissions']=[mode(p) for p in sensitive]
 env=mode(ROOT/'.env');check('backend_env_permissions','FAIL' if env.get('world_readable') or env.get('world_writable') else 'PASS' if 'mode' in env else 'UNKNOWN','Only owner/mode was read; secret values were not read.')
 hashes={}
 for p in sorted((ROOT/'app').rglob('*.py')):
  if p.is_file() and not p.is_symlink():hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 for p in (ROOT/'scripts/add_domain.sh',ROOT/'scripts/remove_domain.sh'):
  if p.exists() and not p.is_symlink():hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 report['facts']['backend_sha256']=hashes
 config=cmd(['nginx','-T'],30)[1]
 report['facts']['nginx_observations']={'real_ip_header_override_present':bool(re.search(r'proxy_set_header\s+X-Real-IP\s+\$remote_addr',config)),'forwarded_for_append_present':'$proxy_add_x_forwarded_for' in config,'request_rate_limit_present':'limit_req_zone' in config,'body_limits':re.findall(r'client_max_body_size\s+([0-9]+[kKmMgG]?)\s*;',config),'trusted_everywhere_real_ip':bool(re.search(r'set_real_ip_from\s+(0\.0\.0\.0/0|::/0)\s*;',config))}
 checks={}
 for folder in ('pulsarx-launch','pulsarx-layout','pulsarx-community'):
  p=Path('/var/lib')/folder/'state.json'
  try:
   raw=json.loads(p.read_text());checks[folder]={k:raw[k] for k in ('phase','release','updated_at','metrics') if k in raw}
  except (OSError,ValueError):checks[folder]={'unavailable':True}
 report['facts']['deployment_checkpoints']=checks
 suspicious=[]
 for n,p in enumerate(WEB.rglob('*')):
  if n>20000:break
  if p.is_file() and (p.name=='.env' or p.suffix in ('.py','.sql','.sqlite','.db','.pem','.key') or p.name in ('config','credentials') and '.git' in p.parts):suspicious.append(str(p.relative_to(WEB)))
 report['facts']['sensitive_looking_public_files']=suspicious[:60]
 check('public_root_sensitive_file_names','REVIEW' if suspicious else 'PASS','Names only, not file content. Server access rules still need verification.')
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 responses=[]
 paths=['/api/health','/api/auth/me','/api/servers','/api/admin/users','/api/admin/servers','/api/wallet','/api/support/tickets','/.env','/.git/config','/app/config.py','/backup.sql','/openapi.json']
 for path in paths:
  try:
   with opener.open(urllib.request.Request('https://pulsarx.example.invalid'+path,headers={'User-Agent':'PulsarX-owner-readonly-audit/1'}),timeout=10) as res:
    body=res.read(4096);headers=res.headers;status=res.status
  except urllib.error.HTTPError as e:body=e.read(4096);headers=e.headers;status=e.code
  except Exception as e:responses.append({'path':path,'result':type(e).__name__});continue
  row={'path':path,'status':status}
  if path=='/api/health':row['security_headers']={k:re.sub(r"'nonce-[^']*'", "'nonce-REDACTED'",headers.get(k,'')) for k in ('Strict-Transport-Security','Content-Security-Policy','Content-Security-Policy-Report-Only','X-Content-Type-Options','X-Frame-Options','Referrer-Policy','Cache-Control')}
  if path.startswith(('/.','/app/','/backup.')):row['secret_pattern_detected']=bool(re.search(rb'(?i)(DATABASE_URL\s*=|SMTP_PASSWORD\s*=|BEGIN [A-Z ]*PRIVATE KEY)',body))
  responses.append(row)
 report['facts']['public_readonly_http']=responses
 for row in responses:
  if row.get('path') in ('/api/auth/me','/api/servers','/api/admin/users','/api/admin/servers','/api/wallet','/api/support/tickets'):
   check('unauthenticated'+row['path'],'PASS' if row.get('status') in (401,403,422) else 'FAIL' if row.get('status')==200 else 'UNKNOWN','HTTP '+str(row.get('status',row.get('result'))))
 report['facts']['database_backup_service']=unit('pulsarx-backup.service',['ActiveState','Result','ExecMainStatus','ExecMainExitTimestamp'])

def host_role():
 def inventory():
  rows=json_cmd(['incus','--force-local','list','--all-projects','--format','json'],40)
  if not isinstance(rows,list):raise RuntimeError('invalid instance inventory')
  data=[];roots=[]
  for item in rows:
   name=item.get('name','');project=item.get('project','default');cfg=item.get('expanded_config',{});devices=item.get('expanded_devices',{})
   observed={k:cfg.get(k) for k in ('security.privileged','security.nesting','security.idmap.isolated','limits.cpu','limits.cpu.allowance','limits.memory','limits.memory.enforce','limits.memory.swap','limits.processes')}
   observed['raw_lxc_present']=bool(cfg.get('raw.lxc'));observed['raw_idmap_present']=bool(cfg.get('raw.idmap'))
   maps=[]
   try:
    values=json.loads(cfg.get('volatile.idmap.current','[]'))
    for v in values:
     if v.get('Nsid')==0:
      m={k:v.get(k) for k in ('Isuid','Isgid','Hostid','Nsid','Maprange')};maps.append(m)
      if v.get('Isuid'):roots.append({'name':name,'project':project,'host_root_uid':v.get('Hostid')})
   except (ValueError,TypeError):pass
   devs=[]
   for key,v in devices.items():
    if not isinstance(v,dict):continue
    dev={k:v.get(k) for k in ('type','path','pool','network','security.port_isolation','security.mac_filtering','security.ipv4_filtering') if k in v}
    dev['name']=key
    if v.get('type')=='disk' and not v.get('pool'):dev['host_bind_source_present']=bool(v.get('source'))
    if v.get('type')=='proxy':dev['management_socket_reference']=any('incus' in str(v.get(k,'')) and 'socket' in str(v.get(k,'')) for k in ('listen','connect'))
    devs.append(dev)
   runtime={}
   if item.get('status')=='Running':
    try:
     state=incus('/1.0/instances/'+urllib.parse.quote(name,safe='')+'/state?project='+urllib.parse.quote(project,safe=''))
     pid=state.get('pid')
     if type(pid) is not int or pid<=1:raise RuntimeError('missing init PID')
     runtime=for_pid(name,pid)
     attr=(Path('/proc')/str(pid)/'attr/current').read_text().strip()
     runtime['apparmor']='unconfined' if attr=='unconfined' else 'enforced' if '(enforce)' in attr else 'other'
     status=(Path('/proc')/str(pid)/'status').read_text()
     runtime['seccomp']=next((line.split(':',1)[1].strip() for line in status.splitlines() if line.startswith('Seccomp:')),'unknown')
     if not runtime.get('instance_scope'):check('runtime_memory_limit:'+name,'UNKNOWN','Per-instance cgroup boundary could not be identified.')
     elif runtime.get('instance_memory_max') is None:check('runtime_memory_limit:'+name,'FAIL','No finite memory.max in the per-instance cgroup ancestry.')
     else:check('runtime_memory_limit:'+name,'PASS','Per-instance inherited memory maximum: '+str(runtime['instance_memory_max'])+' bytes.')
    except Exception as e:
     runtime={'unavailable':type(e).__name__};check('runtime_limits:'+name,'UNKNOWN','Controller ancestry could not be collected; this is not a pass.')
   data.append({'name':name,'project':project,'status':item.get('status'),'config':observed,'runtime':runtime,'root_maps':maps,'devices':devs})
   check('unprivileged:'+name,'PASS' if cfg.get('security.privileged','false')=='false' else 'FAIL','Expanded security.privileged flag.')
   check('process_limit:'+name,'REVIEW' if not cfg.get('limits.processes') else 'INFO','Expanded process limit: '+str(cfg.get('limits.processes','unset')))
   if any(v.get('Hostid')==0 for v in maps):check('host_root_mapping:'+name,'FAIL','Container root maps to host UID/GID zero.')
  report['facts']['guest_root_uid_maps']=roots
  return data
 safe_json(inventory,'instances')
 def trust():
  rows=json_cmd(['incus','--force-local','config','trust','list','--format','json'])
  return [{k:r.get(k) for k in ('type','restricted','projects')} for r in rows]
 safe_json(trust,'incus_trust_scope')
 def server():
  root=incus('/1.0');cfg=root.get('config',{});return {'clustered':root.get('environment',{}).get('server_clustered'),'https_address':cfg.get('core.https_address'),'trust_password_present':bool(cfg.get('core.trust_password')),'oidc_configured':bool(cfg.get('oidc.issuer'))}
 safe_json(server,'incus_server')
 report['facts']['backup_service']=unit('pulsarx-container-backup.service',['ActiveState','Result','ExecMainStatus','ExecMainExitTimestamp'])
 report['facts']['backup_timer']=unit('pulsarx-container-backup.timer',['ActiveState','NextElapseUSecRealtime'])
 report['facts']['permissions']=[mode(p) for p in ('/root/.config/rclone/rclone.conf','/opt/pulsarx-backup','/opt/pulsarx-backup/backup_manager.py','/usr/local/bin/backup_containers.sh','/var/lib/incus','/var/lib/incus/unix.socket')]
 # Expose only storage policy and names of eligible report receipts, never disk contents.
 receipts=[]
 for p in sorted(Path('/var/backups').glob('pulsarx-container-run-*'),reverse=True)[:3]:
  receipts.append({'name':p.name,'mtime':int(p.stat().st_mtime)})
 report['facts']['recent_backup_reports']=receipts
 report['facts']['restoration_test']='NOT RUN: no customer backup was imported or guest started by this checker.'
 report['facts']['cloud_immutability']='UNKNOWN: bucket Object Lock and key permissions were not queried by this checker.'

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--role',choices=ROLES,required=True);a=p.parse_args()
 if os.geteuid()!=0:raise SystemExit('Run as root/sudo; no changes attempted.')
 addresses=json_cmd(['ip','-json','address','show']);actual={v.get('local') for x in addresses for v in x.get('addr_info',[])}
 if ROLES[a.role] not in actual:raise SystemExit('Wrong host for requested role; no changes attempted.')
 report['role']=a.role;common()
 if a.role=='control':control()
 else:host_role()
 report['summary']={s:sum(c['status']==s for c in report['checks']) for s in ('PASS','FAIL','REVIEW','UNKNOWN','INFO')}
 report['verdict']='EVIDENCE COLLECTED; not a certification and not an assurance of no vulnerabilities.'
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
