"""PulsarX narrow security repair; exact file backups and no customer disk mutations."""
import argparse,ast,fcntl,hashlib,json,os,pwd,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
from security_patch import changes,stylesheet_links_only
RELEASE='SECURITY-FIX-20261109-r1.1'
HERE=Path(__file__).resolve().parent
ROOT=Path('/opt/pulsarx-backend');WEB=Path('/var/www/html')
STATE=Path('/var/lib/pulsarx-security-fix');JOURNAL=STATE/'control.json'
TIMERS=['pulsarx-wallet.timer','pulsarx-payments.timer','pulsarx-billing-check.timer','pulsarx-error-alert.timer','pulsarx-host-alert.timer']

class Stop(RuntimeError):pass
class FilePlan(dict):
 def __init__(self):
  super().__init__();self.expected_before={}

def sha(raw):return hashlib.sha256(raw).hexdigest()

def atomic(path,raw,mode=0o600,uid=0,gid=0):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():raise Stop('Symlink target rejected: '+str(p))
 raw=raw.encode() if isinstance(raw,str) else raw;fd,tmp=tempfile.mkstemp(prefix='.launch-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),mode);os.fchown(f.fileno(),uid,gid);f.write(raw);f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

def read(path):
 p=Path(path);s=p.lstat()
 if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
 return p.read_bytes()

def run(args,label,timeout=60,data=None,env=None):
 e={**os.environ,'LC_ALL':'C','HOME':'/root'};e.update(env or {})
 try:p=subprocess.run(list(map(str,args)),input=data,capture_output=True,timeout=timeout,env=e,cwd='/')
 except subprocess.TimeoutExpired:raise Stop(label+' timed out') from None
 if p.returncode:
  STATE.mkdir(mode=0o700,exist_ok=True);fd,name=tempfile.mkstemp(prefix='private-error-',suffix='.log',dir=STATE)
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),0o600);f.write(p.stdout[-64000:]+p.stderr[-64000:])
  raise Stop(label+' failed; private diagnostic: '+name)
 return p.stdout

def unit(name,key='ActiveState'):return run(['systemctl','show',name,'-p',key,'--value'],'Read service state').decode().strip()

def health():
 import urllib.request,urllib.error
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open('http://127.0.0.1:8000/api/health',timeout=5) as r:
   if r.status!=200 or json.loads(r.read()).get('status')!='ok':return False
  try:opener.open(urllib.request.Request('http://127.0.0.1:8000/api/auth/me',headers={'Authorization':'Bearer invalid-launch-test'}),timeout=5)
  except urllib.error.HTTPError as e:return e.code==401
  return False
 except Exception:return False

def check_host():
 if os.geteuid()!=0:raise Stop('Use sudo on the application host')
 addresses=json.loads(run(['ip','-json','address','show'],'Host identity'))
 if '192.0.2.11' not in {a.get('local') for x in addresses for a in x.get('addr_info',[])}:raise Stop('Wrong host: application host 192.0.2.11 required')
 if unit('pulsarx-api.service','User')!='pulsarx' or unit('pulsarx-api.service','WorkingDirectory')!=str(ROOT):raise Stop('API service identity differs')

def pg(sql,write=False):
 tx='BEGIN'+('' if write else ' READ ONLY')+"; SET LOCAL statement_timeout='30s'; SET LOCAL lock_timeout='5s'; "+sql+';'+('COMMIT' if write else 'ROLLBACK')+';'
 return run(['runuser','-u','postgres','--','psql','-X','-qAt','-v','ON_ERROR_STOP=1','--dbname=pulsarx'],'Private database check/migration',45,data=tx.encode()).decode().strip()

def quiet():
 result=json.loads(pg("SELECT json_build_object('orders',(SELECT count(*) FROM wallet_orders WHERE status IN ('queued','working','review')),'gifts',(SELECT count(*) FROM wallet_mini_gift_codes WHERE state IN ('queued','working')),'invoices',(SELECT count(*) FROM payments WHERE status='needs_review' OR (status IN ('created','pending') AND expires_at>now())))"))
 if any(result.values()):raise Stop('Let pending orders, gifts and payment invoices finish before applying; no service was changed by this check')

def service_code(code,label,timeout=90):
 prefix="import os,sys;os.chdir('/opt/pulsarx-backend');sys.path.insert(0,os.getcwd());from dotenv import load_dotenv;load_dotenv('/opt/pulsarx-backend/.env');\n"
 return run(['runuser','-u','pulsarx','-g','pulsarx','--',ROOT/'venv/bin/python3','-c',prefix+code],label,timeout,env={'HOME':'/home/pulsarx','INCUS_CONF':'/home/pulsarx/.config/incus','INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})

def restore_timers(s):
 for name,was in s.get('timers',{}).items():
  if was:run(['systemctl','start',name],'Restore application timer')

def load():return json.loads(read(JOURNAL)) if JOURNAL.exists() else {}
def save(s,phase=None,message=None):
 if phase:s['phase']=phase
 if message:s['message']=message
 s.update(release=RELEASE,updated_at=int(time.time()));atomic(JOURNAL,json.dumps(s,indent=2)+'\n')
 if message:print('PHASE: '+s['phase']+' | '+message,flush=True)

def planned():
 if load().get('phase')=='complete':
  verify_files();return {}
 for rel,expected in json.loads(read(HERE/'backend-pins.json')).items():
  if sha(read(ROOT/rel))!=expected:raise Stop('Backend changed since uploaded audit: '+rel)
 for p in (ROOT,ROOT/'app',ROOT/'scripts',ROOT/'scripts/add_domain.sh',ROOT/'scripts/remove_domain.sh'):
  st=p.stat()
  if p.is_symlink() or st.st_uid!=0 or st.st_mode&0o022:raise Stop('Root-owned code or parent permissions changed: '+str(p))
 manifest=json.loads(read(HERE/'frontend-manifest.json'))
 for rel,c in manifest.items():
  p=WEB/rel;actual=sha(read(p)) if p.exists() else None
  if actual!=c['before_sha256']:raise Stop('Frontend differs from audited Layout/Community: '+rel)
 # Controller edits are restricted to the reviewed page inventory. Extra
 # installed pages may receive only a parsed shared stylesheet href update.
 reviewed=[WEB/rel for rel in manifest if rel.endswith('.html')]
 output=changes(ROOT,WEB,html_pages=reviewed);target=FilePlan()
 for p,raw in output.items():
  if p.is_relative_to(WEB):
   rel=p.relative_to(WEB).as_posix();c=manifest.get(rel)
   if not c or sha(raw)!=c['after_sha256']:raise Stop('Unreviewed frontend output: '+rel)
   target.expected_before[str(p)]=c['before_sha256']
  elif p.is_relative_to(ROOT):
   pins=json.loads(read(HERE/'backend-pins.json'));rel=p.relative_to(ROOT).as_posix()
   if rel not in pins:raise Stop('Unreviewed backend output')
   target.expected_before[str(p)]=pins[rel]
  else:raise Stop('Output outside approved application paths')
  if p.suffix=='.py':ast.parse(raw)
  if p.suffix=='.sh':run(['bash','-n'],'Shell syntax',data=raw)
  target[str(p)]=raw
 css_names=[n for n in manifest if n.startswith('px-pulse-security-r1-') and n.endswith('.css')]
 if len(css_names)!=1:raise Stop('Shared stylesheet inventory differs')
 for p in sorted(WEB.rglob('*.html')):
  rel=p.relative_to(WEB).as_posix()
  if rel in manifest:continue
  if p.is_symlink() or not p.resolve().is_relative_to(WEB.resolve()):raise Stop('Unexpected page symlink: '+rel)
  original=read(p)
  updated=stylesheet_links_only(original.decode('utf-8'),css_names[0]).encode('utf-8')
  if updated!=original:
   target[str(p)]=updated;target.expected_before[str(p)]=sha(original)
 return target


def verify_files():
 state=load()
 if not state.get('files'):raise Stop('No saved file inventory to verify')
 for name,c in state['files'].items():
  if sha(read(name))!=c['after_sha256']:raise Stop('Installed source changed: '+name)


def live_metrics():
 code="""import json
from app.routers import auth,admin
for router in (auth.router,admin.router):
 assert any(r.path.endswith('/logout') and 'POST' in r.methods for r in router.routes)
print(json.dumps({'logout_routes':'PASS','running_instances_checked':0}))
"""
 output=service_code(code,'Validate imported logout routes',60).decode().strip()
 result=json.loads(output.splitlines()[-1])
 if result.get('logout_routes')!='PASS':raise Stop('Logout routes unavailable')
 return result


def check_logout_routes():
 import urllib.request,urllib.error
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 for path in ('/api/auth/logout','/api/admin/logout'):
  try:opener.open(urllib.request.Request('http://127.0.0.1:8000'+path,method='POST'),timeout=5)
  except urllib.error.HTTPError as e:
   if e.code==401:continue
  raise Stop('Logout route did not reject a missing bearer token: '+path)

def ready():
 deadline=time.time()+60
 while not health():
  if time.time()>deadline:raise Stop('API health/private authentication did not recover')
  time.sleep(2)

def worker():
 check_host();STATE.mkdir(mode=0o700,exist_ok=True)
 if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o022:raise Stop('Unsafe checkpoint directory')
 with open(STATE/'worker.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);s=load()
  if s.get('phase')=='complete':
   verify_files()
   if not health():raise Stop('API/private authentication is unhealthy')
   s['worker_succeeded']=True;save(s);return
  try:
   if not s.get('prepared'):
    target=planned()
    if not health():raise Stop('API/private authentication is unhealthy before apply')
    quiet();backups=STATE/'backups'/uuid.uuid4().hex;entries={}
    for n,(name,raw) in enumerate(target.items()):
     p=Path(name);old=read(p) if p.exists() else None;st=p.stat() if old is not None else None
     expected=getattr(target,'expected_before',None)
     if expected is not None and (sha(old) if old is not None else None)!=expected.get(name):raise Stop('File changed while preparing backup: '+name)
     before=backups/'before'/str(n);after=backups/'after'/str(n)
     if old is not None:atomic(before,old)
     atomic(after,raw)
     entries[name]={'before_sha256':sha(old) if old is not None else None,'after_sha256':sha(raw),'before':str(before),'after':str(after),'mode':stat.S_IMODE(st.st_mode) if st else 0o644,'uid':st.st_uid if st else 0,'gid':st.st_gid if st else 0}
    s.update(prepared=True,files=entries,timers={n:unit(n)=='active' for n in TIMERS},backup=str(backups))
    save(s,'prepared','Exact file backup prepared. Existing VPS continue running.')
   s['pause_started']=True;save(s,'applying','Pausing API/timers briefly for logout and process-limit provisioning fixes; customer VPS remain running.')
   for n in TIMERS:run(['systemctl','stop',n],'Pause application timer')
   run(['systemctl','stop','pulsarx-api.service'],'Pause API')
   quiet()
   for name,m in s['files'].items():
    p=Path(name);actual=sha(read(p)) if p.exists() else None
    if actual not in (m['before_sha256'],m['after_sha256']):raise Stop('A staged file changed: '+name)
   for name,m in s['files'].items():
    p=Path(name)
    if p.exists() and sha(read(p))==m['after_sha256']:continue
    atomic(p,read(m['after']),m['mode'],m['uid'],m['gid'])
   verify_files();run(['nginx','-t'],'Nginx syntax')
   s['metrics']=live_metrics();save(s,'resuming','Python, shell and route checks passed; resuming API.')
   run(['systemctl','start','pulsarx-api.service'],'Start API');ready();check_logout_routes();restore_timers(s)
   s['worker_succeeded']=True
   save(s,'complete','Logout, root-script diagnostics, new/upgrade process caps, view-transition CSS and disk units verified. Existing guest disks, balances and paid dates preserved.')
  except BaseException as exc:
   if s.get('pause_started'):
    run(['systemctl','stop','pulsarx-api.service'],'Pause API for file restoration')
    for name,m in reversed(list(s.get('files',{}).items())):
     p=Path(name)
     if p.exists() and sha(read(p))==m['after_sha256']:
      if m['before_sha256'] is None:p.unlink()
      else:atomic(p,read(m['before']),m['mode'],m['uid'],m['gid'])
    run(['systemctl','start','pulsarx-api.service'],'Restore API');restore_timers(s)
   s.update(prepared=False,pause_started=False,worker_succeeded=False);s.pop('files',None);save(s,'failed',str(exc));raise

def start():
 check_host();STATE.mkdir(mode=0o700,exist_ok=True)
 if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o022:raise Stop('Unsafe checkpoint directory')
 with open(STATE/'launch.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  name='pulsarx-security-fix-control.service'
  if unit(name) in ('active','activating'):return name
  if unit(name)=='failed':run(['systemctl','reset-failed',name],'Clear completed worker state')
  s=load();s['worker_succeeded']=False;save(s)
  run(['systemd-run','--unit',name,'--collect','--property=Type=exec','/usr/bin/python3',HERE/'install.py','--worker'],'Start independent security worker',30)
  return name

def main():
 p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');p.add_argument('--worker',action='store_true');p.add_argument('--check',action='store_true');p.add_argument('--status',action='store_true');p.add_argument('--verify',action='store_true');a=p.parse_args();print('RELEASE: '+RELEASE,flush=True)
 if a.worker:return worker()
 check_host()
 if a.status:print(json.dumps({k:v for k,v in load().items() if k in ('phase','message','release','updated_at','metrics')},indent=2));return
 if a.check:
  planned();quiet()
  if not health():raise Stop('API/private authentication is unhealthy')
  print('READ ONLY: file contracts, private authentication and pending operations verified. No application or guest changes.');return
 if a.verify:
  verify_files()
  if not health():raise Stop('API/private authentication is unhealthy')
  check_logout_routes();print('VERIFIED: '+json.dumps(live_metrics()));return
 if a.apply:
  name=start();print('WORKER: '+name+'; continues after SSH disconnects.',flush=True)
  while unit(name) in ('active','activating'):
   s=load();print('WORKING: '+s.get('phase','queued')+' | '+s.get('message','Independent layout worker running'),flush=True);time.sleep(15)
  s=load()
  if s.get('phase')!='complete' or s.get('worker_succeeded') is not True or unit(name,'Result') not in ('','success'):raise Stop(s.get('message','Worker needs attention; use --status'))
  print('COMPLETE: control security fixes verified.',flush=True);return
 p.error('Choose --apply, --check, --verify or --status')
if __name__=='__main__':
 try:main()
 except Exception as exc:print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(1)

