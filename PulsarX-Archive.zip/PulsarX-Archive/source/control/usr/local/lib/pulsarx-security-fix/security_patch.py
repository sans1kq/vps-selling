"""Guarded, narrow source edits. Never deploy the sanitized source snapshot."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import hashlib,re

OLD_CSS='px-pulse-5949b0daa5.css'

def stylesheet_links_only(source,new_name):
    """Change an actual shared stylesheet href; preserve scripts and all other bytes."""
    if not re.fullmatch(r'px-pulse-security-r1-[a-f0-9]{10}\.css',new_name):
        raise ValueError('Unexpected stylesheet target')
    offsets=[0]+[m.end() for m in re.finditer('\n',source)]
    edits=[]
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            if tag.lower()!='link':return
            rels=[v or '' for k,v in attrs if k.lower()=='rel']
            hrefs=[v or '' for k,v in attrs if k.lower()=='href']
            if not any('stylesheet' in value.lower().split() for value in rels):return
            if not any(OLD_CSS in value for value in hrefs):return
            if len(hrefs)!=1 or len(rels)!=1:raise ValueError('Duplicate stylesheet attributes')
            href=hrefs[0]
            url=urlsplit(href)
            if url.scheme not in ('','https') or url.netloc not in ('','pulsarx.example.invalid') or url.path!='/'+OLD_CSS:
                raise ValueError('Unreviewed shared stylesheet URL')
            raw=self.get_starttag_text()
            start=re.match(r'<\s*link\b',raw,re.I).end()
            attributes=re.finditer(r'''(?P<name>[^\s=<>/]+)(?:\s*=\s*(?:"(?P<double>[^"]*)"|'(?P<single>[^']*)'|(?P<bare>[^\s>]+)))?''',raw[start:])
            matches=[m for m in attributes if m.group('name').lower()=='href']
            if len(matches)!=1:raise ValueError('Ambiguous stylesheet href syntax')
            match=matches[0];group=next(g for g in ('double','single','bare') if match.group(g) is not None)
            value=match.group(group)
            if value.count(OLD_CSS)!=1:raise ValueError('Ambiguous stylesheet binding')
            line,column=self.getpos();position=offsets[line-1]+column+start+match.start(group)+value.index(OLD_CSS)
            edits.append((position,position+len(OLD_CSS)))
    parser=Links(convert_charrefs=False);parser.feed(source);parser.close()
    for a,b in reversed(edits):
        if source[a:b]!=OLD_CSS:raise ValueError('Stylesheet position differs')
        source=source[:a]+new_name+source[b:]
    return source

def replace_once(text,old,new):
    if text.count(old)!=1:raise ValueError('Source contract changed; review before applying')
    return text.replace(old,new,1)

def logout_endpoint(admin=False):
    table='AdminSession' if admin else 'UserSession'
    return '''

# SECURITY-20261109-r1: revoke the presented bearer session, including expired ones.
@router.post("/logout")
def logout_session(request: Request, db: Session = Depends(get_db)):
    authorization = request.headers.get("authorization", "")
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.removeprefix("Bearer ").strip()
    if not token or len(token) > 256:
        raise HTTPException(401, "Invalid bearer token")
    session = db.get(auth.'''+table+''', token)
    if session is not None:
        db.delete(session)
        db.commit()
    return {"status": "signed_out"}
'''

def changes(backend,frontend,html_pages=None):
    backend=Path(backend);frontend=Path(frontend);result={}
    for admin in (False,True):
        p=backend/'app/routers'/('admin.py' if admin else 'auth.py');s=p.read_text()
        if 'def logout_session(' in s:raise ValueError('Logout route already exists; inspect installed version')
        # Existing router, Request, auth and get_db imports are required.
        for marker in ('router = APIRouter(', 'Request', 'from .. import auth', 'from ..database import get_db'):
            if marker not in s:raise ValueError('Router imports changed')
        result[p]=(s+logout_endpoint(admin)).encode()
    for name in ('add_domain.sh','remove_domain.sh'):
        p=backend/'scripts'/name;s=p.read_text()
        s=replace_once(s,'CONF="/etc/nginx/sites-available/customer-${DOMAIN}.conf"',
            '# SECURITY-20261109-r1: private, atomically created nginx diagnostic.\n'
            'umask 077\nPX_NGINX_ERROR=$(mktemp /tmp/pulsarx-domain.XXXXXXXX)\n'
            'trap \'rm -f -- "$PX_NGINX_ERROR"\' EXIT\n\n'
            'CONF="/etc/nginx/sites-available/customer-${DOMAIN}.conf"')
        if s.count('/tmp/nginx_test_err')!=2:raise ValueError('Unexpected domain diagnostic uses')
        s=s.replace('2>/tmp/nginx_test_err','2>"$PX_NGINX_ERROR"').replace('cat /tmp/nginx_test_err','cat "$PX_NGINX_ERROR"')
        result[p]=s.encode()
    css=frontend/'px-pulse-5949b0daa5.css'
    text=replace_once(css.read_text(),'@view-transition{navigation:auto}','@view-transition{navigation:none}')
    newcss='px-pulse-security-r1-'+hashlib.sha256(text.encode()).hexdigest()[:10]+'.css'
    result[frontend/newcss]=text.encode()
    portal=frontend/'px-flex-portal-layout-r1.js'
    old="document.querySelector('[data-signout]').onclick=()=>{localStorage.removeItem('pulsarx_token');localStorage.removeItem('pulsarx_user');sessionStorage.removeItem('px-auth-email');location.replace('/login/');};"
    new="document.querySelector('[data-signout]').onclick=async e=>{const b=e.currentTarget;if(b.disabled)return;b.disabled=true;try{await api('/api/auth/logout',post({}));localStorage.removeItem('pulsarx_token');localStorage.removeItem('pulsarx_user');sessionStorage.removeItem('px-auth-email');location.replace('/login/');}catch(ex){toast(ex.message);}finally{b.disabled=false;}};"
    text=replace_once(portal.read_text(),old,new)
    newportal='px-portal-security-r1-'+hashlib.sha256(text.encode()).hexdigest()[:10]+'.js'
    result[frontend/newportal]=text.encode()
    for p in sorted(frontend.rglob('*.html') if html_pages is None else html_pages):
        s=p.read_text();updated=s.replace(css.name,newcss).replace(portal.name,newportal)
        if p.relative_to(frontend).as_posix()=='admin/index.html':
            old="""document.getElementById('logoutBtn').addEventListener('click', ()=>{
    localStorage.removeItem('pulsarx_admin_token');
    window.location.href = '/adminlogin/';
  });"""
            new="""document.getElementById('logoutBtn').addEventListener('click', async e=>{
    const button=e.currentTarget;if(button.disabled)return;button.disabled=true;
    try {
      const response=await fetch('/api/admin/logout',{method:'POST',cache:'no-store',headers:{Authorization:'Bearer '+token}});
      if(!response.ok)throw new Error('Server sign-out failed. Please retry.');
      localStorage.removeItem('pulsarx_admin_token');
      window.location.href = '/adminlogin/';
    } catch(error) { alert(error.message); }
    finally { button.disabled=false; }
  });"""
            updated=replace_once(updated,old,new)
        if updated!=s:result[p]=updated.encode()
    terms=frontend/'terms/index.html'
    updated=result.get(terms,terms.read_bytes()).decode()
    for number in (8,16,32):
        updated=replace_once(updated,str(number)+' ГиБ диска',str(number)+' GB диска')
    result[terms]=updated.encode()
    service=backend/'app/incus_service.py';updated=service.read_text()
    updated=replace_once(updated,'        "--config", f"limits.memory={ram_mb}MiB",',
        '        "--config", f"limits.memory={ram_mb}MiB",\n'
        '        "--config", f"limits.processes={max(1024, int(ram_mb))}",')
    updated=replace_once(updated,"f'limits.memory={ram_mb}MiB'])", "f'limits.memory={ram_mb}MiB',f'limits.processes={max(1024, int(ram_mb))}'])")
    result[service]=updated.encode()
    return result
