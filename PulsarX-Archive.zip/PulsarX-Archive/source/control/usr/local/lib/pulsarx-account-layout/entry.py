#!/usr/bin/env python3
"""Guarded public CSS update. No backend, payment, email or VPS operation."""
import argparse,fcntl,hashlib,json,os,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse

RELEASE='ACCOUNT-LAYOUT-20261110-r1'
STYLE='/* Dashboard account cards only. No account, payment or gift-code logic changes. */\nhtml body #launchActivation{\n  display:grid;grid-template-columns:44px minmax(0,1fr) auto;align-items:center;\n  column-gap:18px;row-gap:7px;width:100%;min-width:0;box-sizing:border-box;\n  margin:0 0 22px;padding:24px;border:1px solid #493252;border-radius:16px;\n  background:linear-gradient(115deg,#140a1c,#08060b 75%);\n  box-shadow:inset 0 1px 0 #ffffff04;\n}\nhtml body #launchActivation::before{\n  content:"";grid-column:1;grid-row:1/span 2;align-self:start;\n  width:44px;height:44px;border:1px solid #5a3d6a;border-radius:12px;\n  background:#24102e url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'23\' height=\'23\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%23c5a0df\' stroke-width=\'1.5\' stroke-linecap=\'round\'%3E%3Ccircle cx=\'12\' cy=\'8\' r=\'3.5\'/%3E%3Cpath d=\'M5 21v-2a7 7 0 0 1 14 0v2\'/%3E%3C/svg%3E") center/23px no-repeat;\n}\nhtml body #launchActivation>h3{grid-column:2;grid-row:1;margin:0;color:#f3ecf9;font-size:18px;font-weight:650;line-height:1.4;letter-spacing:-.02em;overflow-wrap:anywhere}\nhtml body #launchActivation>p{grid-column:2;grid-row:2;margin:0;color:#bdb0c9;font-size:13px;line-height:1.75;overflow-wrap:anywhere}\nhtml body #launchActivation>a.btn{grid-column:3;grid-row:1/span 2;justify-self:end;min-height:42px;margin:0;padding:10px 16px;border:1px solid #79518d;border-radius:9px;background:#24112f;color:#f2e6fc;font-size:12px;font-weight:600;text-align:center;white-space:normal}\nhtml body #launchActivation>a.btn:hover{background:#321640;border-color:#ad7cc6}\n/* Keep the disclosure outline inside the card, away from clipping parents. */\nhtml body details.gift-code-box{\n  display:block;box-sizing:border-box;width:100%;max-width:100%;min-width:0;\n  padding:0!important;margin:22px 0 0;border:1px solid #493252;border-radius:16px;\n  background:linear-gradient(120deg,#100815,#060507 85%);overflow:visible;\n  color:#dfd2ea;box-shadow:inset 0 1px 0 #ffffff04;\n}\nhtml body details.gift-code-box>summary{\n  display:flex;align-items:center;justify-content:space-between;gap:16px;\n  box-sizing:border-box;width:100%;min-width:0;min-height:66px;padding:19px 24px;\n  margin:0;border:0;border-radius:15px;color:#f2eaf8;background:transparent;\n  font-size:15px;font-weight:600;line-height:1.5;overflow-wrap:anywhere;\n}\nhtml body details.gift-code-box>summary::after{content:"+";display:grid;place-items:center;flex:0 0 26px;width:26px;height:26px;border:1px solid #584063;border-radius:7px;background:#1b0f23;color:#cba9e0;font-size:20px;line-height:1;font-weight:400}\nhtml body details.gift-code-box[open]>summary{border-bottom:1px solid #37243f;border-radius:15px 15px 0 0}\nhtml body details.gift-code-box[open]>summary::after{content:"−"}\nhtml body details.gift-code-box>summary:focus{outline:none}\nhtml body details.gift-code-box>summary:focus-visible{outline:2px solid #b984d4;outline-offset:-5px}\nhtml body details.gift-code-box>div{box-sizing:border-box;width:100%;max-width:none!important;min-width:0;margin:0;padding:22px 24px 24px}\nhtml body details.gift-code-box>div>p{margin:0;color:#c4b7cf;font-size:13px;line-height:1.8;overflow-wrap:anywhere}\nhtml body details.gift-code-box #giftForm{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end;column-gap:12px;row-gap:10px;width:100%;max-width:none;min-width:0;margin:20px 0 0}\nhtml body details.gift-code-box #giftForm>label{display:block;grid-column:1;grid-row:1;min-width:0;margin:0}\nhtml body details.gift-code-box #giftForm .field-label{margin:0 0 8px;color:#dbcae6;font-size:12px;font-weight:550;line-height:1.5}\nhtml body details.gift-code-box #giftCode{box-sizing:border-box;display:block;min-width:0;width:100%;max-width:100%;height:46px;margin:0;padding:11px 14px;border:1px solid #62456f;border-radius:9px;background:#08060b;color:#f4edf9;font:500 15px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.025em;box-shadow:none;text-overflow:clip}\nhtml body details.gift-code-box #giftCode::placeholder{color:#a590b7;opacity:1}\nhtml body details.gift-code-box #giftCode:focus{border-color:#bb86d7;outline:2px solid #bb86d74d;outline-offset:2px}\nhtml body details.gift-code-box #giftForm>button{grid-column:2;grid-row:1;align-self:end;min-width:142px;min-height:46px;margin:0;padding:11px 17px;border:1px solid #9862b3;border-radius:9px;background:#4d1769;color:#faf3ff;font-size:12px;font-weight:600;white-space:normal;text-align:center}\nhtml body details.gift-code-box #giftForm>button:hover{background:#622283;border-color:#c58de0}\nhtml body details.gift-code-box #giftForm>button:disabled{opacity:.55;cursor:wait}\nhtml body details.gift-code-box #giftError{grid-column:1/-1;grid-row:2;min-width:0;margin:0;color:#f3a7ba;font-size:12px;line-height:1.7;overflow-wrap:anywhere}\nhtml body details.gift-code-box #giftError:empty{display:none}\nhtml body details.gift-code-box>div>.trial-note{margin:18px 0 0;padding:14px 0 0;border-top:1px solid #34223e;color:#b6a6c4;font-size:12px;line-height:1.8;max-width:none;overflow-wrap:anywhere}\n@media(max-width:640px){\n  html body #launchActivation{grid-template-columns:38px minmax(0,1fr);column-gap:13px;row-gap:8px;padding:20px}\n  html body #launchActivation::before{width:38px;height:38px;border-radius:10px;background-size:21px}\n  html body #launchActivation>h3{font-size:17px}\n  html body #launchActivation>p{font-size:12px}\n  html body #launchActivation>a.btn{grid-column:1/-1;grid-row:3;justify-self:stretch;width:100%;margin-top:7px}\n  html body details.gift-code-box>summary{min-height:62px;padding:17px 20px;font-size:14px}\n  html body details.gift-code-box>div{padding:18px 20px 20px}\n  html body details.gift-code-box #giftForm{grid-template-columns:minmax(0,1fr);gap:12px}\n  html body details.gift-code-box #giftCode{font-size:16px;letter-spacing:0}\n  html body details.gift-code-box #giftForm>button{grid-column:1;grid-row:2;width:100%;min-width:0}\n  html body details.gift-code-box #giftError{grid-row:3}\n  html body details.gift-code-box>div>p,html body details.gift-code-box>div>.trial-note{font-size:12px}\n}\n'
ASSET='px-account-layout-r1.css'
WEB=Path('/var/www/html')
STATE=Path('/var/lib/pulsarx-account-layout')
ENTRY=Path('/usr/local/lib/pulsarx-account-layout/entry.py')
SERVICE='pulsarx-account-layout-update.service'


class Stop(RuntimeError):pass
def sha(raw):return hashlib.sha256(raw).hexdigest()


def read(path):
    p=Path(path);s=p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
    return p.read_bytes()


def atomic(path,raw,mode=0o600,uid=0,gid=0):
    path=Path(path)
    if path.is_symlink():raise Stop('Symlink target rejected')
    raw=raw.encode() if isinstance(raw,str) else raw
    fd,temp=tempfile.mkstemp(prefix='.account-layout-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),mode);os.fchown(stream.fileno(),uid,gid)
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def unit():
    r=subprocess.run(['systemctl','show',SERVICE,'-p','ActiveState','--value'],capture_output=True,text=True,timeout=10)
    return r.stdout.strip()


def check_host():
    if os.geteuid()!=0:raise Stop('Run with sudo on the application host')
    r=subprocess.run(['ip','-json','address','show'],capture_output=True,text=True,timeout=10,check=True)
    ips={a.get('local') for n in json.loads(r.stdout) for a in n.get('addr_info',[])}
    if '192.0.2.11' not in ips:raise Stop('Wrong host: application host 192.0.2.11 required')
    for path in (WEB,):
        info=path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022:raise Stop('Unsafe website directory')


class Page(HTMLParser):
    def __init__(self,source):
        super().__init__(convert_charrefs=False)
        self.links=[];self.heads=[];self.offsets=[0]
        for line in source.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.feed(source);self.close()
    def handle_starttag(self,tag,attrs):
        if tag!='link':return
        if len([k for k,v in attrs if k=='href'])>1:raise Stop('Ambiguous stylesheet link')
        attrs=dict(attrs)
        if 'stylesheet' in attrs.get('rel','').split():self.links.append(attrs.get('href',''))
    def handle_endtag(self,tag):
        if tag=='head':
            line,column=self.getpos();self.heads.append(self.offsets[line-1]+column)


def eligible(relative):
    return bool(relative.parts) and relative.parts[0].lower()=='dashboard'


def update_html(raw):
    source=raw.decode('utf-8');page=Page(source)
    if any(urlparse(href).path=='/'+ASSET for href in page.links):return raw
    marker=False
    for href in page.links:
        url=urlparse(href)
        if url.scheme not in ('','https') or url.netloc not in ('','pulsarx.example.invalid'):continue
        name=Path(url.path).name
        if name.startswith('px-pulse-') and name.endswith('.css'):marker=True
    if not marker:return raw
    if len(page.heads)!=1:raise Stop('Public page has an unexpected head structure')
    index=page.heads[0]
    return (source[:index]+'<link rel="stylesheet" href="/'+ASSET+'">'+source[index:]).encode('utf-8')


def planned(web=WEB):
    web=Path(web);result={};asset=web/ASSET
    if asset.exists() and read(asset)!=STYLE.encode():raise Stop('Existing account layout stylesheet differs')
    pages={}
    for p in sorted(web.rglob('*.html')):
        rel=p.relative_to(web)
        if not eligible(rel):continue
        if p.is_symlink() or not p.resolve().is_relative_to(web.resolve()):raise Stop('Unexpected public page symlink')
        original=read(p);updated=update_html(original)
        if updated!=original:pages[p]=updated
    if not asset.exists():result[asset]=STYLE.encode()
    result.update(pages)
    return result


def load():
    return json.loads(read(STATE/'status.json')) if (STATE/'status.json').exists() else {}


def save(state,phase,message):
    state.update(release=RELEASE,phase=phase,message=message,updated_at=int(time.time()))
    atomic(STATE/'status.json',json.dumps(state,indent=2)+'\n')
    print(phase.upper()+': '+message,flush=True)


def verify(state):
    if not state.get('files'):raise Stop('No saved installation inventory')
    if state.get('asset_path') and read(state['asset_path'])!=STYLE.encode():
        raise Stop('Installed account layout stylesheet changed')
    for name,item in state['files'].items():
        if sha(read(name))!=item['after_sha256']:raise Stop('Installed file changed: '+name)


def rollback(state):
    for name,item in reversed(list(state.get('files',{}).items())):
        p=Path(name);actual=sha(read(p)) if p.exists() else None
        if actual==item['before_sha256']:continue
        if actual!=item['after_sha256']:raise Stop('Refusing to overwrite an unrelated edit: '+name)
        if item['backup']:
            raw=read(item['backup'])
            if sha(raw)!=item['before_sha256']:raise Stop('Backup checksum differs')
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        else:p.unlink()


def worker():
    state=load()
    if state.get('phase')=='complete':verify(state);return
    if state.get('phase')=='applying':
        rollback(state);save(state,'rolled_back','Interrupted public file transaction recovered')
    plan=planned()
    if not plan:raise Stop('No pending account layout changes; run --verify')
    backup=Path('/var/backups')/('pulsarx-account-layout-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+uuid.uuid4().hex[:8])
    backup.mkdir(mode=0o700)
    state={'backup':str(backup),'asset_path':str(WEB/ASSET),'files':{}}
    for index,(p,raw) in enumerate(plan.items()):
        previous=read(p) if p.exists() else None;info=p.stat() if p.exists() else None
        b=backup/str(index) if previous is not None else None
        if b:atomic(b,previous)
        state['files'][str(p)]={'before_sha256':sha(previous) if previous is not None else None,
            'after_sha256':sha(raw),'backup':str(b) if b else None,
            'mode':stat.S_IMODE(info.st_mode) if info else 0o644,
            'uid':info.st_uid if info else 0,'gid':info.st_gid if info else 0}
    save(state,'applying','Installing account activation and gift code layout; all services stay running')
    try:
        for p,raw in plan.items():
            item=state['files'][str(p)];actual=sha(read(p)) if p.exists() else None
            if actual!=item['before_sha256']:raise Stop('File changed after staging: '+str(p))
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        verify(state)
        save(state,'complete','Account activation and gift code layout installed; scripts and backend unchanged; API and VPS stayed online')
    except Exception as exc:
        rollback(state);save(state,'rolled_back','File changes reverted: '+str(exc));raise


def main():
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    for name in ('apply','worker','check','status','verify'):group.add_argument('--'+name,action='store_true')
    args=parser.parse_args();check_host()
    STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o077:raise Stop('Unsafe checkpoint directory')
    print('RELEASE: '+RELEASE,flush=True)
    if args.status:print(json.dumps(load(),indent=2));return
    if args.verify:verify(load());print('VERIFIED: installed CSS and public page hashes');return
    if args.check:
        plan=planned();print('CHECK OK: '+str(len(plan))+' presentation-only file updates; no production files changed');return
    if args.worker:
        with open(STATE/'worker.lock','a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);worker()
        return
    if load().get('phase')=='complete':verify(load());print('ALREADY COMPLETE');return
    if unit() not in ('active','activating','deactivating'):
        ENTRY.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        info=ENTRY.parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o077:raise Stop('Unsafe worker directory')
        atomic(ENTRY,read(Path(__file__)))
        state=load()
        if state.get('phase')!='applying':save(state,'queued','Starting independent public style worker')
        subprocess.run(['systemd-run','--unit=pulsarx-account-layout-update','--collect','--no-block','--service-type=exec',
            '/usr/bin/python3',str(ENTRY),'--worker'],capture_output=True,check=True,timeout=15)
    began=time.monotonic()
    for _ in range(60):
        state=load();phase=state.get('phase')
        if phase=='complete':print('FINISHED: '+state['message']);return
        status=unit()
        if status in ('inactive','failed') and not (phase=='queued' and time.monotonic()-began<10):
            raise Stop('Worker stopped; run --status and journalctl -u '+SERVICE)
        print('WORKING: '+str(phase),flush=True);time.sleep(2)
    raise Stop('Worker still running; use --status')


if __name__=='__main__':
    try:main()
    except Exception as exc:print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(1)
