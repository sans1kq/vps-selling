"""Control-host-only launch update; no existing guest disk/network mutations."""
import argparse,ast,fcntl,hashlib,json,os,pwd,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
from source_patch import apply_edits
RELEASE='LAUNCH-20261109-r1.1';HERE=Path(__file__).resolve().parent;ROOT=Path('/opt/pulsarx-backend');WEB=Path('/var/www/html');STATE=Path('/var/lib/pulsarx-launch');JOURNAL=STATE/'state.json'
SMOKE_R1_SHA256='1ed3916a1ce6fdce28355487a15eeb783b7ab84a0c8b2d9618de8e828c1771cf'
TIMERS=['pulsarx-wallet.timer','pulsarx-payments.timer','pulsarx-billing-check.timer','pulsarx-error-alert.timer','pulsarx-host-alert.timer']
class Stop(RuntimeError):pass

def sha(raw):return hashlib.sha256(raw).hexdigest()
def atomic(path,raw,mode=0o600,uid=0,gid=0):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():raise Stop('Symlink target rejected: '+str(p))
 raw=raw.encode() if isinstance(raw,str) else raw;fd,tmp=tempfile.mkstemp(prefix='.launch-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),mode);os.fchown(f.fileno(),uid,gid);f.write(raw);f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

def read(path):
 p=Path(path);s=p.lstat()
 if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
 return p.read_bytes()
def load():return json.loads(read(JOURNAL)) if JOURNAL.exists() else {}
def save(s,phase=None,message=None):
 if phase:s['phase']=phase
 if message:s['message']=message
 s.update(release=RELEASE,updated_at=int(time.time()));atomic(JOURNAL,json.dumps(s,indent=2)+'\n')
 if message:print('PHASE: '+s['phase']+' | '+message,flush=True)
def run(args,label,timeout=60,data=None,env=None):
 e={**os.environ,'LC_ALL':'C','HOME':'/root'};e.update(env or {})
 try:p=subprocess.run(list(map(str,args)),input=data,capture_output=True,timeout=timeout,env=e,cwd='/')
 except subprocess.TimeoutExpired:raise Stop(label+' timed out') from None
 if p.returncode:
  STATE.mkdir(mode=0o700,exist_ok=True);fd,name=tempfile.mkstemp(prefix='private-error-',suffix='.log',dir=STATE)
  with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),0o600);f.write(p.stdout[-64000:]+p.stderr[-64000:])
  raise Stop(label+' failed; private diagnostic: '+name)
 return p.stdout

def unit(name,key='ActiveState'):return run(['systemctl','show',name,'-p',key,'--value'],'Read service state').decode().strip()
def health():
 import urllib.request,urllib.error
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open('http://127.0.0.1:8000/api/health',timeout=5) as r:
   if r.status!=200 or json.loads(r.read()).get('status')!='ok':return False
  try:opener.open(urllib.request.Request('http://127.0.0.1:8000/api/auth/me',headers={'Authorization':'Bearer invalid-launch-test'}),timeout=5)
  except urllib.error.HTTPError as e:return e.code==401
  return False
 except Exception:return False

def check_host():
 if os.geteuid()!=0:raise Stop('Use sudo on the application host')
 addresses=json.loads(run(['ip','-json','address','show'],'Host identity'))
 if '192.0.2.11' not in {a.get('local') for x in addresses for a in x.get('addr_info',[])}:raise Stop('Wrong host: application host 192.0.2.11 required')
 if unit('pulsarx-api.service','User')!='pulsarx' or unit('pulsarx-api.service','WorkingDirectory')!=str(ROOT):raise Stop('API service identity differs')

def pg(sql,write=False):
 tx='BEGIN'+('' if write else ' READ ONLY')+"; SET LOCAL statement_timeout='30s'; SET LOCAL lock_timeout='5s'; "+sql+';'+('COMMIT' if write else 'ROLLBACK')+';'
 return run(['runuser','-u','postgres','--','psql','-X','-qAt','-v','ON_ERROR_STOP=1','--dbname=pulsarx'],'Private database check/migration',45,data=tx.encode()).decode().strip()
def quiet():
 result=json.loads(pg("SELECT json_build_object('orders',(SELECT count(*) FROM wallet_orders WHERE status IN ('queued','working','review')),'gifts',(SELECT count(*) FROM wallet_mini_gift_codes WHERE state IN ('queued','working')),'invoices',(SELECT count(*) FROM payments WHERE status='needs_review' OR (status IN ('created','pending') AND expires_at>now())))"))
 if any(result.values()):raise Stop('Let pending orders, gifts and payment invoices finish before applying; no service was changed by this check')
def financial():
 parts=[]
 for t in ('users','servers','payments','wallet_accounts','wallet_entries','wallet_orders','wallet_topups','wallet_mini_gift_codes'):
  v="(to_jsonb(t)-'plan'-'duration_hours'-'review_reference')::text" if t=='wallet_mini_gift_codes' else 'to_jsonb(t)::text'
  parts.extend(["'"+t+"'","(SELECT md5(COALESCE(string_agg(h,'' ORDER BY h),'')) FROM (SELECT md5("+v+") h FROM public."+t+" t) q)"])
 return json.loads(pg('SELECT json_build_object('+','.join(parts)+')'))

def outputs(s):
 flex=json.loads(read('/var/lib/pulsarx-flex/control.json'))
 if flex.get('phase')!='complete':raise Stop('Flex must be completed before this launch update')
 result={};contracts=json.loads(read(HERE/'backend-edits.json'))
 for rel,c in contracts.items():
  path=ROOT/rel;raw=read(path)
  saved=s.get('files',{}).get(str(path))
  if saved and sha(raw)==saved['after_sha256']:continue
  trusted=flex.get('files',{}).get(str(path),{}).get('after_sha256',c['baseline_sha256'])
  if sha(raw)!=trusted:raise Stop('Live source changed: '+rel)
  try:target=apply_edits(raw,{'input_sha256':trusted,'edits':c['edits']})
  except ValueError:raise Stop('Live source hunk changed: '+rel) from None
  result[str(path)]=target
 path=ROOT/'app/launch_smoke.py';target=read(HERE/'launch_smoke.py')
 if path.exists() and sha(read(path))!=sha(target):raise Stop('Existing smoke module differs')
 result[str(path)]=target
 for rel,m in json.loads(read(HERE/'frontend-manifest.json')).items():
  path=WEB/rel;raw=read(path) if path.exists() else None
  if raw is not None and sha(raw)==m['after_sha256']:continue
  if (sha(raw) if raw is not None else None)!=m['before_sha256']:raise Stop('Live frontend changed: '+rel)
  target=read(HERE/'frontend'/rel)
  if sha(target)!=m['after_sha256']:raise Stop('Packaged frontend checksum differs')
  result[str(path)]=target
 return result

def service_code(code,label,timeout=90):
 prefix="import os,sys;os.chdir('/opt/pulsarx-backend');sys.path.insert(0,os.getcwd());from dotenv import load_dotenv;load_dotenv('/opt/pulsarx-backend/.env');\n"
 return run(['runuser','-u','pulsarx','-g','pulsarx','--',ROOT/'venv/bin/python3','-c',prefix+code],label,timeout,env={'HOME':'/home/pulsarx','INCUS_CONF':'/home/pulsarx/.config/incus','INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})

def installed_check():
 code="""import json
from sqlalchemy import text
from app.database import SessionLocal
from app.flex_catalog import public_catalog
from app.flex_capacity import capacity_report
from app import growth_service
from app.routers import growth,servers,admin
with SessionLocal() as db:
 db.execute(text('SET TRANSACTION READ ONLY'))
 r=capacity_report(db)
 assert r['memory_budget_bytes']>0
 assert public_catalog()['disk_bytes_per_gb']==1000000000
 assert {p['id']:p['price_cents'] for p in public_catalog()['plans']}=={'nano':175,'mini':300,'plus':500}
 print('INSTALLED CHECK: catalog, decimal accounting, private imports and live capacity OK')
"""
 print(service_code(code,'Installed read-only check').decode().strip(),flush=True)

def restore_timers(s):
 for name,was in s.get('timers',{}).items():
  if was:run(['systemctl','start',name],'Restore application timer')
def worker():
 check_host();STATE.mkdir(mode=0o700,exist_ok=True)
 with open(STATE/'worker.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);s=load()
  if s.get('phase')=='complete':return
  try:
   if not s.get('prepared'):
    target=outputs(s)
    if not s.get('maintenance_started'):
     if not health():raise Stop('API/private authentication is not healthy before apply')
     quiet();s['timers']={n:unit(n)=='active' for n in TIMERS};s.update(maintenance_started=True,api_paused=True)
     save(s,'preparing','Source contracts verified; pausing API/timers briefly. Existing VPS remain running.')
    for n in TIMERS:run(['systemctl','stop',n],'Pause application timer')
    run(['systemctl','stop','pulsarx-api.service'],'Pause API');s['api_paused']=True;save(s)
    quiet();s['finance']=financial()
    dump=run(['runuser','-u','postgres','--','pg_dump','-Fc','--dbname=pulsarx'],'Private pre-change database backup',120);atomic(STATE/'before.pgdump',dump)
    entries={}
    for i,(name,raw) in enumerate(target.items()):
     p=Path(name);old=read(p) if p.exists() else None;st=p.stat() if old is not None else None;backup=STATE/'files-before'/str(i);staged=STATE/'files-after'/str(i)
     if old is not None:atomic(backup,old)
     atomic(staged,raw);entries[name]={'before_sha256':sha(old) if old is not None else None,'after_sha256':sha(raw),'before':str(backup),'after':str(staged),'mode':stat.S_IMODE(st.st_mode) if st else 0o644,'uid':st.st_uid if st else 0,'gid':st.st_gid if st else 0}
    s.update(files=entries,prepared=True);save(s,'prepared','Private backup and exact source replacements staged.')
   for name,m in s['files'].items():
    p=Path(name);actual=sha(read(p)) if p.exists() else None
    if actual==m['after_sha256']:continue
    if actual!=m['before_sha256']:raise Stop('A staged file has unexpected bytes: '+name)
    atomic(p,read(m['after']),m['mode'],m['uid'],m['gid'])
   pg(read(HERE/'postgres.sql').decode(),write=True)
   installed_check();run(['nginx','-t'],'Nginx syntax')
   if not s.get('resume_started') and financial()!=s['finance']:raise Stop('Existing account/financial/server data changed during maintenance')
   s['resume_started']=True;save(s,'resuming','GB catalog, Nano promotion, activation/referral gates and all pages staged; resuming API.')
   run(['systemctl','start','pulsarx-api.service'],'Start API')
   deadline=time.time()+60
   while not health():
    if time.time()>deadline:raise Stop('API health/private authentication did not recover')
    time.sleep(2)
   restore_timers(s);save(s,'complete','Launch update live: existing customer resources, balances and paid periods preserved.')
  except BaseException as exc:
   if not s.get('resume_started'):
    for name,m in reversed(list(s.get('files',{}).items())):
     p=Path(name)
     if p.exists() and sha(read(p))==m['after_sha256']:
      if m['before_sha256'] is None:p.unlink()
      else:atomic(p,read(m['before']),m['mode'],m['uid'],m['gid'])
    if s.get('api_paused'):run(['systemctl','start','pulsarx-api.service'],'Restore original API');restore_timers(s)
    s.update(prepared=False,maintenance_started=False,api_paused=False);s.pop('files',None)
   save(s,'failed',str(exc));raise

def start(stage):
 check_host();STATE.mkdir(mode=0o700,exist_ok=True)
 with open(STATE/'launch.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  name='pulsarx-launch-'+stage
  if unit(name+'.service') in ('active','activating'):return name
  run(['systemctl','reset-failed',name+'.service'],'Clear completed worker state') if unit(name+'.service')=='failed' else None
  run(['systemd-run','--unit',name,'--collect','--property=Type=exec','/usr/bin/python3',HERE/'install.py','--'+stage+'-worker'],'Start independent launch worker',30)
  return name

def refresh_smoke_module():
 """Repair only the known r1 test helper after an otherwise completed apply.

 The API need not restart: this module is used by a separate test process.
 Preserve the completed deployment and its recoverable per-file checkpoint.
 """
 check_host();STATE.mkdir(mode=0o700,exist_ok=True)
 with open(STATE/'worker.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  s=load()
  if s.get('phase')!='complete':raise Stop('Complete the launch update before repairing its smoke helper')
  path=ROOT/'app/launch_smoke.py';raw=read(path);target=read(HERE/'launch_smoke.py')
  actual,wanted=sha(raw),sha(target)
  if actual not in (SMOKE_R1_SHA256,wanted):raise Stop('Smoke helper has unknown changes; no file was replaced')
  receipt=s.get('files',{}).get(str(path))
  if not receipt or receipt.get('after_sha256') not in (SMOKE_R1_SHA256,wanted):raise Stop('Smoke deployment receipt differs; no file was replaced')
  staged=Path(receipt['after'])
  if staged.parent!=STATE/'files-after':raise Stop('Smoke staging path differs')
  if actual!=wanted and unit('pulsarx-launch-smoke.service') in ('active','activating','deactivating'):raise Stop('Let the current smoke worker finish before replacing its helper')
  if actual!=wanted:
   backup=STATE/'smoke-r1-before.py'
   if not backup.exists():atomic(backup,raw)
  # Repeating after a crash at any write boundary completes the same update.
  atomic(staged,target)
  if actual!=wanted:
   st=path.stat();atomic(path,target,stat.S_IMODE(st.st_mode),st.st_uid,st.st_gid)
  receipt['after_sha256']=wanted;s['smoke_build']=RELEASE;save(s)
  print('SMOKE HELPER READY: ordered wallet/user cleanup; existing deployment retained. API and customer VPS were not paused.',flush=True)

def smoke_state():
 p=STATE/'smoke.json'
 return json.loads(read(p)) if p.exists() else {'phase':'queued','passed':False}

def follow(name):
 is_smoke=name.endswith('smoke')
 while unit(name+'.service') in ('active','activating'):
  s=smoke_state() if is_smoke else load()
  message='Disposable Nano verification/owned cleanup in progress' if is_smoke else s.get('message','Independent worker running')
  print('WORKING: '+s.get('phase','queued')+' | '+message,flush=True);time.sleep(15)
 if unit(name+'.service','Result') not in ('','success') or (name.endswith('apply') and load().get('phase')!='complete') or (is_smoke and not smoke_state().get('passed')):
  raise Stop(smoke_state().get('error','Smoke worker needs attention; saved checkpoint retained') if is_smoke else 'Worker needs attention. Run --status; saved checkpoint retained')

def smoke_worker():
 check_host()
 if load().get('phase')!='complete' or not health():raise Stop('Complete the launch update before the live smoke')
 atomic(STATE/'smoke.json',json.dumps({'phase':'running','passed':False}))
 try:
  code="import runpy;runpy.run_module('app.launch_smoke',run_name='__main__')"
  result=service_code(code,'Disposable real Nano smoke',1800).decode()
  if 'SMOKE RECOVERY:' in result:result=service_code(code,'Fresh disposable Nano smoke after cleanup',1800).decode()
  print(result,flush=True)
  if 'SMOKE VERIFIED:' not in result or 'SMOKE CLEANED:' not in result:raise Stop('Live Nano smoke did not produce both verification and cleanup receipts')
  atomic(STATE/'smoke.json',json.dumps({'phase':'complete','passed':True,'updated_at':int(time.time())}))
 except BaseException as exc:
  atomic(STATE/'smoke.json',json.dumps({'phase':'failed','passed':False,'updated_at':int(time.time()),'error':str(exc)[:1000]}));raise

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--apply',action='store_true');p.add_argument('--apply-worker',action='store_true');p.add_argument('--status',action='store_true');p.add_argument('--smoke',action='store_true');p.add_argument('--smoke-worker',action='store_true');a=p.parse_args();print('RELEASE: '+RELEASE,flush=True)
 if a.status:
  check_host();result={k:v for k,v in load().items() if k in ('phase','message','release','updated_at')};result['smoke']=smoke_state();print(json.dumps(result,indent=2));return
 if a.apply_worker:return worker()
 if a.smoke_worker:return smoke_worker()
 if a.check:
  check_host();outputs(load());quiet()
  if not health():raise Stop('API/private authentication is unhealthy')
  print('READ ONLY: source contracts, healthy API and pending operations checked. No changes.');return
 if a.apply or a.smoke:
  if a.smoke:refresh_smoke_module()
  name=start('apply' if a.apply else 'smoke');print('WORKER: '+name+'; continues after SSH disconnects.',flush=True);follow(name);print('COMPLETE: '+('launch update' if a.apply else 'disposable Nano smoke'),flush=True);return
 p.error('Choose --check, --apply, --status or --smoke')
if __name__=='__main__':
 try:main()
 except Exception as exc:print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(1)
