"""Application-only deployment. No Incus command, DB migration or test payment."""
import argparse
import ast
import fcntl
import json
import os
import stat
import sys
import time
import uuid
from pathlib import Path

from deploy_base import (ROOT, WEB, STATE, Stop, sha, atomic, read, run, unit,
                         health, check_host, quiet, service_code, ready)
from patch import changes

RELEASE = 'GIFT-RENEWAL-20261110-r1'
JOURNAL = STATE / 'control.json'
HERE = Path(__file__).resolve().parent
SERVICE = 'pulsarx-gift-renewal-update.service'
TIMERS = ['pulsarx-wallet.timer', 'pulsarx-payments.timer', 'pulsarx-billing-check.timer']


def load():
    return json.loads(read(JOURNAL)) if JOURNAL.exists() else {}


def save(state, phase, message):
    state.update(release=RELEASE, phase=phase, message=message, updated_at=int(time.time()))
    atomic(JOURNAL, json.dumps(state, indent=2) + '\n')
    print(phase.upper() + ': ' + message, flush=True)


def verify_files(state):
    if not state.get('files'):
        raise Stop('No deployment inventory saved')
    for name, item in state['files'].items():
        if sha(read(name)) != item['after_sha256']:
            raise Stop('Installed file differs: ' + name)


def verify_route():
    import urllib.request
    import urllib.error
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for headers in ({}, {'Authorization': 'Bearer invalid-gift-check'}):
        try:
            opener.open(urllib.request.Request('http://127.0.0.1:8000/api/wallet/gift-renewals', headers=headers), timeout=5)
        except urllib.error.HTTPError as exc:
            if exc.code == 401 or (not headers and exc.code == 422):
                continue
        raise Stop('Gift retention endpoint did not reject unauthenticated access')


def check():
    check_host()
    if unit('pulsarx-api.service') != 'active' or not health():
        raise Stop('API must be healthy before application changes')
    for path in (ROOT, ROOT / 'app', WEB, WEB / 'dashboard', WEB / 'terms'):
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise Stop('Unexpected code directory ownership or permissions: ' + str(path))
    for path in (ROOT / 'app/wallet_service.py', ROOT / 'app/trial_service.py',
                 ROOT / 'app/payments_cron.py', ROOT / 'app/main.py',
                 WEB / 'dashboard/index.html', WEB / 'terms/index.html'):
        read(path)
    plan = changes(ROOT, WEB)
    for path, raw in plan.items():
        if path.is_symlink() or not (path.is_relative_to(ROOT) or path.is_relative_to(WEB)):
            raise Stop('Unsafe file target')
        if path.suffix == '.py':
            ast.parse(raw)
    quiet()
    return plan


def resume_timers(state):
    for timer, was_active in state.get('timers', {}).items():
        if was_active:
            run(['systemctl', 'start', timer], 'Restore application timer')


def rollback_files(state):
    for name, item in reversed(list(state.get('files', {}).items())):
        path = Path(name)
        if not path.exists():
            if item['before_sha256'] is not None:
                raise Stop('Rollback target unexpectedly disappeared: ' + name)
            continue
        actual = sha(read(path))
        if actual == item['before_sha256']:
            continue
        if actual != item['after_sha256']:
            raise Stop('Rollback will not overwrite an unrelated edit: ' + name)
        if item['backup']:
            raw = read(item['backup'])
            if sha(raw) != item['before_sha256']:
                raise Stop('Rollback backup checksum differs')
            atomic(path, raw, item['mode'], item['uid'], item['gid'])
        else:
            path.unlink()


def worker():
    state = load()
    if state.get('phase') == 'complete':
        verify_files(state)
        ready()
        verify_route()
        print('ALREADY COMPLETE: gift retention is installed')
        return
    # A killed worker may have left an intentionally paused application.
    # Recover only its saved file inventory before creating a fresh plan.
    if state.get('phase') in ('paused', 'applying', 'recovering'):
        save(state, 'recovering', 'Recovering the interrupted application file transaction')
        run(['systemctl', 'stop', 'pulsarx-api.service'], 'Stop API for file recovery')
        rollback_files(state)
        run(['systemctl', 'start', 'pulsarx-api.service'], 'Restore API')
        ready()
        resume_timers(state)
        save(state, 'rolled_back', 'Previous application files recovered; starting a fresh preflight')
    elif state.get('phase') == 'prepared' and state.get('files'):
        # No files or API state changed before the paused checkpoint, but
        # a previous worker may already have stopped a timer.
        resume_timers(state)
    plan = check()
    if not plan:
        raise Stop('Files already present without this deployment checkpoint; review before applying')
    nonce = uuid.uuid4().hex[:10]
    backup = Path('/var/backups') / ('pulsarx-gift-renewal-' + time.strftime('%Y%m%dT%H%M%SZ', time.gmtime()) + '-' + nonce)
    backup.mkdir(mode=0o700)
    state = {'backup': str(backup), 'timers': {t: unit(t) == 'active' for t in TIMERS}, 'files': {}}
    for index, (path, raw) in enumerate(plan.items()):
        previous = read(path) if path.exists() else None
        info = path.stat() if path.exists() else None
        saved = backup / str(index) if previous is not None else None
        if saved:
            atomic(saved, previous)
        state['files'][str(path)] = {'before_sha256': sha(previous) if previous is not None else None,
            'after_sha256': sha(raw), 'backup': str(saved) if saved else None,
            'mode': stat.S_IMODE(info.st_mode) if info else 0o644,
            'uid': info.st_uid if info else 0, 'gid': info.st_gid if info else 0}
    save(state, 'prepared', 'Guarded file changes staged; guest VPS stay running')
    paused = False
    try:
        for timer in TIMERS:
            if state['timers'][timer]:
                run(['systemctl', 'stop', timer], 'Pause application timer')
        quiet()
        # Mark before stopping so a lost worker can recover the API.
        save(state, 'paused', 'Pausing API briefly; no guest restart or disk change')
        paused = True
        run(['systemctl', 'stop', 'pulsarx-api.service'], 'Pause API')
        quiet()
        # Timers may have already spawned cron jobs. Existing pending payment
        # operations are rejected by quiet(); take no financial action here.
        save(state, 'applying', 'Installing paid gift retention and two expiry reminders')
        for path, raw in plan.items():
            item = state['files'][str(path)]
            before = sha(read(path)) if path.exists() else None
            if before != item['before_sha256']:
                raise Stop('File changed after staging: ' + str(path))
            atomic(path, raw, item['mode'], item['uid'], item['gid'])
        service_code("from app import wallet_service,trial_service,gift_renewal,payments_cron\nassert any(r.path=='/api/wallet/gift-renewals' for r in gift_renewal.router.routes)\nprint('GIFT RETENTION IMPORT OK')", 'Validate gift retention imports')
        verify_files(state)
        run(['systemctl', 'start', 'pulsarx-api.service'], 'Resume API')
        ready()
        verify_route()
        resume_timers(state)
        save(state, 'complete', 'Paid 72-hour Nano retention, renewal-before-upgrade gate, dashboard and expiry reminders installed; API healthy and private endpoint protected')
    except Exception as exc:
        if paused:
            run(['systemctl', 'stop', 'pulsarx-api.service'], 'Pause API for file rollback')
            rollback_files(state)
            run(['systemctl', 'start', 'pulsarx-api.service'], 'Restore API after file rollback')
            ready()
        resume_timers(state)
        save(state, 'rolled_back', 'Application file changes reverted: ' + str(exc))
        raise


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    for command in ('check', 'apply', 'status', 'verify', 'worker'):
        group.add_argument('--' + command, action='store_true')
    args = parser.parse_args()
    check_host()
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid != 0 or STATE.stat().st_mode & 0o077:
        raise Stop('Unsafe checkpoint directory')
    print('RELEASE: ' + RELEASE, flush=True)
    if args.status:
        print(json.dumps(load(), indent=2))
        return
    if args.verify:
        verify_files(load())
        ready()
        verify_route()
        print('VERIFIED: installed files, API health and owner endpoint authentication. No test payment or email sent.')
        return
    if args.check:
        plan = check()
        print('CHECK OK: ' + str(len(plan)) + ' guarded file changes; API, guests and balances unchanged')
        return
    if args.worker:
        with open(STATE / 'worker.lock', 'a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            worker()
        return
    if unit(SERVICE) not in ('active', 'activating', 'deactivating'):
        state = load()
        if state.get('phase') == 'complete':
            verify_files(state)
            ready()
            verify_route()
            print('ALREADY COMPLETE')
            return
        # Keep interrupted-worker state intact for recovery.
        if state.get('phase') not in ('paused', 'applying', 'recovering', 'prepared'):
            save(state, 'queued', 'Starting independent application worker')
        run(['systemd-run', '--unit=pulsarx-gift-renewal-update', '--collect', '--no-block',
             '--service-type=exec', '--property=TimeoutStopSec=30',
             '/usr/bin/python3', HERE / 'install.py', '--worker'], 'Start independent gift retention worker')
    print('WORKER: continues if SSH disconnects; --status reconnects', flush=True)
    deadline = time.monotonic() + 600
    while time.monotonic() < deadline:
        state = load()
        phase = state.get('phase')
        if phase == 'complete':
            print('FINISHED: ' + state['message'])
            return
        if phase == 'rolled_back' and unit(SERVICE) not in ('active', 'activating'):
            raise Stop(state.get('message', 'Worker rolled back'))
        if unit(SERVICE) in ('failed', 'inactive'):
            raise Stop('Worker stopped; run --status and inspect journalctl -u ' + SERVICE)
        print('WORKING: ' + str(phase) + ' | ' + state.get('message', ''), flush=True)
        time.sleep(5)
    raise Stop('Worker still running; use --status. Do not repeat an actual payment.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('STOPPED: ' + str(error), file=sys.stderr, flush=True)
        raise SystemExit(1)
