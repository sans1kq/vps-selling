"""Narrow audited function edits; no whole sanitized files are deployed."""
import ast
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def function_text(source, name):
    nodes = [n for n in ast.parse(source).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
    if len(nodes) != 1:
        raise ValueError('Function inventory differs: ' + name)
    node = nodes[0]
    return ''.join(source.splitlines(keepends=True)[node.lineno - 1:node.end_lineno])


def changes(root, web):
    root, web = Path(root), Path(web)
    result = {}
    contracts = json.loads((HERE / 'contracts.json').read_text())
    for rel, specs in contracts.items():
        path = root / rel
        source = path.read_text()
        for spec in specs:
            current = function_text(source, spec['function'])
            if current == spec['after']:
                continue
            if current != spec['before']:
                raise ValueError('Function changed; no application edits made: ' + rel + ' / ' + spec['function'])
            source = source.replace(current, spec['after'], 1)
        if source != path.read_text():
            ast.parse(source)
            result[path] = source.encode()
    path = root / 'app/main.py'
    source = path.read_text()
    addition = '\n# PulsarX gift retention r1: authenticated owner-only overview.\nfrom .gift_renewal import router as _px_gift_retention_router\napp.include_router(_px_gift_retention_router)\n'
    if '_px_gift_retention_router' not in source:
        if 'app.include_router(wallet.router)' not in source:
            raise ValueError('Wallet router installation differs')
        source += addition
        ast.parse(source)
        result[path] = source.encode()
    path = root / 'app/gift_renewal.py'
    payload = (HERE / 'payload/gift_renewal.py').read_bytes()
    if path.exists() and path.read_bytes() != payload:
        raise ValueError('Existing gift retention module differs')
    if not path.exists():
        result[path] = payload
    for suffix in ('js', 'css'):
        target = web / ('px-gift-renewal-r1.' + suffix)
        raw = (HERE / ('payload/gift-renewal.' + suffix)).read_bytes()
        if target.exists() and target.read_bytes() != raw:
            raise ValueError('Existing gift retention asset differs')
        if not target.exists():
            result[target] = raw
    path = web / 'dashboard/index.html'
    source = path.read_text()
    if '/px-gift-renewal-r1.js' not in source:
        if source.count('</body>') != 1 or source.count('</head>') != 1:
            raise ValueError('Dashboard HTML inventory differs')
        source = source.replace('</head>', '<link rel="stylesheet" href="/px-gift-renewal-r1.css"></head>')
        source = source.replace('</body>', '<script src="/px-gift-renewal-r1.js" defer></script></body>')
        result[path] = source.encode()
    path = web / 'terms/index.html'
    source = path.read_text()
    for before, after in TERM_EDITS:
        if before in source:
            source = source.replace(before, after)
        elif after not in source:
            raise ValueError('Terms wording changed; review required: ' + before[:70])
    if source != path.read_text():
        result[path] = source.encode()
    return result


RU = ('Подарочный Nano на 72 часа можно сохранить платным продлением с баланса, пока VPS ещё существует. '
      'Остаток бесплатного времени сохраняется. Без оплаты сервер и данные удаляются по окончании срока. '
      'Для апгрейда сначала подтвердите продление. После удаления продление недоступно. '
      'Другие временные выдачи сохраняют прежние ограничения.')
EN = ('A 72-hour gift Nano can be retained by confirming a paid renewal from the wallet while the VPS still exists. '
      'Remaining free time is preserved. Without payment, the VPS and data are deleted at expiry. '
      'Renew first, then upgrade. Renewal is unavailable after deletion. Other temporary grants retain their existing restrictions.')
RO = ('Un Nano cadou de 72 de ore poate fi păstrat prin confirmarea unei reînnoiri plătite din sold, cât timp VPS-ul există. '
      'Timpul gratuit rămas se păstrează. Fără plată, VPS-ul și datele sunt șterse la expirare. '
      'Mai întâi reînnoiește, apoi fă upgrade. După ștergere, reînnoirea nu mai este disponibilă. '
      'Celelalte oferte temporare își păstrează restricțiile.')
TERM_EDITS = [
    ('A promotional instance cannot be renewed or upgraded.', EN),
    ('When the promotional period ends, the instance and its data are deleted; promotional instances cannot be renewed or upgraded.', EN),
    ('Промо-инстанс нельзя продлить или улучшить.', RU),
    ('По окончании срока сервер и данные удаляются; промо-инстанс нельзя продлить или улучшить.', RU),
    ('Instanta promotionala nu poate fi reinnoita sau imbunatatita.', RO),
    ('La expirare, serverul și datele sunt șterse; instanța promoțională nu poate fi reînnoită sau îmbunătățită.', RO),
]
