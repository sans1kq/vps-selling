"""Paid retention of an existing 72-hour Nano gift. No provider charge or provisioning."""
from datetime import datetime, timedelta, timezone
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from . import auth
from .database import get_db
from .growth_models import GiftCode
from .models import Server, ServerStatus, User

router = APIRouter(prefix='/api/wallet', tags=['wallet'])
logger = logging.getLogger('pulsarx.gift_renewal')
REMIND_HOURS = (24, 3)


def utc(value):
    return value.replace(tzinfo=timezone.utc) if value and value.tzinfo is None else value


def grant_for(db, server, lock=False):
    q = db.query(GiftCode).filter_by(server_id=server.id, redeemed_by=server.owner_id,
                                    plan='nano', duration_hours=72, state='active')
    if lock:
        q = q.populate_existing().with_for_update()
    grant = q.one_or_none()
    if (grant is None or grant.revoked_at is not None or grant.activated_at is None
            or utc(grant.expires_at) != utc(server.trial_expires_at)):
        return None
    return grant


def renewable(db, server):
    return (server.plan == 'nano' and server.trial_expires_at is not None
            and server.paid_until is None and not server.ls_subscription_id
            and not server.subscription_cancelled_at and server.admin_suspended_at is None
            and server.status == ServerStatus.running and grant_for(db, server) is not None)


def prepare(db, server, kind):
    """Caller must hold the wallet account and server row locks until commit.

    The reaper holds the same server lock throughout deletion. If it wins,
    checkout sees no server and cannot debit; if checkout wins, the trial
    deadline is cleared in the debit transaction and the reaper skips it.
    """
    if server.trial_expires_at is None:
        return None
    if kind != 'renew':
        raise HTTPException(409, 'Renew this server before upgrading')
    if not renewable(db, server):
        raise HTTPException(403, 'This temporary instance cannot be renewed. Contact support.')
    return grant_for(db, server, lock=True)


def complete(server, grant, now, months):
    from .payments_service import PERIOD_DAYS
    server.paid_until = max(utc(server.trial_expires_at), utc(now)) + timedelta(days=PERIOD_DAYS[months])
    server.trial_expires_at = None
    server.renewal_reminder_for = None
    server.payment_failed_at = server.last_dunning_email_sent_at = None
    grant.state = 'paid'
    grant.error_code = None


@router.get('/gift-renewals')
def overview(user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    from .payments_service import price_usd
    now = datetime.now(timezone.utc)
    rows = db.query(Server).filter(Server.owner_id == user.id,
        Server.status.in_((ServerStatus.running, ServerStatus.suspended))).all()
    return {'gifts': [{'id': str(s.id), 'name': s.container_name,
                      'expires_at': s.trial_expires_at,
                      'monthly_cents': int(price_usd('nano', 1) * 100)}
                     for s in rows if renewable(db, s)],
            'renew_first_ids': [str(s.id) for s in rows if s.trial_expires_at is not None
                or (s.paid_until is not None and utc(s.paid_until) <= now)]}


def due_reminder(deadline, previous, now):
    deadline, previous, now = utc(deadline), utc(previous), utc(now)
    if deadline <= now:
        return None
    due = None
    for hours in REMIND_HOURS:
        candidate = deadline - timedelta(hours=hours)
        if candidate <= now:
            due = candidate
    return due if due is not None and (previous is None or previous < due) else None


def send_reminders(db, now):
    """Uses the existing email transport and durable server reminder marker.

    Row locking serializes normal overlapping cron runs, renewals and expiry.
    Delivery retries after errors; a crash after provider acceptance may repeat
    a notification, like the existing paid renewal notification implementation.
    """
    from . import email_service
    from .wallet_service import active_order
    now = utc(now)
    ids = [r[0] for r in db.query(Server.id).filter(
        Server.trial_expires_at > now,
        Server.trial_expires_at <= now + timedelta(hours=24),
        Server.paid_until.is_(None), Server.status == ServerStatus.running).limit(100).all()]
    db.rollback()
    for ident in ids:
        try:
            server = db.query(Server).filter_by(id=ident).populate_existing().with_for_update(skip_locked=True).one_or_none()
            if server is None or not renewable(db, server) or active_order(db, ident):
                db.rollback()
                continue
            due = due_reminder(server.trial_expires_at, server.renewal_reminder_for, now)
            if due is None:
                db.rollback()
                continue
            deadline = utc(server.trial_expires_at).strftime('%Y-%m-%d %H:%M UTC')
            base = str(email_service.settings.frontend_base_url).rstrip('/')
            email_service._send(server.owner_email,
                f'PulsarX: подарочный Nano {server.container_name} скоро будет удалён',
                f'Срок бесплатного Nano {server.container_name} заканчивается {deadline}.\n\n'
                'Если вы не оплатите продление до удаления, VPS и его данные будут удалены. '
                'Чтобы сохранить этот сервер, откройте личный кабинет, пополните баланс '
                'при необходимости и отдельно подтвердите платное продление Nano. '
                'Остаток бесплатного времени сохраняется. После продления можно перейти на Mini или Plus.\n\n'
                'Если VPS уже истёк, сначала продлите его, затем выбирайте апгрейд. '
                'После удаления восстановить VPS этим платежом нельзя. '
                'Автоматического списания нет.\n\n'
                f'{base}/dashboard/\n\n— PulsarX Cloud')
            server.renewal_reminder_for = due
            db.commit()
        except Exception:
            db.rollback()
            logger.exception('Gift expiry reminder will retry: %s', ident)
