#!/usr/bin/env python3
"""Guarded public CSS update. No backend, payment, email or VPS operation."""
import argparse,fcntl,hashlib,json,os,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse

RELEASE='SERVER-CARDS-20261110-r1'
STYLE='/* One public server-card layout, scoped to the instances page. */\nhtml body #page-instances .page-head{justify-content:space-between;text-align:left;gap:20px;align-items:center;margin-bottom:26px}\nhtml body #page-instances .page-head h1{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;font-size:30px;line-height:1.2;font-weight:650;letter-spacing:-.025em}\nhtml body #page-instances .page-head>.btn{position:static;flex-shrink:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;font-size:13px;line-height:1.4;min-height:42px;padding:10px 16px;letter-spacing:normal}\nhtml body #page-instances #serversContent{min-width:0;width:100%}\nhtml body #page-instances #serversContent .server-workspace{align-items:start;justify-items:stretch;min-width:0}\nhtml body #page-instances #serversContent .server-list{width:100%;min-width:0;margin:0;justify-self:stretch}\nhtml body #page-instances #serversContent .server-grid,\nhtml body #page-instances #serversContent .server-grid:has(>.server-card:only-child){display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,340px),1fr));justify-items:stretch;align-items:start;gap:20px;width:100%;min-width:0;margin:0}\nhtml body #page-instances #serversContent .has-selection .server-grid{grid-template-columns:minmax(0,1fr)}\nhtml body #page-instances #serversContent .server-card,\nhtml body #page-instances #serversContent .server-card:only-child{\n  box-sizing:border-box;display:flex;flex-direction:column;align-self:start;justify-self:stretch;\n  width:100%;max-width:none!important;min-width:0;min-height:0;height:auto;margin:0;padding:22px;\n  border:1px solid #493752;border-radius:16px;background:linear-gradient(145deg,#100914,#050407 90%);\n  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;\n  font-size:14px;line-height:1.5;font-style:normal;letter-spacing:normal;color:#f0eaf7;\n  transform:none;filter:none;text-shadow:none;\n}\nhtml body #page-instances #serversContent .server-card.selected{border-color:#ac78d1!important}\nhtml body #page-instances #serversContent .server-heading{display:flex;flex-direction:row;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;width:100%;margin:0}\nhtml body #page-instances #serversContent .server-identity{display:flex;align-items:center;flex:1 1 180px;min-width:0;gap:10px}\nhtml body #page-instances #serversContent .server-identity>div{min-width:0;flex:1}\nhtml body #page-instances #serversContent .server-symbol{display:grid!important;place-items:center;flex:0 0 34px;width:34px;height:34px;border:1px solid #533960;border-radius:9px;background:#1c0b27;color:#bd93d8}\nhtml body #page-instances #serversContent .server-symbol svg{width:17px;height:17px}\nhtml body #page-instances #serversContent .server-identity h3{max-width:none;margin:0;color:#f2edf9;font-family:inherit;font-size:15px!important;font-weight:600;line-height:1.4;letter-spacing:normal;white-space:normal;overflow:visible;overflow-wrap:anywhere;text-overflow:clip}\nhtml body #page-instances #serversContent .server-identity small{display:block;margin:3px 0 0;color:#b5a7c2;font-family:inherit;font-size:12px;line-height:1.5;letter-spacing:normal}\nhtml body #page-instances #serversContent .server-heading>.status-badge{position:static!important;flex:0 0 auto;align-self:center;max-width:100%!important;margin:0;padding:5px 8px!important;font-family:inherit;font-size:11px!important;line-height:1.4;font-weight:500;letter-spacing:normal;white-space:normal;color:#b9d8c9;background:#101711;border-color:#2e4037}\nhtml body #page-instances #serversContent .server-heading>.status-badge:not(.status-running){color:#c2b3d0;background:#130c1b;border-color:#42334e}\nhtml body #page-instances #serversContent .server-heading>.status-badge::before{background:currentColor}\nhtml body #page-instances #serversContent .server-heading>.status-badge.status-failed,\nhtml body #page-instances #serversContent .server-heading>.status-badge.status-held{color:#f1a4b8;background:#26131d;border-color:#623141}\nhtml body #page-instances #serversContent .server-heading>.status-badge.status-suspended{color:#ddc08d;background:#211a11;border-color:#59472a}\nhtml body #page-instances #serversContent .server-specs{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,.85fr) minmax(0,1.35fr);gap:12px;margin:22px 0 20px;padding:0;min-width:0}\nhtml body #page-instances #serversContent .server-card .server-specs>span,\nhtml body #page-instances #serversContent .server-card .server-specs>span+span,\nhtml body #page-instances #serversContent .server-card .server-specs>span:first-child{grid-column:auto;display:block;min-width:0;padding:0;border:0;background:none}\nhtml body #page-instances #serversContent .server-card .server-specs small,\nhtml body #page-instances #serversContent .server-card .server-specs>span:first-child small{display:flex;align-items:center;gap:5px;min-height:0;margin:0 0 7px;color:#b5a7c2;font-family:inherit;font-size:11px;line-height:1.45;font-weight:400;letter-spacing:normal}\nhtml body #page-instances #serversContent .server-specs small svg{width:12px;height:12px;flex:0 0 12px;margin:0;color:#a38ab8}\nhtml body #page-instances #serversContent .server-card .server-specs strong,\nhtml body #page-instances #serversContent .server-card .server-specs>span:first-child strong{display:block;margin:0;color:#f1ebf8;font-family:inherit;font-size:16px!important;font-weight:600;line-height:1.35;letter-spacing:normal;font-variant-numeric:tabular-nums;overflow-wrap:normal}\nhtml body #page-instances #serversContent .server-card .server-term{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:end;gap:12px;margin:0;padding:16px 0 0;border-top:1px solid #35273f;min-width:0}\nhtml body #page-instances #serversContent .server-term>div{min-width:0}\nhtml body #page-instances #serversContent .server-term small{display:block;margin:0 0 5px;color:#b5a7c2;font-family:inherit;font-size:11px;line-height:1.45;letter-spacing:normal}\nhtml body #page-instances #serversContent .server-card .server-term strong{display:block;margin:0;color:#e8deef;font-family:inherit;font-size:13px;font-weight:500;line-height:1.5;letter-spacing:normal;overflow-wrap:anywhere}\nhtml body #page-instances #serversContent .server-term .term-left{margin:0;color:#99cdb3;font-family:inherit;font-size:12px;line-height:1.5;font-weight:400;letter-spacing:normal;white-space:normal;text-align:right}\nhtml body #page-instances #serversContent .server-card .server-actions{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;margin:20px 0 0;padding:0;width:100%}\nhtml body #page-instances #serversContent .server-card .server-actions>.btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;min-height:42px;min-width:0;margin:0;padding:10px 13px;border-radius:9px;font-family:inherit;font-size:13px;font-weight:500;line-height:1.4;letter-spacing:normal;white-space:normal;text-align:center;transform:none}\nhtml body #page-instances #serversContent .server-actions>.btn:only-child{grid-column:1/-1}\nhtml body #page-instances #serversContent .server-actions>.btn svg{width:15px;height:15px;flex:0 0 15px}\n@media(max-width:1100px){html body #page-instances #serversContent .server-workspace.has-selection{grid-template-columns:minmax(0,1fr)}html body #page-instances #serversContent .has-selection .server-list{position:static}}\n@media(max-width:680px){html body #page-instances #serversContent .server-grid,html body #page-instances #serversContent .server-grid:has(>.server-card:only-child){grid-template-columns:minmax(0,1fr)}html body #page-instances .page-head{gap:12px;align-items:center}html body #page-instances .page-head h1{font-size:27px}html body #page-instances .page-head>.btn{font-size:12px;padding:10px 12px}html body #page-instances #serversContent .server-card{padding:20px}html body #page-instances #serversContent .server-identity{flex-basis:160px}}\n@media(max-width:380px){html body #page-instances .page-head{align-items:flex-start;flex-direction:column}html body #page-instances #serversContent .server-specs{gap:9px}html body #page-instances #serversContent .server-card{padding:18px}html body #page-instances #serversContent .server-card .server-term{grid-template-columns:minmax(0,1fr)}html body #page-instances #serversContent .server-term .term-left{text-align:left}html body #page-instances #serversContent .server-card .server-actions{grid-template-columns:minmax(0,1fr)}html body #page-instances #serversContent .server-actions>.btn{width:100%}}\n'
ASSET='px-server-cards-r1.css'
WEB=Path('/var/www/html')
STATE=Path('/var/lib/pulsarx-server-cards')
ENTRY=Path('/usr/local/lib/pulsarx-server-cards/entry.py')
SERVICE='pulsarx-server-cards-update.service'


class Stop(RuntimeError):pass
def sha(raw):return hashlib.sha256(raw).hexdigest()


def read(path):
    p=Path(path);s=p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
    return p.read_bytes()


def atomic(path,raw,mode=0o600,uid=0,gid=0):
    path=Path(path)
    if path.is_symlink():raise Stop('Symlink target rejected')
    raw=raw.encode() if isinstance(raw,str) else raw
    fd,temp=tempfile.mkstemp(prefix='.server-cards-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),mode);os.fchown(stream.fileno(),uid,gid)
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def unit():
    r=subprocess.run(['systemctl','show',SERVICE,'-p','ActiveState','--value'],capture_output=True,text=True,timeout=10)
    return r.stdout.strip()


def check_host():
    if os.geteuid()!=0:raise Stop('Run with sudo on the application host')
    r=subprocess.run(['ip','-json','address','show'],capture_output=True,text=True,timeout=10,check=True)
    ips={a.get('local') for n in json.loads(r.stdout) for a in n.get('addr_info',[])}
    if '192.0.2.11' not in ips:raise Stop('Wrong host: application host 192.0.2.11 required')
    for path in (WEB,):
        info=path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022:raise Stop('Unsafe website directory')


class Page(HTMLParser):
    def __init__(self,source):
        super().__init__(convert_charrefs=False)
        self.links=[];self.heads=[];self.offsets=[0]
        for line in source.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.feed(source);self.close()
    def handle_starttag(self,tag,attrs):
        if tag!='link':return
        if len([k for k,v in attrs if k=='href'])>1:raise Stop('Ambiguous stylesheet link')
        attrs=dict(attrs)
        if 'stylesheet' in attrs.get('rel','').split():self.links.append(attrs.get('href',''))
    def handle_endtag(self,tag):
        if tag=='head':
            line,column=self.getpos();self.heads.append(self.offsets[line-1]+column)


def eligible(relative):
    return bool(relative.parts) and relative.parts[0].lower()=='dashboard'


def update_html(raw):
    source=raw.decode('utf-8');page=Page(source)
    if any(urlparse(href).path=='/'+ASSET for href in page.links):return raw
    marker=False
    for href in page.links:
        url=urlparse(href)
        if url.scheme not in ('','https') or url.netloc not in ('','pulsarx.example.invalid'):continue
        name=Path(url.path).name
        if name.startswith('px-pulse-') and name.endswith('.css'):marker=True
    if not marker:return raw
    if len(page.heads)!=1:raise Stop('Public page has an unexpected head structure')
    index=page.heads[0]
    return (source[:index]+'<link rel="stylesheet" href="/'+ASSET+'">'+source[index:]).encode('utf-8')


def planned(web=WEB):
    web=Path(web);result={};asset=web/ASSET
    if asset.exists() and read(asset)!=STYLE.encode():raise Stop('Existing server cards stylesheet differs')
    pages={}
    for p in sorted(web.rglob('*.html')):
        rel=p.relative_to(web)
        if not eligible(rel):continue
        if p.is_symlink() or not p.resolve().is_relative_to(web.resolve()):raise Stop('Unexpected public page symlink')
        original=read(p);updated=update_html(original)
        if updated!=original:pages[p]=updated
    if not asset.exists():result[asset]=STYLE.encode()
    result.update(pages)
    return result


def load():
    return json.loads(read(STATE/'status.json')) if (STATE/'status.json').exists() else {}


def save(state,phase,message):
    state.update(release=RELEASE,phase=phase,message=message,updated_at=int(time.time()))
    atomic(STATE/'status.json',json.dumps(state,indent=2)+'\n')
    print(phase.upper()+': '+message,flush=True)


def verify(state):
    if not state.get('files'):raise Stop('No saved installation inventory')
    if state.get('asset_path') and read(state['asset_path'])!=STYLE.encode():
        raise Stop('Installed server cards stylesheet changed')
    for name,item in state['files'].items():
        if sha(read(name))!=item['after_sha256']:raise Stop('Installed file changed: '+name)


def rollback(state):
    for name,item in reversed(list(state.get('files',{}).items())):
        p=Path(name);actual=sha(read(p)) if p.exists() else None
        if actual==item['before_sha256']:continue
        if actual!=item['after_sha256']:raise Stop('Refusing to overwrite an unrelated edit: '+name)
        if item['backup']:
            raw=read(item['backup'])
            if sha(raw)!=item['before_sha256']:raise Stop('Backup checksum differs')
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        else:p.unlink()


def worker():
    state=load()
    if state.get('phase')=='complete':verify(state);return
    if state.get('phase')=='applying':
        rollback(state);save(state,'rolled_back','Interrupted public file transaction recovered')
    plan=planned()
    if not plan:raise Stop('No pending server cards changes; run --verify')
    backup=Path('/var/backups')/('pulsarx-server-cards-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+uuid.uuid4().hex[:8])
    backup.mkdir(mode=0o700)
    state={'backup':str(backup),'asset_path':str(WEB/ASSET),'files':{}}
    for index,(p,raw) in enumerate(plan.items()):
        previous=read(p) if p.exists() else None;info=p.stat() if p.exists() else None
        b=backup/str(index) if previous is not None else None
        if b:atomic(b,previous)
        state['files'][str(p)]={'before_sha256':sha(previous) if previous is not None else None,
            'after_sha256':sha(raw),'backup':str(b) if b else None,
            'mode':stat.S_IMODE(info.st_mode) if info else 0o644,
            'uid':info.st_uid if info else 0,'gid':info.st_gid if info else 0}
    save(state,'applying','Installing aligned server cards and readable typography; all services stay running')
    try:
        for p,raw in plan.items():
            item=state['files'][str(p)];actual=sha(read(p)) if p.exists() else None
            if actual!=item['before_sha256']:raise Stop('File changed after staging: '+str(p))
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        verify(state)
        save(state,'complete','Aligned server cards and readable typography installed; scripts and backend unchanged; API and VPS stayed online')
    except Exception as exc:
        rollback(state);save(state,'rolled_back','File changes reverted: '+str(exc));raise


def main():
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    for name in ('apply','worker','check','status','verify'):group.add_argument('--'+name,action='store_true')
    args=parser.parse_args();check_host()
    STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o077:raise Stop('Unsafe checkpoint directory')
    print('RELEASE: '+RELEASE,flush=True)
    if args.status:print(json.dumps(load(),indent=2));return
    if args.verify:verify(load());print('VERIFIED: installed CSS and public page hashes');return
    if args.check:
        plan=planned();print('CHECK OK: '+str(len(plan))+' presentation-only file updates; no production files changed');return
    if args.worker:
        with open(STATE/'worker.lock','a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);worker()
        return
    if load().get('phase')=='complete':verify(load());print('ALREADY COMPLETE');return
    if unit() not in ('active','activating','deactivating'):
        ENTRY.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        info=ENTRY.parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o077:raise Stop('Unsafe worker directory')
        atomic(ENTRY,read(Path(__file__)))
        state=load()
        if state.get('phase')!='applying':save(state,'queued','Starting independent public style worker')
        subprocess.run(['systemd-run','--unit=pulsarx-server-cards-update','--collect','--no-block','--service-type=exec',
            '/usr/bin/python3',str(ENTRY),'--worker'],capture_output=True,check=True,timeout=15)
    began=time.monotonic()
    for _ in range(60):
        state=load();phase=state.get('phase')
        if phase=='complete':print('FINISHED: '+state['message']);return
        status=unit()
        if status in ('inactive','failed') and not (phase=='queued' and time.monotonic()-began<10):
            raise Stop('Worker stopped; run --status and journalctl -u '+SERVICE)
        print('WORKING: '+str(phase),flush=True);time.sleep(2)
    raise Stop('Worker still running; use --status')


if __name__=='__main__':
    try:main()
    except Exception as exc:print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(1)
