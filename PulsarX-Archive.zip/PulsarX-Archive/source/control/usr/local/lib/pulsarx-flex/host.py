"""Native offline relocation with durable checkpoints, exact filesystem checks."""
import copy,importlib.util,json,os,socket
from pathlib import Path
from shared import *
import flex_probe as probe
import pool_cleanup
HOLD=STATE/'host.hold';MARKER='user.pulsarx.flex'
BACKUP=Path('/opt/pulsarx-backup/backup_manager.py')
EXPECTED_BACKUP_SHA='a93d00170895a932c5062bb13fc200a1c8ceb3433133f3021038505d2789c9d0'
def local(*args,timeout=60,data=None):return run(['incus','--force-local','--project','default',*args],'Incus '+args[0],timeout,data)
def query(path):
    if 'project=' not in path and 'all-projects=' not in path:path+=('&' if '?' in path else '?')+'project=default'
    return incus_metadata(run(['incus','--force-local','query','--raw',path],'Read Incus metadata '+path),path)
def item(name):return query('/1.0/instances/'+name)
def pools():return {p['name']:p for p in query('/1.0/storage-pools?recursion=1')}
def size(raw):
    m=re.fullmatch(r'([1-9][0-9]*)(GiB|GB|MiB|MB)',str(raw))
    if not m:raise Stop('Unsupported explicit resource size')
    return int(m[1])*{'GiB':GIB,'GB':10**9,'MiB':1024**2,'MB':10**6}[m[2]]
def maintenance(s):
    raw=query('/1.0').get('config',{}).get('user.pulsarx.storage_maintenance')
    try:owner=json.loads(raw).get('nonce') if raw else None
    except (ValueError,AttributeError):owner=None
    if owner!=s['nonce']:raise Stop('Compute maintenance is not owned by this prepared deployment')
def load_backup():
    if sha(regular(BACKUP))!=EXPECTED_BACKUP_SHA:raise Stop('The verified backup helper changed')
    spec=importlib.util.spec_from_file_location('px_existing_backup',BACKUP);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def root(name,pool):return probe.root_path(name,pool)
MOVE_BOOT_KEYS={'volatile.cloud-init.instance-id','volatile.uuid.generation'}
def verify_identity(s,name,deferred_boot_keys=()):
    before=s['guests'][name]['before'];live=item(name)
    ignored={'boot.autostart','limits.cpu','limits.cpu.allowance','limits.memory','limits.memory.enforce',MARKER,'volatile.root.apply_quota','volatile.apply_template'}
    if live['profiles']!=before['profiles'] or set(live['devices'])!=set(before['devices']):raise Stop('Guest profiles/device names changed')
    # Incus 6.0.4 nicBridged.postStop clears this host-side veth name; Start
    # generates it again. It is runtime state, separate from the stable guest
    # MAC/name/IP and all NIC/proxy device options checked below. Never exempt
    # the entire volatile namespace or write the previous veth name back.
    ignored.update('volatile.'+device+'.host_name' for device,dev in live.get('expanded_devices',live['devices']).items() if dev.get('type')=='nic')
    changes=[k for k,v in before['config'].items() if k not in ignored and k not in deferred_boot_keys and not k.startswith('volatile.last_state.') and live['config'].get(k,'' if k in MOVE_BOOT_KEYS else None)!=v]
    if changes:raise Stop('Guest identity/security setting changed: '+name+' / '+', '.join(sorted(changes)))
    for k,v in before['devices'].items():
        if v.get('type')=='disk' and v.get('path')=='/':continue
        if live['devices'].get(k)!=v:raise Stop('Guest network or port device changed: '+name)
    if live['config'].get(MARKER)!=s['nonce']:raise Stop('Guest maintenance ownership changed')
    return live
def preserve_move_boot_metadata(s,name):
    """Incus pool moves copy+rename; restore boot IDs only in verified offline moves.

    Incus 6.0.4 instanceCreate resets generation to uuid and Rename resets
    cloud-init ID. Neither field can simply be ignored before customer boot.
    The fixed saved UUID/idmap/NIC/proxy settings must still match first.
    """
    g=s['guests'][name];before=g['before']['config'];live=item(name)
    changed=[k for k in sorted(MOVE_BOOT_KEYS) if live['config'].get(k,'')!=before.get(k,'')]
    if not changed:return
    # No repair is permitted before a completed native move, on a running
    # guest, or after this deployment could have allowed guest writes.
    expected={'moving_out':g['temp_pool'],'recreating':g['temp_pool'],
              'moving_back':name+'-pool','starting':name+'-pool'}.get(g['step'])
    pool=live.get('expanded_devices',{}).get('root',{}).get('pool')
    if not expected or pool!=expected or live.get('status')!='Stopped' or g.get('may_have_written'):
        verify_identity(s,name)
        raise Stop('Boot metadata differs outside a verified offline move: '+name+' / '+', '.join(changed))
    # This explicit defer is private to the recovery gate; all ordinary
    # identity checks remain strict, including both boot keys after repair.
    checked=verify_identity(s,name,MOVE_BOOT_KEYS)
    if checked['status']!='Stopped' or checked['expanded_devices']['root']['pool']!=expected:raise Stop('Stopped move scope changed before boot metadata preservation')
    if not g.get('backup') or not g.get('digest'):
        raise Stop('Verified customer bytes and offline backup are required before preserving boot metadata')
    if probe.tree_digest(root(name,pool))!=g['digest']:raise Stop('Stopped customer filesystem differs; boot metadata preservation blocked')
    g['boot_metadata_repair']={'pool':pool,'keys':changed}
    save('host',s,'resizing','Preserving original boot metadata for '+name+' before startup.')
    for key in changed:
        value=before.get(key,'')
        if value:local('config','set',name,key+'='+value)
        else:local('config','unset',name,key)
    verify_identity(s,name)
    if any(item(name)['config'].get(k,'')!=before.get(k,'') for k in MOVE_BOOT_KEYS):raise Stop('Original boot metadata did not remain applied')
    g['boot_metadata_preserved']=True;g.pop('boot_metadata_repair',None);save('host',s)
def remove_copy_template(s,name):
    live=item(name)
    if live['config'].get('volatile.apply_template') in ('copy','create'):
        if s['guests'][name]['before']['config'].get('volatile.apply_template'):raise Stop('An original image template trigger needs review')
        local('config','unset',name,'volatile.apply_template')
class RelocatedPool(pool_cleanup.Incus):
    def __init__(self,s,name):
        self.s,self.name=s,name
        super().__init__(lambda args,timeout=60:run(['incus','--force-local',*args[1:]],'Inspect/purge cached images',timeout).decode())
    def instances(self):
        result=[]
        for row in super().instances():
            if row['name']!=self.name:result.append(row);continue
            ct=verify_identity(self.s,self.name)
            if ct['status']!='Stopped' or ct['expanded_devices']['root']['pool']!=self.s['guests'][self.name]['temp_pool']:raise Stop('Guest is not stopped in its verified temporary pool')
            if any(d.get('pool')==self.name+'-pool' for d in ct['expanded_devices'].values()):raise Stop('A guest device still references the canonical pool')
        return result
def canonical_config(p,name):
    c=p['config']
    if p['driver']!='btrfs' or c.get('source')!='/var/lib/incus/disks/'+name+'-pool.img':raise Stop('Canonical backing image ownership/source differs')
    # btrfs.Create stores the provided source in volatile.initial_source.
    # It is absent/empty for an automatically selected loop image and equals
    # the canonical image for our explicit-source recreation. Retain strict
    # source ownership checks instead of exempting all volatile pool settings.
    if 'volatile.initial_source' in c and c['volatile.initial_source'] not in ('',c['source']):raise Stop('Canonical initial backing source differs: volatile.initial_source')
    unexpected=sorted(k for k in c if k not in ('size','source','volatile.initial_source') and not k.startswith('user.'))
    if unexpected:raise Stop('Custom pool settings need review: '+', '.join(unexpected))
    return c
def inspect_scope(plan):
    info=query('/1.0')
    if info['environment'].get('certificate_fingerprint')!=plan['incus_fingerprint'] or info['environment'].get('server_clustered') is not False:raise Stop('Compute identity or standalone contract differs')
    rows=query('/1.0/instances?recursion=1&all-projects=true')
    if {r['name'] for r in rows}!={r['container_name'] for r in plan['servers']}:raise Stop('Live instance inventory changed')
    if any(r.get('project','default')!='default' or r.get('type')!='container' or r['status'] not in ('Running','Stopped') for r in rows):raise Stop('Unexpected instance project/type/state')
    return rows
def hold_backup(s):
    atomic(HOLD,s['nonce']+'\n');guard('pulsarx-container-backup.service',HOLD);run(['systemctl','daemon-reload'],'Load backup hold')
    for u in HOST_TIMERS:set_unit(u,'stop')
    if busy('pulsarx-container-backup.service'):raise Stop('A backup started during maintenance acquisition')
def restore_timer(s):
    HOLD.unlink(missing_ok=True)
    for u,was in s.get('timers',{}).items():
        if was:set_unit(u,'start')
def begin(path):
    check_host('host');private_dir(STATE);p=validate_plan(read_json(path));old=read_json(STATE/'host.json')
    if old:
        if old['nonce']!=p['nonce']:raise Stop('Another deployment owns this node')
        return validate_plan(old)
    rows=inspect_scope(p);maintenance(p)
    if busy('pulsarx-container-backup.service'):raise Stop('Let the running backup finish')
    if unit('pulsarx-container-backup.service','Result')!='success':raise Stop('A successful ordinary backup is required first')
    from backup_preflight import require_proof
    require_proof({r['container_name'] for r in p['servers']})
    load_backup();s={**p,'role':'host','phase':'prepared','probe_token':p['nonce'],'guests':{},'timers':{u:unit(u)=='active' for u in HOST_TIMERS}}
    available=pools()
    for ct in rows:
        name=ct['name'];pool=available.get(name+'-pool')
        if not pool or ct['expanded_devices'].get('root',{}).get('pool')!=name+'-pool':raise Stop('A guest no longer uses its dedicated canonical pool')
        canonical_config(pool,name)
        s['guests'][name]={'before':{k:ct[k] for k in ('config','devices','profiles','status')},'pool_before':pool,'step':'pending','temp_pool':'px-flex-'+s['nonce'][:8]+'-'+name[-10:]}
    save('host',s,'prepared','Host scope saved; probe and native moves will run independently.');return s
def wait_idle():
    def ready():
        groups=query('/1.0/operations?recursion=1')
        if isinstance(groups,dict):
            if any(not isinstance(values,list) for values in groups.values()):raise Stop('Incus operation groups have an unexpected type')
            rows=[r for values in groups.values() for r in values]
        else:rows=groups
        if not isinstance(rows,list) or any(not isinstance(r,dict) or type(r.get('status_code')) is not int for r in rows):raise Stop('Incus operation inventory differs')
        return not any(100<=r['status_code']<200 for r in rows)
    wait_for(ready,'Prior Incus operations',120)
def limits(name,p):local('config','set',name,'limits.cpu='+str(p['cpu_cores']),'limits.cpu.allowance=100%','limits.memory='+str(p['ram_mb'])+'MiB','limits.memory.enforce=hard')
def autostart(s,name):
    v=s['guests'][name]['before']['config'].get('boot.autostart')
    if v is None:local('config','unset',name,'boot.autostart')
    else:local('config','set',name,'boot.autostart='+v)
def ssh_ready(row):
    try:
        with socket.create_connection(('127.0.0.1',int(row['ssh_port'])),timeout=3) as s:s.settimeout(3);return s.recv(256).startswith(b'SSH-2.0-')
    except OSError:return False
def keep_large(s,name,p,reason):
    g=s['guests'][name];quota=size(g['pool_before']['config']['size'])//GIB
    limits(name,p);local('config','device','set',name,'root','size='+str(quota)+'GiB')
    if g['step']!='pending':
        autostart(s,name)
        if g['before']['status']=='Running' and item(name)['status']=='Stopped':local('start',name,timeout=150)
    g.update(step='complete',disk_gb=quota,legacy_disk_retained=True,reason=reason);save('host',s,'resizing','Kept larger disk for '+name+'; RAM/CPU updated.')
def create_canonical(s,name,target):
    if name+'-pool' in pools():return
    old=s['guests'][name]['pool_before']['config'];extras=[k+'='+v for k,v in old.items() if k.startswith('user.') and k!=MARKER]
    local('storage','create',name+'-pool','btrfs','source='+old['source'],'size='+str(target)+'GiB',MARKER+'='+s['nonce'],*extras,timeout=120)
def convert(s,row,backup):
    name=row['container_name'];g=s['guests'][name];p=CATALOG['plans'][row['plan']];target=p['disk_gb'];canonical=name+'-pool';tmp=g['temp_pool']
    if g['step']=='complete':return
    maintenance(s)
    preserve_move_boot_metadata(s,name)
    if g['step']=='pending':
        snapshots=query('/1.0/instances/'+name+'/snapshots?recursion=1');usage=query('/1.0/instances/'+name+'/state').get('disk',{}).get('root',{}).get('usage')
        if snapshots or (usage is not None and int(usage)>target*GIB*7//10):keep_large(s,name,p,'Snapshots/data need the existing larger quota');return
        local('config','set',name,MARKER+'='+s['nonce'],'boot.autostart=false');g['step']='stopping';save('host',s,'resizing','Stopping only '+name+' for its verified offline move.')
    if g['step']=='stopping':
        ct=verify_identity(s,name)
        if ct['status']=='Running':local('stop',name,'--timeout','120',timeout=150)
        if item(name)['status']!='Stopped':raise Stop('Graceful stop was not confirmed')
        used=int(run(['du','-sx','--block-size=1',str(root(name,canonical))],'Measure stopped filesystem',180).split()[0])
        if used>target*GIB*7//10:keep_large(s,name,p,'Stopped filesystem needs the existing larger quota');return
        local('config','device','set',name,'root','size='+str(target)+'GiB');g['digest']=probe.tree_digest(root(name,canonical))
        if not g['digest']['entries']:raise Stop('The customer filesystem is unexpectedly empty')
        g['step']='backing_up';save('host',s)
    if g['step']=='backing_up':
        verify_identity(s,name)
        if item(name)['status']!='Stopped':raise Stop('Offline backup requires the stopped original')
        folder=private_dir(STATE/'offline-backups');path=folder/(name+'.tar.gz');partial=folder/(name+'.partial.tar.gz')
        if not path.exists():
            if partial.exists():
                backup.validate_archive(partial);os.replace(partial,path)
            else:
                local('export',name,str(partial),'--compression','gzip','--quiet',timeout=3600);backup.validate_archive(partial);os.replace(partial,path)
        g['backup']=backup.validate_archive(path);g['step']='moving_out';save('host',s)
    if g['step']=='moving_out':
        ct=verify_identity(s,name)
        if ct['expanded_devices']['root']['pool']==canonical:
            if probe.tree_digest(root(name,canonical))!=g['digest']:raise Stop('Stopped source changed after backup')
            if tmp not in pools():local('storage','create',tmp,'btrfs','size='+str(target)+'GiB',MARKER+'='+s['nonce'],timeout=120)
            if pools()[tmp]['config'].get(MARKER)!=s['nonce']:raise Stop('Temporary pool ownership differs')
            local('move',name,'--storage',tmp,timeout=3600)
        preserve_move_boot_metadata(s,name);remove_copy_template(s,name);ct=verify_identity(s,name)
        if ct['status']!='Stopped' or ct['expanded_devices']['root']['pool']!=tmp:raise Stop('Native move target was not confirmed')
        if probe.tree_digest(root(name,tmp))!=g['digest']:raise Stop('Temporary bytes/IDs/links/xattrs differ')
        g['step']='recreating';save('host',s,'resizing','Verified '+name+' in the smaller temporary pool.')
    if g['step']=='recreating':
        ct=verify_identity(s,name)
        if ct['status']!='Stopped' or ct['expanded_devices']['root']['pool']!=tmp or probe.tree_digest(root(name,tmp))!=g['digest']:raise Stop('Verified stopped temporary copy is required')
        available=pools()
        if canonical in available and available[canonical]['config'].get(MARKER)!=s['nonce']:
            if available[canonical]['config']!=g['pool_before']['config']:raise Stop('Old canonical pool changed')
            RelocatedPool(s,name).purge_images(name)
            if query('/1.0/storage-pools/'+canonical).get('used_by'):raise Stop('Old pool still has references')
            local('storage','delete',canonical,timeout=120)
        create_canonical(s,name,target);installed=pools()[canonical];canonical_config(installed,name)
        if installed['config'].get(MARKER)!=s['nonce'] or size(installed['config']['size'])!=target*GIB:raise Stop('Recreated canonical pool was not confirmed')
        g['step']='moving_back';save('host',s)
    if g['step']=='moving_back':
        ct=verify_identity(s,name)
        if ct['expanded_devices']['root']['pool']==tmp:local('move',name,'--storage',canonical,timeout=3600)
        preserve_move_boot_metadata(s,name);remove_copy_template(s,name);ct=verify_identity(s,name)
        if ct['status']!='Stopped' or ct['expanded_devices']['root']['pool']!=canonical or probe.tree_digest(root(name,canonical))!=g['digest']:raise Stop('Final canonical filesystem verification failed')
        g['step']='starting';save('host',s,'resizing','Verified canonical filesystem for '+name+'.')
    if g['step']=='starting':
        verify_identity(s,name);remove_copy_template(s,name);limits(name,p);autostart(s,name);g['may_have_written']=True;save('host',s)
        if g['before']['status']=='Running':
            if item(name)['status']=='Stopped':local('start',name,timeout=150)
            wait_for(lambda:ssh_ready(row),'Guest SSH '+name,120)
        available=pools()
        if tmp in available:
            if available[tmp]['config'].get(MARKER)!=s['nonce'] or available[tmp].get('used_by'):raise Stop('Temporary pool ownership/references changed')
            local('storage','delete',tmp,timeout=120)
        g.update(step='complete',disk_gb=target,filesystem_verified=True);save('host',s,'resizing','Completed '+name+'; original identity and ports retained.')
def receipt(s):return {'release':RELEASE,'nonce':s['nonce'],'phase':'complete','incus_fingerprint':s['incus_fingerprint'],'instances':[{'name':r['container_name'],'plan':r['plan'],**CATALOG['plans'][r['plan']],'disk_gb':s['guests'][r['container_name']]['disk_gb'],'filesystem_verified':bool(s['guests'][r['container_name']].get('filesystem_verified')),'legacy_disk_retained':bool(s['guests'][r['container_name']].get('legacy_disk_retained'))} for r in s['servers']]}
def worker():
    check_host('host');lock=process_lock('host');backup_lock=None;s=journal('host')
    try:
        if s.get('phase')=='complete':return
        s['worker_step']='incus_preflight';save('host',s,'checking','Reading Incus maintenance and operation inventory through raw JSON replies.')
        maintenance(s);wait_idle()
        if busy('pulsarx-container-backup.service'):raise Stop('Let the ordinary backup finish')
        backup_lock=open('/run/lock/pulsarx-container-backup.lock','a');fcntl.flock(backup_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        hold_backup(s);backup=load_backup()
        if not s.get('driver_probe',{}).get('passed'):
            if any(g.get('step')!='pending' for g in s['guests'].values()):raise Stop('Guest work began without a saved successful native probe')
            # An r1 checkpoint has no recorded foreground probe token. Never
            # guess ownership of a resource left by that older process.
            if not s.get('probe_token'):s['probe_token']=s['nonce'];save('host',s)
            if s['probe_token']!=s['nonce']:raise Stop('Saved native probe ownership differs')
            save('host',s,'probing','Checking the owned empty native-move probe; customer VPS remain running.')
            probe.cleanup_probe(s['probe_token']);inspect_scope(s)
            result=probe.driver_probe(s['probe_token'])
            if not result.get('passed') or not result.get('cleanup'):raise Stop('Native smaller-pool probe did not pass')
            s['driver_probe']=result;save('host',s,'prepared','Native move probe passed and removed; proceeding to customer resources.')
        inspect_scope(s);largest=max(size(g['pool_before']['config']['size']) for g in s['guests'].values());fs=os.statvfs('/')
        if fs.f_bavail*fs.f_frsize<2*largest+8*GIB:raise Stop('Insufficient offline working space before stopping a customer')
        for row in s['servers']:convert(s,row,backup)
        raw=regular(Path(__file__).parent/'flex_backup.py');compile(raw,'flex_backup.py','exec');atomic('/opt/pulsarx-backup/flex_backup.py',raw,mode=0o700)
        path=Path('/opt/pulsarx-backup/backup_containers.sh');before=regular(path);old=b'exec /usr/bin/python3 /opt/pulsarx-backup/backup_manager.py --backup';new=b'exec /usr/bin/python3 /opt/pulsarx-backup/flex_backup.py --backup'
        if before.count(old)!=1 and before.count(new)!=1:raise Stop('Backup wrapper differs')
        if not (STATE/'backup-wrapper.before').exists():atomic(STATE/'backup-wrapper.before',before)
        atomic(path,before.replace(old,new),mode=0o700);run(['bash','-n',str(path)],'Backup wrapper syntax');restore_timer(s)
        run(['systemctl','start','pulsarx-capacity-publish.service'],'Refresh capacity sample',60)
        write_json(STATE/'host-receipt.json',receipt(s));save('host',s,'complete','Guest resources and sequential backups ready; apply the control host to resume the API.')
    except BaseException as exc:save('host',s,'failed',str(exc));raise
    finally:
        if backup_lock:backup_lock.close()
        lock.close()
