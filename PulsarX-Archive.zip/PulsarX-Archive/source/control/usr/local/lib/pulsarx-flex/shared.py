"""Fixed-scope local deployment journals and process helpers."""
import fcntl,hashlib,json,os,re,stat,subprocess,tempfile,time
from pathlib import Path
LIB=Path('/usr/local/lib/pulsarx-flex');STATE=Path('/var/lib/pulsarx-flex');RELEASE='FLEX-20261108-r1';BUILD='FLEX-20261109-r1.6';GIB=1024**3
CATALOG=json.loads((Path(__file__).parent/'catalog.json').read_text())
APP_TIMERS=['pulsarx-wallet.timer','pulsarx-payments.timer','pulsarx-billing-check.timer','pulsarx-error-alert.timer','pulsarx-host-alert.timer']
HOST_TIMERS=['pulsarx-container-backup.timer'];HOSTS={'control':'192.0.2.11','host':'192.0.2.12'}
class Stop(RuntimeError):pass
def incus_metadata(raw,path):
    from flex_probe import decode_query,Stop as ProtocolError
    try:return decode_query(raw,path)
    except ProtocolError as exc:raise Stop(str(exc)) from None
def sha(raw):return hashlib.sha256(raw).hexdigest()
def private_dir(path):
    p=Path(path);p.mkdir(parents=True,exist_ok=True,mode=0o700);s=p.lstat()
    if not stat.S_ISDIR(s.st_mode) or s.st_uid!=0 or s.st_mode&0o022:raise Stop('Unsafe private directory: '+str(p))
    p.chmod(0o700);return p
def regular(path,limit=8*1024**2):
    p=Path(path);s=p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size>limit:raise Stop('Expected a bounded regular file: '+str(p))
    return p.read_bytes()
def atomic(path,raw,mode=0o600,uid=0,gid=0):
    p=Path(path)
    if p.is_symlink():raise Stop('Symlink write target rejected')
    raw=raw.encode() if isinstance(raw,str) else raw;fd,tmp=tempfile.mkstemp(prefix='.px-flex-',dir=p.parent)
    try:
        with os.fdopen(fd,'wb') as out:
            os.fchmod(out.fileno(),mode);os.fchown(out.fileno(),uid,gid);out.write(raw);out.flush();os.fsync(out.fileno())
        os.replace(tmp,p);d=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(d)
        finally:os.close(d)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def read_json(path,default=None):return json.loads(regular(path)) if Path(path).exists() else default
def write_json(path,v):atomic(path,json.dumps(v,sort_keys=True,indent=2)+'\n')
def run(args,label,timeout=60,data=None,env=None):
    e={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root','LC_ALL':'C'};e.update(env or {})
    try:r=subprocess.run([str(x) for x in args],input=data,capture_output=True,timeout=timeout,env=e,cwd='/')
    except subprocess.TimeoutExpired:raise Stop(label+' timed out; inspect the saved checkpoint') from None
    if r.returncode:
        private_dir(STATE);fd,path=tempfile.mkstemp(prefix='private-error-',suffix='.log',dir=STATE)
        with os.fdopen(fd,'wb') as f:os.fchmod(f.fileno(),0o600);f.write(r.stdout[-65536:]+r.stderr[-65536:])
        raise Stop(label+' failed (exit '+str(r.returncode)+'); private diagnostic: '+path)
    return r.stdout
def check_host(role):
    if os.geteuid()!=0:raise Stop('Use sudo/root')
    links=json.loads(run(['ip','-json','address','show'],'Host identity'))
    if HOSTS[role] not in {a.get('local') for row in links for a in row.get('addr_info',[])}:raise Stop('Wrong host for '+role)
def unit(name,key='ActiveState'):
    p=subprocess.run(['systemctl','show',name,'-p',key,'--value'],capture_output=True,timeout=15)
    return p.stdout.decode().strip() or {'ActiveState':'inactive','SubState':'dead'}.get(key,'')
def busy(name):return unit(name) in ('active','activating','deactivating','reloading') and unit(name,'SubState')!='exited'
def worker_pending(s):
    name=s.get('worker_unit')
    if not name:return False
    if busy(name) or unit(name,'Job') not in ('','0','0 /'):return True
    return s.get('phase')=='queued' and int(time.time())-s.get('queued_at',s.get('updated_at',0))<30
def set_unit(name,verb):run(['systemctl',verb,name],verb+' '+name,180)
def guard(name,hold):
    p=Path('/etc/systemd/system')/(name+'.d');p.mkdir(mode=0o755,exist_ok=True)
    atomic(p/'pulsarx-flex.conf','[Unit]\nConditionPathExists=!'+str(hold)+'\n',mode=0o644)
def wait_for(predicate,label,seconds=90):
    deadline=time.monotonic()+seconds
    while not predicate():
        if time.monotonic()>=deadline:raise Stop(label+' did not become ready')
        time.sleep(2)
def process_lock(role):
    private_dir(STATE);f=open(STATE/(role+'.lock'),'a')
    try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:f.close();raise Stop('Another '+role+' worker is still running') from None
    return f
def journal(role):
    s=read_json(STATE/(role+'.json'))
    if not s or s.get('release')!=RELEASE:raise Stop('This role is not prepared')
    return s
def save(role,s,phase=None,message=None):
    s['updated_at']=int(time.time());s['build']=BUILD
    if phase:s['phase']=phase
    if message:s['message']=message
    write_json(STATE/(role+'.json'),s)
    if message:print('PHASE: '+s.get('phase','')+' | '+message,flush=True)
def validate_plan(p):
    if not isinstance(p,dict) or p.get('release')!=RELEASE or p.get('catalog')!=CATALOG:raise Stop('Plan release/catalog differs')
    if not re.fullmatch('[0-9a-f]{32}',str(p.get('nonce',''))):raise Stop('Invalid nonce')
    rows=p.get('servers',[])
    if len(rows)!=2 or {r.get('container_name'):r.get('plan') for r in rows}!={'mini-0f419f50e2':'mini','mini-eeed8e64f0':'plus'}:raise Stop('The two production instances changed; refresh inventory')
    if any(r.get('status') not in ('running','suspended') for r in rows):raise Stop('An instance is transitioning')
    return p
