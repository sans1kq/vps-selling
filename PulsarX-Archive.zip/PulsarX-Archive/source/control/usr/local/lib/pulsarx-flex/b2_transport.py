"""Try DNS endpoints through verified TLS before sending any HTTP request."""
import http.client,json,re,socket,ssl,sys,time
API_HOST=re.compile(r'api[0-9]*\.backblazeb2\.com\Z')
PER_ATTEMPT_TIMEOUT=5.0
TOTAL_CONNECT_BUDGET=20.0
CACHE_SECONDS=300.0
_ORIGINAL=http.client.HTTPSConnection.connect
_GOOD={}

def _fields(exc):
    fields={'kind':type(exc).__name__}
    if isinstance(getattr(exc,'errno',None),int):fields['errno']=exc.errno
    if isinstance(getattr(exc,'verify_code',None),int):fields['certificate_verify_code']=exc.verify_code
    return fields

def connect(connection):
    host=connection.host
    if not isinstance(host,str) or not API_HOST.fullmatch(host) or connection.port!=443 or connection._tunnel_host:
        return _ORIGINAL(connection)
    context=connection._context
    if context.verify_mode!=ssl.CERT_REQUIRED or not context.check_hostname:raise ssl.SSLError('Verified TLS context is required for the backup API')
    sys.audit('http.client.connect',connection,host,connection.port)
    timeout=connection.timeout
    if timeout is socket._GLOBAL_DEFAULT_TIMEOUT:timeout=socket.getdefaulttimeout()
    budget=min(TOTAL_CONNECT_BUDGET,timeout) if isinstance(timeout,(float,int)) and timeout>0 else TOTAL_CONNECT_BUDGET
    deadline=time.monotonic()+budget;rows=[];seen=set()
    for af,kind,proto,_,address in socket.getaddrinfo(host,connection.port,0,socket.SOCK_STREAM):
        key=(af,kind,proto,address)
        if key not in seen:seen.add(key);rows.append(key)
    if not rows:raise OSError('No backup API address returned by DNS')
    cached=_GOOD.get(host)
    if cached and 0<=time.monotonic()-cached[1]<CACHE_SECONDS and cached[0] in rows:
        rows.remove(cached[0]);rows.insert(0,cached[0])
    last=TimeoutError('Backup API connection deadline exceeded')
    for af,kind,proto,address in rows[:8]:
        sock=None;secured=None;stage='TCP'
        try:
            remaining=deadline-time.monotonic()
            if remaining<=0:break
            sock=socket.socket(af,kind,proto);sock.settimeout(min(PER_ATTEMPT_TIMEOUT,remaining))
            if connection.source_address:sock.bind(connection.source_address)
            sock.connect(address)
            sock.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('Backup API connection deadline exceeded')
            stage='TLS';sock.settimeout(min(PER_ATTEMPT_TIMEOUT,remaining))
            secured=context.wrap_socket(sock,server_hostname=host)
            secured.settimeout(timeout);connection.sock=secured;_GOOD[host]=((af,kind,proto,address),time.monotonic())
            return
        except OSError as exc:
            last=exc
            if secured is not None:secured.close()
            if sock is not None:sock.close()
            print('B2 CONNECT RETRY: '+json.dumps({'host':host,'ip':address[0],'stage':stage,**_fields(exc)},sort_keys=True),flush=True)
    connection.sock=None
    raise last

def enable():
    current=http.client.HTTPSConnection.connect
    if current not in (_ORIGINAL,connect):raise RuntimeError('Another HTTPS transport override is active')
    http.client.HTTPSConnection.connect=connect

def disable():
    if http.client.HTTPSConnection.connect is connect:http.client.HTTPSConnection.connect=_ORIGINAL
