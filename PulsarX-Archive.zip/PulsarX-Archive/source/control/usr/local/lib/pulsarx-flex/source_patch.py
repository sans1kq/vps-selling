"""Never replace sanitized originals as whole files."""
import ast,hashlib
def apply_edits(raw,contract):
    if hashlib.sha256(raw).hexdigest()!=contract['input_sha256']:raise ValueError('Live source checksum differs')
    lines=raw.decode().splitlines(keepends=True)
    for e in reversed(contract['edits']):
        if ''.join(lines[e['start']:e['end']])!=e['old']:raise ValueError('Live source hunk differs')
        if '[REDACTED]' in e['old']+e['new']:raise ValueError('Private placeholder entered a source edit')
        lines[e['start']:e['end']]=e['new'].splitlines(keepends=True)
    result=''.join(lines).encode();ast.parse(result);return result
