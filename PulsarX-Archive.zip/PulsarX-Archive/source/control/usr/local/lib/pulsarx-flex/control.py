"""Guarded source/UI apply and CPU/RAM/disk-only entitlement transaction."""
import json,pwd,urllib.error,urllib.request,uuid
from pathlib import Path
from shared import *
from source_patch import apply_edits
ROOT=Path('/opt/pulsarx-backend');WEB=Path('/var/www/html');HOLD=STATE/'api.hold';DATA=Path(__file__).parent/'data'
NEW_FILES=('app/flex_catalog.json','app/flex_catalog.py','app/flex_capacity.py')
EDITS=read_json(DATA/'backend-edits.json');FRONT=read_json(DATA/'frontend-manifest.json')
def pg(statement,write=False):
    sql=('BEGIN'+('' if write else ' READ ONLY')+"; SET LOCAL statement_timeout='20s'; SET LOCAL lock_timeout='4s'; SET LOCAL search_path=pg_catalog; "+statement+'; '+('COMMIT' if write else 'ROLLBACK')+';')
    return json.loads(run(['runuser','-u','postgres','--','psql','-X','-q','-A','-t','-v','ON_ERROR_STOP=1','--dbname=pulsarx'],'Resource database transaction',30,data=sql.encode()))
def inventory():return pg("SELECT COALESCE(json_agg(row_to_json(s)),'[]'::json) FROM (SELECT id,container_name,plan,status,cpu_cores,ram_mb,disk_gb,paid_until,ssh_port,web_port,password_set,admin_suspended_at FROM public.servers WHERE status<>'deleted' ORDER BY container_name) s")
def finance_digest():
    parts=[]
    for table in ('servers','payments','wallet_accounts','wallet_entries','wallet_orders','wallet_topups'):
        value="(to_jsonb(t)-'cpu_cores'-'ram_mb'-'disk_gb')::text" if table=='servers' else 'row_to_json(t)::text'
        parts.extend(["'"+table+"'","(SELECT md5(COALESCE(string_agg(h,'' ORDER BY h),'')) FROM (SELECT md5("+value+') AS h FROM public.'+table+' t) v)'])
    return pg('SELECT json_build_object('+','.join(parts)+')')
def no_orders():
    v=pg("SELECT json_build_object('orders',(SELECT count(*) FROM public.wallet_orders WHERE status IN ('queued','working','review')),'invoices',(SELECT count(*) FROM public.payments WHERE status='needs_review' OR (status IN ('created','pending') AND expires_at>now())))")
    if v['orders'] or v['invoices']:raise Stop('Let existing orders/invoices finish or expire before changing the installed catalog')
def api_cli(*args,timeout=40):return run(['runuser','-u','pulsarx','-g','pulsarx','--','incus',*args],'Existing application Incus remote',timeout,env={'HOME':'/home/pulsarx','INCUS_CONF':'/home/pulsarx/.config/incus','INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'})
def query(path):
    return incus_metadata(api_cli('query','--raw',path),path)
def http(path,expected=200):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));req=urllib.request.Request('http://127.0.0.1:8000'+path,headers={'Authorization':'Bearer invalid-pulsarx-flex-private-health','Cache-Control':'no-cache'})
    try:
        with opener.open(req,timeout=5) as r:code=r.status;raw=r.read(1024**2)
    except urllib.error.HTTPError as exc:code=exc.code;raw=b''
    if code!=expected:raise Stop('API returned '+str(code)+' for '+path)
    return json.loads(raw) if raw else None
def health():
    try:return http('/api/health').get('status')=='ok' and http('/api/auth/me',401) is None
    except (Stop,OSError,ValueError):return False
def preflight_sources():
    outputs={}
    for name,c in EDITS.items():
        try:outputs[str(ROOT/name)]=apply_edits(regular(ROOT/name),c)
        except ValueError as exc:raise Stop(str(exc)+': '+name) from None
    for name in NEW_FILES:
        if (ROOT/name).exists():raise Stop('A catalog module already exists outside this prepared release: '+name)
        outputs[str(ROOT/name)]=regular(DATA/'backend'/name)
    for name,c in FRONT['pages'].items():
        if sha(regular(WEB/name))!=c['input_sha256']:raise Stop('Public page changed: '+name)
        raw=regular(DATA/'frontend'/name)
        if sha(raw)!=c['output_sha256']:raise Stop('Packaged page digest differs')
        outputs[str(WEB/name)]=raw
    for name,h in FRONT['assets'].items():
        raw=regular(DATA/'frontend'/name)
        if sha(raw)!=h:raise Stop('Packaged asset digest differs')
        if (WEB/name).exists() and sha(regular(WEB/name))!=h:raise Stop('New asset filename already has different bytes')
        outputs[str(WEB/name)]=raw
    return outputs
def owned_maintenance(s,clear=False):
    raw=query('/1.0').get('config',{}).get('user.pulsarx.storage_maintenance')
    try:owner=json.loads(raw).get('nonce') if raw else None
    except (ValueError,AttributeError):owner=None
    if raw and owner!=s['nonce']:raise Stop('Another compute maintenance is active')
    if clear:
        if raw:api_cli('config','unset','user.pulsarx.storage_maintenance')
    else:api_cli('config','set','user.pulsarx.storage_maintenance='+json.dumps({'release':RELEASE,'nonce':s['nonce'],'phase':'flex'}))
def begin_prepare():
    """Only stage a private journal; all service/DB checks run in systemd."""
    check_host('control');private_dir(STATE);s=read_json(STATE/'control.json')
    if s:
        if s.get('release')!=RELEASE:raise Stop('Another deployment release owns the application journal')
        if s.get('prepared'):return s
        if s.get('files') or s.get('db_resources_applied') or s.get('resume_started'):raise Stop('Continue the saved application apply checkpoint')
        if not re.fullmatch('[0-9a-f]{32}',str(s.get('nonce',''))):raise Stop('Saved preparation nonce differs')
        return s
    s={'release':RELEASE,'role':'control','catalog':CATALOG,'nonce':uuid.uuid4().hex,'phase':'preparing','created_at':int(time.time())}
    save('control',s);return s
def prepare():
    check_host('control');lock=process_lock('control');s=None;acquired=False
    try:
        s=begin_prepare()
        if s.get('prepared'):return s
        if unit('pulsarx-api.service','User')!='pulsarx' or unit('pulsarx-api.service','WorkingDirectory')!=str(ROOT):raise Stop('Application service identity changed')
        preflight_sources();no_orders()
        held=HOLD.exists()
        if held and regular(HOLD).decode().strip()!=s['nonce']:raise Stop('Another deployment owns the API hold')
        if not held and not health():raise Stop('Current API/private authentication is unhealthy')
        for u in [x.removesuffix('.timer')+'.service' for x in APP_TIMERS]+['pulsarx-backup.service']:
            if busy(u):raise Stop('Let the running application job finish: '+u)
        rows=inventory();info=query('/1.0')
        if info['environment'].get('server_name','').split('.')[0]!='pulsar2':raise Stop('Application remote is not the new compute')
        raw=info.get('config',{}).get('user.pulsarx.storage_maintenance')
        if raw:
            try:owner=json.loads(raw).get('nonce')
            except (ValueError,AttributeError):owner=None
            if owner!=s['nonce']:raise Stop('Another compute maintenance is active')
        fingerprint=info['environment']['certificate_fingerprint']
        if held:
            validate_plan(s)
            if rows!=s['servers'] or fingerprint!=s['incus_fingerprint'] or set(s.get('timers',{}))!=set(APP_TIMERS) or not s.get('api_was_active'):raise Stop('Interrupted preparation baseline differs')
        else:
            s.update(servers=rows,incus_fingerprint=fingerprint,api_was_active=True,timers={u:unit(u)=='active' for u in APP_TIMERS})
            validate_plan(s)
        save('control',s,'preparing','Checking and acquiring the saved API/timer pause.')
        acquired=True;owned_maintenance(s);atomic(HOLD,s['nonce']+'\n')
        for u in ['pulsarx-api.service',*[x.removesuffix('.timer')+'.service' for x in APP_TIMERS]]:guard(u,HOLD)
        run(['systemctl','daemon-reload'],'Load persistent application hold')
        for u in APP_TIMERS:set_unit(u,'stop')
        for u in [x.removesuffix('.timer')+'.service' for x in APP_TIMERS]:
            if busy(u):raise Stop('An application job started during maintenance acquisition')
        set_unit('pulsarx-api.service','stop')
        if unit('pulsarx-api.service')!='inactive' or inventory()!=rows:raise Stop('Consistent API/database pause was not confirmed')
        no_orders();s['finance_before']=finance_digest();raw=run(['runuser','-u','postgres','--','pg_dump','--format=custom','--dbname=pulsarx'],'Private pre-change DB backup',180)
        if not raw.startswith(b'PGDMP'):raise Stop('Database backup header differs')
        atomic(STATE/'database-before.dump',raw);write_json(STATE/'plan.json',{k:s[k] for k in ('release','catalog','nonce','servers','incus_fingerprint','created_at')});s['prepared']=True
        save('control',s,'prepared','API/timers paused; existing VPS continue running. Next: apply-host.');return s
    except BaseException as exc:
        if s is not None:
            message='Preparation stopped before changing services: '+str(exc)
            if acquired:
                try:
                    owned_maintenance(s,clear=True)
                    if HOLD.exists():
                        if regular(HOLD).decode().strip()!=s['nonce']:raise Stop('API hold ownership changed; retained')
                        HOLD.unlink()
                    set_unit('pulsarx-api.service','start')
                    for u,was in s['timers'].items():set_unit(u,'start' if was else 'stop')
                    message='Preparation stopped; original API/timers restored. '+str(exc)
                except BaseException as cleanup:
                    message='Preparation needs attention at its saved checkpoint: '+str(exc)+'; restore: '+str(cleanup)
            elif HOLD.exists():message='Interrupted preparation remains held for a checked retry: '+str(exc)
            save('control',s,'failed_prepare',message)
        raise
    finally:lock.close()
def host_resources(s,r):
    if r.get('release')!=RELEASE or r.get('nonce')!=s['nonce'] or r.get('phase')!='complete' or r.get('incus_fingerprint')!=s['incus_fingerprint']:raise Stop('Host receipt identity/phase differs')
    actual={c['name']:c for c in query('/1.0/instances?recursion=1&project=default')};targets={x['name']:x for x in r['instances']}
    if set(actual)!=set(targets) or set(targets)!={x['container_name'] for x in s['servers']}:raise Stop('Instance scope differs')
    from host import size
    for row in s['servers']:
        name=row['container_name'];p=CATALOG['plans'][row['plan']];x=targets[name];ct=actual[name];cfg=ct['expanded_config'];root=ct['expanded_devices']['root']
        if x['plan']!=row['plan'] or any(x[k]!=p[k] for k in ('ram_mb','cpu_cores')) or type(x['disk_gb']) is not int or x['disk_gb'] not in (row['disk_gb'],p['disk_gb']):raise Stop('Receipt resource specification differs')
        if not x.get('filesystem_verified') and not x.get('legacy_disk_retained'):raise Stop('Disk integrity outcome missing')
        if int(cfg.get('limits.cpu','0'))!=x['cpu_cores'] or size(cfg.get('limits.memory'))!=x['ram_mb']*1024**2:raise Stop('Live CPU/RAM differs from the receipt')
        if root.get('pool')!=name+'-pool' or size(root.get('size'))!=x['disk_gb']*GIB:raise Stop('Live root quota differs')
        pool=query('/1.0/storage-pools/'+name+'-pool?project=default')
        if pool['driver']!='btrfs' or pool['config'].get('source')!='/var/lib/incus/disks/'+name+'-pool.img' or size(pool['config']['size'])!=x['disk_gb']*GIB:raise Stop('Live dedicated physical pool differs')
        if row['status']=='running' and ct['status']!='Running':raise Stop('A previously running guest is not running')
    return targets
def finish_staging(s,outputs=None):
    if outputs is None:
        outputs={}
        for path,m in s['files'].items():
            if path.startswith(str(ROOT)+'/'):
                rel=Path(path).relative_to(ROOT).as_posix();outputs[path]=apply_edits(regular(m['backup']),EDITS[rel]) if rel in EDITS else regular(DATA/'backend'/rel)
            else:outputs[path]=regular(DATA/'frontend'/Path(path).relative_to(WEB))
    for path,m in s['files'].items():
        p=Path(path);actual=sha(regular(p)) if p.exists() else None
        if actual==m['after_sha256']:continue
        if actual!=m['before_sha256'] or sha(outputs[path])!=m['after_sha256']:raise Stop('A file has neither original nor target bytes: '+path)
        atomic(p,outputs[path],mode=m['mode'],uid=m['uid'],gid=m['gid'])
    s['files_staged']=True;save('control',s)
def stage_sources(s):
    if s.get('files'):
        finish_staging(s);return
    outputs=preflight_sources();entries={};folder=private_dir(STATE/'files-before')
    for i,(name,raw) in enumerate(outputs.items()):
        p=Path(name);old=regular(p) if p.exists() else None;st=p.stat() if old is not None else None;backup=folder/str(i)
        if old is not None:atomic(backup,old)
        entries[name]={'before_sha256':sha(old) if old is not None else None,'backup':str(backup),'after_sha256':sha(raw),'uid':st.st_uid if st else 0,'gid':st.st_gid if st else 0,'mode':stat.S_IMODE(st.st_mode) if st else 0o644}
    s['files']=entries;save('control',s);finish_staging(s,outputs)
def update_resources(s,targets):
    if finance_digest()!=s['finance_before']:raise Stop('Non-resource financial/server fields changed during maintenance')
    records=[{'id':row['id'],**{k:targets[row['container_name']][k] for k in ('cpu_cores','ram_mb','disk_gb')}} for row in s['servers']];payload=json.dumps(records,separators=(',',':')).replace("'","''")
    sql="SELECT pg_advisory_xact_lock(7001); WITH target AS (SELECT * FROM json_to_recordset('"+payload+"'::json) AS x(id uuid,cpu_cores integer,ram_mb integer,disk_gb integer)), changed AS (UPDATE public.servers s SET cpu_cores=t.cpu_cores,ram_mb=t.ram_mb,disk_gb=t.disk_gb FROM target t WHERE s.id=t.id RETURNING s.id) SELECT count(*) FROM changed"
    if pg(sql,write=True)!=len(records):raise Stop('Resource update row count differs')
    if finance_digest()!=s['finance_before']:raise Stop('Non-resource fields changed during resource-only update')
    s['db_resources_applied']=True;save('control',s)
def smoke_code():
    code="""import os,sys,json
os.chdir('/opt/pulsarx-backend');sys.path.insert(0,os.getcwd())
from dotenv import load_dotenv
load_dotenv('/opt/pulsarx-backend/.env')
from app.routers import servers,wallet,admin_capacity
from app.database import SessionLocal
from app.flex_capacity import capacity_report
from sqlalchemy import text
db=SessionLocal()
try:
 db.execute(text('SET TRANSACTION READ ONLY'))
 r=capacity_report(db)
 print(json.dumps({'catalog':servers.get_pricing(),'memory_budget_bytes':r['memory_budget_bytes'],'memory_reserved_bytes':r['memory_reserved_bytes'],'disk_available_bytes':r['available_for_new_bytes'],'cpu_allocated':r['cpu_allocated']}))
finally:db.rollback();db.close()
"""
    return json.loads(run(['runuser','-u','pulsarx','-g','pulsarx','--',str(ROOT/'venv/bin/python3'),'-c',code],'Read-only installed catalog/resource check',60,env={'HOME':'/home/pulsarx','INCUS_CONF':'/home/pulsarx/.config/incus','INCUS_REMOTE':'vps2','INCUS_PROJECT':'default'}))
def restore_timers(s):
    for u,was in s['timers'].items():
        if was:set_unit(u,'start')
def apply(path):
    check_host('control');lock=process_lock('control');s=journal('control')
    try:
        if s.get('phase')=='complete':return
        if s.get('resume_started') and not HOLD.exists() and health():
            if {p['id']:p['price_cents'] for p in http('/api/servers/pricing')['plans']}!={'nano':175,'mini':300,'plus':500}:raise Stop('Resumed catalog differs')
            restore_timers(s);save('control',s,'complete','Recovered completed API resume; current user data retained.');return
        if not s.get('prepared') or not HOLD.exists() or unit('pulsarx-api.service')!='inactive':raise Stop('Prepared stopped application required')
        owned_maintenance(s);targets=host_resources(s,read_json(path));stage_sources(s);save('control',s,'applying','Three-plan backend/UI staged; applying CPU/RAM/disk-only entitlements.');update_resources(s,targets);r=smoke_code()
        if {p['id']:p['price_cents'] for p in r['catalog']['plans']}!={'nano':175,'mini':300,'plus':500}:raise Stop('Catalog prices differ')
        run(['nginx','-t'],'Nginx configuration syntax')
        if finance_digest()!=s['finance_before']:raise Stop('Financial fields changed before API resume')
        s['resource_report']=r;s['resume_started']=True;save('control',s);owned_maintenance(s,clear=True);HOLD.unlink(missing_ok=True);set_unit('pulsarx-api.service','start');wait_for(health,'API health/private authentication',60)
        if http('/api/servers/pricing').get('plans')!=r['catalog']['plans']:raise Stop('Live catalog differs')
        restore_timers(s);save('control',s,'complete','Nano $1.75, Mini $3, Plus $5 live; shared resources/current quotas verified; balances and paid dates preserved.')
    except BaseException as exc:
        if s.get('resume_started'):atomic(HOLD,s['nonce']+'\n');set_unit('pulsarx-api.service','stop');owned_maintenance(s)
        save('control',s,'failed',str(exc));raise
    finally:lock.close()
