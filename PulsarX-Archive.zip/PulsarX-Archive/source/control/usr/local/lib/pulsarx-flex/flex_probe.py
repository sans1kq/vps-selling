#!/usr/bin/env python3
"""Check live readiness for PulsarX Flex; existing VPS are never stopped.

Control: source hashes, read-only DB inventory, API/auth status.
Compute: current limits/storage usage and an owned empty-container move probe.
The probe verifies 4 -> 3 GiB relocation through two pools, without touching
customer pools or reading customer files. No email/payment/provider operation.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

RELEASE = 'FLEX-CHECK-20261108-r1'
MARKER = 'user.pulsarx.flex_probe'
EXPECTED_SOURCES = {'app/capacity_service.py': 'e20d112e2a971c0c6faf6cda4992c579179986de249b2f2fe83fb8010e432b02', 'app/growth_service.py': '46f52023f23c1b2ef23d4cff6d8973f46516cd7f71be99dc1c00441bd9e44405', 'app/incus_service.py': '7cc21218f9e35680a5fd7ea72a219410f3783662bc137910e0f53c411526e068', 'app/payments_service.py': 'c6161010862a3d94ff00b1bfb8b1faf0914f6ee4fa839c0c261390a4b11052c1', 'app/routers/admin.py': 'b059ad0782e6fd82e1a14d0c649a68c39b9838fced4c2fc63e773d71ba7f1b8a', 'app/routers/admin_capacity.py': 'aa888379b0bb51fcf5f6fb6a82a12dce36a924395d7c4d0a722c6a13fdb6a986', 'app/routers/servers.py': 'ad608fcf96a641c8ef8dd5516f31f95cc19115690ec5ae1c688b87483810fceb', 'app/schemas.py': '3adeb1cc0778ebc86b8f1bc12cf33dc3210adda09b9ef8255b85476cf9874096', 'app/wallet_service.py': 'ecbe4710b8cf1ccfcaaf92d799a74a17ab8c8690d6b7e0fe33e98c6df42eb08f', 'app/wallet_worker.py': 'e65d1a1aca82515e1ead4e6185f545b3e9337f562e4e42c7716ddb339b9945bd'}
TARGET_CATALOG = {'version': 1, 'currency': 'USD', 'ram_budget_gib': 42, 'cpu_overcommit': 3, 'plans': {'nano': {'ram_mb': 1024, 'cpu_cores': 1, 'disk_gb': 8, 'price_cents': 175}, 'mini': {'ram_mb': 2048, 'cpu_cores': 1, 'disk_gb': 16, 'price_cents': 300}, 'plus': {'ram_mb': 4096, 'cpu_cores': 2, 'disk_gb': 32, 'price_cents': 500}}}


class Stop(RuntimeError):pass


def run(args, timeout=30, data=None):
    result = subprocess.run(args, input=data, capture_output=True, timeout=timeout)
    if result.returncode:
        # These diagnostics never execute commands with credentials in argv.
        # Keep arbitrary subprocess output private rather than printing it.
        folder=Path('/var/lib/pulsarx-flex-check');folder.mkdir(mode=0o700,exist_ok=True)
        fd, name=tempfile.mkstemp(prefix='command-error-',suffix='.log',dir=folder)
        with os.fdopen(fd,'wb') as f:
            os.fchmod(f.fileno(),0o600);f.write(result.stdout[-64000:]+result.stderr[-64000:])
        raise Stop('Command failed: '+args[0]+' (exit '+str(result.returncode)+'); private diagnostic: '+name)
    return result.stdout


def incus(*args, timeout=60, data=None):
    return run(['incus','--force-local','--project','default',*args],timeout,data)


def decode_query(raw,path):
    """--raw retains the response envelope even for empty metadata (Incus 6)."""
    if not raw or not raw.strip():raise Stop('Empty Incus --raw response for '+path)
    try:response=json.loads(raw)
    except (ValueError,TypeError,UnicodeError):raise Stop('Invalid JSON in Incus --raw response for '+path) from None
    if not isinstance(response,dict) or not {'type','status_code','metadata'}<=set(response):raise Stop('Missing Incus response envelope for '+path)
    if response['type']!='sync' or response['status_code']!=200:
        code=response['status_code'] if type(response['status_code']) is int else 'invalid'
        raise Stop('Incus API did not return success for '+path+' (status '+str(code)+')')
    if not isinstance(response['metadata'],(dict,list)):raise Stop('Unexpected Incus metadata type for '+path)
    return response['metadata']


def query(path):
    # Incus 6.0 query does not accept --project; use the URL query argument.
    if 'project=' not in path and 'all-projects=' not in path:path += ('&' if '?' in path else '?')+'project=default'
    return decode_query(run(['incus','--force-local','query','--raw',path]),path)


def require_host(role):
    if os.geteuid()!=0:raise Stop('Run with sudo/root')
    addresses=json.loads(run(['ip','-json','address','show']))
    target={'control':'192.0.2.11','host':'192.0.2.12'}[role]
    if target not in {a.get('local') for row in addresses for a in row.get('addr_info',[])}:
        raise Stop('Wrong host; expected '+target)


def unit(name, field='ActiveState'):
    return run(['systemctl','show',name,'-p',field,'--value']).decode().strip()


def api_health():
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    status={}
    for path,expected in [('/api/health',200),('/api/auth/me',401)]:
        req=urllib.request.Request('http://127.0.0.1:8000'+path,
            headers={'Authorization':'Bearer invalid-pulsarx-flex-readiness-session'})
        try:
            with opener.open(req,timeout=5) as response:
                code=response.status;raw=response.read(16384)
        except urllib.error.HTTPError as exc:code=exc.code;raw=b''
        if code!=expected:raise Stop('API health/private authentication returned an unexpected status')
        if expected==200 and json.loads(raw).get('status')!='ok':raise Stop('API health body is unexpected')
        status[path]=code
    return status


def control_check():
    sources=[]
    for name,expected in EXPECTED_SOURCES.items():
        path=Path('/opt/pulsarx-backend')/name
        if path.is_symlink() or not path.is_file():raise Stop('Required backend source missing: '+name)
        raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
        sources.append({'path':name,'matches':actual==expected,'sha256':actual})
    sql="""BEGIN READ ONLY;
SET LOCAL statement_timeout='15s'; SET LOCAL lock_timeout='3s'; SET LOCAL search_path=pg_catalog;
SELECT json_build_object(
 'servers', (SELECT COALESCE(json_agg(row_to_json(s)),'[]'::json) FROM
   (SELECT id,container_name,plan,status,cpu_cores,ram_mb,disk_gb,paid_until,
           ssh_port,web_port,password_set,admin_suspended_at
    FROM public.servers WHERE status <> 'deleted' ORDER BY container_name) AS s),
 'active_orders',(SELECT count(*) FROM public.wallet_orders WHERE status IN ('queued','working','review')),
 'active_invoices',(SELECT count(*) FROM public.payments WHERE status='needs_review'
   OR (status IN ('created','pending') AND expires_at>now()))
); ROLLBACK;"""
    inventory=json.loads(run(['runuser','-u','postgres','--','psql','-X','-q','-A','-t',
                            '-v','ON_ERROR_STOP=1','--dbname=pulsarx','-c',sql],timeout=25))
    return {'role':'control','api':api_health(),'service_user':unit('pulsarx-api.service','User'),
            'source_contracts':sources,'database':inventory,
            'ready':all(row['matches'] for row in sources) and inventory['active_orders']==0 and inventory['active_invoices']==0}


def root_path(instance,pool):
    if not re.fullmatch(r'[a-z0-9-]+',instance) or not re.fullmatch(r'[a-z0-9-]+',pool):raise Stop('Invalid probe path')
    p=Path('/var/lib/incus/storage-pools')/pool/'containers'/instance/'rootfs'
    if p.is_symlink() or not p.is_dir():raise Stop('Probe root filesystem is unavailable')
    return p


def tree_digest(root):
    digest=hashlib.sha256();count=0;hardlinks={}
    def emit(value):digest.update(json.dumps(value,ensure_ascii=True,separators=(',',':')).encode()+b'\n')
    for folder,dirs,files in os.walk(root,followlinks=False):
        dirs.sort();files.sort()
        for leaf in dirs+files:
            p=Path(folder)/leaf;rel=p.relative_to(root).as_posix();info=p.lstat()
            attrs=[]
            try:
                for key in sorted(os.listxattr(p,follow_symlinks=False)):
                    attrs.append([key,hashlib.sha256(os.getxattr(p,key,follow_symlinks=False)).hexdigest()])
            except OSError as exc:
                if exc.errno not in (95,61):raise
            common=[rel,stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid,attrs]
            if stat.S_ISLNK(info.st_mode):emit(common+['symlink',os.readlink(p)])
            elif stat.S_ISDIR(info.st_mode):emit(common+['directory'])
            elif stat.S_ISREG(info.st_mode):
                key=(info.st_dev,info.st_ino)
                if info.st_nlink>1 and key in hardlinks:emit(common+['hardlink',hardlinks[key]])
                else:
                    hardlinks[key]=rel;h=hashlib.sha256()
                    with p.open('rb') as stream:
                        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
                    emit(common+['file',info.st_size,h.hexdigest()])
            else:emit(common+['special',stat.S_IFMT(info.st_mode),info.st_rdev])
            count+=1
    return {'sha256':digest.hexdigest(),'entries':count}


def cleanup_probe(token):
    """Recover only the journaled, marked, never-booted disposable resources."""
    if not re.fullmatch('[0-9a-f]{32}',str(token)):raise Stop('Invalid disposable probe ownership token')
    prefix='px-flex-'+token[:10];name=prefix+'-test';profile=prefix+'-profile';pools=[prefix+'-a',prefix+'-b']
    instances={r['name']:r for r in query('/1.0/instances?recursion=1')}
    profiles={r['name']:r for r in query('/1.0/profiles?recursion=1')}
    storage={r['name']:r for r in query('/1.0/storage-pools?recursion=1')}
    instance_refs={'/1.0/instances/'+name,'/1.0/instances/'+name+'?project=default'}
    pool_refs=instance_refs|{'/1.0/profiles/'+profile,'/1.0/profiles/'+profile+'?project=default'}
    if name in instances:
        ct=instances[name];root=ct.get('expanded_devices',{}).get('root',{})
        if ct.get('config',{}).get(MARKER)!=token or ct.get('status')!='Stopped' or ct.get('type')!='container' or ct.get('project','default')!='default' or ct.get('profiles')!=[profile] or set(ct.get('expanded_devices',{}))!={'root'} or root.get('pool') not in pools or root.get('type')!='disk' or root.get('path')!='/':
            raise Stop('Disposable instance ownership/type/state differs; retained')
    if profile in profiles:
        row=profiles[profile]
        if row.get('config',{}).get(MARKER)!=token or not set(row.get('used_by',[]))<=instance_refs:raise Stop('Disposable profile ownership/references differ; retained')
        if any(d.get('type')!='disk' or d.get('path')!='/' or d.get('pool') not in pools for d in row.get('devices',{}).values()):raise Stop('Disposable profile devices differ; retained')
    for pool in pools:
        if pool not in storage:continue
        row=storage[pool];cfg=row.get('config',{})
        if row.get('driver')!='btrfs' or cfg.get(MARKER)!=token or cfg.get('source')!='/var/lib/incus/disks/'+pool+'.img' or cfg.get('size') not in ('3GiB','4GiB') or not set(row.get('used_by',[]))<=pool_refs:
            raise Stop('Disposable pool ownership/source/references differ; retained')
    # Validate the entire scope before deleting anything. No force-delete of a
    # running guest and no adoption of an unmarked resource after a collision.
    if name in instances:incus('delete',name,timeout=90)
    if profile in profiles:
        row=query('/1.0/profiles/'+profile)
        if row.get('config',{}).get(MARKER)!=token or row.get('used_by'):raise Stop('Disposable profile is still referenced; retained')
        incus('profile','delete',profile)
    for pool in reversed(pools):
        if pool not in storage:continue
        row=query('/1.0/storage-pools/'+pool)
        if row.get('config',{}).get(MARKER)!=token or row.get('used_by'):raise Stop('Disposable pool is still referenced; retained')
        incus('storage','delete',pool,timeout=90)


def driver_probe(token=None):
    token=token or uuid.uuid4().hex
    if not re.fullmatch('[0-9a-f]{32}',str(token)):raise Stop('Invalid disposable probe token')
    prefix='px-flex-'+token[:10]
    name=prefix+'-test';profile=prefix+'-profile';pools=[prefix+'-a',prefix+'-b']
    print('DRIVER PROBE: empty marked container; existing VPS stay running.',flush=True)
    steps=[]
    try:
        for pool,size in zip(pools,[4,3]):
            incus('storage','create',pool,'btrfs','size='+str(size)+'GiB',MARKER+'='+token,timeout=90)
        payload={'name':profile,'description':'PulsarX Flex empty move readiness probe','config':{MARKER:token},
                 'devices':{'root':{'type':'disk','path':'/','pool':pools[0],'size':'4GiB'}}}
        # Create the profile and ownership marker in the same request. A kill
        # between profile-create and profile-edit must not leave unowned state.
        run(['incus','--force-local','query','/1.0/profiles?project=default','--request','POST','--data',json.dumps(payload)])
        incus('init',name,'--empty','--profile',profile,'--config',MARKER+'='+token,
              '--config','limits.cpu=1','--config','limits.memory=256MiB',timeout=90)
        incus('config','device','override',name,'root','pool='+pools[0],'size=4GiB')
        # The instance now owns its root device. Remove the profile's reference
        # before testing deletion/recreation of the original pool.
        payload.pop('name');payload['devices']={}
        incus('profile','edit',profile,data=json.dumps(payload).encode())
        before_config=query('/1.0/instances/'+name)['config']
        root=root_path(name,pools[0]);sample=root/'pulsarx-move-probe';sample.mkdir(mode=0o750)
        for index in range(4):
            p=sample/('sample-'+str(index));p.write_bytes((token.encode()*16384));p.chmod(0o640)
        os.link(sample/'sample-0',sample/'hardlink');os.symlink('sample-0',sample/'symlink')
        os.setxattr(sample/'sample-0','user.pulsarx_probe',token.encode())
        before=tree_digest(root)
        incus('config','device','set',name,'root','size=3GiB')
        print('DRIVER PROBE: moving 4 GiB source into 3 GiB target.',flush=True)
        incus('move',name,'--storage',pools[1],timeout=180)
        state=query('/1.0/instances/'+name)
        if state['status']!='Stopped' or state['expanded_devices']['root']['pool']!=pools[1]:raise Stop('Native move target was not confirmed')
        if tree_digest(root_path(name,pools[1]))!=before:raise Stop('Native move changed probe bytes, ownership, links, modes or xattrs')
        steps.append('smaller_pool_move_and_digest')
        if query('/1.0/storage-pools/'+pools[0]).get('used_by'):raise Stop('Probe source pool still has references')
        incus('storage','delete',pools[0])
        incus('storage','create',pools[0],'btrfs','size=3GiB',MARKER+'='+token,timeout=90)
        print('DRIVER PROBE: moving back into recreated canonical pool.',flush=True)
        incus('move',name,'--storage',pools[0],timeout=180)
        state=query('/1.0/instances/'+name)
        if state['expanded_devices']['root']['pool']!=pools[0] or tree_digest(root_path(name,pools[0]))!=before:
            raise Stop('Canonical-pool recreation verification failed')
        identity_keys=['raw.idmap','security.idmap.base','security.idmap.size','volatile.idmap.current','volatile.idmap.next']
        if any(before_config.get(k)!=state['config'].get(k) for k in identity_keys):raise Stop('Probe UID/GID map changed during native move')
        steps.append('canonical_pool_recreated_and_verified')
    finally:
        cleanup_probe(token)
    print('DRIVER PROBE OK: original-name recreation, bytes, modes, owner IDs, links and xattrs; probe removed.',flush=True)
    return {'passed':True,'checks':steps,'cleanup':True,'digest':before}


def host_check(skip_probe=False):
    root=query('/1.0');instances=query('/1.0/instances?recursion=1');pools=query('/1.0/storage-pools?recursion=1')
    by_pool={p['name']:p for p in pools};resources=query('/1.0/resources')
    guests=[]
    for instance in instances:
        name=instance['name']
        if not re.fullmatch(r'mini-[a-f0-9]{10}',name):raise Stop('Unexpected non-customer instance; review inventory first')
        config=instance.get('expanded_config',instance.get('config',{}));disk=instance.get('expanded_devices',{}).get('root',{})
        pool=by_pool.get(disk.get('pool'),{})
        if pool.get('driver')!='btrfs':raise Stop('Expected dedicated Btrfs storage')
        live=query('/1.0/instances/'+name+'/state')
        snapshots=query('/1.0/instances/'+name+'/snapshots?recursion=1')
        guests.append({'name':name,'status':instance['status'],'cpu':config.get('limits.cpu'),
            'memory':config.get('limits.memory'),'pool':disk.get('pool'),'root_quota':disk.get('size'),
            'pool_size':pool.get('config',{}).get('size'),
            'disk_usage_bytes':live.get('disk',{}).get('root',{}).get('usage'),
            'snapshots':len(snapshots),'uid_map_present':bool(config.get('volatile.idmap.current'))})
    status={'active':unit('pulsarx-container-backup.service'),'result':unit('pulsarx-container-backup.service','Result'),
            'exit':unit('pulsarx-container-backup.service','ExecMainStatus')}
    if status['active'] in ('active','activating','deactivating'):raise Stop('Let the running backup finish before the driver probe')
    probe={'skipped':True}
    if not skip_probe:
        lock=open('/run/lock/pulsarx-container-backup.lock','a')
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            probe=driver_probe()
        finally:lock.close()
    cap=root.get('config',{}).get('user.pulsarx.storage_capacity')
    capacity=json.loads(cap) if cap else None
    return {'role':'host','incus_version':root.get('environment',{}).get('server_version'),
            'memory_total_bytes':resources['memory']['total'],'cpu_total':resources['cpu']['total'],
            'root_free_bytes':os.statvfs('/').f_bavail*os.statvfs('/').f_frsize,
            'root_size_bytes':os.statvfs('/').f_blocks*os.statvfs('/').f_frsize,
            'instances':guests,'backup':status,'capacity_sample_version':capacity.get('version') if capacity else None,
            'probe':probe,'ready':probe.get('passed',False)}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--role',choices=['control','host'],required=True)
    ap.add_argument('--skip-driver-probe',action='store_true');args=ap.parse_args()
    print('RELEASE: '+RELEASE,flush=True);require_host(args.role)
    with open('/run/lock/pulsarx-flex-check.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        report=control_check() if args.role=='control' else host_check(args.skip_driver_probe)
    report.update(release=RELEASE,checked_at=datetime.now(timezone.utc).isoformat(),target_catalog=TARGET_CATALOG)
    print('REPORT:\n'+json.dumps(report,ensure_ascii=False,indent=2),flush=True)
    print('CHECK COMPLETE: existing VPS, API, balances, paid periods and production configuration were not changed.',flush=True)
    return 0 if report.get('ready') else 2


if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:print('STOPPED: interrupted; check for marked probe resources before retrying.');sys.exit(2)
    except Exception as exc:
        print('STOPPED: '+(str(exc) if isinstance(exc,Stop) else type(exc).__name__),flush=True);sys.exit(2)
