#!/usr/bin/env python3
"""Ordinary backup entry: existing verifier/policy with DNS+TLS fallback."""
import hashlib,importlib.util,json,os,re,stat,sys,time
from datetime import datetime,timezone
from pathlib import Path
BASE=Path('/opt/pulsarx-backup');STATE=Path('/var/lib/pulsarx-flex')
MANAGER_SHA='a93d00170895a932c5062bb13fc200a1c8ceb3433133f3021038505d2789c9d0'
TRANSPORT_SHA='73abaff41ec315c1e4b3193e9f2e3c08391fa6af11c6cde7e578d35994666abe'
FLEX_SHA='eaa381dabb144a6c1e4047aa2cf5a0df4a96a11be73615d88426bb2c192520cd'
WRAPPERS={'255515133e684390949ecc559dab0a18bd992d2ac169c1bafad31c7c534b2b54': 'legacy', 'c5b7df7453009b375892b8f8aa613c57ebe26850af7c39c2a1c32332abf7bf6c': 'flex'}

def checked(path,digest):
    st=path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=0 or st.st_mode&0o022 or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise RuntimeError('Backup runtime/source checksum differs: '+path.name)

def load(path,name,digest):
    checked(path,digest);spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def claim_reuse(old):
    path=STATE/'reuse-pending.json'
    if not path.exists():return None
    st=path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=0 or st.st_mode&0o077 or st.st_size>65536:raise RuntimeError('Unsafe one-run archive reuse request')
    request=json.loads(path.read_bytes());now=time.time();invocation=os.environ.get('INVOCATION_ID','')
    if request.get('version')!=1 or not re.fullmatch('[0-9a-f]{32}',str(request.get('token',''))) or not re.fullmatch('[0-9a-f]{32}',invocation):raise RuntimeError('One-run archive reuse identity differs')
    target=STATE/('reuse-consumed-'+request['token']+'.json')
    if target.exists():raise RuntimeError('One-run archive reuse was already claimed')
    os.replace(path,target)
    if not 0<=now-request.get('issued_at',0)<=3600:
        old.log('REUSE REQUEST EXPIRED: ordinary fresh exports will run.');return None
    if request.get('names')!=sorted(old.instance_names()):raise RuntimeError('Instance inventory changed before claiming archive reuse')
    request['claimed_invocation']=invocation
    with target.open('wb') as out:
        os.fchmod(out.fileno(),0o600);out.write(json.dumps(request,sort_keys=True).encode());out.flush();os.fsync(out.fileno())
    return request

def reuse_validated_local(old,request):
    if not request:return
    original_plan=old.local_plan;original_export=old.export_instance;cache={}
    def plan(*args,**kwargs):
        result=original_plan(*args,**kwargs);cache.clear();cache.update(result['keep']);return result
    def export(name,directory,report,previous_size=0):
        metadata=cache.get(name)
        if name in request['names'] and metadata:
            p=Path(metadata['path']);key=old.archive_key(p.name)
            if key and key[0]==name and p.parent==directory and old.file_signature(p)==tuple(metadata['signature']):
                created=datetime.strptime(key[1],'%Y%m%d_%H%M%S').replace(tzinfo=timezone.utc).timestamp()
                if 0<=time.time()-created<=86400:
                    old.log('REUSE VALIDATED LOCAL: '+p.name+'; original backup time retained; one invocation only.');return dict(metadata)
        return original_export(name,directory,report,previous_size)
    old.local_plan=plan;old.export_instance=export

def main():
    if os.geteuid()!=0 or sys.argv[1:]!=['--backup']:raise RuntimeError('Run the ordinary backup service as root')
    os.umask(0o077);os.environ.pop('SSLKEYLOGFILE',None)
    wrapper=BASE/'backup_containers.sh';digest=hashlib.sha256(wrapper.read_bytes()).hexdigest();mode=WRAPPERS.get(digest)
    if mode not in ('legacy','flex'):raise RuntimeError('Backup wrapper is neither the reviewed original nor Flex version')
    checked(wrapper,digest)
    transport=load(BASE/'b2_transport.py','pulsarx_b2_transport',TRANSPORT_SHA);transport.enable()
    old=load(BASE/'backup_manager.py','pulsarx_existing_backup',MANAGER_SHA)
    if (BASE/'local').is_symlink():raise RuntimeError('Local backup directory is a symlink')
    (BASE/'local').mkdir(mode=0o700,exist_ok=True);old.safe_parent(BASE/'local')
    if mode=='flex':
        runtime=load(BASE/'flex_backup.py','pulsarx_sequential_backup',FLEX_SHA);runtime.install_runtime(old)
    else:reuse_validated_local(old,claim_reuse(old))
    old.log('B2 TRANSPORT: live DNS candidates, verified TLS, original request timeouts and backup policy.')
    old.main()
if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('ERROR: '+(str(exc) if isinstance(exc,RuntimeError) else type(exc).__name__),file=sys.stderr,flush=True);sys.exit(1)
