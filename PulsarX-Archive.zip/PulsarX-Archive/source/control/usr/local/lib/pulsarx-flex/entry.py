#!/usr/bin/env python3
"""Independent root workers; only the fixed deployment roles are accepted."""
import argparse,json,pwd,sys,uuid
from pathlib import Path
from shared import *
def export_plan():
    owner=pwd.getpwnam('debian');p=Path('/home/debian/pulsarx-flex-plan.json');atomic(p,regular(STATE/'plan.json'),uid=owner.pw_uid,gid=owner.pw_gid);print('PLAN: '+str(p),flush=True)
def launch(role,action='apply',initialize=None):
    check_host(role);launch_lock=process_lock(role+'-launch')
    try:
        s=read_json(STATE/(role+'.json')) or {}
        if action=='prepare' and s.get('prepared'):
            print('ALREADY PREPARED: control; saved plan retained.',flush=True);return
        if worker_pending(s):
            if s.get('worker_action','apply')!=action:raise Stop('A different worker stage is still running; wait for it before continuing')
            print('WORKER: already running or queued independently.',flush=True);return
        lock=process_lock(role)
        try:
            if initialize:initialize()
            s=journal(role)
            if s.get('phase')=='complete':print('ALREADY COMPLETE: '+role,flush=True);return
            if action=='prepare' and s.get('prepared'):return
            name='pulsarx-flex-'+role+'-'+uuid.uuid4().hex[:8]+'.service'
            s.update(worker_unit=name,worker_action=action,queued_at=int(time.time()))
            save(role,s,'queued','Starting independent '+role+' '+action+' worker.')
        finally:lock.close()
        # Release the worker lock before starting it; keep the launch lock until
        # systemd accepted the job so another terminal cannot replace this unit.
        flag='--worker-prepare-control' if action=='prepare' else '--worker-'+role
        run(['systemd-run','--unit='+name,'--collect','--no-block','--property=Type=exec','--property=UMask=0077','--property=RuntimeMaxSec=4h','/usr/bin/python3',str(LIB/'entry.py'),flag],'Start independent '+role+' worker',30)
        print('WORKER: '+name+'; continues after SSH disconnects.',flush=True)
    finally:launch_lock.close()
def status(role):
    check_host(role)
    if role=='host' and not (STATE/'host.json').exists():
        s=read_json(STATE/'backup-preflight.json') or {}
        print(json.dumps({'release':RELEASE,'build':BUILD,'role':'host','phase':'backup_preflight','backup':{k:s.get(k) for k in ('phase','names','started_at','report','verified_at')},'backup_service':unit('pulsarx-container-backup.service'),'backup_result':unit('pulsarx-container-backup.service','Result')},indent=2),flush=True);return
    s=journal(role);v={k:s.get(k) for k in ('release','build','role','phase','message','updated_at','worker_unit','worker_action','worker_step','prepared','db_resources_applied','backup_verified')}
    if role=='control':v['api_state']=unit('pulsarx-api.service');v['api_hold']=(STATE/'api.hold').exists()
    if role=='host':v['instances']={n:{k:g.get(k) for k in ('step','disk_gb','filesystem_verified','legacy_disk_retained')} for n,g in s.get('guests',{}).items()}
    print(json.dumps(v,indent=2),flush=True)
def watch(role,goal='complete'):
    check_host(role);last=None;heartbeat=0;started=time.monotonic()
    while True:
        s=journal(role);summary=s.get('phase'),s.get('message')
        if summary!=last:print('PHASE: '+str(summary[0])+' | '+str(summary[1]),flush=True);last=summary
        if s.get('phase')=='complete' or (goal=='prepared' and s.get('prepared')):return
        active=busy(s.get('worker_unit','nonexistent.service'))
        if s.get('phase') in ('failed','failed_prepare') and not active:raise Stop('Stopped at a saved checkpoint. Use Status, then Continue; no stale guest backup was restored.')
        if s.get('worker_unit') and unit(s['worker_unit']) in ('failed','inactive') and s.get('phase')!='queued':raise Stop('Worker inactive; inspect Status/journal before Continue')
        if s.get('phase')=='queued' and not active and time.monotonic()-started>20:raise Stop('Worker did not start; inspect its saved unit name with journalctl, then Continue')
        if time.monotonic()-heartbeat>=30:heartbeat=time.monotonic();print('WORKING: '+role+' / '+str(s.get('phase'))+'; checkpoint saved.',flush=True)
        time.sleep(3)
def verify_backup():
    check_host('host');s=journal('host')
    if s.get('phase')!='complete':raise Stop('Complete the host move first')
    from host import query,load_backup
    if query('/1.0').get('config',{}).get('user.pulsarx.storage_maintenance'):raise Stop('Apply/resume the control host before the final backup')
    started=int(time.time())
    if not busy('pulsarx-container-backup.service'):
        invocation=unit('pulsarx-container-backup.service','InvocationID');run(['systemctl','start','--no-block','pulsarx-container-backup.service'],'Start ordinary post-change backup');wait_for(lambda:unit('pulsarx-container-backup.service','InvocationID')!=invocation,'New backup invocation',15)
    last=None
    while busy('pulsarx-container-backup.service'):
        raw=run(['journalctl','-u','pulsarx-container-backup.service','-n','1','--no-pager','-o','cat'],'Backup progress').decode().strip()
        print('BACKUP: '+(raw if raw and raw!=last else 'still running; current VPS and API remain available.'),flush=True);last=raw;time.sleep(20)
    if unit('pulsarx-container-backup.service','Result')!='success':raise Stop('Site/VPS changes are live; ordinary backup needs attention. Unverified local files were retained.')
    reports=sorted(Path('/var/backups').glob('pulsarx-container-run-*/complete.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not reports:raise Stop('Verified backup completion report is missing')
    r=read_json(reports[0])
    current={v['name'] for v in query('/1.0/instances?recursion=1&project=default')}
    if reports[0].stat().st_mtime<started or r.get('sequential') is not True or set(r.get('instances',[]))!=current or not set(s['guests'])<=current:raise Stop('A new verified sequential backup for every current guest was not confirmed')
    old=load_backup()
    for g in s['guests'].values():
        m=g.get('backup')
        if not m:continue
        p=Path(m['path'])
        if not p.exists():continue
        if p.parent!=STATE/'offline-backups':raise Stop('Offline archive cleanup path differs')
        current=old.validate_archive(p)
        if current['bytes']!=m['bytes'] or current['sha1']!=m['sha1']:raise Stop('Offline archive changed; retained')
        p.unlink()
    s['backup_verified']=True;s['backup_report']=str(reports[0]);save('host',s);run(['systemctl','start','pulsarx-capacity-publish.service'],'Refresh final capacity sample');print('BACKUP VERIFIED: all current guests; offline work archives released.',flush=True)
def main():
    ap=argparse.ArgumentParser(description=__doc__);g=ap.add_mutually_exclusive_group(required=True)
    for n in ('prepare','prepare-backup','apply-host','apply-control','worker-host','worker-control','worker-prepare-control','verify-host'):g.add_argument('--'+n,action='store_true')
    g.add_argument('--status',choices=['control','host']);g.add_argument('--watch',choices=['control','host']);ap.add_argument('--plan',type=Path);ap.add_argument('--receipt',type=Path);ap.add_argument('--follow',action='store_true');a=ap.parse_args();print('RELEASE: '+BUILD,flush=True)
    if a.prepare_backup:
        import backup_preflight
        backup_preflight.run_preflight()
    elif a.prepare:
        import control
        launch('control','prepare',control.begin_prepare);watch('control','prepared');export_plan()
    elif a.apply_host:
        if not a.plan:raise Stop('--plan is required')
        import host
        launch('host',initialize=lambda:host.begin(a.plan))
        if a.follow:watch('host')
    elif a.apply_control:
        check_host('control')
        if not a.receipt:raise Stop('--receipt is required')
        def receive():
            v=read_json(a.receipt);s=journal('control')
            if not s.get('prepared') or v.get('nonce')!=s['nonce']:raise Stop('Prepared plan/receipt nonce differs')
            write_json(STATE/'host-receipt-import.json',v)
        launch('control',initialize=receive)
        if a.follow:watch('control')
    elif a.worker_host:
        import host
        host.worker()
    elif a.worker_control:
        import control
        control.apply(STATE/'host-receipt-import.json')
    elif a.worker_prepare_control:
        import control
        control.prepare();export_plan()
    elif a.verify_host:
        lock=process_lock('host')
        try:verify_backup()
        finally:lock.close()
    elif a.status:status(a.status)
    elif a.watch:watch(a.watch)
if __name__=='__main__':
    try:main()
    except (Stop,ValueError,KeyError,OSError) as exc:print('STOPPED: '+str(exc),file=sys.stderr,flush=True);raise SystemExit(1)
