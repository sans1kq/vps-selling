#!/usr/bin/env python3
"""Guarded public CSS update. No backend, payment, email or VPS operation."""
import argparse,fcntl,hashlib,json,os,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse

RELEASE='PUBLIC-CLARITY-20261110-r1'
STYLE='/* PulsarX public clarity r1: presentation only; keep the black/violet design. */\n:root{--text:#f5f2fa;--muted:#c1b9cc;--quiet:#aaa0b9;--line:#3d2e47;--soft-edge:#674b7870;--soft-inner:#68537266;--soft-divider:#604d6b55;--soft-control:#80618e9c;--soft-selected:#ac78d1;--soft-hover:#a777bf}\nhtml body :is(.hero-copy>p,.section-head p,.advantages-list p,.product-details p,.plan-use-card p,.network-ribbon p){color:#c5bdcf}\nhtml body :is(.field-label,.field .field-label,.wallet-muted,.wallet-row-sub,.help-text,.muted-note,.plan-note,.settings-row .sub,.settings-card>p,.form-hint){color:#bfb5cd}\nhtml body :is(.field-label,.field .field-label){font-weight:550}\nhtml body :is(.help-text,.wallet-muted,.muted-note){font-size:12px;line-height:1.7}\nhtml body :is(.server-specs small,.plan-specs small,.resource-plan small,.stage-resource small,.resource-card small){color:#b5aac4}\nhtml body :is(.server-specs strong,.plan-specs strong,.resource-plan strong,.wallet-amount,.wallet-balance-value,.server-identity h3){color:#f5f2fa;font-weight:650;font-variant-numeric:tabular-nums}\nhtml body :is(.page-head h1,.section-head h2,.hero h1,.server-card h3){text-shadow:none}\nhtml body :is(.server-card,.server-details,.settings-card,.wallet-card,.wallet-hero,.auth-classic-card,.resource-plan,.plan-use-card,.order-summary,.stage-console,.advantages-list article){border-color:#493752!important}\nhtml body :is(.server-card.selected,.resource-plan.selected,.resource-plan.active,.plan-use-card.selected){border-color:#ac78d1!important}\nhtml body :is(input:not([type=checkbox]):not([type=radio]),select,textarea){border-color:#58435f;color:#f0eaf8;background-color:#09070c}\nhtml body :is(input,textarea)::placeholder{color:#a094ad;opacity:1}\nhtml body :is(input,select,textarea):focus{border-color:#b47bdb;outline-color:#b47bdb}\nhtml body :is(.btn-secondary,.btn-ghost,.icon-button){border-color:#58435f;color:#ece5f5}\nhtml body :is(.btn-secondary,.btn-ghost,.icon-button):hover{border-color:#9973ae}\nhtml body :focus-visible{outline:2px solid #c192e6;outline-offset:3px}\n/* An opaque black payment window; background content is dimmed without blur. */\nhtml body dialog.wallet-dialog{background:#000!important;background-image:none!important;color:#f7f4fb!important;border:1px solid #66536f!important;box-shadow:0 24px 90px #000c!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;filter:none!important;opacity:1!important}\nhtml body dialog.wallet-dialog::backdrop{background:rgba(0,0,0,.82)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}\nhtml body dialog.wallet-dialog::before,html body dialog.wallet-dialog::after{background:none!important;box-shadow:none!important}\nhtml body dialog.wallet-dialog :is(h2,h3,.wallet-amount,dd){color:#f7f4fb!important;text-shadow:none!important}\nhtml body dialog.wallet-dialog :is(p,dt,.wallet-muted){color:#c4bccf!important;line-height:1.7}\nhtml body dialog.wallet-dialog .wallet-amount{font-weight:700;font-variant-numeric:tabular-nums}\nhtml body dialog.wallet-dialog .wallet-quote{background:#0b090e!important;background-image:none!important;border-color:#44394d;color:#f3edf9}\nhtml body dialog.wallet-dialog :is(input,select,textarea){background:#0b090e!important;border-color:#66536f;color:#f7f4fb}\nhtml body dialog.wallet-dialog .wallet-error{color:#ffadbd}\nhtml body dialog.wallet-dialog :is(.btn-ghost,.btn-secondary){background:#111014;border-color:#66536f;color:#f0e9f8}\nhtml body dialog.wallet-dialog :is(.btn-ghost,.btn-secondary):hover{background:#211929;border-color:#aa7bc6}\n@media(max-width:540px){html body dialog.wallet-dialog{padding:23px 19px}html body dialog.wallet-dialog :is(p,.wallet-muted){font-size:13px}html body dialog.wallet-dialog .wallet-dialog-actions{flex-wrap:wrap}}\n'
ASSET='px-public-clarity-r1.css'
WEB=Path('/var/www/html')
STATE=Path('/var/lib/pulsarx-public-clarity')
ENTRY=Path('/usr/local/lib/pulsarx-public-clarity/entry.py')
SERVICE='pulsarx-public-clarity-update.service'


class Stop(RuntimeError):pass
def sha(raw):return hashlib.sha256(raw).hexdigest()


def read(path):
    p=Path(path);s=p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size>16*1024**2:raise Stop('Unexpected input file: '+str(p))
    return p.read_bytes()


def atomic(path,raw,mode=0o600,uid=0,gid=0):
    path=Path(path)
    if path.is_symlink():raise Stop('Symlink target rejected')
    raw=raw.encode() if isinstance(raw,str) else raw
    fd,temp=tempfile.mkstemp(prefix='.clarity-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            os.fchmod(stream.fileno(),mode);os.fchown(stream.fileno(),uid,gid)
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def unit():
    r=subprocess.run(['systemctl','show',SERVICE,'-p','ActiveState','--value'],capture_output=True,text=True,timeout=10)
    return r.stdout.strip()


def check_host():
    if os.geteuid()!=0:raise Stop('Run with sudo on the application host')
    r=subprocess.run(['ip','-json','address','show'],capture_output=True,text=True,timeout=10,check=True)
    ips={a.get('local') for n in json.loads(r.stdout) for a in n.get('addr_info',[])}
    if '192.0.2.11' not in ips:raise Stop('Wrong host: application host 192.0.2.11 required')
    for path in (WEB,):
        info=path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022:raise Stop('Unsafe website directory')


class Page(HTMLParser):
    def __init__(self,source):
        super().__init__(convert_charrefs=False)
        self.links=[];self.heads=[];self.offsets=[0]
        for line in source.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.feed(source);self.close()
    def handle_starttag(self,tag,attrs):
        if tag!='link':return
        if len([k for k,v in attrs if k=='href'])>1:raise Stop('Ambiguous stylesheet link')
        attrs=dict(attrs)
        if 'stylesheet' in attrs.get('rel','').split():self.links.append(attrs.get('href',''))
    def handle_endtag(self,tag):
        if tag=='head':
            line,column=self.getpos();self.heads.append(self.offsets[line-1]+column)


def eligible(relative):
    return bool(relative.parts) and not relative.parts[0].lower().startswith('admin')


def update_html(raw):
    source=raw.decode('utf-8');page=Page(source)
    if any(urlparse(href).path=='/'+ASSET for href in page.links):return raw
    marker=False
    for href in page.links:
        url=urlparse(href)
        if url.scheme not in ('','https') or url.netloc not in ('','pulsarx.example.invalid'):continue
        name=Path(url.path).name
        if name.startswith('px-pulse-') and name.endswith('.css'):marker=True
    if not marker:return raw
    if len(page.heads)!=1:raise Stop('Public page has an unexpected head structure')
    index=page.heads[0]
    return (source[:index]+'<link rel="stylesheet" href="/'+ASSET+'">'+source[index:]).encode('utf-8')


def planned(web=WEB):
    web=Path(web);result={};asset=web/ASSET
    if asset.exists() and read(asset)!=STYLE.encode():raise Stop('Existing clarity stylesheet differs')
    pages={}
    for p in sorted(web.rglob('*.html')):
        rel=p.relative_to(web)
        if not eligible(rel):continue
        if p.is_symlink() or not p.resolve().is_relative_to(web.resolve()):raise Stop('Unexpected public page symlink')
        original=read(p);updated=update_html(original)
        if updated!=original:pages[p]=updated
    if not asset.exists():result[asset]=STYLE.encode()
    result.update(pages)
    return result


def load():
    return json.loads(read(STATE/'status.json')) if (STATE/'status.json').exists() else {}


def save(state,phase,message):
    state.update(release=RELEASE,phase=phase,message=message,updated_at=int(time.time()))
    atomic(STATE/'status.json',json.dumps(state,indent=2)+'\n')
    print(phase.upper()+': '+message,flush=True)


def verify(state):
    if not state.get('files'):raise Stop('No saved installation inventory')
    if state.get('asset_path') and read(state['asset_path'])!=STYLE.encode():
        raise Stop('Installed clarity stylesheet changed')
    for name,item in state['files'].items():
        if sha(read(name))!=item['after_sha256']:raise Stop('Installed file changed: '+name)


def rollback(state):
    for name,item in reversed(list(state.get('files',{}).items())):
        p=Path(name);actual=sha(read(p)) if p.exists() else None
        if actual==item['before_sha256']:continue
        if actual!=item['after_sha256']:raise Stop('Refusing to overwrite an unrelated edit: '+name)
        if item['backup']:
            raw=read(item['backup'])
            if sha(raw)!=item['before_sha256']:raise Stop('Backup checksum differs')
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        else:p.unlink()


def worker():
    state=load()
    if state.get('phase')=='complete':verify(state);return
    if state.get('phase')=='applying':
        rollback(state);save(state,'rolled_back','Interrupted public file transaction recovered')
    plan=planned()
    if not plan:raise Stop('No pending clarity changes; run --verify')
    backup=Path('/var/backups')/('pulsarx-public-clarity-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+uuid.uuid4().hex[:8])
    backup.mkdir(mode=0o700)
    state={'backup':str(backup),'asset_path':str(WEB/ASSET),'files':{}}
    for index,(p,raw) in enumerate(plan.items()):
        previous=read(p) if p.exists() else None;info=p.stat() if p.exists() else None
        b=backup/str(index) if previous is not None else None
        if b:atomic(b,previous)
        state['files'][str(p)]={'before_sha256':sha(previous) if previous is not None else None,
            'after_sha256':sha(raw),'backup':str(b) if b else None,
            'mode':stat.S_IMODE(info.st_mode) if info else 0o644,
            'uid':info.st_uid if info else 0,'gid':info.st_gid if info else 0}
    save(state,'applying','Installing black payment windows and clearer public text/borders; all services stay running')
    try:
        for p,raw in plan.items():
            item=state['files'][str(p)];actual=sha(read(p)) if p.exists() else None
            if actual!=item['before_sha256']:raise Stop('File changed after staging: '+str(p))
            atomic(p,raw,item['mode'],item['uid'],item['gid'])
        verify(state)
        save(state,'complete','Public clarity and black payment windows installed; scripts and backend unchanged; API and VPS stayed online')
    except Exception as exc:
        rollback(state);save(state,'rolled_back','File changes reverted: '+str(exc));raise


def main():
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    for name in ('apply','worker','check','status','verify'):group.add_argument('--'+name,action='store_true')
    args=parser.parse_args();check_host()
    STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
    if STATE.is_symlink() or STATE.stat().st_uid!=0 or STATE.stat().st_mode&0o077:raise Stop('Unsafe checkpoint directory')
    print('RELEASE: '+RELEASE,flush=True)
    if args.status:print(json.dumps(load(),indent=2));return
    if args.verify:verify(load());print('VERIFIED: installed CSS and public page hashes');return
    if args.check:
        plan=planned();print('CHECK OK: '+str(len(plan))+' presentation-only file updates; no production files changed');return
    if args.worker:
        with open(STATE/'worker.lock','a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);worker()
        return
    if load().get('phase')=='complete':verify(load());print('ALREADY COMPLETE');return
    if unit() not in ('active','activating','deactivating'):
        ENTRY.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        info=ENTRY.parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o077:raise Stop('Unsafe worker directory')
        atomic(ENTRY,read(Path(__file__)))
        state=load()
        if state.get('phase')!='applying':save(state,'queued','Starting independent public style worker')
        subprocess.run(['systemd-run','--unit=pulsarx-public-clarity-update','--collect','--no-block','--service-type=exec',
            '/usr/bin/python3',str(ENTRY),'--worker'],capture_output=True,check=True,timeout=15)
    began=time.monotonic()
    for _ in range(60):
        state=load();phase=state.get('phase')
        if phase=='complete':print('FINISHED: '+state['message']);return
        status=unit()
        if status in ('inactive','failed') and not (phase=='queued' and time.monotonic()-began<10):
            raise Stop('Worker stopped; run --status and journalctl -u '+SERVICE)
        print('WORKING: '+str(phase),flush=True);time.sleep(2)
    raise Stop('Worker still running; use --status')


if __name__=='__main__':
    try:main()
    except Exception as exc:print('STOPPED: '+str(exc),file=sys.stderr);raise SystemExit(1)
