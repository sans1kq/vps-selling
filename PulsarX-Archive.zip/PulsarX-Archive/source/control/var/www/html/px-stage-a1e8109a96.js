/* Annual display on the landing page; period selection remains in deploy. */
(() => {
 'use strict';const P=window.Pulse,t=P.t;
 const query=new URLSearchParams(location.search);let plan=query.get('plan')==='plus'?'plus':'mini';
 const prices={mini:null,plus:null},el=id=>document.getElementById(id);
 const money=c=>'$'+(c/100).toFixed(2).replace(/\.00$/,'');
 function render(animate=false){
  document.body.dataset.stagePlan=plan;
  document.querySelectorAll('[data-stage-plan]').forEach(b=>{const on=b.dataset.stagePlan===plan;b.classList.toggle('selected',on);b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;});
  document.querySelector('.plan-switch').style.setProperty('--plan-index',plan==='plus'?'1':'0');
  const annual=prices[plan];el('stagePrice').textContent=annual?money(Math.round(annual/12)):'—';
  el('stageCpu').textContent=(plan==='mini'?1:2)+' vCPU';el('stageRam').textContent=(plan==='mini'?1:4)+' GB RAM';el('stageDisk').textContent=(plan==='mini'?25:50)+' GB NVMe';
  el('stageLaunchText').removeAttribute('data-t');el('stageLaunchText').textContent=t(plan==='mini'?'launchMini':'launchPlus');
  el('stageLaunch').href='/deploy/?plan='+plan+'&months=12';
  el('stageTotal').textContent=annual?t('annualBill',{amount:money(annual)}):t('priceOnDeploy');
  const from=document.querySelector('[data-t=stageFromAnnual]');const available=Object.values(prices).filter(n=>n>0);
  from.textContent=available.length?t('stageFromAnnual',{amount:money(Math.round(Math.min(...available)/12))}):t('annualTerm');
  if(animate&&!matchMedia('(prefers-reduced-motion: reduce)').matches)for(const n of [el('stagePrice'),document.querySelector('.console-resources'),el('stageLaunchText')])n.animate?.([{opacity:.25,transform:'translateY(6px)'},{opacity:1,transform:'none'}],{duration:280,easing:'cubic-bezier(.2,.8,.2,1)'});
 }
 function choose(next){if(next!==plan){plan=next;render(true);}}
 function info(key){document.querySelectorAll('[data-info-tab]').forEach(b=>{const on=b.dataset.infoTab===key;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;el(b.getAttribute('aria-controls')).hidden=!on;});}
 async function init(){
  if(!el('stageLaunch'))return;P.apply();render();
  document.querySelectorAll('[data-stage-plan]').forEach(b=>{b.addEventListener('click',()=>choose(b.dataset.stagePlan));b.addEventListener('keydown',e=>{if(!['Home','End','ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();choose(e.key==='Home'?'mini':e.key==='End'?'plus':plan==='mini'?'plus':'mini');document.querySelector('[data-stage-plan='+plan+']').focus();});});
  const tabs=Array.from(document.querySelectorAll('[data-info-tab]'));tabs.forEach((b,i)=>{b.addEventListener('click',()=>info(b.dataset.infoTab));b.addEventListener('keydown',e=>{if(!['Home','End','ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();const n=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;info(tabs[n].dataset.infoTab);tabs[n].focus();});});
  document.addEventListener('px:lang',()=>render());
  try{const data=await P.api('/api/servers/pricing',{},false);for(const p of ['mini','plus']){const raw=String(data?.prices?.[p]?.['12']??'');if(/^\d{1,7}(?:\.\d{1,2})?$/.test(raw)&&Number(raw)>0)prices[p]=Math.round(Number(raw)*100);}render();}catch{/* Deploy always fetches the authoritative current price before payment. */}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
