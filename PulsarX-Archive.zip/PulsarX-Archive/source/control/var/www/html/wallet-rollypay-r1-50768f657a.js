/* PulsarX RollyPay r1 */
(function () {
  'use strict';
  const copy = {
    en: { title:'Balance', available:'Available balance', sub:'USD for your PulsarX instances. Renew only when you choose.', topup:'Top up via AnyPay', amount:'Amount in USD', go:'Continue to AnyPay', note:'Payment methods and any fees are shown by AnyPay before payment. A top-up adds funds to your account; it does not create or renew an instance.', history:'Balance history', empty:'No transactions yet. Top up your balance to get started.', recent:'Recent top-ups', orders:'Paid operations', refresh:'Refresh', checking:'Checking…', check:'Check payment', pending:'Awaiting confirmation', credited:'Credited', closed:'Not completed', expired:'Expired', review:'Needs support review', queued:'Queued', working:'Processing', completed:'Completed', refunded:'Returned to balance', purchase:'Instance payment', refund:'Creation refund', notice:'Returned from AnyPay. Waiting for verified payment confirmation; this page will refresh automatically.', failed:'Payment was not completed. You can try again below.', frozen:'Your balance is under review. Please contact support.', unavailable:'Top-ups are temporarily unavailable.', error:'Could not complete the request. Please try again.', range:'Enter an amount within the permitted range.', confirm:'Confirm payment', pay:'Pay from balance', cancel:'Cancel', cost:'This amount will be deducted from your balance.', short:'Your balance is too low. Top up, then return to this purchase.', add:'Top up balance', success:'Payment accepted', processing:'Your payment is saved. Check the operation status in your dashboard.', balance:'Your balance', more:'Show more', awaiting:'Payment found. Waiting for AnyPay notification.', new:'New instance', renew:'Renewal', upgrade:'Upgrade to Plus', deadline:'Review the payment details in AnyPay and save your receipt.' },
    ru: { title:'Баланс', available:'Доступный баланс', sub:'Доллары для ваших инстансов PulsarX. Продлевайте, когда нужно вам.', topup:'Пополнить через AnyPay', amount:'Сумма в USD', go:'Перейти к AnyPay', note:'Способы оплаты и возможные комиссии AnyPay покажет до оплаты. Пополнение добавляет деньги на баланс: инстанс нужно купить или продлить отдельно.', history:'История баланса', empty:'Операций пока нет. Пополните баланс, чтобы начать.', recent:'Последние пополнения', orders:'Оплаченные операции', refresh:'Обновить', checking:'Проверяем…', check:'Проверить платёж', pending:'Ждём подтверждения', credited:'Зачислено', closed:'Не завершён', expired:'Срок истёк', review:'Нужна проверка поддержки', queued:'В очереди', working:'Выполняется', completed:'Завершено', refunded:'Возвращено на баланс', purchase:'Оплата инстанса', refund:'Возврат за создание', notice:'Вы вернулись из AnyPay. Ждём проверенного подтверждения платежа; баланс обновится автоматически.', failed:'Оплата не завершена. Ниже можно попробовать снова.', frozen:'Баланс на проверке. Обратитесь в поддержку.', unavailable:'Пополнение временно недоступно.', error:'Не удалось выполнить запрос. Попробуйте ещё раз.', range:'Введите сумму в допустимом диапазоне.', confirm:'Подтвердить оплату', pay:'Оплатить с баланса', cancel:'Отмена', cost:'Эта сумма спишется с баланса.', short:'На балансе не хватает средств. Пополните его и вернитесь к покупке.', add:'Пополнить баланс', success:'Оплата принята', processing:'Оплата сохранена. Статус операции доступен в кабинете.', balance:'Ваш баланс', more:'Показать ещё', awaiting:'Платёж найден. Ждём уведомление AnyPay.', new:'Новый инстанс', renew:'Продление', upgrade:'Апгрейд до Plus', deadline:'Проверьте условия оплаты в AnyPay и сохраните квитанцию.' },
    ro: { title:'Sold', available:'Sold disponibil', sub:'USD pentru instantele PulsarX. Reinnoiesti cand alegi tu.', topup:'Alimenteaza prin AnyPay', amount:'Suma in USD', go:'Continua la AnyPay', note:'AnyPay afiseaza metodele de plata si eventualele comisioane inainte de plata. Alimentarea adauga bani in cont; cumpararea sau reinnoirea instantei se face separat.', history:'Istoricul soldului', empty:'Nu exista tranzactii. Alimenteaza soldul pentru a incepe.', recent:'Alimentari recente', orders:'Operatiuni platite', refresh:'Actualizeaza', checking:'Se verifica…', check:'Verifica plata', pending:'Se asteapta confirmarea', credited:'Creditat', closed:'Neefectuat', expired:'Expirat', review:'Necesita verificarea suportului', queued:'In asteptare', working:'Se proceseaza', completed:'Finalizat', refunded:'Returnat in sold', purchase:'Plata instantei', refund:'Rambursare pentru creare', notice:'Ai revenit de la AnyPay. Asteptam confirmarea verificata a platii; soldul se va actualiza automat.', failed:'Plata nu a fost finalizata. Poti incerca din nou mai jos.', frozen:'Soldul este in verificare. Contacteaza suportul.', unavailable:'Alimentarile sunt temporar indisponibile.', error:'Cererea nu a putut fi finalizata. Incearca din nou.', range:'Introdu o suma in intervalul permis.', confirm:'Confirma plata', pay:'Plateste din sold', cancel:'Anuleaza', cost:'Aceasta suma va fi retrasa din sold.', short:'Sold insuficient. Alimenteaza contul, apoi revino la cumparare.', add:'Alimenteaza soldul', success:'Plata acceptata', processing:'Plata a fost salvata. Verifica starea operatiunii in panou.', balance:'Soldul tau', more:'Arata mai mult', awaiting:'Plata gasita. Asteptam notificarea AnyPay.', new:'Instanta noua', renew:'Reinnoire', upgrade:'Upgrade la Plus', deadline:'Verifica detaliile platii in AnyPay si pastreaza dovada.' }
  };
  Object.assign(copy.en, {
    topup:'Top up balance', go:'Create invoice', pending:'Awaiting payment', creating:'Preparing invoice', confirming:'Confirming payment', cancelled:'Closed by you',
    note:'Choose a payment provider. Available methods, crypto networks and fees are shown on the payment page. A top-up adds USD to your balance; buy or renew an instance separately.',
    method:'Payment method', anypayHint:'Cards and other available methods', freekassaHint:'Methods enabled for this store', plisioHint:'Cryptocurrency checkout', resume:'Continue payment', reminder:'You have an unpaid invoice',
    active:'Continue or close your open invoice before creating another.', expires:'Time left', until:'Local checkout deadline', timerDone:'Checkout time has expired',
    timerNote:'This timer closes the invoice on this site. The processor controls its payment status; verified late payments are still credited.',
    providerDeadline:'The payment deadline is shown on the KASSA payment page. An SBP QR code may expire sooner than this invoice. If it expires and you have not sent money, close this invoice here and create a new one. If you have paid, check the payment status and wait for confirmation.',
    closeInvoice:'Close on this site', closeTitle:'Close this unpaid invoice on PulsarX?', closeNote:'Only close it if you have not sent money. Closing hides its checkout here; it does not stop a transfer at the processor. A verified late payment will still be credited.',
    back:'Back', minimize:'Minimize reminder', expand:'Expand reminder', details:'Open balance', totalOpen:'Open invoices',
    confirmingNote:'Funds were detected. Wait for confirmation; do not pay again.', checkoutError:'The payment page is temporarily unavailable. Your invoice is saved; try again shortly.',
    checkingError:'Payment confirmation is temporarily unavailable. Try again shortly.', closeError:'A payment is being confirmed. Wait for its result.',
    awaiting:'Payment found. Waiting for the processor notification.', notice:'Returned from checkout. The balance updates after verified confirmation.',
    failed:'Checkout was closed. You can continue the same unpaid invoice below.', deadline:'Review the amount and, for crypto, the exact coin and network before sending.',
  });
  Object.assign(copy.ru, {
    topup:'Пополнить баланс', go:'Создать счёт', pending:'Ожидает оплаты', creating:'Готовим счёт', confirming:'Подтверждаем платёж', cancelled:'Закрыт вами',
    note:'Выберите платёжного оператора. Доступные способы, криптосети и комиссии указаны на странице оплаты. Пополнение добавляет USD на баланс; покупка и продление инстанса оплачиваются отдельно.',
    method:'Способ оплаты', anypayHint:'Карты и другие доступные способы', freekassaHint:'Способы, подключённые магазину', plisioHint:'Оплата криптовалютой', resume:'Продолжить оплату', reminder:'У вас есть неоплаченный счёт',
    active:'Завершите или закройте открытый счёт, прежде чем создавать новый.', expires:'Осталось', until:'Срок оплаты на сайте', timerDone:'Время для оплаты истекло',
    timerNote:'Таймер закрывает счёт на сайте. Статус оплаты определяет платёжный оператор; подтверждённый поздний платёж тоже будет зачислен.',
    providerDeadline:'Срок оплаты указан на странице KASSA. QR-код СБП может истечь раньше, чем этот счёт. Если время истекло и вы ещё не отправляли деньги, закройте счёт здесь и создайте новый. Если уже оплатили, проверьте статус платежа и дождитесь подтверждения.',
    closeInvoice:'Закрыть на сайте', closeTitle:'Закрыть неоплаченный счёт на PulsarX?', closeNote:'Закрывайте счёт, только если ещё не отправляли деньги. Это уберёт переход к оплате здесь, но не остановит перевод у оператора. Подтверждённый поздний платёж будет зачислен.',
    back:'Назад', minimize:'Свернуть уведомление', expand:'Развернуть уведомление', details:'Открыть баланс', totalOpen:'Открытых счетов',
    confirmingNote:'Оплата обнаружена. Дождитесь подтверждения, повторно платить не нужно.', checkoutError:'Страница оплаты временно недоступна. Счёт сохранён — попробуйте открыть его чуть позже.',
    checkingError:'Подтверждение платежа временно недоступно. Попробуйте чуть позже.', closeError:'Платёж уже подтверждается. Дождитесь результата.',
    awaiting:'Платёж найден. Ждём уведомление платёжного оператора.', notice:'Вы вернулись со страницы оплаты. Баланс обновится после проверенного подтверждения.',
    failed:'Страница оплаты закрыта. Ниже можно продолжить оплату того же счёта.', deadline:'Перед переводом проверьте сумму, а для криптовалюты — точную монету и сеть.',
  });
  Object.assign(copy.ro, {
    topup:'Alimenteaza soldul', go:'Creeaza factura', pending:'Asteapta plata', creating:'Se pregateste factura', confirming:'Se confirma plata', cancelled:'Inchisa de tine',
    note:'Alege un procesator de plati. Metodele disponibile, retelele crypto si comisioanele sunt afisate la plata. Alimentarea adauga USD in sold; cumpara sau reinnoieste instanta separat.',
    method:'Metoda de plata', anypayHint:'Carduri si alte metode disponibile', freekassaHint:'Metode activate pentru magazin', plisioHint:'Plata in criptomoneda', resume:'Continua plata', reminder:'Ai o factura neplatita',
    active:'Continua sau inchide factura deschisa inainte de a crea alta.', expires:'Timp ramas', until:'Termenul platii pe site', timerDone:'Timpul pentru plata a expirat',
    timerNote:'Cronometrul inchide factura pe site. Procesatorul stabileste starea platii; platile intarziate confirmate sunt creditate.',
    providerDeadline:'Termenul platii este afisat pe pagina KASSA. Codul QR SBP poate expira inaintea acestei facturi. Daca a expirat si nu ai trimis bani, inchide factura aici si creeaza una noua. Daca ai platit deja, verifica starea platii si asteapta confirmarea.',
    closeInvoice:'Inchide pe site', closeTitle:'Inchizi factura neplatita pe PulsarX?', closeNote:'Inchide factura numai daca nu ai trimis bani. Inchiderea ascunde plata aici, dar nu opreste transferul la procesator. O plata intarziata confirmata va fi creditata.',
    back:'Inapoi', minimize:'Restrange notificarea', expand:'Extinde notificarea', details:'Deschide soldul', totalOpen:'Facturi deschise',
    confirmingNote:'Plata a fost detectata. Asteapta confirmarea; nu plati din nou.', checkoutError:'Pagina de plata este temporar indisponibila. Factura este salvata; incearca din nou.',
    checkingError:'Confirmarea platii este temporar indisponibila. Incearca mai tarziu.', closeError:'Plata se confirma deja. Asteapta rezultatul.',
    awaiting:'Plata gasita. Asteptam notificarea procesatorului.', notice:'Ai revenit de la plata. Soldul se actualizeaza dupa confirmarea verificata.',
    failed:'Pagina de plata a fost inchisa. Poti continua aceeasi factura mai jos.', deadline:'Verifica suma si, pentru crypto, moneda si reteaua exacta inainte de transfer.',
  });
  const lang = () => window.pulsarxI18n?.getLang() || 'en';
  const tr = key => (copy[lang()] || copy.en)[key] || key;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = value => '$' + (Number(value) / 100).toFixed(2);
  const invoiceNumber = value => {
    const raw=String(value), number=Number(raw);
    return /^\d+$/.test(raw)&&Number.isSafeInteger(number)&&number>=86000000000000
      ? String(number-86000000000000+50) : raw;
  };
  const date = value => value ? new Date(value).toLocaleString(lang() === 'ru' ? 'ru-RU' : lang() === 'ro' ? 'ro-RO' : 'en-GB', {dateStyle:'medium', timeStyle:'short'}) : '';
  Object.assign(copy.en, {fkTitle:'Cards + crypto · KASSA', plisioTitle:'Crypto · Plisio', fkMethod:'Payment method in KASSA', freekassaHint:'SBP, Russian cards and cryptocurrency', fkUnavailable:'KASSA methods are unavailable. You can use Plisio or try again later.', uncertain:'The request was already sent to KASSA. Check the saved invoice or contact support; a duplicate will not be created.'});
  Object.assign(copy.ru, {fkTitle:'Карты + криптовалюта · KASSA', plisioTitle:'Криптовалюта · Plisio', fkMethod:'Способ оплаты в KASSA', freekassaHint:'СБП, карты РФ и криптовалюта', fkUnavailable:'Способы KASSA недоступны. Можно выбрать Plisio или попробовать позже.', uncertain:'Запрос уже отправлен в KASSA. Проверьте сохранённый счёт или обратитесь в поддержку; повторный заказ не создаётся.'});
  Object.assign(copy.ro, {fkTitle:'Carduri + crypto · KASSA', plisioTitle:'Crypto · Plisio', fkMethod:'Metoda de plata in KASSA', freekassaHint:'SBP, carduri rusesti si criptomoneda', fkUnavailable:'Metodele KASSA sunt indisponibile. Alege Plisio sau incearca mai tarziu.', uncertain:'Cererea a fost trimisa la KASSA. Verifica factura salvata sau contacteaza suportul; nu cream o comanda duplicata.'});
  const providerName = value => value === 'rollypay' ? 'RollyPay' : value === 'freekassa' ? tr('fkTitle') : value === 'plisio' ? tr('plisioTitle') : 'AnyPay';
  Object.assign(copy.en, {methodLimits:'KASSA payment limits', from:'from', to:'to', amountOutside:'Amount outside the permitted range.', conversionLimits:'Enter the balance top-up in USD. KASSA checks the payment amount after conversion and shows the final amount and fees.', limitsUnknown:'KASSA will check the limits when preparing payment.'});
  Object.assign(copy.ru, {methodLimits:'Лимиты оплаты KASSA', from:'от', to:'до', amountOutside:'Сумма вне допустимого диапазона.', conversionLimits:'Введите пополнение баланса в USD. KASSA проверит сумму после пересчёта и покажет итог с комиссиями.', limitsUnknown:'KASSA проверит лимиты при подготовке оплаты.'});
  Object.assign(copy.ro, {methodLimits:'Limitele platii KASSA', from:'de la', to:'pana la', amountOutside:'Suma este in afara intervalului permis.', conversionLimits:'Introdu alimentarea soldului in USD. KASSA verifica suma dupa conversie si afiseaza totalul si comisioanele.', limitsUnknown:'KASSA verifica limitele la pregatirea platii.'});
  const active = row => row && (row.status === 'pending' || row.status === 'creating');
  let cached = null, offset = 0, currentHistory = [], loading = false, hasPending = false, clockOffset = 0, submitting = false;
  let collapsedId = sessionStorage.getItem('px-wallet-reminder-collapsed') || '';
  const busyActions = new Set();
  let failedAuthToken = null;
  let selectedMethod = sessionStorage.getItem('px-wallet-topup-method');
  let currentFkMethods = [];
  let summaryFlight=null, methodsFlight=null, methodsToken=null, methodsUpdated=0, methodsState='idle';
  let loadGeneration=0;
  Object.assign(copy.en, {fkTitle:'KASSA',plisioTitle:'Plisio',amount:'Balance top-up in USD',sub:'Use your balance to buy and renew instances.',note:'A top-up adds USD to your balance. Buy or renew an instance separately.',method:'Payment provider',fkMethod:'Payment method',methodsLoading:'Loading payment methods…',retry:'Try again',loading:'Loading…',sectionError:'Could not load this section.',pastInvoices:'Previous invoices',operationsHint:'Payments from your balance',conversionLimits:'This limit is in the payment currency. Your balance top-up is in USD; KASSA shows the converted amount and fees before payment.',emptyHistory:'Your balance transactions will appear here.',emptyInvoices:'No previous invoices.',emptyOrders:'No instance payments yet.',methodLimits:'Payment limits',moreDetails:'Payment details',paymentNote:'The payment provider shows the final amount and fees before payment.'});
  Object.assign(copy.ru, {fkTitle:'KASSA',plisioTitle:'Plisio',amount:'Пополнение баланса в USD',sub:'Для покупки и продления инстансов.',note:'Пополнение добавляет USD на баланс. Покупка и продление инстанса оплачиваются отдельно.',method:'Платёжный оператор',fkMethod:'Способ оплаты',methodsLoading:'Загружаем способы оплаты…',retry:'Повторить',loading:'Загрузка…',sectionError:'Не удалось загрузить этот раздел.',pastInvoices:'Предыдущие счета',operationsHint:'Оплаты с баланса',conversionLimits:'Это лимит в валюте платежа. Пополнение баланса — в USD; сумму после пересчёта и комиссии покажет KASSA перед оплатой.',emptyHistory:'Здесь появятся зачисления и списания с баланса.',emptyInvoices:'Предыдущих счетов пока нет.',emptyOrders:'Оплат инстансов пока нет.',methodLimits:'Лимиты платежа',moreDetails:'Об оплате',paymentNote:'Итоговую сумму и комиссии оператор покажет перед оплатой.'});
  Object.assign(copy.ro, {fkTitle:'KASSA',plisioTitle:'Plisio',amount:'Alimentarea soldului in USD',sub:'Pentru cumpararea si reinnoirea instantelor.',note:'Alimentarea adauga USD in sold. Cumpara sau reinnoieste instanta separat.',method:'Procesator de plati',fkMethod:'Metoda de plata',methodsLoading:'Se incarca metodele de plata…',retry:'Reincearca',loading:'Se incarca…',sectionError:'Nu s-a putut incarca aceasta sectiune.',pastInvoices:'Facturi anterioare',operationsHint:'Plati din sold',conversionLimits:'Aceasta limita este in moneda platii. Alimentarea soldului este in USD; KASSA afiseaza suma convertita si comisioanele inainte de plata.',emptyHistory:'Aici vor aparea creditarile si platile din sold.',emptyInvoices:'Nu exista facturi anterioare.',emptyOrders:'Nu exista plati pentru instante.',methodLimits:'Limitele platii',moreDetails:'Despre plata',paymentNote:'Procesatorul afiseaza suma finala si comisioanele inainte de plata.'});
  Object.assign(copy.en, {methodUnavailable:'This payment method is temporarily unavailable. Choose another method.'});
  Object.assign(copy.ru, {methodUnavailable:'Этот способ оплаты временно недоступен. Выберите другой способ.'});
  Object.assign(copy.ro, {methodUnavailable:'Aceasta metoda de plata este temporar indisponibila. Alege alta metoda.'});

  function methodLimits(value) {
    if(!value||!/^[A-Z0-9]{2,12}$/.test(value.currency||''))return null;
    if(!['min','max'].every(k=>typeof value[k]==='string'&&/^\d{1,13}(?:\.\d{1,12})?$/.test(value[k])))return null;
    const lower=Number(value.min), upper=Number(value.max);
    return Number.isFinite(lower)&&Number.isFinite(upper)&&lower>=0&&upper>0&&lower<=upper&&upper<=1e12?value:null;
  }
  function selectedLimits() {
    if(document.querySelector('input[name="walletProvider"]:checked')?.value!=='freekassa')return null;
    const ident=Number(document.getElementById('walletFkMethod')?.value);
    return methodLimits(currentFkMethods.find(row=>row.id===ident)?.limits);
  }
  function topupBounds() {
    const bounds={min:cached?.min_topup_cents??100,max:cached?.max_topup_cents??10000};
    const limits=selectedLimits();
    if(limits?.currency==='USD'&&Number.isSafeInteger(limits.min_cents)&&Number.isSafeInteger(limits.max_cents)){
      bounds.min=Math.max(bounds.min,limits.min_cents); bounds.max=Math.min(bounds.max,limits.max_cents);
    }
    return bounds;
  }
  function rangeText(limits) {
    return `${tr('from')} ${limits.min} ${tr('to')} ${limits.max} ${limits.currency}`;
  }
  function limitError(value) {
    const limits=methodLimits(value);
    return limits?`${tr('amountOutside')} ${tr('methodLimits')}: ${rangeText(limits)}.`:tr('range');
  }
  function inputCents() {
    const raw=document.getElementById('walletAmount')?.value.trim().replace(',','.');
    if(!/^\d{1,6}(?:\.\d{1,2})?$/.test(raw||''))return null;
    const [whole,fraction='']=raw.split('.');
    return Number(whole)*100+Number(fraction.padEnd(2,'0'));
  }
  function updateAmountLimits() {
    const limits=selectedLimits(), bounds=topupBounds();
    const note=document.getElementById('walletMethodLimits');
    if(note)note.textContent=limits?`${tr('methodLimits')}: ${rangeText(limits)}.${limits.currency==='USD'?'':' '+tr('conversionLimits')}`:methodsState==='loading'?tr('methodsLoading'):tr('limitsUnknown');
    const label=document.querySelector('label[for="walletAmount"]');
    if(label)label.textContent=`${tr('amount')} · ${money(bounds.min)}–${money(bounds.max)}`;
    document.querySelectorAll('[data-cents]').forEach(button=>{const n=Number(button.dataset.cents);button.hidden=n<bounds.min||n>bounds.max;});
    const error=document.getElementById('walletTopupError'), cents=inputCents();
    if(error&&cents!==null&&(cents<bounds.min||cents>bounds.max)&&(cents!==0||document.getElementById('walletAmount')?.dataset.edited)){
      error.textContent=`${tr('amountOutside')} ${tr('from')} ${money(bounds.min)} ${tr('to')} ${money(bounds.max)} USD.`;
      error.dataset.amountRangeError='1';
    }else if(error?.dataset.amountRangeError){error.textContent='';delete error.dataset.amountRangeError;}
    refreshRollyQuote();
  }

  function updatePaymentMethods() {
    const selected = document.querySelector('input[name="walletProvider"]:checked')?.value;
    const box = document.getElementById('walletFkMethods');
    if (box) box.hidden = selected !== 'freekassa';
    updateAmountLimits();
    updateFormLock();
    refreshRollyQuote();
    if(selected==='freekassa')requestPaymentMethods();
  }
  function paintPaymentMethods() {
    const select=document.getElementById('walletFkMethod');if(!select)return;
    const selected=Number(select.value||sessionStorage.getItem('px-wallet-fk-method')||44);
    const chosen=currentFkMethods.some(x=>x.id===selected)?selected:currentFkMethods[0]?.id;
    select.innerHTML=currentFkMethods.length?currentFkMethods.map(x=>`<option value="${x.id}" ${x.id===chosen?'selected':''}>${esc(x.name)}</option>`).join(''):`<option value="">${esc(tr(methodsState==='loading'?'methodsLoading':'fkUnavailable'))}</option>`;
    select.setAttribute('aria-busy',String(methodsState==='loading'));
    const retry=document.getElementById('walletMethodsRetry');if(retry)retry.hidden=methodsState!=='error';
    updateAmountLimits();updateFormLock();
  }
  function requestPaymentMethods(force=false) {
    const token=localStorage.getItem('pulsarx_token');
    if(!token||!cached?.providers?.includes('freekassa'))return;
    if(methodsToken!==token){methodsToken=token;currentFkMethods=[];methodsUpdated=0;methodsFlight=null;methodsState='idle';}
    if(methodsFlight)return methodsFlight;
    if(!force&&methodsUpdated>Date.now()-60000){paintPaymentMethods();return;}
    methodsState='loading';paintPaymentMethods();
    const flight=api('/freekassa/methods',undefined,true).then(data=>{
      if(token!==localStorage.getItem('pulsarx_token'))return;
      if(!Array.isArray(data.methods))throw new Error(tr('fkUnavailable'));
      currentFkMethods=data.methods.filter(x=>Number.isInteger(x.id)&&typeof x.name==='string');
      methodsState=currentFkMethods.length?'ready':'error';methodsUpdated=Date.now();
    }).catch(()=>{
      if(token!==localStorage.getItem('pulsarx_token'))return;
      currentFkMethods=[];methodsState='error';methodsUpdated=Date.now();
    }).finally(()=>{
      if(methodsFlight===flight){methodsFlight=null;paintPaymentMethods();}
    });
    methodsFlight=flight;return flight;
  }
  async function api(path, body, passive=false) {
    const response = await fetch('/api/wallet' + path, { method: body === undefined ? 'GET' : 'POST', headers:{Authorization:'Bearer ' + localStorage.getItem('pulsarx_token'), ...(body === undefined ? {} : {'Content-Type':'application/json'})}, ...(body === undefined ? {} : {body:JSON.stringify(body)}) });
    let data;
    try { data=await response.json(); } catch (_) { throw new Error(tr('error')); }
    if (response.status === 401) { document.getElementById('pxWalletPaymentNotice')?.remove(); failedAuthToken=localStorage.getItem('pulsarx_token'); if(!passive)location.href='/login/'; throw new Error(tr('error')); }
    if (!response.ok) {
      const detail = data.detail;
      const message = ['rollypay_quote_expired','rollypay_rejected'].includes(detail?.code)?tr(detail.code):detail?.code === 'payment_method_unavailable' ? tr('methodUnavailable') : detail?.code === 'payment_amount_range' ? limitError(detail.limits) : detail?.code === 'checkout_uncertain' ? tr('uncertain') : detail?.code === 'insufficient_balance' ? tr('short') : detail?.code === 'active_topup' ? tr('active') :
        response.status === 503 ? tr(path.endsWith('/check') ? 'checkingError' : 'checkoutError') :
        path.endsWith('/cancel') && response.status === 409 ? tr('closeError') : typeof detail === 'string' ? detail : tr('error');
      const error = new Error(message); error.code = detail?.code; throw error;
    }
    return data;
  }
  function intent(payload) {
    const user = JSON.parse(localStorage.getItem('pulsarx_user') || '{}');
    const name = 'px-wallet-intent:' + (user.id || user.email || '') + ':' + JSON.stringify(payload);
    let key = sessionStorage.getItem(name);
    if (!key) { key = crypto.randomUUID(); sessionStorage.setItem(name, key); }
    return {name, key};
  }
  async function createOrder(payload, expected) {
    const identity = intent(payload);
    const result = await api('/orders', {...payload, expected_amount_cents:expected, request_key:identity.key});
    sessionStorage.removeItem(identity.name);
    await refreshSummary().catch(() => {});
    return result;
  }
  async function refreshSummary() {
    const token=localStorage.getItem('pulsarx_token');
    if (!token||token===failedAuthToken) { cached=null;document.getElementById('pxWalletPaymentNotice')?.remove();return null; }
    if(summaryFlight?.token===token)return summaryFlight.promise;
    const promise=fetchSummary(token).finally(()=>{if(summaryFlight?.promise===promise)summaryFlight=null;});
    summaryFlight={token,promise};return promise;
  }
  async function fetchSummary(token) {
    const balance=await api('',undefined,true);
    if(token!==localStorage.getItem('pulsarx_token'))return null;
    cached=balance;
    if (cached.server_time) clockOffset = new Date(cached.server_time).getTime() - Date.now();
    const badge = document.getElementById('walletNavValue');
    if (badge) badge.textContent = money(cached.balance_cents);
    const deploy = document.getElementById('walletDeployBalance');
    if (deploy) deploy.textContent = tr('balance') + ': ' + money(cached.balance_cents);
    updateReminder(cached.pending_topup);
    updateFormLock();
    return cached;
  }
  function countdown(row) {
    if (row.payment_in_progress) return `<p class="wallet-note">${esc(tr('confirmingNote'))}</p>`;
    if (active(row) && row.provider === 'freekassa') return `<p class="wallet-note" data-wallet-provider-deadline>${esc(tr('providerDeadline'))}</p>`;
    if (!active(row) || !row.expires_at) return '';
    return `<div class="wallet-countdown"><span>${esc(tr('expires'))}</span><time data-wallet-expiry="${esc(row.expires_at)}" role="timer" aria-live="off">--:--</time></div><div class="wallet-row-sub">${esc(tr('until'))}: ${esc(date(row.expires_at))}</div>`;
  }
  function invoiceActions(row) {
    const id = esc(row.id);
    return `<div class="wallet-invoice-actions">${row.can_resume?`<button type="button" class="btn wallet-resume" data-wallet-action="checkout" data-invoice="${id}" data-pay-until="${esc(row.expires_at)}">${esc(tr('resume'))} ↗</button>`:''}${active(row)?`<button type="button" class="wallet-check" data-wallet-action="check" data-invoice="${id}" data-check="${id}">${esc(tr('check'))}</button>`:''}${row.can_cancel?`<button type="button" class="wallet-check wallet-close-invoice" data-wallet-action="cancel" data-invoice="${id}">${esc(tr('closeInvoice'))}</button>`:''}</div>`;
  }
  function invoice(row, featured=false) {
    const title = `${providerName(row.provider)} · ${money(row.amount_cents)}${row.provider==='rollypay'&&row.payment_currency==='RUB'?' · '+row.payment_amount+' RUB':''}`;
    return `<${featured?'section':'div'} class="${featured?'wallet-active-invoice':'wallet-row wallet-invoice-row'}"><div class="wallet-invoice-main">${featured?`<div class="wallet-eyebrow">${esc(tr(row.payment_in_progress?'confirming':'reminder'))}</div>`:''}<div class="wallet-row-title">${esc(title)}</div><div class="wallet-row-sub">${esc(date(row.created_at))} · #${esc(invoiceNumber(row.id))}</div>${countdown(row)}${invoiceActions(row)}${row.awaiting_notification?`<div class="wallet-row-sub">${esc(tr('awaiting'))}</div>`:''}${featured&&row.provider!=='freekassa'?`<p class="wallet-note">${esc(tr('timerNote'))}</p>`:''}</div><span class="wallet-state ${row.status==='credited'?'good':''}">${esc(tr(row.payment_in_progress?'confirming':row.status))}</span></${featured?'section':'div'}>`;
  }
  function updateReminder(row) {
    let holder = document.getElementById('pxWalletPaymentNotice');
    if (!active(row)) { holder?.remove(); return; }
    if (!holder) { holder=document.createElement('aside'); holder.id='pxWalletPaymentNotice'; holder.setAttribute('role','region'); document.body.appendChild(holder); }
    const collapsed = collapsedId === String(row.id);
    holder.className='wallet-payment-notice'+(collapsed?' is-collapsed':'');
    holder.setAttribute('aria-label',tr(row.payment_in_progress?'confirming':'reminder'));
    holder.innerHTML=`<div class="wallet-notice-head"><span class="wallet-notice-dot" aria-hidden="true"></span><strong>${esc(tr(row.payment_in_progress?'confirming':'reminder'))}</strong><button type="button" class="wallet-notice-toggle" data-wallet-toggle="${esc(row.id)}" aria-expanded="${!collapsed}" aria-label="${esc(tr(collapsed?'expand':'minimize'))}">${collapsed?'+':'−'}</button></div><div class="wallet-notice-details"><div class="wallet-notice-value">${money(row.amount_cents)} <span>${esc(providerName(row.provider))} · #${esc(invoiceNumber(row.id))}</span></div>${countdown(row)}${invoiceActions(row)}<a class="wallet-details-link" href="/dashboard/?tab=wallet">${esc(tr('details'))}${cached?.pending_count>1?' · '+cached.pending_count+' '+esc(tr('totalOpen')):''} →</a><div class="wallet-error" data-notice-error role="alert"></div></div>`;
    tickCountdowns();
  }
  function tickCountdowns() {
    const now = Date.now() + clockOffset;
    document.querySelectorAll('[data-wallet-expiry]').forEach(timer=>{
      const remaining=Math.max(0,Math.ceil((new Date(timer.dataset.walletExpiry).getTime()-now)/1000));
      if(!Number.isFinite(remaining))return;
      const hours=Math.floor(remaining/3600), minutes=Math.floor(remaining%3600/60), seconds=remaining%60;
      timer.textContent=remaining?(hours?String(hours).padStart(2,'0')+':':'')+String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0'):tr('timerDone');
      timer.classList.toggle('is-urgent',remaining<300);
    });
    document.querySelectorAll('[data-pay-until]').forEach(button=>{
      if(new Date(button.dataset.payUntil).getTime()<=now){button.disabled=true;button.textContent=tr('expired');}
    });
  }
  function updateFormLock() {
    const form=document.getElementById('walletTopupForm'); if(!form||!cached)return;
    const locked=Boolean(cached.pending_topup)||!cached.topup_available||cached.frozen;
    form.querySelectorAll('input,button,select').forEach(el=>{el.disabled=locked||submitting;});
    const selected=form.querySelector('input[name="walletProvider"]:checked')?.value;
    const fkSelect=form.querySelector('#walletFkMethod');
    if(fkSelect)fkSelect.disabled=locked||submitting||!currentFkMethods.length;
    if(selected==='freekassa'&&!currentFkMethods.some(x=>x.id===Number(fkSelect?.value)))form.querySelector('[type="submit"]').disabled=true;
    rollyLock();
    const message=document.getElementById('walletActiveWarning');
    if(message){message.hidden=!cached.pending_topup;message.textContent=tr('active');}
  }
  function renderHistory(items, append=false) {
    const holder = document.getElementById('walletHistory'); if (!holder) return;
    currentHistory = append ? currentHistory.concat(items) : items;
    holder.innerHTML = currentHistory.length ? currentHistory.map(row => `<div class="wallet-row wallet-ledger-row"><span class="wallet-entry-symbol ${row.amount_cents>0?'positive':''}">${walletIcon(row.amount_cents>0?'in':'out')}</span><div class="wallet-entry-copy"><div class="wallet-row-title">${esc(tr(row.kind))}</div><div class="wallet-row-sub">${esc(row.kind === 'topup' ? (row.label?.startsWith('FreeKassa')?'KASSA':row.label?.startsWith('Plisio')?'Plisio':row.label?.startsWith('RollyPay')?'RollyPay':'AnyPay') : row.label)} · ${esc(date(row.created_at))}</div></div><div class="wallet-row-value ${row.amount_cents>0?'positive':''}">${row.amount_cents>0?'+':'−'}${money(Math.abs(row.amount_cents))}</div></div>`).join('') : `<div class="wallet-empty wallet-empty-ledger"><span class="wallet-empty-symbol">${walletIcon('history')}</span><strong>${esc(tr('emptyTitle'))}</strong><p>${esc(tr('emptyHistory'))}</p></div>`;
  }
  function sectionLoading() {
    return `<p class="wallet-note" role="status">${esc(tr('loading'))}</p>`;
  }
  function sectionError(holder) {
    if(holder)holder.innerHTML=`<p class="wallet-error" role="alert">${esc(tr('sectionError'))}</p>`;
  }
  async function load() {
    if(loading)return;
    const holder=document.getElementById('walletContent');if(!holder)return;
    loading=true;
    const generation=++loadGeneration,token=localStorage.getItem('pulsarx_token');
    const previousAmount=document.getElementById('walletAmount')?.value;
    const openDetails=Array.from(holder.querySelectorAll('details[open]'),x=>x.id);
    const valid=()=>generation===loadGeneration&&token===localStorage.getItem('pulsarx_token');
    // Each local section can finish independently. In particular, no part of
    // this page waits for external payment-method discovery.
    const resource=path=>api(path).then(data=>({data}),error=>({error}));
    const historyRequest=resource('/history'),topupsRequest=resource('/topups'),ordersRequest=resource('/orders');
    if(!holder.querySelector('.wallet-shell'))holder.innerHTML=`<div class="wallet-shell" aria-busy="true"><section class="wallet-hero"><div class="wallet-eyebrow">${esc(tr('available'))} · USD</div><div class="wallet-amount wallet-placeholder">—</div>${sectionLoading()}</section><div class="wallet-grid"><section class="wallet-card"><h2>${esc(tr('topup'))}</h2>${sectionLoading()}</section><section class="wallet-card"><h2>${esc(tr('history'))}</h2>${sectionLoading()}</section></div></div>`;
    try {
      const balance=await refreshSummary();if(!balance||!valid())return;
      const methods=balance.providers||['anypay'];
      if(!methods.includes(selectedMethod))selectedMethod=methods[0]||null;
      const fkControl=methods.includes('freekassa')?`<div id="walletFkMethods" class="wallet-payment-method"><label class="wallet-label" for="walletFkMethod">${esc(tr('fkMethod'))}</label><select id="walletFkMethod" class="wallet-select" aria-describedby="walletMethodLimits"></select><p class="wallet-note" id="walletMethodLimits" aria-live="polite"></p><button type="button" class="wallet-check" id="walletMethodsRetry" hidden>${esc(tr('retry'))}</button></div>`:'';
      const payment=balance.pending_topup;hasPending=Boolean(payment);
      holder.innerHTML=`<div class="wallet-shell">
        ${balance.frozen?`<div class="wallet-warning">${esc(tr('frozen'))}</div>`:''}
        <div id="walletReturnNotice"></div>
        <section class="wallet-hero"><div class="wallet-balance-main"><div class="wallet-eyebrow">${esc(tr('available'))} · USD</div><div class="wallet-amount">${money(balance.balance_cents)}</div></div><p class="wallet-balance-use">${walletIcon('server')}<span>${esc(tr('sub'))}</span></p></section>
        ${payment?invoice(payment,true):''}
        <div class="wallet-grid">
          <section class="wallet-card wallet-topup-card"><h2>${esc(tr('topup'))}</h2><p id="walletActiveWarning" class="wallet-warning" hidden>${esc(tr('active'))}</p>
            <form id="walletTopupForm">
              <div class="wallet-amount-field"><label class="wallet-label" for="walletAmount">${esc(tr('amount'))} · ${money(balance.min_topup_cents)}–${money(balance.max_topup_cents)}</label><div class="wallet-input-wrap"><span>$</span><input id="walletAmount" inputmode="decimal" autocomplete="off" placeholder="5" maxlength="9" required aria-describedby="walletTopupNote walletTopupError"><span>USD</span></div><div class="wallet-picks">${[300,500,1000,2000].filter(v=>v>=balance.min_topup_cents&&v<=balance.max_topup_cents).map(v=>`<button type="button" data-cents="${v}">${money(v)}</button>`).join('')}</div></div>
              <fieldset class="wallet-methods"><legend class="wallet-label">${esc(tr('method'))}</legend>${methods.map(name=>`<label class="wallet-method"><input type="radio" name="walletProvider" value="${esc(name)}" ${name===selectedMethod?'checked':''} ${name==='freekassa'?'aria-controls="walletFkMethods"':''}><span class="wallet-provider-symbol">${walletIcon(name==='plisio'?'crypto':'card')}</span><span class="wallet-provider-copy"><strong>${esc(providerName(name))}</strong><small>${esc(tr(name==='rollypay'?'rollypayHint':name==='freekassa'?'freekassaHint':name==='plisio'?'plisioHint':'anypayHint'))}</small></span></label>`).join('')}</fieldset>
              ${fkControl}

              <div class="wallet-error" id="walletTopupError" role="alert"></div>
              <button class="btn wallet-topup-btn" type="submit">${esc(tr('go'))} ↗</button>
              <p class="wallet-note" id="walletTopupNote">${esc(tr('paymentNote'))}</p>
              <details class="wallet-help"><summary>${esc(tr('moreDetails'))}</summary><p class="wallet-note">${esc(tr('note'))}</p><p class="wallet-note">${esc(balance.topup_available?tr('deadline'):tr('unavailable'))}</p></details>
            </form>
          </section>
          <section class="wallet-card wallet-history-card"><div class="wallet-toolbar"><h2>${esc(tr('history'))}</h2><button class="wallet-check" id="walletRefresh">${esc(tr('refresh'))}</button></div><div id="walletHistory">${sectionLoading()}</div><button class="wallet-check wallet-more" id="walletMore" hidden>${esc(tr('more'))}</button>
            <details class="wallet-archive" id="walletInvoicesArchive"><summary>${esc(tr('pastInvoices'))}<span id="walletInvoicesCount"></span></summary><div id="walletTopups">${sectionLoading()}</div></details>
            <details class="wallet-archive" id="walletOrdersArchive"><summary>${esc(tr('operationsHint'))}<span id="walletOrdersCount"></span></summary><div id="walletOrders">${sectionLoading()}</div></details>
            <div class="wallet-error" id="walletCheckError" role="alert"></div>
          </section>
        </div>
      </div>`;
      if(previousAmount!==undefined)document.getElementById('walletAmount').value=previousAmount;
      for(const id of openDetails)document.getElementById(id)?.setAttribute('open','');
      document.getElementById('walletTopupForm').addEventListener('submit',submitTopup);
      holder.querySelectorAll('input[name="walletProvider"]').forEach(input=>input.addEventListener('change',()=>{selectedMethod=input.value;sessionStorage.setItem('px-wallet-topup-method',selectedMethod);updatePaymentMethods();}));
      document.getElementById('walletFkMethod')?.addEventListener('change',e=>{sessionStorage.setItem('px-wallet-fk-method',e.target.value);updateAmountLimits();});
      document.getElementById('walletMethodsRetry')?.addEventListener('click',()=>requestPaymentMethods(true));
      document.getElementById('walletAmount').addEventListener('input',event=>{event.target.dataset.edited='1';updateAmountLimits();});
      holder.querySelectorAll('[data-cents]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('walletAmount').value=(Number(b.dataset.cents)/100).toFixed(2);holder.querySelectorAll('[data-cents]').forEach(x=>x.classList.toggle('active',x===b));updateAmountLimits();}));
      document.getElementById('walletRefresh').addEventListener('click',()=>load());
      document.getElementById('walletMore').addEventListener('click',async e=>{const button=e.currentTarget;button.disabled=true;try{const data=await api('/history?offset='+offset);offset+=data.items.length;renderHistory(data.items,true);document.getElementById('walletMore').hidden=!data.has_more;}catch(error){document.getElementById('walletCheckError').textContent=error.message;}finally{button.disabled=false;}});
      updatePaymentMethods();paintPaymentMethods();tickCountdowns();
      if(returnState){const notice=document.getElementById('walletReturnNotice');notice.className='wallet-success';notice.textContent=tr(returnState==='success'?'notice':'failed');}
      loading=false;
      await Promise.all([
        historyRequest.then(result=>{if(!valid())return;if(result.error){sectionError(document.getElementById('walletHistory'));return;}offset=result.data.items.length;renderHistory(result.data.items);document.getElementById('walletMore').hidden=!result.data.has_more;}),
        topupsRequest.then(result=>{if(!valid())return;if(result.error){sectionError(document.getElementById('walletTopups'));return;}const rows=result.data;hasPending=hasPending||rows.some(active);const previous=rows.filter(row=>String(row.id)!==String(payment?.id));document.getElementById('walletTopups').innerHTML=previous.length?previous.map(row=>invoice(row)).join(''):`<div class="wallet-empty">${esc(tr('emptyInvoices'))}</div>`;document.getElementById('walletInvoicesCount').textContent=previous.length?String(previous.length):'';tickCountdowns();if(returnState&&rows.find(row=>String(row.id)===returnId)?.status==='credited')document.getElementById('walletReturnNotice').textContent=tr('credited');}),
        ordersRequest.then(result=>{if(!valid())return;if(result.error){sectionError(document.getElementById('walletOrders'));return;}const rows=result.data;hasPending=hasPending||rows.some(row=>row.status==='queued'||row.status==='working');document.getElementById('walletOrdersCount').textContent=rows.length?String(rows.length):'';document.getElementById('walletOrders').innerHTML=rows.length?rows.map(row=>`<div class="wallet-row"><div><div class="wallet-row-title">${esc(tr(row.kind))} · ${esc(row.plan)} · ${money(row.amount_cents)}</div><div class="wallet-row-sub">${esc(date(row.created_at))}</div></div><span class="wallet-state ${row.status==='completed'||row.status==='refunded'?'good':''}">${esc(tr(row.status))}</span></div>`).join(''):`<div class="wallet-empty">${esc(tr('emptyOrders'))}</div>`;})
      ]);
    } catch(error) {
      if(!valid())return;
      holder.innerHTML=`<div class="wallet-error" role="alert">${esc(error.message)}</div><button class="wallet-check" id="walletLoadRetry">${esc(tr('retry'))}</button>`;
      document.getElementById('walletLoadRetry').addEventListener('click',load);
    } finally {if(generation===loadGeneration)loading=false;}
  }

  // Balance layout r16: concise labels, with all payment behavior unchanged.
  Object.assign(copy.en, {topup:'Add funds',amount:'Top-up amount',method:'Pay with',history:'Transactions',go:'Continue to payment',sub:'For buying and renewing your servers.',emptyTitle:'No transactions yet',conversionLimits:'Enter USD here. Conversion and fees are shown at checkout.',paymentNote:'The processor shows the final amount and any fees before payment.'});
  Object.assign(copy.ru, {topup:'Пополнение',amount:'Сумма пополнения',method:'Оплата через',history:'История операций',go:'Перейти к оплате',sub:'Для покупки и продления серверов.',emptyTitle:'Операций пока нет',conversionLimits:'Введите сумму в USD. Пересчёт и комиссии — на странице оплаты.',paymentNote:'Итоговую сумму и комиссию вы увидите перед оплатой.'});
  Object.assign(copy.ro, {topup:'Alimentare',amount:'Suma alimentarii',method:'Plateste prin',history:'Tranzactii',go:'Continua la plata',sub:'Pentru cumpararea si reinnoirea serverelor.',emptyTitle:'Nu exista tranzactii',conversionLimits:'Introdu suma in USD. Conversia si comisioanele sunt afisate la plata.',paymentNote:'Procesatorul afiseaza suma finala si comisioanele inainte de plata.'});
  function walletIcon(kind) {
    const paths={card:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h3"/>',crypto:'<path d="m12 3 8 5v8l-8 5-8-5V8zM12 3v18M4 8l8 5 8-5"/>',history:'<path d="M3 11a9 9 0 1 1 2.7 7M3 4v7h7M12 7v5l3 2"/>',server:'<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01M16 7h2M16 17h2"/>',in:'<path d="M12 5v14m-5-5 5 5 5-5"/>',out:'<path d="M12 19V5m-5 5 5-5 5 5"/>'};
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[kind]||paths.card}</svg>`;
  }

  function publicCheckoutHost(host) {
    if(host.length>253||!host.includes('.')||host.endsWith('.'))return false;
    const labels=host.split('.');
    if(!labels.every(label=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))||!/^[a-z]{2,63}$/.test(labels.at(-1)))return false;
    if(['localhost','local','localdomain','internal','lan','home','test','invalid','example','onion','arpa'].includes(labels.at(-1)))return false;
    return !['pay.freekassa.net','pay.fk.money','fmt.me','payment.duckgo.io'].some(known=>host.startsWith(known+'.'));
  }
  function goCheckout(row) {
    const url=new URL(row.checkout_url);
    const valid=typeof row.checkout_url==='string'&&!/[\u0000-\u0020\u007f\\]/.test(row.checkout_url)&&url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&!url.hash&&
      (row.provider==='rollypay'?url.hostname==='pay.rollypay.io'&&/^\/pay\/[A-Za-z0-9_-]{1,256}$/.test(url.pathname)&&!url.search:
       row.provider==='plisio'?url.hostname==='plisio.net'&&/^\/invoice\/[a-f0-9]{24}$/.test(url.pathname)&&!url.search:
        row.provider==='freekassa'?(['pay.freekassa.net','pay.fk.money','fmt.me','payment.duckgo.io'].includes(url.hostname)||(row.checkout_api_verified===true&&publicCheckoutHost(url.hostname)))&&url.pathname.startsWith('/')&&url.href.length<=4096:row.provider==='anypay'&&url.hostname==='anypay.io'&&url.pathname==='/merchant');
    if(!valid)throw new Error(tr('error'));
    location.assign(url.href);
  }

  let rollyQuote=null,rollyFlight=null,rollyKey='',rollyGeneration=0,rollyExpiryTimer=null;
  Object.assign(copy.en,{rollypayHint:'SBP and methods available at checkout',rollyQuote:'To pay',rollyCredit:'Added to balance',rollyLoading:'Calculating the RUB amount…',rollyQuoteError:'Could not calculate the payment amount. Change the amount to try again.',rollypay_quote_expired:'The quote expired. Review the updated RUB amount and continue again.',rollypay_rejected:'RollyPay rejected this payment amount. Check the limits for the selected method on its payment page.',uncertain:'The request was already sent to the processor. Check the saved invoice or contact support; a duplicate will not be created.'});
  Object.assign(copy.ru,{rollypayHint:'СБП и способы, доступные на странице оплаты',rollyQuote:'К оплате',rollyCredit:'На баланс',rollyLoading:'Рассчитываем сумму в рублях…',rollyQuoteError:'Не удалось рассчитать сумму. Измените сумму, чтобы повторить.',rollypay_quote_expired:'Расчёт устарел. Проверьте новую сумму в рублях и снова продолжите оплату.',rollypay_rejected:'RollyPay отклонил сумму платежа. Уточните лимиты выбранного способа оплаты.',uncertain:'Запрос уже отправлен оператору. Проверьте сохранённый счёт или обратитесь в поддержку; повторный заказ не создаётся.'});
  Object.assign(copy.ro,{rollypayHint:'SBP si metode disponibile la plata',rollyQuote:'De achitat',rollyCredit:'In sold',rollyLoading:'Se calculeaza suma in RUB…',rollyQuoteError:'Suma nu a putut fi calculata. Modifica suma pentru a reincerca.',rollypay_quote_expired:'Calculul a expirat. Verifica noua suma in RUB si continua din nou.',rollypay_rejected:'RollyPay a refuzat suma. Verifica limitele metodei alese.',uncertain:'Cererea a fost trimisa procesatorului. Verifica factura salvata sau contacteaza suportul; nu cream o comanda duplicata.'});
  function rollyCurrent(){return document.querySelector('input[name="walletProvider"]:checked')?.value==='rollypay';}
  function rollyReady(){return rollyQuote&&rollyQuote.amount_cents===inputCents()&&rollyQuote._token===localStorage.getItem('pulsarx_token')&&Date.parse(rollyQuote.expires_at)>Date.now()+clockOffset+1000;}
  function rollyLock(){
    const button=document.querySelector('#walletTopupForm [type="submit"]');
    if(!button)return;
    if(rollyCurrent()){
      button.disabled=button.disabled||!rollyReady();
      button.textContent=rollyReady()?`${tr('go')} · ${rollyQuote.payment_amount} ₽ ↗`:tr('go')+' ↗';
    }else button.textContent=tr('go')+' ↗';
  }
  async function refreshRollyQuote(force=false){
    const form=document.getElementById('walletTopupForm');if(!form)return;
    let box=document.getElementById('walletRollyQuote');
    if(!box){box=document.createElement('p');box.id='walletRollyQuote';box.className='wallet-note';box.setAttribute('aria-live','polite');form.querySelector('#walletTopupError').before(box);}
    box.hidden=!rollyCurrent()||Boolean(cached?.pending_topup)||Boolean(cached?.frozen);if(box.hidden){rollyGeneration++;rollyKey='';rollyFlight=null;return;}
    const amount=inputCents(),token=localStorage.getItem('pulsarx_token'),bounds=topupBounds();
    if(!Number.isSafeInteger(amount)||amount<bounds.min||amount>bounds.max){rollyQuote=null;rollyGeneration++;rollyKey='';rollyFlight=null;box.textContent='';updateFormLock();return;}
    const key=token+':'+amount;
    if(!force&&rollyReady()){box.textContent=`${tr('rollyQuote')}: ${rollyQuote.payment_amount} RUB · ${tr('rollyCredit')}: ${money(amount)}`;updateFormLock();return;}
    if(!force&&rollyFlight&&rollyKey===key)return rollyFlight;
    rollyQuote=null;rollyKey=key;const generation=++rollyGeneration;
    box.textContent=tr('rollyLoading');updateFormLock();
    const flight=api('/rollypay/quote?amount_cents='+amount,undefined,true).then(data=>{
      if(generation!==rollyGeneration||token!==localStorage.getItem('pulsarx_token')||!rollyCurrent()||amount!==inputCents())return;
      if(data.amount_cents!==amount||data.payment_currency!=='RUB'||!/^\d+\.\d{2}$/.test(data.payment_amount)||typeof data.quote_token!=='string'||!Number.isFinite(Date.parse(data.expires_at)))throw new Error(tr('rollyQuoteError'));
      rollyQuote={...data,_token:token};
      box.textContent=`${tr('rollyQuote')}: ${data.payment_amount} RUB · ${tr('rollyCredit')}: ${money(amount)}`;
      clearTimeout(rollyExpiryTimer);
      rollyExpiryTimer=setTimeout(()=>{if(generation===rollyGeneration&&rollyCurrent())refreshRollyQuote(true);},Math.max(1000,Date.parse(data.expires_at)-Date.now()-clockOffset));
    }).catch(()=>{if(generation===rollyGeneration){rollyQuote=null;box.textContent=tr('rollyQuoteError');}}).finally(()=>{if(rollyFlight===flight)rollyFlight=null;updateFormLock();});
    rollyFlight=flight;return flight;
  }

  async function submitTopup(event) {
    event.preventDefault(); if(submitting)return;
    if(cached?.pending_topup){updateReminder(cached.pending_topup);return;}
    const error=document.getElementById('walletTopupError'); error.textContent='';
    const raw=document.getElementById('walletAmount').value.trim().replace(',','.');
    if (!/^\d{1,6}(?:\.\d{1,2})?$/.test(raw)) {error.textContent=tr('range');return;}
    const [whole, fraction='']=raw.split('.'), amount=Number(whole)*100+Number(fraction.padEnd(2,'0'));
    const bounds=topupBounds();
    if (!cached||!cached.topup_available||amount<bounds.min||amount>bounds.max) {error.textContent=`${tr('amountOutside')} ${tr('from')} ${money(bounds.min)} ${tr('to')} ${money(bounds.max)} USD.`;return;}
    const method=document.querySelector('input[name="walletProvider"]:checked')?.value||cached.providers?.[0]||'anypay';
    const provider=method;
    if(provider==='rollypay'&&!rollyReady()){await refreshRollyQuote(true);return;}
    const provider_method=provider==='freekassa'?Number(document.getElementById('walletFkMethod')?.value):undefined;
    if(provider==='freekassa'&&(!Number.isInteger(provider_method)||provider_method<=0)){error.textContent=tr('fkUnavailable');return;}
    submitting=true; updateFormLock(); const identity=intent({topup:amount,provider,provider_method});
    try {
      const row=await api('/topups',{amount_cents:amount,provider,provider_method,request_key:identity.key,rollypay_quote:provider==='rollypay'?rollyQuote.quote_token:undefined});
      sessionStorage.removeItem(identity.name);
      if(row.checkout_url)goCheckout(row);else await load();
    } catch(e) {if(['payment_amount_range','rollypay_rejected'].includes(e.code))sessionStorage.removeItem(identity.name);if(e.code==='rollypay_quote_expired'){rollyQuote=null;refreshRollyQuote(true);}await refreshSummary().catch(()=>{});if(cached?.pending_topup||e.code==='payment_amount_range')await load();document.getElementById('walletTopupError').textContent=e.message;}
    finally{submitting=false;updateFormLock();}
  }
  async function confirmClose() {
    if(document.querySelector('dialog.wallet-dialog[open]'))return false;
    const dialog=document.createElement('dialog'); dialog.className='wallet-dialog';dialog.setAttribute('aria-labelledby','pxWalletCloseTitle');
    dialog.innerHTML=`<h2 id="pxWalletCloseTitle">${esc(tr('closeTitle'))}</h2><p class="wallet-muted">${esc(tr('closeNote'))}</p><div class="wallet-dialog-actions"><button class="btn btn-ghost" data-close-back>${esc(tr('back'))}</button><button class="btn" data-close-confirm>${esc(tr('closeInvoice'))}</button></div>`;
    document.body.appendChild(dialog); dialog.showModal();
    return new Promise(resolve=>{let accepted=false;dialog.querySelector('[data-close-back]').addEventListener('click',()=>dialog.close());dialog.querySelector('[data-close-confirm]').addEventListener('click',()=>{accepted=true;dialog.close();});dialog.addEventListener('close',()=>{dialog.remove();resolve(accepted);},{once:true});});
  }
  document.addEventListener('click',async event=>{
    const toggle=event.target.closest?.('[data-wallet-toggle]');
    if(toggle){collapsedId=collapsedId===toggle.dataset.walletToggle?'':toggle.dataset.walletToggle;sessionStorage.setItem('px-wallet-reminder-collapsed',collapsedId);updateReminder(cached?.pending_topup);return;}
    const button=event.target.closest?.('[data-wallet-action]');if(!button||button.disabled)return;
    const id=button.dataset.invoice, action=button.dataset.walletAction;
    if(busyActions.has(id))return;busyActions.add(id);button.disabled=true;
    try {
      if(action==='cancel'&&!await confirmClose())return;
      const result=await api('/topups/'+encodeURIComponent(id)+'/'+action,{});
      if(action==='checkout')goCheckout(result);else{
        if(action==='cancel'){
          const identity=intent({topup:result.amount_cents,provider:result.provider,provider_method:result.provider==='freekassa'?result.provider_method:undefined});
          sessionStorage.removeItem(identity.name);
        }
        await refreshSummary();await load();
      }
    } catch(error){
      await refreshSummary().catch(()=>{});
      document.querySelectorAll('#walletCheckError,[data-notice-error]').forEach(box=>{box.textContent=error.message;});
    } finally {busyActions.delete(id);button.disabled=false;tickCountdowns();}
  });
  async function confirmOrder(payload) {
    if(document.querySelector('dialog.wallet-dialog[open]'))return null;
    const quote=await api('/quote',{...payload,request_key:crypto.randomUUID()});
    if(document.querySelector('dialog.wallet-dialog[open]'))return null;
    const dialog=document.createElement('dialog');dialog.className='wallet-dialog';dialog.setAttribute('aria-labelledby','pxWalletConfirmTitle');
    dialog.innerHTML=`<h2 id="pxWalletConfirmTitle">${esc(tr('confirm'))}</h2><div class="wallet-muted">${esc(tr(payload.kind))}</div><div class="wallet-amount">${money(quote.amount_cents)}</div><p class="wallet-muted">${esc(tr('balance'))}: ${money(quote.balance_cents)}</p><p class="wallet-muted">${esc(tr(quote.shortfall_cents?'short':'cost'))}</p><div class="wallet-error" role="alert"></div><div class="wallet-dialog-actions"><button class="btn btn-ghost" data-cancel>${esc(tr('cancel'))}</button>${quote.shortfall_cents?`<a class="btn" href="/dashboard/?tab=wallet">${esc(tr('add'))}</a>`:`<button class="btn" data-confirm>${esc(tr('pay'))}</button>`}</div>`;
    document.body.appendChild(dialog);dialog.showModal();
    return new Promise(resolve=>{
      let busy=false;
      dialog.querySelector('[data-cancel]').addEventListener('click',()=>dialog.close());
      dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
      dialog.addEventListener('close',()=>{dialog.remove();resolve(null);},{once:true});
      dialog.querySelector('[data-confirm]')?.addEventListener('click',async e=>{
        if(busy)return;busy=true;e.currentTarget.disabled=true;dialog.querySelector('[data-cancel]').disabled=true;
        try {const row=await createOrder(payload,quote.amount_cents);resolve(row);dialog.close();if(typeof showToast==='function')showToast(tr('success'),tr('processing'));if(typeof loadServers==='function')loadServers();}
        catch(error){dialog.querySelector('[role="alert"]').textContent=error.message;e.target.disabled=false;dialog.querySelector('[data-cancel]').disabled=false;busy=false;}
      });
    });
  }
  function open() {
    document.querySelector('.nav-item[data-page="wallet"]')?.click(); load();
  }
  const query=new URLSearchParams(location.search), returnState=query.get('wallet_payment'), returnId=query.get('topup');
  window.PxWallet={api, createOrder, confirmOrder, load, open, refreshSummary, tr, money};
  document.querySelector('.nav-item[data-page="wallet"]')?.addEventListener('click',load);
  function init(){
    if(!localStorage.getItem('pulsarx_token'))return;
    refreshSummary().catch(()=>{});
    if(document.getElementById('walletContent')&&(query.get('tab')==='wallet'||returnState))open();
    if(returnState){const clean=new URL(location.href);clean.searchParams.delete('wallet_payment');clean.searchParams.delete('topup');history.replaceState(null,'',clean.pathname+clean.search+clean.hash);}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  setInterval(tickCountdowns,1000);
  setInterval(()=>{
    if(!localStorage.getItem('pulsarx_token')){document.getElementById('pxWalletPaymentNotice')?.remove();return;}
    if(document.visibilityState==='hidden')return;
    if(hasPending&&document.getElementById('page-wallet')?.classList.contains('show')&&!document.activeElement?.closest('#walletTopupForm')&&!document.querySelector('dialog.wallet-dialog[open]'))load();else refreshSummary().catch(()=>{});
  },15000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='hidden')refreshSummary().catch(()=>{});});
  window.addEventListener('focus',()=>refreshSummary().catch(()=>{}));
  window.addEventListener('storage',event=>{if(event.key==='pulsarx_token')refreshSummary().catch(()=>{});});
})();
