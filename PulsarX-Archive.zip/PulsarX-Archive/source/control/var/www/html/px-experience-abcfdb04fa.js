/* Presentation only: keep payment elements and their listeners intact when moving them. */
(() => {
  'use strict';
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  function decorateInvoices(){
    document.querySelectorAll('.wallet-active-invoice .wallet-row-title').forEach(title=>{
      if(title.dataset.invoiceDecorated)return;
      title.dataset.invoiceDecorated='1';
      const parts=title.textContent.split(' · ');if(parts.length<2||parts.length>3)return;
      const provider=document.createElement('span');provider.className='invoice-provider';provider.textContent=parts[0];
      const amount=document.createElement('strong');amount.className='invoice-credit';amount.textContent=parts[1];
      title.replaceChildren(provider,document.createTextNode(' '),amount);
      if(parts[2]){const converted=document.createElement('span');converted.className='invoice-converted';converted.textContent=parts[2];title.append(document.createTextNode(' '),converted);}
    });
  }
  function arrangeWallet(){
    decorateInvoices();
    document.querySelectorAll('#walletHistory .wallet-row-title').forEach(n=>{if(n.textContent==='admin_grant'){n.dataset.t='adminGrant';n.textContent=window.Pulse.t('adminGrant');}});
    const shell=document.querySelector('#walletContent .wallet-shell');
    if(!shell||shell.dataset.financeLayout)return;
    const hero=shell.querySelector('.wallet-hero'),topup=shell.querySelector('.wallet-topup-card'),history=shell.querySelector('.wallet-history-card');
    if(!hero||!topup||!history)return;
    shell.dataset.financeLayout='1';
    const layout=document.createElement('div');layout.className='finance-layout';
    const aside=document.createElement('aside');aside.className='finance-aside';
    const main=document.createElement('div');main.className='finance-main';
    shell.insertBefore(layout,hero);layout.append(aside,main);aside.append(hero);
    hero.querySelector('.px-growth-invite')?.remove();
    const active=shell.querySelector('#walletActiveInvoice');if(active)main.append(active);
    main.append(topup);shell.append(history);shell.querySelector('.wallet-grid')?.remove();
  }
  function revealOnScroll(){
    if(reduced()||!('IntersectionObserver' in window))return;
    const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){entry.target.classList.add('revealed');observer.unobserve(entry.target);}},{threshold:.09,rootMargin:'0px 0px -30px 0px'});
    document.querySelectorAll('[data-reveal]').forEach((node,i)=>{if(node.getBoundingClientRect().top>innerHeight*.88){node.classList.add('will-reveal');node.style.setProperty('--reveal-delay',String(i%2*70)+'ms');observer.observe(node);}else node.classList.add('revealed');});
  }
  function init(){
    revealOnScroll();
    const holder=document.getElementById('walletContent');
    if(holder){new MutationObserver(arrangeWallet).observe(holder,{childList:true,subtree:true});arrangeWallet();}
    document.querySelectorAll('.site-dock a').forEach(a=>{
      const u=new URL(a.href,location.origin),active=u.pathname===location.pathname&&u.search===location.search;
      a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');
    });
    window.addEventListener('pageshow',()=>document.body.classList.remove('is-leaving'));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
