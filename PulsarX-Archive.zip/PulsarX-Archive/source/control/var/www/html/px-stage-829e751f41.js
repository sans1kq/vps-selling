/* Public price display only: every launch continues to the existing deploy flow. */
(() => {
  'use strict';
  const P=window.Pulse, t=P.t, periods=[1,3,6,12];
  const query=new URLSearchParams(location.search);
  let plan=query.get('plan')==='plus'?'plus':'mini', months=1;
  const prices={mini:{1:300},plus:{1:500}};
  const el=id=>document.getElementById(id);
  const money=cents=>'$'+(cents/100).toFixed(2).replace(/\.00$/,'');
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  function render(animate=false){
    if(!prices[plan][months])months=1;
    document.body.dataset.stagePlan=plan;
    document.querySelectorAll('[data-stage-plan]').forEach(b=>{
      const on=b.dataset.stagePlan===plan;b.classList.toggle('selected',on);
      b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;
    });
    document.querySelector('.plan-switch').style.setProperty('--plan-index',plan==='plus'?'1':'0');
    const total=prices[plan][months];
    el('stagePrice').textContent=money(Math.round(total/months));
    el('stageCpu').textContent=(plan==='mini'?1:2)+' vCPU';
    el('stageRam').textContent=(plan==='mini'?1:4)+' GB RAM';
    el('stageDisk').textContent=(plan==='mini'?25:50)+' GB SSD';
    el('stageLaunchText').removeAttribute('data-t');
    el('stageLaunchText').textContent=t(plan==='mini'?'launchMini':'launchPlus');
    el('stageLaunch').href='/deploy/?plan='+plan+'&months='+months;
    el('stageTotal').textContent=months===1?'':t('payForPeriod',{amount:money(total),n:months});
    for(const option of el('stagePeriod').options){
      const m=Number(option.value);option.disabled=!prices[plan][m];option.textContent=t('months',{n:m});
    }
    el('stagePeriod').value=String(months);
    const from=document.querySelector('[data-t=stageFrom]');
    from.textContent=t('stageFrom').replace('$3',money(Math.min(prices.mini[1],prices.plus[1])));
    if(animate&&!reduced())for(const node of [el('stagePrice'),document.querySelector('.console-resources'),el('stageLaunchText')])
      node.animate?.([{opacity:.2,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:260,easing:'cubic-bezier(.2,.8,.2,1)'});
  }
  function choose(next){if(next===plan)return;plan=next;render(true);}
  function selectInfo(key){
    document.querySelectorAll('[data-info-tab]').forEach(b=>{
      const active=b.dataset.infoTab===key;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;
      document.getElementById(b.getAttribute('aria-controls')).hidden=!active;
    });
  }
  async function init(){
    if(!el('stageLaunch'))return;P.apply();render();
    document.querySelectorAll('[data-stage-plan]').forEach(b=>{
      b.addEventListener('click',()=>choose(b.dataset.stagePlan));
      b.addEventListener('keydown',e=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();
        choose(e.key==='Home'?'mini':e.key==='End'?'plus':plan==='mini'?'plus':'mini');
        document.querySelector('[data-stage-plan='+plan+']').focus();
      });
    });
    el('stagePeriod').addEventListener('change',()=>{const value=Number(el('stagePeriod').value);if(periods.includes(value)&&prices[plan][value]){months=value;render(true);}});
    const tabs=Array.from(document.querySelectorAll('[data-info-tab]'));
    tabs.forEach((b,i)=>{
      b.addEventListener('click',()=>selectInfo(b.dataset.infoTab));
      b.addEventListener('keydown',e=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();
        const n=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
        selectInfo(tabs[n].dataset.infoTab);tabs[n].focus();
      });
    });
    document.addEventListener('px:lang',()=>render());
    try{
      const data=await P.api('/api/servers/pricing',{},false);
      for(const p of ['mini','plus'])for(const m of periods){
        const raw=String(data?.prices?.[p]?.[m]??'');
        if(/^\d{1,7}(?:\.\d{1,2})?$/.test(raw)&&Number(raw)>0)prices[p][m]=Math.round(Number(raw)*100);
      }
      const wanted=Number(query.get('months'));if(periods.includes(wanted)&&prices[plan][wanted])months=wanted;
      render();
    }catch{/* One-month fallback remains visible; unverified longer periods stay disabled. */}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
