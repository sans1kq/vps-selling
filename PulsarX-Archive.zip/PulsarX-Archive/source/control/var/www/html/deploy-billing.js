/* PulsarX deploy page: billing period picker with prices from /api/servers/pricing. */
let selectedMonths = 1;
(function () {
  const style = document.createElement('style');
  style.textContent =
    '.periods{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px}' +
    '.period-option{border:1px solid #22222e;border-radius:10px;padding:12px;cursor:pointer;background:#12121b;text-align:center}' +
    '.period-option.selected{border-color:#8b7cff;box-shadow:0 0 0 1px #8b7cff inset}' +
    '.period-option .p-name{font-weight:600}' +
    '.period-option .p-price{font-family:"IBM Plex Mono",monospace;font-size:14px;margin-top:4px}' +
    '.period-option .p-off{font-size:12px;color:#34d399;margin-top:2px}' +
    '.pay-note{font-size:13px;opacity:.75;line-height:1.5;margin:0 0 18px}';
  document.head.appendChild(style);

  const btn = document.getElementById('deployBtn');
  const h = document.createElement('h2');
  h.setAttribute('data-i18n', 'deploy_pick_period');
  h.textContent = t('deploy_pick_period', 'Billing period');
  const box = document.createElement('div');
  box.className = 'periods';
  const note = document.createElement('p');
  note.className = 'pay-note';
  note.setAttribute('data-i18n', 'deploy_pay_note');
  note.textContent = t('deploy_pay_note', 'You pay in crypto (BTC, ETH, SOL, LTC, TON, USDT). Nothing is charged automatically: pay once for the period you choose and renew whenever you like. Send the full amount before the payment timer ends, in one or several transfers. Partial and late payments are not credited, and an overpayment is not refunded.');
  btn.parentNode.insertBefore(h, btn);
  btn.parentNode.insertBefore(box, btn);
  btn.parentNode.insertBefore(note, btn);

  let pricing = null, shownPlan = null;
  function render() {
    shownPlan = selectedPlan;
    const prices = (pricing && pricing.prices && pricing.prices[selectedPlan]) || {};
    const disc = (pricing && pricing.discount_pct) || {};
    box.innerHTML = [1, 3, 6, 12].map(m => `
      <div class="period-option${m === selectedMonths ? ' selected' : ''}" data-m="${m}">
        <div class="p-name">${t('deploy_period_' + m, m + ' mo')}</div>
        <div class="p-price">${prices[String(m)] ? '$' + prices[String(m)] : '-'}</div>
        ${disc[String(m)] ? `<div class="p-off">${t('deploy_period_off', '{pct}% off').replace('{pct}', disc[String(m)])}</div>` : ''}
      </div>`).join('');
    box.querySelectorAll('.period-option').forEach(el => el.addEventListener('click', () => {
      selectedMonths = parseInt(el.dataset.m, 10);
      render();
    }));
  }
  render();
  fetch('/api/servers/pricing').then(r => r.json()).then(d => { pricing = d; render(); }).catch(() => {});
  setInterval(() => { if (shownPlan !== selectedPlan) render(); }, 500);
})();
