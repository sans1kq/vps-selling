/* Small, independent translations; existing site language and assets are retained. */
(() => {
  'use strict';
  const copy={
    en:{nav_community:'Community',eyebrow:'COMMUNITY & SUPPORT',heading:'Stay connected with PulsarX.',intro:'Join us on Telegram, or open a private support ticket when you need help.',community_tag:'COMMUNITY',community_title:'PulsarX community',community_body:'Find PulsarX on Telegram. Join the community and stay in touch with the project.',community_button:'Join the community',support_tag:'PRIVATE SUPPORT',support_title:'Support in Telegram',support_body:'Questions about your account, server or payment? Send a private message to our support bot.',support_steps:'Send this command, then describe your issue in the next message. Our reply will arrive in the bot.',support_button:'Open support bot',email_label:'Prefer email?',footer_support:'Telegram support'},
    ru:{nav_community:'Коммьюнити',eyebrow:'КОММЬЮНИТИ И ПОДДЕРЖКА',heading:'На связи с PulsarX.',intro:'Присоединяйтесь к нам в Telegram, а если нужна помощь — создайте личное обращение в поддержку.',community_tag:'СООБЩЕСТВО',community_title:'Коммьюнити PulsarX',community_body:'PulsarX в Telegram. Присоединяйтесь к сообществу и оставайтесь на связи с проектом.',community_button:'Присоединиться',support_tag:'ЛИЧНЫЕ ОБРАЩЕНИЯ',support_title:'Поддержка в Telegram',support_body:'Вопрос по аккаунту, серверу или оплате? Напишите в личный чат нашего бота поддержки.',support_steps:'Отправьте эту команду, затем следующим сообщением опишите проблему. Ответ придёт в бот.',support_button:'Открыть бота поддержки',email_label:'Удобнее по почте?',footer_support:'Поддержка в Telegram'},
    ro:{nav_community:'Comunitate',eyebrow:'COMUNITATE ȘI SUPORT',heading:'Rămâi în legătură cu PulsarX.',intro:'Alătură-te comunității pe Telegram sau deschide un tichet privat când ai nevoie de ajutor.',community_tag:'COMUNITATE',community_title:'Comunitatea PulsarX',community_body:'PulsarX pe Telegram. Alătură-te comunității și rămâi în legătură cu proiectul.',community_button:'Alătură-te comunității',support_tag:'SUPORT PRIVAT',support_title:'Suport pe Telegram',support_body:'Ai o întrebare despre cont, server sau plată? Scrie un mesaj privat botului nostru de suport.',support_steps:'Trimite această comandă, apoi descrie problema în mesajul următor. Răspunsul va veni în bot.',support_button:'Deschide botul de suport',email_label:'Preferi emailul?',footer_support:'Suport pe Telegram'}
  };
  function translate(){
    const language=(document.documentElement.lang||'en').split('-')[0];const dict=copy[language]||copy.en;
    document.querySelectorAll('[data-px-connect]').forEach(node=>{const value=dict[node.getAttribute('data-px-connect')];if(value!==undefined)node.textContent=value;});
  }
  translate();document.addEventListener('DOMContentLoaded',translate);
  new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();
