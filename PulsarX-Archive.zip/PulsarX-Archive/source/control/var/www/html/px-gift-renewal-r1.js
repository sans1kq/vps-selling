/* Paid gift retention; prices, owner checks and debits remain on the server. */
(() => {
  'use strict';
  const P = window.Pulse;
  if (!P || !document.getElementById('serversContent')) return;
  const words = {
    title: ['Сохраните подарочный Nano', 'Keep your gift Nano', 'Păstrează serverul Nano cadou'],
    until: ['Без оплаты VPS и данные будут удалены: ', 'Without renewal the VPS and data will be deleted: ', 'Fără reînnoire, VPS-ul și datele vor fi șterse: '],
    expired: ['Срок истёк. Продлите сейчас, пока сервер ещё не удалён.', 'The gift has expired. Renew while the server still exists.', 'Perioada a expirat. Reînnoiește cât timp serverul încă există.'],
    note: ['Продлите Nano с сохранением данных. После оплаты можно перейти на Mini или Plus. Автосписаний нет.', 'Renew Nano and keep your data. After renewal you can upgrade to Mini or Plus. No automatic charges.', 'Reînnoiește Nano și păstrează datele. După plată poți trece la Mini sau Plus. Fără debitări automate.'],
    renew: ['Продлить Nano', 'Renew Nano', 'Reînnoiește Nano'],
    first: ['Сначала продлите сервер, затем выберите апгрейд.', 'Renew this server before upgrading.', 'Reînnoiește serverul înainte de upgrade.'],
    warning: ['Отсчёт начнётся после готовности. Без платного продления через 72 часа VPS и данные будут удалены. После продления можно повысить тариф.', 'The timer starts when ready. Without paid renewal the VPS and data are deleted after 72 hours. After renewal you can upgrade.', 'Perioada începe când serverul este gata. Fără reînnoire plătită, VPS-ul și datele sunt șterse după 72 de ore. După reînnoire poți face upgrade.']
  };
  let state = null, fetching = false, busy = false;
  const t = key => words[key][({ru: 0, en: 1, ro: 2})[P.getLang()] ?? 0];
  const node = (tag, text, cls) => { const el = document.createElement(tag); if (text) el.textContent = text; if (cls) el.className = cls; return el; };
  function render() {
    document.getElementById('pxGiftRetention')?.remove();
    // Use the common dictionary so later language rerenders keep the new terms.
    P.merge({giftWarning: words.warning});
    document.querySelectorAll('[data-t="giftWarning"]').forEach(el => { el.textContent = t('warning'); });
    if (!state?.gifts?.length) return;
    const section = node('section', '', 'px-gift-retention'); section.id = 'pxGiftRetention';
    section.setAttribute('aria-label', t('title'));
    for (const gift of state.gifts) {
      const card = node('div', '', 'px-gift-retention-row');
      const text = node('div'); text.append(node('h3', t('title') + ' · ' + gift.name));
      const deadline = new Date(gift.expires_at);
      text.append(node('p', deadline <= new Date() ? t('expired') : t('until') + deadline.toLocaleString()));
      text.append(node('p', t('note'), 'help-text'));
      const btn = node('button', t('renew') + ' · ' + P.currency(gift.monthly_cents), 'btn'); btn.type = 'button';
      btn.addEventListener('click', async () => {
        if (busy) return; busy = true; btn.disabled = true;
        try {
          if (!window.PxWallet?.confirmOrder) throw new Error(t('first'));
          const order = await window.PxWallet.confirmOrder({kind: 'renew', server_id: gift.id, months: 1});
          if (order) { location.reload(); return; }
        } catch (error) { P.toast(error.message); }
        finally { busy = false; btn.disabled = false; await refresh(); }
      });
      card.append(text, btn); section.append(card);
    }
    document.getElementById('serversContent').before(section);
  }
  async function refresh() {
    if (fetching || busy || document.visibilityState === 'hidden') return;
    if (!localStorage.getItem('pulsarx_token')) { state = null; document.getElementById('pxGiftRetention')?.remove(); return; }
    fetching = true;
    try { state = await P.api('/api/wallet/gift-renewals'); render(); }
    catch { /* The primary dashboard reports session and connection errors. */ }
    finally { fetching = false; }
  }
  // The backend is authoritative. This capture handler also gives a clear
  // explanation before opening the old upgrade dialog for an expired VPS.
  document.addEventListener('click', event => {
    const button = event.target.closest?.('[data-upgrade],[data-flex-upgrade]');
    if (!button) return;
    const detail = button.closest('[data-server-detail]');
    const id = detail?.dataset.serverDetail || button.dataset.serverId;
    if (state?.renew_first_ids?.includes(id)) {
      event.preventDefault(); event.stopImmediatePropagation(); P.toast(t('first'));
    }
  }, true);
  document.addEventListener('px:lang', render);
  window.addEventListener('storage', event => { if (event.key === 'pulsarx_token') refresh(); });
  document.addEventListener('visibilitychange', refresh);
  setInterval(refresh, 60000);
  refresh();
})();
