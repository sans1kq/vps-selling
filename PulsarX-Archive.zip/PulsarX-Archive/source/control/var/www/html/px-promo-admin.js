(() => {
  const panel = document.getElementById('tab-gifts');
  if (!panel) return;
  panel.innerHTML = `<section class="panel"><header class="panel-head"><h2>Новый промокод VPS</h2></header>
    <form class="panel-body" id="promo-create"><div class="form-grid">
      <label class="field">Название промокода<input name="name" maxlength="64" required></label>
      <label class="field">Срок работы Nano VPS<input name="duration" type="number" min="1" step="1" required value="3"></label>
      <label class="field">Единица времени<select name="unit"><option value="24">Дни</option><option value="1">Часы</option></select></label>
      <label class="field">Принимать код до (необязательно, местное время)<input name="end" type="datetime-local"></label></div>
      <button class="btn" type="submit">Создать промокод</button></form>
      <p role="status" class="panel-body"></p><div class="panel-body" id="promo-list"></div></section>`;
  const form = panel.querySelector('form');
  const status = panel.querySelector('[role=status]');
  async function request(path, body) {
    const response = await fetch('/api/admin/promotions' + path, {
      method:body ? 'POST' : 'GET', cache:'no-store',
      headers:{Authorization:'Bearer ' + localStorage.getItem('pulsarx_admin_token'),'Content-Type':'application/json'},
      body:body && JSON.stringify(body)
    });
    const data=await response.json();
    if (!response.ok) throw Error(typeof data.detail==='string' ? data.detail : 'Проверьте введённые данные');
    return data;
  }
  async function refresh() {
    const rows=await request('');
    const list=panel.querySelector('#promo-list');
    list.replaceChildren();
    for (const row of rows) {
      const block=document.createElement('p');
      const active=!row.closed_at && (!row.ends_at || Date.parse(row.ends_at)>Date.now());
      block.textContent=row.name+' · Nano на '+row.duration_hours+' ч. · '+(row.closed_at?'Закрыт':row.ends_at?'До '+new Date(row.ends_at).toLocaleString():'До ручного закрытия')+' ';
      if (active) {
        const close=document.createElement('button');
        close.className='btn'; close.textContent='Закрыть';
        close.onclick=async()=>{close.disabled=true;try {await request('/close',{name:row.name});await refresh();} catch(e){status.textContent=e.message;close.disabled=false;}};
        block.append(close);
      }
      list.append(block);
    }
  }
  form.onsubmit=async event=>{
    event.preventDefault();const submit=form.querySelector('button');submit.disabled=true;
    try {
      await request('',{name:form.elements.name.value,duration_hours:Number(form.elements.duration.value)*Number(form.elements.unit.value),
        ends_at:form.elements.end.value ? new Date(form.elements.end.value).toISOString() : null});
      status.textContent='Промокод создан';form.reset();await refresh();
    } catch(e){status.textContent=e.message;} finally{submit.disabled=false;}
  };
  document.addEventListener('px:admin-promos',()=>refresh().catch(e=>status.textContent=e.message));
  if(panel.classList.contains('active'))refresh().catch(e=>status.textContent=e.message);
})();
