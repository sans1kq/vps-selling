(function(){
  if (window.__pulsarxV31) return;
  window.__pulsarxV31 = true;

  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const surfaces = document.querySelectorAll([
    '.landing-page .cap-card', '.landing-page .promise-card', '.landing-page .use-card-v3',
    '.landing-page .plan-v3', '.landing-page .faq-item', '.landing-page .status-card',
    '.dashboard-page .stat-card', '.dashboard-page .row-card', '.dashboard-page .mon-chart-card',
    '.deploy-v31 .plan-option', '.deploy-v31 .os-option', '.deploy-v31 .period-option'
  ].join(','));

  surfaces.forEach(el => {
    el.classList.add('interactive-surface');
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--ix', (e.clientX - r.left) + 'px');
      el.style.setProperty('--iy', (e.clientY - r.top) + 'px');
    }, {passive:true});
  });

  if (!reduced && 'IntersectionObserver' in window) {
    const revealTargets = document.querySelectorAll([
      '.landing-page .v3-section > .wrap > *',
      '.landing-page .live-strip',
      '.landing-page .final-cta',
      '.dashboard-page .page-head',
      '.dashboard-page .stat-grid',
      '.deploy-v31 .deploy-step-card'
    ].join(','));
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('motion-in');
        io.unobserve(entry.target);
      });
    }, {threshold:0.08, rootMargin:'0px 0px -30px 0px'});
    revealTargets.forEach((el, i) => {
      el.classList.add('motion-reveal');
      el.style.transitionDelay = Math.min((i % 4) * 55, 165) + 'ms';
      io.observe(el);
    });
  }
})();
