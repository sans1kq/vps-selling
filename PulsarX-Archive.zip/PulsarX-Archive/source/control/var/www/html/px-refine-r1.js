/* Additive theme, account information and explicit gift activation. */
(()=>{'use strict';
 const root=document.documentElement;
 root.dataset.pxTheme='dark';try{localStorage.removeItem('px-public-theme');}catch{}
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
 const tx=(ru,en,ro)=>({ru,en,ro}[window.Pulse?.getLang?.()]||ru);
 const api=(path,body)=>window.Pulse.api(path,body===undefined?{}:{method:'POST',body:JSON.stringify(body)});
 let sequence=0;
 async function footer(){const host=document.getElementById('pxHomeClosing');if(!host)return;let box=document.getElementById('pxAccountFooter');if(!box){box=el('section',null,'px-account-footer');box.id='pxAccountFooter';host.append(box);}const seq=++sequence;const text=el('div'),state=el('div','','px-account-state'),h=el('h3'),kicker=el('span',tx('Первое пополнение','First top-up','Prima alimentare'),'offer-label'),amount=el('strong',tx('До −20%','Up to 20% off','Până la −20%'),'offer-amount'),p=el('p',tx('Сэкономьте 10% при первом пополнении или 20%, если вас пригласил друг. После активации вы тоже можете пригласить одного друга.','Save 10% on your first top-up, or 20% if a friend invited you. Once activated, you can invite one friend too.','Economisești 10% la prima alimentare sau 20% dacă te-a invitat un prieten. După activare poți invita și tu un prieten.'));h.append(kicker,amount);text.append(state,h,p);const a=el('a',tx('Войти','Sign in','Autentificare'),'btn btn-secondary');a.href='/login/';box.replaceChildren(text,a);
 const token=localStorage.getItem('pulsarx_token');if(!token){state.textContent=tx('Войдите, чтобы увидеть статус аккаунта','Sign in to see your account status','Autentifică-te pentru a vedea starea contului');return;}
 state.textContent=tx('Проверяем статус…','Checking status…','Verificăm starea…');
 try{const s=await api('/api/wallet/growth/status');if(seq!==sequence||token!==localStorage.getItem('pulsarx_token'))return;state.textContent=s.activated?tx('● Аккаунт активирован','● Account activated','● Cont activat'):tx('Аккаунт ещё не активирован','Account not activated yet','Contul nu este încă activat');
 a.href=s.link?'/dashboard/?tab=settings&section=invite':'/dashboard/?tab=wallet';a.textContent=s.link?tx('Пригласить друга →','Invite a friend →','Invită un prieten →'):tx('Пополнить баланс →','Top up →','Alimentează soldul →');
 if(s.activated&&!s.referral_enabled){state.textContent=tx('Аккаунт активирован · приглашения ограничены','Account activated · invitations restricted','Cont activat · invitații restricționate');a.href='/support/';a.textContent=tx('Поддержка','Support','Suport');}
 }catch{if(seq===sequence){state.textContent=tx('Статус временно недоступен','Status temporarily unavailable','Starea este temporar indisponibilă');a.href='/dashboard/?tab=settings';a.textContent=tx('Настройки аккаунта','Account settings','Setările contului');}}
 }
 function init(){if(!document.body.classList.contains('pulse-page'))return;document.querySelectorAll('.gift-code-box').forEach(n=>{n.hidden=true;});footer();document.addEventListener('px:lang',()=>{footer();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)footer();});window.addEventListener('storage',e=>{if(e.key==='pulsarx_token')footer();});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
