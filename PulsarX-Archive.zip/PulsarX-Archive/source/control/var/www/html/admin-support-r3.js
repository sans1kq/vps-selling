/* PulsarX Support r3: visible Telegram rejection causes and explicit safe retries. */
(() => {
  'use strict';
  const bar=document.querySelector('.tabbar'),content=document.querySelector('.content');
  if(!bar||!content||!document.getElementById('tab-overview')||document.getElementById('tab-support'))return;
  const tab=document.createElement('button');tab.type='button';tab.className='tab-item';tab.dataset.tab='support';tab.textContent='Support';bar.append(tab);
  const panel=document.createElement('div');panel.className='tab-panel';panel.id='tab-support';
  panel.innerHTML=`<div class="ps-header"><div><h2>Support</h2><p>Telegram inbox · Email remains a separate support channel.</p><p id="psAlerts"></p></div><span id="psWorker">Checking connection…</span></div>
  <p class="ps-notice">Telegram identity is unverified. Confirm account ownership before changing a VPS, access credentials or billing.</p>
  <div id="psError" class="ps-error" role="status"></div>
  <div class="ps-layout"><section class="panel ps-inbox"><div class="ps-filters"><select id="psFilter" aria-label="Ticket status"><option value="open">Open</option><option value="closed">Closed</option><option value="all">All tickets</option></select><input id="psSearch" placeholder="Name, username or ticket number" aria-label="Search tickets"><button type="button" class="btn btn-small" id="psRefresh">Refresh</button></div><div id="psTickets" class="ps-ticket-list"></div><button type="button" class="btn btn-small" id="psMoreTickets" hidden>More tickets</button></section>
  <section class="panel ps-thread"><div id="psThreadTitle" class="ps-thread-title">Select a ticket</div><button type="button" class="btn btn-small" id="psOlder" hidden>Earlier messages</button><div id="psMessages" class="ps-messages"><p class="ps-empty">Customer messages and screenshots will appear here.</p></div><form id="psReply" hidden><label for="psText">Reply to customer in Telegram</label><textarea id="psText" maxlength="4000" rows="4" placeholder="Write your reply…" required></textarea><div class="ps-reply-actions"><button type="button" class="btn btn-small" id="psState">Close ticket</button><button type="submit" class="btn" id="psSend">Send reply</button></div><p class="ps-muted">Queued means waiting to send. Sent confirms that Telegram accepted the message; it does not confirm that the customer read it.</p></form></section></div>`;
  content.append(panel);
  const el=id=>document.getElementById(id);
  let selected=null,currentTicket=null,moreTickets=null,older=null,busyList=false,busyThread=false,busySend=false,stopped=false,searchTimer;
  let replies=new Map(),pendingReply=null,initializedThread=false;
  const token=()=>localStorage.getItem('pulsarx_admin_token');
  const visible=()=>panel.classList.contains('active')&&!document.hidden;
  const fail=e=>{el('psError').textContent=e.message||'Could not load support. Try again.';};
  const stamp=n=>new Date(n*1000).toLocaleString();
  async function api(path,options={}){
    const authToken=token();if(!authToken||stopped)throw new Error('Sign in to the admin panel again.');
    const response=await fetch('/api/admin/support'+path,{...options,cache:'no-store',headers:{...options.headers,Authorization:'Bearer '+authToken}});
    if(token()!==authToken)throw new Error('Admin session changed. Reload the page.');
    if([401,403,422].includes(response.status)&&response.status!==422){stopped=true;location.href='/adminlogin/';throw new Error('Admin session expired.');}
    if(!response.ok)throw new Error(response.status===409?'Ticket changed. Refresh it before replying.':'Support request failed ('+response.status+').');
    const value=await response.json();if(token()!==authToken)throw new Error('Admin session changed. Reload the page.');return value;
  }
  async function loadList(append=false){
    if(busyList||!token()||stopped)return;busyList=true;
    try{
      const params=new URLSearchParams({status:el('psFilter').value,q:el('psSearch').value.trim()});
      if(append&&moreTickets)params.set('before',String(moreTickets));
      const data=await api('?'+params);if(!Array.isArray(data.tickets))throw new Error('Invalid inbox response.');
      if(!append)el('psTickets').replaceChildren();
      for(const t of data.tickets){
        const b=document.createElement('button');b.type='button';b.className='ps-ticket'+(t.id===selected?' is-selected':'')+(t.unread?' is-unread':'');b.dataset.ticket=String(t.id);
        const head=document.createElement('strong');head.textContent='#'+t.id+' · '+t.name;
        const sub=document.createElement('span');sub.textContent=(t.username?'@'+t.username+' · ':'')+t.status+' · '+stamp(t.updated);
        b.append(head,sub);b.addEventListener('click',()=>choose(t.id));el('psTickets').append(b);
      }
      if(!el('psTickets').children.length){const p=document.createElement('p');p.className='ps-empty';p.textContent='No matching tickets.';el('psTickets').append(p);}
      moreTickets=data.next_before;el('psMoreTickets').hidden=!moreTickets;
      tab.textContent='Support'+(data.unread?' · '+data.unread:'');
      const healthy=!data.worker_error&&Date.now()/1000-data.poll_at<60;
      el('psWorker').textContent=healthy?'Bot connected':('Bot needs attention'+(data.worker_error?' · '+data.worker_error:''));
      el('psWorker').className=healthy?'ps-online':'ps-error';el('psError').textContent='';
      const alerts=data.notifications||{};
      el('psAlerts').textContent=alerts.enabled?'Personal Telegram alerts: on · '+(alerts.username?'@'+alerts.username:alerts.name||'linked account'):'Personal Telegram alerts: off';
      if(alerts.last_delivery)el('psAlerts').textContent+=' · Last alert: '+alerts.last_delivery+(alerts.last_error?' · '+reason(alerts.last_error):'');
    }catch(e){fail(e);el('psWorker').textContent='Connection unavailable';}finally{busyList=false;}
  }
  function choose(id){
    if(selected===id)return;
    if(el('psText').value.trim()&&!window.confirm('Discard the unsent draft and open another ticket?'))return;
    selected=id;currentTicket=null;replies=new Map();pendingReply=null;initializedThread=false;el('psText').value='';
    el('psThreadTitle').textContent='Loading ticket #'+id+'…';el('psReply').hidden=true;el('psMessages').replaceChildren();
    document.querySelectorAll('.ps-ticket').forEach(b=>b.classList.toggle('is-selected',Number(b.dataset.ticket)===id));loadThread();
  }
  const delivery={queued:'Queued',sending:'Sending…',sent:'Sent',failed:'Delivery failed',unknown:'Delivery uncertain — verify before sending again',received:'Received'};
  function reason(error){
    const key=String(error||'').split(':')[0];
    const labels={bot_blocked_by_user:'Пользователь заблокировал бота. Для получения ответа ему нужно разблокировать бота.',recipient_deactivated:'Аккаунт получателя удалён или деактивирован.',chat_not_started:'Получателю нужно открыть бота и нажать Start.',chat_not_found:'Telegram не находит чат получателя. Ему нужно снова открыть бота и написать сообщение.',invalid_bot_token:'Telegram отклонил токен бота. Требуется проверить настройку токена на сервере.',telegram_forbidden:'Telegram запретил отправку в этот чат.',telegram_bad_request:'Telegram отклонил параметры сообщения.',chat_topic_unavailable:'Telegram не находит тему чата получателя.',message_too_long:'Сообщение слишком длинное.',empty_message:'Текст сообщения пуст.',rate_limited:'Telegram ограничил частоту отправки.',telegram_service_unavailable:'Сервис Telegram временно недоступен.',network_or_response_error:'Нет подтверждения доставки из-за ошибки связи. Не повторяйте вслепую.',worker_restarted_during_send:'Сервис перезапустился во время отправки; результат не подтверждён.',telegram_http_error:'В старой записи нет точной причины. Повторите один ответ, чтобы получить её.',polling_conflict:'С этим ботом уже работает другой получатель обновлений.'};
    const detail=String(error||'').split(':').slice(2).join(':');
    if(detail&&['telegram_bad_request','telegram_http_error','telegram_forbidden','chat_topic_unavailable'].includes(key))return (labels[key]||'Telegram отклонил сообщение.')+' '+detail;
    return labels[key]||'Отправка не подтверждена. Проверьте состояние бота.';
  }
  function renderMessages(){
    const box=el('psMessages'),atBottom=box.scrollHeight-box.scrollTop-box.clientHeight<80,oldHeight=box.scrollHeight;
    box.replaceChildren();
    for(const m of [...replies.values()].sort((a,b)=>a.id-b.id)){
      const item=document.createElement('article');item.className='ps-message ps-'+m.direction;
      const meta=document.createElement('div');meta.className='ps-message-meta';meta.textContent=(m.direction==='in'?'Customer':m.direction==='out'?'Support':'Bot')+' · '+stamp(m.created);
      const body=document.createElement('div');body.className='ps-message-body';body.textContent=m.body;item.append(meta,body);
      for(const f of m.attachments||[]){
        const b=document.createElement('button');b.type='button';b.className='btn btn-small ps-file';b.textContent=f.name+' · '+(f.status==='ready'?'Download':f.status==='pending'?'Preparing…':f.status==='too_large'?'Over 10 MB':'File unavailable');b.disabled=f.status!=='ready';
        b.addEventListener('click',()=>download(f));item.append(b);
      }
      if(m.direction!=='in'){
        const state=document.createElement('div');state.className='ps-delivery ps-'+m.delivery;state.textContent=(delivery[m.delivery]||m.delivery)+(m.error?' · '+reason(m.error):'');item.append(state);
        if(m.direction==='out'&&m.delivery==='failed'&&currentTicket?.status==='open'){
          const retry=document.createElement('button');retry.type='button';retry.className='btn btn-small ps-file ps-retry';retry.textContent='Повторить отправку';retry.disabled=busySend;
          retry.addEventListener('click',()=>retryMessage(m.id,retry));item.append(retry);
        }
      }
      box.append(item);
    }
    if(atBottom||!oldHeight)box.scrollTop=box.scrollHeight;
  }
  async function loadThread(past=false){
    if(!selected||busyThread||stopped)return;busyThread=true;const id=selected;
    try{
      const data=await api('/'+id+(past&&older?'?before='+older:''));if(selected!==id)return;
      if(!data.ticket||!Array.isArray(data.messages))throw new Error('Invalid ticket response.');
      currentTicket=data.ticket;
      el('psThreadTitle').textContent='#'+id+' · '+data.ticket.name+(data.ticket.username?' · @'+data.ticket.username:'')+' · '+data.ticket.status;
      for(const m of data.messages)replies.set(m.id,m);
      if(past||!initializedThread){older=data.next_before;initializedThread=true;}
      el('psOlder').hidden=!older;
      renderMessages();el('psReply').hidden=false;
      el('psState').textContent=data.ticket.status==='open'?'Close ticket':'Reopen ticket';
      el('psSend').disabled=data.ticket.status!=='open'||busySend;el('psText').disabled=data.ticket.status!=='open';
    }catch(e){fail(e);}finally{busyThread=false;if(selected!==id)loadThread();}
  }
  async function download(file){
    try{
      const authToken=token();if(!authToken)throw new Error('Sign in again.');
      const r=await fetch('/api/admin/support/files/'+file.id+'/download',{cache:'no-store',headers:{Authorization:'Bearer '+authToken}});
      if(!r.ok||token()!==authToken)throw new Error('Could not download the attachment.');
      const objectUrl=URL.createObjectURL(await r.blob());const a=document.createElement('a');a.href=objectUrl;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);
    }catch(e){fail(e);}
  }
  async function retryMessage(messageId,button){
    if(busySend||!selected||currentTicket?.status!=='open')return;
    const id=selected;busySend=true;button.disabled=true;el('psSend').disabled=true;
    try{await api('/messages/'+messageId+'/retry',{method:'POST'});if(selected===id)await loadThread();}
    catch(e){fail(e);}
    finally{busySend=false;button.disabled=false;el('psSend').disabled=currentTicket?.status!=='open';document.querySelectorAll('.ps-retry').forEach(n=>n.disabled=currentTicket?.status!=='open');}
  }
  tab.addEventListener('click',()=>{document.querySelectorAll('.tab-item,.tab-panel').forEach(n=>n.classList.remove('active'));tab.classList.add('active');panel.classList.add('active');loadList();loadThread();});
  el('psRefresh').addEventListener('click',()=>{loadList();loadThread();});
  el('psFilter').addEventListener('change',()=>loadList());
  el('psSearch').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadList(),350);});
  el('psMoreTickets').addEventListener('click',()=>loadList(true));el('psOlder').addEventListener('click',()=>loadThread(true));
  el('psState').addEventListener('click',async()=>{
    if(!currentTicket||busySend)return;const id=selected,newState=currentTicket.status==='open'?'closed':'open';
    try{await api('/'+id+'/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:newState})});await loadThread();await loadList();}catch(e){fail(e);}
  });
  el('psReply').addEventListener('submit',async e=>{
    e.preventDefault();const body=el('psText').value.trim(),id=selected;if(!body||!id||busySend||!currentTicket||currentTicket.status!=='open')return;
    if(!pendingReply||pendingReply.text!==body||pendingReply.ticket!==id)pendingReply={text:body,ticket:id,request_id:crypto.randomUUID()};
    busySend=true;el('psSend').disabled=true;el('psText').disabled=true;
    try{
      await api('/'+id+'/reply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:pendingReply.text,request_id:pendingReply.request_id})});
      if(selected===id){el('psText').value='';pendingReply=null;await loadThread();}
    }catch(err){fail(err);}finally{busySend=false;el('psSend').disabled=currentTicket?.status!=='open';el('psText').disabled=currentTicket?.status!=='open';}
  });
  setInterval(()=>{if(visible()){loadList();loadThread();}},15000);
  const target=new URLSearchParams(location.search||'').get('support_ticket');
  if(target&&/^[1-9][0-9]{0,12}$/.test(target)){tab.click();choose(Number(target));}
})();
