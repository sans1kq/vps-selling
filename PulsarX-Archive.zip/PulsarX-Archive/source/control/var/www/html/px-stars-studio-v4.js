/* Quotes and ownership are enforced by the server; no client-side payment confirmation. */
(()=>{'use strict';
const tx=(r,e,m)=>({ru:r,en:e,ro:m}[window.Pulse?.getLang?.()]||r);
const node=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
const api=(url,body)=>Pulse.api('/api/telegram/'+url,body===undefined?{}:{method:'POST',body:JSON.stringify(body)});
function sync(){document.getElementById('walletStarsSlot')?.syncStarsAmount?.();}
document.addEventListener('input',e=>{if(e.target.id==='walletAmount')sync();});
document.addEventListener('click',e=>{if(e.target.closest('#walletTopupForm [data-cents]'))sync();});
window.pxMountWalletStars=function(host,initial){
const box=node('section');box.className='stars-inline';host.append(box);
const title=node('h3','Telegram Stars'),intro=node('p',tx('Пополните баланс через Telegram. Доступность покупки звёзд зависит от страны и способа оплаты.','Top up through Telegram. Star purchase options depend on your country and payment method.','Alimentează soldul prin Telegram. Opțiunile de cumpărare depind de țară și metoda de plată.'));
const content=node('div'),out=node('output');out.setAttribute('aria-live','polite');box.append(title,content,out);
let activeId=null,busy=false,version=0,requestKey=null,quote=null,body=null;
const message=e=>{out.textContent=e?.message||String(e);};
function button(label,fn){const b=node('button',label);b.type='button';b.className='btn wallet-topup-btn';b.onclick=async()=>{if(busy)return;busy=true;b.disabled=true;try{await fn();}catch(e){message(e);}finally{busy=false;b.disabled=false;}};return b;}
function link(url,label){const a=node('a',label);a.href=url;if(url !== '/terms/#telegram-stars' && !/^https:\/\/t\.me\/[a-z0-9_]+(?:\?start=[a-z0-9_-]+)?$/i.test(url))throw Error('Invalid Telegram link');if(url.startsWith('https://t.me/'))a.className='btn wallet-topup-btn stars-open';a.target='_blank';a.rel='noopener noreferrer';return a;}
async function refresh(){const serial=++version;const s=await api('status');if(serial!==version)return;if(!s.enabled){content.replaceChildren();out.textContent=tx('Оплата звёздами временно недоступна.','Stars payments are temporarily unavailable.','Plata cu Stars este momentan indisponibilă.');return;}content.replaceChildren();out.textContent='';
const live=(s.invoices||[]).find(inv=>['created','send_unknown','sent','approved'].includes(inv.state));
if(!live && activeId){activeId=null;window.PxWallet?.load();return;}
if(live){
  activeId=live.id;
  const receipt=node('div');receipt.className='stars-receipt';
  const price=node('strong','★ '+live.stars+' Stars'), credit=node('span',tx('На баланс','Balance credit','În sold')+' · $'+(live.credit_cents/100).toFixed(2));
  const timer=node('time'); timer.setAttribute('role','timer');
  const approved=live.state==='approved';
  const label=node('p',approved?tx('Ожидаем подтверждение Telegram','Awaiting Telegram confirmation','Așteptăm confirmarea Telegram'):tx('Счёт открыт','Invoice open','Factură deschisă'));
  const offset=Date.parse(s.server_time)-Date.now()||0;
  function tick(){const left=Math.max(0,Math.ceil((Date.parse(live.expires_at)-Date.now()-offset)/1000));timer.textContent=Math.floor(left/60)+':'+String(left%60).padStart(2,'0');}
  receipt.append(label,price,credit);
  if(!approved){receipt.append(timer);tick();}
  content.append(receipt);
  if(s.bot_url&&!approved)content.append(link(s.bot_url,tx('Открыть Telegram','Open Telegram','Deschide Telegram')));
  content.append(button(tx('Обновить статус','Refresh status','Actualizează starea'),refresh));
  let ticks=0;
  const interval=setInterval(()=>{if(!receipt.isConnected){clearInterval(interval);return;}if(document.hidden)return;tick();if(++ticks%6===0&&!busy)refresh().catch(message);},1000);
  return;
}
if(s.invoices?.[0]?.state==='awaiting_receipt')content.append(node('p',tx('Предыдущий счёт ожидает квитанцию Telegram. Если вы оплатили, дождитесь зачисления.','Awaiting the Telegram receipt for the previous invoice. If you paid, wait for the balance update.','Așteptăm chitanța Telegram pentru factura anterioară. Dacă ai plătit, așteaptă creditarea.')));
if(!s.linked){content.append(intro);const startLink=button(tx('Привязать Telegram','Link Telegram','Conectează Telegram'),async()=>{const r=await api('link',{});out.replaceChildren(link(r.url,tx('Открыть бота →','Open bot →','Deschide botul →')),node('p',tx('Нажмите Start в боте, затем обновите статус здесь.','Press Start in the bot, then refresh here.','Apasă Start în bot, apoi actualizează aici.')));});startLink.classList.add('stars-link');content.append(startLink);
if(s.candidate){
  const pin=node('input');pin.type='text';pin.inputMode='numeric';pin.maxLength=8;pin.autocomplete='one-time-code';pin.pattern='[0-9]{8}';
  const label=node('label',tx('Код из сообщения бота','Code from the bot','Cod de la bot'));label.append(pin);
  content.append(node('p',s.candidate.name+' · ID '+s.candidate.telegram_id),label,
    button(tx('Подтвердить привязку','Confirm link','Confirmă conectarea'),async()=>{
      if(!/^[0-9]{8}$/.test(pin.value))throw Error(tx('Введите 8 цифр','Enter 8 digits','Introdu 8 cifre'));
      await api('link/confirm',{intent_id:s.candidate.id,telegram_id:s.candidate.telegram_id,code:pin.value});await refresh();
    }));
}
}else{const account=node('div');account.className='stars-account';account.append(node('span',tx('Привязан Telegram','Linked Telegram','Telegram conectat')+' · '+s.telegram_id));
if(s.bot_url){const bot=link(s.bot_url+'?start=wallet',tx('Перейти к боту ↗','Open bot ↗','Deschide botul ↗'));bot.className='stars-bot';account.append(bot);}content.append(account);
const form=node('form'),grid=node('div');grid.className='px-release-grid';const plan=node('select'),months=node('select'),amount=node('input');amount.type='number';amount.min='1';amount.max='100';amount.step='0.01';amount.value='3';
[['nano','Nano'],['mini','Mini'],['plus','Plus'],['custom',tx('Другая сумма','Custom amount','Altă sumă')]].forEach(([v,t])=>{const o=node('option',t);o.value=v;plan.append(o);});
[[1,tx('1 месяц','1 month','1 lună')],[3,tx('3 месяца · −5%','3 months · −5%','3 luni · −5%')],[6,tx('6 месяцев · −10%','6 months · −10%','6 luni · −10%')],[12,tx('12 месяцев · −15%','12 months · −15%','12 luni · −15%')]].forEach(([v,t])=>{const o=node('option',t);o.value=v;months.append(o);});
plan.value='custom';months.disabled=true;amount.value=(initial||'').replace(',','.');
function field(text,input){const l=node('label',text);l.append(input);return l;}const amountLabel=field(tx('Сумма USD','Amount USD','Suma USD'),amount);amount.id='starsAmount';amount.inputMode='decimal';amount.placeholder='1.00–100.00';amountLabel.className='stars-amount-field';grid.append(field(tx('Баланс для тарифа','Balance for plan','Sold pentru tarif'),plan),field(tx('Период','Period','Perioadă'),months));
const ref=node('input');ref.type='checkbox';ref.className='px-small-check';const reflabel=field(tx('Применить доступную скидку друга 10%','Apply available friend discount (10%)','Aplică reducerea disponibilă de 10%'),ref);
const agree=node('input');agree.type='checkbox';agree.className='px-small-check';const terms=field(tx('Принимаю условия оплаты Stars','I accept the Stars payment terms','Accept condițiile de plată Stars'),agree);terms.append(link('/terms/#telegram-stars',tx('Условия','Terms','Condiții')));
const preview=node('p');preview.className='stars-quote';const send=button(tx('Получить счёт в Telegram','Send invoice to Telegram','Primește factura în Telegram'),async()=>{if(!quote||!agree.checked)throw Error(tx('Рассчитайте сумму и примите условия.','Calculate the amount and accept the terms.','Calculează suma și acceptă condițiile.'));requestKey=requestKey||crypto.randomUUID();const r=await api('create-invoice',{...body,request_key:requestKey,expected_stars:quote.stars,expected_credit_cents:quote.credit_cents,accepted_terms:true});out.replaceChildren(node('p',tx('Счёт сохранён. Оплатите его в Telegram, затем обновите статус.','Invoice saved. Pay in Telegram, then refresh the status.','Factura a fost salvată. Plătește în Telegram, apoi actualizează starea.')),link(r.bot_url,tx('Открыть Telegram →','Open Telegram →','Deschide Telegram →')));send.disabled=true;await refresh();});
terms.hidden=true;send.hidden=true;agree.onchange=()=>{send.disabled=!agree.checked;};
const calc=button(tx('Рассчитать','Calculate','Calculează'),async()=>{if(plan.value==='custom'&&(!amount.value||!amount.checkValidity())){amount.focus();throw Error(tx('Введите сумму от $1 до $100.','Enter $1 to $100.','Introdu între 1 și 100 USD.'));}const draft=body={months:plan.value==='custom'?1:Number(months.value),...(plan.value==='custom'?{amount_cents:Math.round(Number(amount.value)*100)}:{plan_key:plan.value})};const result=await api('quote',draft);if(body!==draft)return;quote=result;if(plan.value!=='custom')document.getElementById('walletAmount').value=(result.credit_cents/100).toFixed(2);requestKey=null;preview.replaceChildren(node('span',tx('К оплате','To pay','De plată')),node('strong','★ '+quote.stars+' Stars'),node('small',tx('На баланс','Balance credit','În sold')+' · $'+(quote.credit_cents/100).toFixed(2)+tx(' · Наценка 30% включена',' · Includes 30% markup',' · Adaosul de 30% inclus')));terms.hidden=false;send.hidden=false;send.disabled=!agree.checked;});
const options=node('details');options.className='stars-options';options.append(node('summary',tx('Тариф и скидки','Plan and discounts','Plan și reduceri')),grid);
const review=node('div');review.className='stars-review';review.append(preview,terms,send);
form.append(amountLabel,options,calc,review);
form.onsubmit=e=>e.preventDefault();[plan,months,amount,ref].forEach(n=>n.addEventListener('input',()=>{quote=null;body=null;agree.checked=false;terms.hidden=true;send.hidden=true;preview.textContent='';amountLabel.hidden=plan.value!=='custom';months.disabled=plan.value==='custom';}));content.append(form);
const master=document.getElementById('walletAmount');
amount.addEventListener('input',()=>{
  if(master.value!==amount.value){
    master.value=amount.value;
    master.dispatchEvent(new Event('input'));
  }
});
function sync(){if(!host.isConnected||!form.isConnected)return;plan.value='custom';amount.value=master.value.replace(',','.');amount.dispatchEvent(new Event('input'));agree.checked=false;}
host.syncStarsAmount=sync;sync();}
const refreshButton=button(tx('Обновить статус','Refresh status','Actualizează starea'),refresh);refreshButton.className='wallet-check';content.append(refreshButton);
const labels={awaiting_receipt:tx('Ожидаем квитанцию Telegram','Awaiting Telegram receipt','Așteptăm chitanța Telegram'),paid:tx('Зачислено','Credited','Creditat'),refunded:tx('Возвращено','Refunded','Rambursat'),approved:tx('Ожидаем подтверждение оплаты','Awaiting payment confirmation','Așteptăm confirmarea plății'),expired:tx('Счёт истёк','Invoice expired','Factura a expirat'),sent:tx('Счёт отправлен','Invoice sent','Factura trimisă'),created:tx('Готовится','Preparing','Se pregătește'),send_unknown:tx('Проверьте наличие счёта в Telegram','Check Telegram for the invoice','Verifică factura în Telegram')};
const history=node('details');history.className='stars-history';history.append(node('summary',tx('Последние счета Stars','Recent Stars invoices','Facturi Stars recente')));if(s.invoices?.length)content.append(history);for(const inv of s.invoices||[]){history.append(node('p',inv.stars+' Stars → $'+(inv.credit_cents/100).toFixed(2)+' · '+(labels[inv.state]||inv.state)));}
}
out.textContent=tx('Проверяем доступность…','Checking availability…','Verificăm disponibilitatea…');
function start(){refresh().catch(e=>{message(e);content.replaceChildren(button(tx('Повторить','Retry','Reîncearcă'),start));});}
start();
};
})();
