/* PulsarX Cloud UI v3.3 — safe presentation/interactivity layer. */
(function(){
  'use strict';
  const body = document.body;
  if (!body || !body.dataset.v33Page || body.dataset.v33Ready) return;
  body.dataset.v33Ready = '1';
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const mobile = !!(window.matchMedia && window.matchMedia('(max-width: 820px), (pointer: coarse)').matches);
  const lowPower = !!((navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 4));
  const passiveMode = reduce || mobile || lowPower;
  const q = (s, root=document) => root.querySelector(s);
  const qa = (s, root=document) => Array.from(root.querySelectorAll(s));

  function reactive(selector){
    qa(selector).forEach(el => {
      el.classList.add('v33-reactive');
      if(passiveMode) return;
      el.addEventListener('pointermove', e => {
        const r = el.getBoundingClientRect();
        el.style.setProperty('--v33-x', ((e.clientX-r.left)/r.width*100).toFixed(1)+'%');
        el.style.setProperty('--v33-y', ((e.clientY-r.top)/r.height*100).toFixed(1)+'%');
      }, {passive:true});
    });
  }

  function reveals(selector){
    const els=qa(selector); if(!els.length) return;
    els.forEach(el=>el.classList.add('v33-reveal'));
    if(passiveMode || !('IntersectionObserver' in window)){els.forEach(el=>el.classList.add('v33-in'));return;}
    const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('v33-in');io.unobserve(e.target)}}),{threshold:.08,rootMargin:'0px 0px -30px'});
    els.forEach(el=>io.observe(el));
  }

  function lang(){return localStorage.getItem('pulsarx_lang') || document.documentElement.lang || 'en';}
  const authText={
    en:{login:['Your cloud, one secure step away.','Sign in to manage instances, watch live resources and control every server from one place.'],register:['Start small. Ship something real.','Create an account, choose a Linux image and put a real server online without the usual cloud complexity.'],verify:['One code. Then you are in.','Email verification keeps account access simple while protecting the control plane.'],forgot:['Recover access without touching your server.','Reset the account password independently from SSH credentials and instance state.'],reset:['Set a new account password.','Your instances keep running while you restore access to the PulsarX dashboard.'],admin:['Restricted control plane.','Administrative access to users, instances, host capacity, billing state and action history.']},
    ru:{login:['Твоё облако — в одном шаге.','Войди, чтобы управлять серверами, смотреть ресурсы в реальном времени и держать всё под контролем.'],register:['Начни с малого. Запусти настоящее.','Создай аккаунт, выбери Linux-образ и подними реальный сервер без лишней сложности.'],verify:['Один код — и готово.','Подтверждение почты защищает доступ к панели управления и остаётся простым для пользователя.'],forgot:['Верни доступ, не трогая сервер.','Пароль аккаунта восстанавливается отдельно от SSH и не влияет на состояние инстансов.'],reset:['Задай новый пароль аккаунта.','Инстансы продолжают работать, пока ты восстанавливаешь доступ к PulsarX.'],admin:['Закрытая панель управления.','Административный доступ к пользователям, инстансам, ресурсам хоста, платежам и журналу действий.']},
    ro:{login:['Cloud-ul tău, la un pas distanță.','Autentifică-te pentru a controla instanțele, resursele live și toate serverele dintr-un singur loc.'],register:['Începe simplu. Lansează ceva real.','Creează un cont, alege o imagine Linux și pornește un server real fără complexitatea cloud obișnuită.'],verify:['Un cod și ești gata.','Verificarea prin e-mail păstrează accesul simplu și protejează panoul de control.'],forgot:['Recuperează accesul fără să atingi serverul.','Resetează parola contului separat de SSH și fără să afectezi instanțele.'],reset:['Setează o parolă nouă.','Instanțele continuă să ruleze în timp ce recuperezi accesul la PulsarX.'],admin:['Panou de control restricționat.','Acces administrativ la utilizatori, instanțe, capacitate, plăți și istoricul acțiunilor.']}
  };

  function authPage(){
    const kind=body.dataset.v33Page.replace('auth-','');
    const admin=kind==='admin';
    const getCopy=()=>{const dict=authText[lang()]||authText.en;return dict[kind]||dict.login};
    let copy=getCopy();
    const s=document.createElement('section'); s.className='v33-auth-showcase'; s.setAttribute('aria-label','PulsarX platform preview');
    s.innerHTML=`
      <div class="v33-auth-kicker"><i></i>${admin?'PULSARX / ADMIN CONTROL':'PULSARX / FRANKFURT EDGE'}</div>
      <h2 class="v33-auth-title">${copy[0]}</h2>
      <p class="v33-auth-copy">${copy[1]}</p>
      <div class="v33-console" aria-hidden="true">
        <div class="v33-console-top"><span class="v33-console-dots"><i></i><i></i><i></i></span><span>${admin?'control-plane / secure':'ssh / px-edge-01'}</span></div>
        <div class="v33-console-body">
          <div class="v33-console-line" data-line="0"></div>
          <div class="v33-console-line" data-line="1"></div>
          <div class="v33-console-line" data-line="2"></div>
          <div class="v33-console-line" data-line="3"></div>
        </div>
      </div>
      <div class="v33-auth-meta">
        <div><b>${admin?'Protected':'Frankfurt'}</b><span>${admin?'admin route':'DE · edge region'}</span></div>
        <div><b>${admin?'Audit log':'Live stats'}</b><span>${admin?'actions recorded':'CPU · RAM · disk'}</span></div>
        <div><b>${admin?'Scoped':'Root access'}</b><span>${admin?'control plane':'SSH · Linux'}</span></div>
      </div>`;
    body.appendChild(s);
    if(!admin){
      const switcher=document.createElement('div'); switcher.className='v33-auth-lang'; switcher.setAttribute('aria-label','Language');
      switcher.innerHTML=['en','ru','ro'].map(l=>`<button type="button" data-lang="${l}" class="${lang()===l?'active':''}">${l.toUpperCase()}</button>`).join('');
      body.appendChild(switcher);
      const refresh=()=>{copy=getCopy();q('.v33-auth-title',s).textContent=copy[0];q('.v33-auth-copy',s).textContent=copy[1];qa('button',switcher).forEach(b=>b.classList.toggle('active',b.dataset.lang===lang()))};
      qa('button',switcher).forEach(b=>b.addEventListener('click',()=>{if(window.pulsarxI18n?.setLang)window.pulsarxI18n.setLang(b.dataset.lang);else localStorage.setItem('pulsarx_lang',b.dataset.lang);refresh()}));
    }
    const lines=admin?
      ['$ session --scope admin','<strong>auth:</strong> challenge accepted','<strong>control:</strong> <span class="ok">ready</span>','<span class="dim">waiting for operator</span> <span class="v33-cursor"></span>']:
      ['$ ssh root@px-instance','<strong>handshake:</strong> established','<strong>instance:</strong> <span class="ok">running</span> · Frankfurt','root@px:~# <span class="v33-cursor"></span>'];
    const targets=qa('.v33-console-line',s);
    if(passiveMode){targets.forEach((el,i)=>el.innerHTML=lines[i]);}
    else {
      let i=0; const next=()=>{if(i>=lines.length)return; targets[i].innerHTML=lines[i]; i++; setTimeout(next,i===1?520:420);}; setTimeout(next,350);
    }
    reactive('.auth-card,.v33-console,.v33-auth-meta>div');
    // Add a lightweight password strength indicator without changing submission logic.
    qa('input[type="password"]').forEach(inp=>{
      if(inp.autocomplete==='current-password') return;
      const meter=document.createElement('div');meter.className='v33-password-meter';meter.innerHTML='<i></i>';
      const note=document.createElement('div');note.className='v33-field-note';note.textContent='8+ characters';
      inp.insertAdjacentElement('afterend',meter);meter.insertAdjacentElement('afterend',note);
      const bar=q('i',meter);
      const update=()=>{const v=inp.value;let score=0;if(v.length>=8)score++;if(/[A-Z]/.test(v)&&/[a-z]/.test(v))score++;if(/\d/.test(v))score++;if(/[^\w]/.test(v))score++;const pct=[0,30,52,76,100][score];bar.style.width=pct+'%';bar.style.background=score>=3?'#41dfa0':score===2?'#ffbd73':'#ff6d72';note.textContent=v?(score>=3?'strong password':score===2?'good — can be stronger':'use 8+ chars and mix character types'):'8+ characters';};
      inp.addEventListener('input',update);update();
    });
  }

  function legalPage(){
    const progress=document.createElement('div');progress.className='v33-reading-progress';body.appendChild(progress);
    const actions=document.createElement('div');actions.className='v33-legal-topactions';
    const other=body.classList.contains('v33-terms')?'/privacy/':'/terms/';
    actions.innerHTML=`<a class="v33-legal-chip" href="${other}">${body.classList.contains('v33-terms')?'Privacy':'Terms'}</a><a class="v33-legal-chip" href="/">← PulsarX</a>`;body.appendChild(actions);
    const toc=document.createElement('nav');toc.className='v33-legal-toc';toc.setAttribute('aria-label','On this page');body.appendChild(toc);
    function activeBlock(){return q('.terms-block.active')||q('.terms-block');}
    function rebuild(){
      const block=activeBlock(); if(!block)return; const hs=qa('h2',block);
      hs.forEach((h,i)=>{h.dataset.v33Index=String(i+1).padStart(2,'0');h.id='section-'+(i+1)});
      toc.innerHTML='<div class="v33-legal-toc-title">On this page</div>'+hs.map((h,i)=>`<a href="#section-${i+1}">${h.textContent}</a>`).join('');
      qa('a',toc).forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const t=q(a.getAttribute('href'),block);if(t)t.scrollIntoView({behavior:reduce?'auto':'smooth',block:'start'})}));
      observeSections(block);
    }
    let secObs=null;
    function observeSections(block){
      if(secObs)secObs.disconnect(); if(!('IntersectionObserver'in window))return;
      secObs=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){const links=qa('a',toc);links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+e.target.id));}})},{rootMargin:'-18% 0px -68% 0px',threshold:0});
      qa('h2',block).forEach(h=>secObs.observe(h));
    }
    const onScroll=()=>{const h=document.documentElement;const max=h.scrollHeight-h.clientHeight;progress.style.width=(max>0?Math.min(100,Math.max(0,h.scrollTop/max*100)):0)+'%'};
    addEventListener('scroll',onScroll,{passive:true});onScroll();
    rebuild();
    const mo=new MutationObserver(rebuild);qa('.terms-block').forEach(b=>mo.observe(b,{attributes:true,attributeFilter:['class']}));
    reveals('.terms-block.active h2,.terms-block.active p,.terms-block.active ul');
  }

  function adminPage(){
    const content=q('.content'); if(content){
      const hero=document.createElement('div');hero.className='v33-admin-hero';hero.innerHTML='<div><div class="v33-admin-eyebrow">PULSARX / OPERATIONS</div><h1 id="v33AdminTitle">Control center</h1><p id="v33AdminSub">Users, infrastructure and billing state in one operational view.</p><div class="v33-admin-shortcuts"><span><kbd>1</kbd>Overview</span><span><kbd>2</kbd>Billing</span><span><kbd>3</kbd>Instances</span><span><kbd>/</kbd>Search</span></div></div><div class="v33-admin-live"><i></i>CONTROL PLANE ONLINE <time id="v33AdminClock">--:--:-- UTC</time></div>';content.insertBefore(hero,content.firstChild);
      const title=q('#v33AdminTitle'),sub=q('#v33AdminSub');
      const copy={overview:['Control center','Users, infrastructure and recent operator activity.'],billing:['Billing watch','Pending payments, expiring periods and account state.'],instances:['Instances & users','Search, inspect and operate customer infrastructure.']};
      qa('.tab-item').forEach((t,i)=>{t.title='Shortcut '+(i+1);t.addEventListener('click',()=>{const c=copy[t.dataset.tab]||copy.overview;title.textContent=c[0];sub.textContent=c[1]})});
    }
    const clock=q('#v33AdminClock');const tick=()=>{if(clock)clock.textContent=new Date().toISOString().slice(11,19)+' UTC'};tick();setInterval(tick,passiveMode?30000:1000);
    // Animate real values when the existing admin code updates them; never invent data.
    qa('.stat-card .val').forEach(el=>{
      new MutationObserver(()=>{
        if(reduce || !el.animate) return;
        el.animate([{opacity:.35,transform:'translateY(3px)'},{opacity:1,transform:'translateY(0)'}],{duration:260,easing:'cubic-bezier(.16,1,.3,1)'});
      }).observe(el,{childList:true,characterData:true,subtree:true});
    });
    document.addEventListener('keydown',e=>{
      if(e.target && /input|textarea|select/i.test(e.target.tagName))return;
      if(e.key==='/'){e.preventDefault();const active=q('.tab-panel.active .search-input')||q('.search-input');if(active)active.focus();}
      if(['1','2','3'].includes(e.key)){const tab=qa('.tab-item')[Number(e.key)-1];if(tab)tab.click();}
      if(e.key==='Escape'){qa('.grant-modal-backdrop').forEach(m=>{if(getComputedStyle(m).display!=='none')q('#grantCancelBtn')?.click()})}
    });
    qa('.search-input').forEach(i=>{i.placeholder=i.placeholder.replace('…','')+'  /';});
    reactive('.stat-card,.panel');reveals('.stat-grid,.panel');
  }

  function dashboardPage(){
    const main=q('main');if(main){const bar=document.createElement('div');bar.className='v33-dashboard-statusbar';bar.innerHTML='<i></i><span>CONTROL PLANE CONNECTED</span><span class="v33-dashboard-clock"></span>';main.insertBefore(bar,main.firstChild);const c=q('.v33-dashboard-clock');const tick=()=>{if(c)c.textContent='Frankfurt · '+new Date().toISOString().slice(11,19)+' UTC'};tick();setInterval(tick,1000)}
    reactive('.stat-card,.row-card,.mon-panel,.upgrade-card');
    reveals('.page.show .page-head,.page.show .stat-grid,.page.show .row-card,.page.show .stat-card');
    qa('.nav-item[data-page]').forEach(btn=>btn.addEventListener('click',()=>requestAnimationFrame(()=>reveals('.page.show .page-head,.page.show .stat-grid,.page.show .row-card,.page.show .stat-card,.page.show .mon-panel'))));
  }

  if(body.classList.contains('v33-auth')) authPage();
  if(body.classList.contains('v33-legal')) legalPage();
  if(body.classList.contains('v33-admin')) adminPage();
  if(body.classList.contains('v33-dashboard')) dashboardPage();
  if(body.classList.contains('v33-deploy')) {reactive('.plan-card,.image-card,.period-card,.v31-summary-card,.deploy-card');reveals('.deploy-shell,.deploy-card');}
})();
