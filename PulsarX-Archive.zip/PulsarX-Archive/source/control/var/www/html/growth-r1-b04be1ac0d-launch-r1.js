/* PulsarX referrals, settings categories and admin two-hour Mini codes. */
(()=>{
 'use strict';
 const copy={
  ru:{account:'Аккаунт',security:'Безопасность',servers:'Серверы',referrals:'Реферальный код',invite:'Ссылка для друга',inviteNote:'Друг получит разовую скидку 10% на пополнение после регистрации по этой ссылке.',copy:'Копировать',copied:'Скопировано',offer:'Тебе доступна скидка 10%',offerNote:'Одно пополнение: заплати на 10% меньше суммы, которая поступит на баланс.',used:'Реферальная скидка уже использована',gift:'Nano на 3 дня',giftNote:'Получил код за честный отзыв о сайте? Активируй его здесь. Debian 13, 1 vCPU, 1 GB RAM, 8 GB NVMe. Сервер и его данные автоматически удалятся через 72 часа после готовности.',code:'Одноразовый код',activate:'Активировать код',activating:'Активируем…',queued:'Nano создаётся. Он появится в разделе «Серверы». С баланса ничего не списывается.',replayed:'Этот код уже активирован в твоём аккаунте.',open:'Открыть серверы',error:'Не удалось выполнить запрос. Попробуй ещё раз.',review:'Для этой выдачи нужна помощь поддержки.',invited:'Приглашено друзей',admin:'Подарочные коды',adminNote:'Один код → один Nano на 3 дня. Отсчёт начинается после готовности, затем сервер удаляется вместе с данными.',label:'Ссылка или номер обращения с честным отзывом (обязательно)',create:'Создать код',creating:'Создаём…',created:'Код создан. Скопируй и отправь получателю.',refresh:'Обновить',more:'Ещё',revoke:'Отозвать',confirmRevoke:'Отозвать неиспользованный код?',empty:'Кодов пока нет.',unused:'Не использован',revoked:'Отозван',working:'Создаётся',active:'Активен',failed:'Ошибка выдачи',expired:'Срок завершён',deleted:'Сервер удалён',user:'Получатель',state:'Статус',until:'Удаление',reviewState:'Нужна проверка',register:'По ссылке друга: −10% на одно пополнение после регистрации.',pending:'Загрузка…'},
  en:{account:'Account',security:'Security',servers:'Servers',referrals:'Referral code',invite:'Invite a friend',inviteNote:'Your friend gets 10% off one top-up after registering with this link.',copy:'Copy',copied:'Copied',offer:'Your 10% discount is available',offerNote:'For one top-up, pay 10% less than the amount added to your balance.',used:'Your referral discount has been used',gift:'Nano for 3 days',giftNote:'Got a code for an honest review of the website? Redeem it here. Debian 13, 1 vCPU, 1 GB RAM, 8 GB NVMe. The server and its data are automatically deleted 72 hours after it is ready.',code:'One-use code',activate:'Redeem code',activating:'Redeeming…',queued:'Your Nano is being created and will appear in Servers. Nothing is deducted from your balance.',replayed:'This code has already been redeemed by your account.',open:'Open servers',error:'Could not finish the request. Try again.',review:'Please contact support about this grant.',invited:'Friends invited',admin:'Gift codes',adminNote:'One code → one Nano for 3 days. The clock starts when it is ready; then the server and its data are deleted.',label:'Honest review link or support reference (required)',create:'Create code',creating:'Creating…',created:'Code created. Copy it and send it to the recipient.',refresh:'Refresh',more:'More',revoke:'Revoke',confirmRevoke:'Revoke this unused code?',empty:'No codes yet.',unused:'Unused',revoked:'Revoked',working:'Creating',active:'Active',failed:'Grant failed',expired:'Expired',deleted:'Server deleted',user:'Recipient',state:'Status',until:'Deletion',reviewState:'Needs review',register:'Invited by a friend: 10% off one top-up after registration.',pending:'Loading…'},
  ro:{account:'Cont',security:'Securitate',servers:'Servere',referrals:'Cod de recomandare',invite:'Invita un prieten',inviteNote:'Prietenul primeste o reducere de 10% pentru o alimentare dupa inregistrarea prin acest link.',copy:'Copiaza',copied:'Copiat',offer:'Ai o reducere de 10%',offerNote:'Pentru o alimentare platesti cu 10% mai putin decat suma adaugata in sold.',used:'Reducerea de recomandare a fost folosita',gift:'Nano pentru 3 zile',giftNote:'Ai un cod pentru o recenzie sincera a site-ului? Activeaza-l aici. Debian 13, 1 vCPU, 1 GB RAM, 8 GB NVMe. Serverul si datele sale sunt sterse automat la 72 de ore dupa ce este gata.',code:'Cod de unica folosinta',activate:'Activeaza codul',activating:'Se activeaza…',queued:'Mini se creeaza si va aparea in Servere. Nu se retrag bani din sold.',replayed:'Codul a fost deja activat in contul tau.',open:'Deschide serverele',error:'Cererea nu a putut fi finalizata. Incearca din nou.',review:'Contacteaza suportul pentru aceasta activare.',invited:'Prieteni invitati',admin:'Coduri cadou',adminNote:'Un cod → un Nano pentru 3 zile. Timpul incepe cand serverul este gata; apoi serverul si datele sunt sterse.',label:'Nota (de exemplu, recenzie site)',create:'Creeaza cod',creating:'Se creeaza…',created:'Cod creat. Copiaza-l si trimite-l destinatarului.',refresh:'Actualizeaza',more:'Mai multe',revoke:'Revoca',confirmRevoke:'Revoci acest cod nefolosit?',empty:'Nu exista coduri.',unused:'Nefolosit',revoked:'Revocat',working:'Se creeaza',active:'Activ',failed:'Eroare',expired:'Expirat',deleted:'Server sters',user:'Destinatar',state:'Stare',until:'Stergere',reviewState:'Necesita verificare',register:'Invitat de un prieten: reducere de 10% la o alimentare dupa inregistrare.',pending:'Se incarca…'}
 };
 const tr=k=>(copy[document.documentElement.lang]||copy.en)[k]||k;
 Object.assign(copy.ru,{footerPanel:'Панель управления',footerSupport:'Поддержка',footerTerms:'Условия использования',footerPrivacy:'Конфиденциальность',footerCommunity:'Сообщество'});
 Object.assign(copy.en,{footerPanel:'Control panel',footerSupport:'Support',footerTerms:'Terms of service',footerPrivacy:'Privacy',footerCommunity:'Community'});
 Object.assign(copy.ro,{footerPanel:'Panou de control',footerSupport:'Suport',footerTerms:'Conditii de utilizare',footerPrivacy:'Confidentialitate',footerCommunity:'Comunitate'});
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const text=(key,tag='span')=>`<${tag} data-growth-copy="${key}">${esc(tr(key))}</${tag}>`;
 let current=null,flight=null,codesOffset=0,adminBusy=false,createKey=null;
 async function api(path,body,admin=false){
  const token=localStorage.getItem(admin?'pulsarx_admin_token':'pulsarx_token');
  if(!token)throw new Error(tr('error'));
  const response=await fetch('/api/wallet/growth'+path,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+token,...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})});
  let result;try{result=await response.json();}catch(e){throw new Error(tr('error'));}
  if(!response.ok)throw new Error(typeof result.detail==='string'?result.detail:tr('error'));
  return result;
 }
 function inviteBox(){return `<div class="px-growth-invite"><strong>${text('invite')}</strong><p>${text('inviteNote')}</p><div class="px-growth-copy-row"><input data-growth-link readonly aria-label="${esc(tr('invite'))}" value="${esc(current?.link||'')}"><button type="button" class="wallet-check" data-growth-copy-link>${text('copy')}</button></div><small data-growth-invited>${esc(tr('invited'))}: ${current?.invited||0}</small></div>`;}
 function paintStatus(){
  document.querySelectorAll('[data-growth-link]').forEach(input=>{input.value=current?.link||'';});
  document.querySelectorAll('[data-growth-invited]').forEach(node=>node.textContent=tr('invited')+': '+(current?.invited||0));
  document.querySelectorAll('[data-growth-benefit]').forEach(box=>{box.hidden=!current?.available;box.innerHTML=`<strong>−10% · ${esc(tr('offer'))}</strong><p>${esc(tr('offerNote'))}</p>`;});
 }
 async function refresh(){
  if(flight)return flight;
  if(location.pathname.startsWith('/admin')||!localStorage.getItem('pulsarx_token'))return;
  flight=api('/status').then(data=>{current=data;paintStatus();}).catch(()=>{}).finally(()=>{flight=null;});return flight;
 }
 function setSettingsTab(name,focus=false){
  const host=document.getElementById('pxGrowthSettings');if(!host)return;
  host.querySelectorAll('[data-settings-tab]').forEach(b=>{const on=b.dataset.settingsTab===name;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;if(on&&focus)b.focus();});
  host.querySelectorAll('[data-settings-panel]').forEach(panel=>{panel.hidden=panel.dataset.settingsPanel!==name;});
 }
 function settings(){
  const page=document.getElementById('page-settings');if(!page||document.getElementById('pxGrowthSettings'))return;
  const original=[...page.children].find(node=>node.classList.contains('stat-card'));if(!original)return;
  const rows=[...original.querySelectorAll('.settings-row')];if(rows.length<4)return;
  const host=document.createElement('section');host.id='pxGrowthSettings';host.className='px-growth-settings';
  const tabs=['account','security','servers','referrals'];
  host.innerHTML=`<div class="px-settings-tabs" role="tablist">${tabs.map((name,n)=>`<button type="button" id="pxSettingsTab-${name}" role="tab" aria-controls="pxSettingsPanel-${name}" aria-selected="${n===0}" tabindex="${n===0?0:-1}" data-settings-tab="${name}">${text(name)}</button>`).join('')}</div>${tabs.map((name,n)=>`<div class="stat-card px-settings-panel" role="tabpanel" id="pxSettingsPanel-${name}" aria-labelledby="pxSettingsTab-${name}" data-settings-panel="${name}" ${n?'hidden':''}></div>`).join('')}`;
  original.before(host);
  for(const row of rows){
   const name=row.id==='sshResetRow'||row.id==='subCancelRow'?'servers':row.querySelector('#settingsEmail')?'account':'security';
   host.querySelector('[data-settings-panel="'+name+'"]').appendChild(row);
  }
  original.remove();
  host.querySelector('[data-settings-panel="referrals"]').innerHTML=inviteBox()+`<div class="px-growth-gift"><h2>${text('gift')}</h2><p>${text('giftNote')}</p><form id="pxGiftRedeemForm"><label for="pxGiftCode">${text('code')}</label><div class="px-growth-copy-row"><input id="pxGiftCode" name="code" maxlength="80" autocomplete="off" spellcheck="false" required placeholder="PX-…"><button type="submit" class="btn">${text('activate')}</button></div><div id="pxGiftResult" role="status"></div></form></div>`;
  host.querySelectorAll('[data-settings-tab]').forEach(button=>button.addEventListener('click',()=>setSettingsTab(button.dataset.settingsTab)));
  host.querySelector('[role="tablist"]').addEventListener('keydown',event=>{
   const b=event.target.closest('[data-settings-tab]');if(!b||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
   event.preventDefault();let index=tabs.indexOf(b.dataset.settingsTab);index=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;setSettingsTab(tabs[index],true);
  });
  document.getElementById('pxGiftRedeemForm').addEventListener('submit',async event=>{
   event.preventDefault();const button=event.currentTarget.querySelector('[type="submit"]');if(button.disabled)return;
   const box=document.getElementById('pxGiftResult');box.textContent='';button.disabled=true;button.textContent=tr('activating');
   try{const result=await api('/redeem',{code:document.getElementById('pxGiftCode').value.trim()});box.textContent=tr(['failed','review'].includes(result.state)?'review':result.replayed?'replayed':'queued');document.getElementById('pxGiftCode').value='';const link=document.createElement('button');link.className='wallet-check';link.type='button';link.textContent=tr('open');link.addEventListener('click',()=>{document.querySelector('.nav-item[data-page="instances"]')?.click();window.loadServers?.();});box.appendChild(link);}
   catch(error){box.textContent=error.message;}finally{button.disabled=false;button.textContent=tr('activate');}
  });
 }
 function banners(){
  const overview=document.querySelector('#page-overview .page-head'),deploy=document.querySelector('.deploy-intro');
  for(const anchor of [overview,deploy]){
   if(!anchor||anchor.nextElementSibling?.hasAttribute('data-growth-benefit'))continue;
   const box=document.createElement('aside');box.className='px-growth-benefit';box.setAttribute('data-growth-benefit','');box.hidden=true;anchor.after(box);
  }
 }
 function register(){
  if(!location.pathname.startsWith('/register'))return;
  const value=new URLSearchParams(location.search).get('ref');
  if(value&&/^[A-Za-z0-9_-]{20,48}$/.test(value))sessionStorage.setItem('px-referral-code',value);
  if(!sessionStorage.getItem('px-referral-code'))return;
  const form=document.querySelector('form');if(!form||document.getElementById('pxRegisterReferral'))return;
  const note=document.createElement('p');note.id='pxRegisterReferral';note.className='px-growth-benefit';note.setAttribute('data-growth-copy','register');note.textContent=tr('register');form.before(note);
 }
 async function copyLink(button){
  const input=button.closest('.px-growth-copy-row')?.querySelector('input');if(!input||!input.value)return;
  try{await navigator.clipboard.writeText(input.value);button.textContent=tr('copied');}
  catch(e){input.focus();input.select();button.textContent=tr('copy');}
 }
 function adminTab(){
  if(!location.pathname.startsWith('/admin')||!document.querySelector('.tabbar')||document.getElementById('tab-giftcodes'))return;
  const tab=document.createElement('button');tab.type='button';tab.className='tab-item';tab.dataset.tab='giftcodes';tab.textContent=tr('admin');document.querySelector('.tabbar').appendChild(tab);
  const panel=document.createElement('section');panel.className='tab-panel';panel.id='tab-giftcodes';panel.innerHTML=`<div class="panel px-growth-admin"><h2>${text('admin')}</h2><p>${text('adminNote')}</p><form id="pxGiftCreate"><label for="pxGiftLabel">${text('label')}</label><div class="px-growth-copy-row"><input id="pxGiftLabel" maxlength="100"><button class="btn" type="submit">${text('create')}</button></div></form><div id="pxGiftCreated" role="status"></div><div class="px-growth-toolbar"><button type="button" class="wallet-check" id="pxGiftRefresh">${text('refresh')}</button></div><div id="pxGiftCodeList"></div><button type="button" id="pxGiftMore" class="wallet-check" hidden>${text('more')}</button><div id="pxGiftAdminError" class="wallet-error" role="alert"></div></div>`;document.querySelector('.content').appendChild(panel);
  tab.addEventListener('click',()=>{document.querySelectorAll('.tab-item').forEach(t=>t.classList.toggle('active',t===tab));document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p===panel));loadCodes(true);});
  document.getElementById('pxGiftCreate').addEventListener('submit',async event=>{
   event.preventDefault();if(adminBusy)return;adminBusy=true;const b=event.currentTarget.querySelector('button');b.disabled=true;b.textContent=tr('creating');
   const label=document.getElementById('pxGiftLabel').value.trim();if(!createKey||createKey.label!==label)createKey={label,key:crypto.randomUUID()};
   try{const result=await api('/admin/codes',{request_key:createKey.key,label},true);createKey=null;document.getElementById('pxGiftCreated').innerHTML=`<p>${esc(tr('created'))}</p><div class="px-growth-copy-row"><input readonly value="${esc(result.code||'')}" aria-label="${esc(tr('code'))}"><button type="button" data-growth-copy-link class="wallet-check">${esc(tr('copy'))}</button></div>`;await loadCodes(true);}
   catch(e){document.getElementById('pxGiftAdminError').textContent=e.message;}finally{adminBusy=false;b.disabled=false;b.textContent=tr('create');}
  });
  document.getElementById('pxGiftRefresh').addEventListener('click',()=>loadCodes(true));document.getElementById('pxGiftMore').addEventListener('click',()=>loadCodes(false));
 }
 async function loadCodes(reset){
  const holder=document.getElementById('pxGiftCodeList');if(!holder)return;
  if(reset){codesOffset=0;holder.innerHTML='';}
  try{const data=await api('/admin/codes?offset='+codesOffset,undefined,true);document.getElementById('pxGiftAdminError').textContent='';
   if(!data.items.length&&!codesOffset)holder.textContent=tr('empty');
   for(const row of data.items){const el=document.createElement('article');el.className='px-gift-code-row';let state=row.state==='queued'?'working':row.state==='review'?'reviewState':row.state;el.innerHTML=`<div><strong>•••• ${esc(row.hint)}</strong><p>${esc(row.label)}</p><small>${esc(row.user_email||'—')}</small></div><div><b>${esc(tr(state))}</b><p>${row.expires_at?esc(tr('until')+': '+new Date(row.expires_at).toLocaleString()):''}</p>${row.state==='unused'?`<button class="wallet-check" type="button" data-gift-revoke="${esc(row.id)}">${esc(tr('revoke'))}</button>`:''}</div>`;holder.appendChild(el);}
   codesOffset+=data.items.length;document.getElementById('pxGiftMore').hidden=!data.has_more;
  }catch(e){document.getElementById('pxGiftAdminError').textContent=e.message;}
 }
 document.addEventListener('click',async event=>{
  const copy=event.target.closest?.('[data-growth-copy-link]');if(copy){copyLink(copy);return;}
  const revoke=event.target.closest?.('[data-gift-revoke]');if(!revoke||revoke.disabled)return;
  if(!window.confirm(tr('confirmRevoke')))return;revoke.disabled=true;
  try{await api('/admin/codes/'+encodeURIComponent(revoke.dataset.giftRevoke)+'/revoke',{},true);await loadCodes(true);}catch(e){document.getElementById('pxGiftAdminError').textContent=e.message;}finally{revoke.disabled=false;}
 });
 function translate(){document.querySelectorAll('[data-growth-copy]').forEach(node=>node.textContent=tr(node.dataset.growthCopy));paintStatus();}
 function footer(){
  if(!document.body.classList.contains('dashboard-page')||document.getElementById('pxDashboardFooter'))return;
  const main=document.querySelector('.shell>main');if(!main)return;
  const node=document.createElement('footer');node.id='pxDashboardFooter';
  node.innerHTML=`<div class="px-dash-footer-brand"><a href="/" aria-label="PulsarX Cloud"><svg viewBox="0 0 26 26" fill="none" aria-hidden="true"><circle cx="13" cy="13" r="3" fill="currentColor"/><circle cx="13" cy="13" r="8" stroke="currentColor" stroke-width="1.4" opacity=".5"/><circle cx="13" cy="13" r="12" stroke="currentColor" opacity=".22"/></svg><b>PulsarX <small>Cloud</small></b></a><p>© ${new Date().getFullYear()} · ${text('footerPanel')}</p></div><nav aria-label="PulsarX links"><a href="https://example.invalid/community" target="_blank" rel="noopener noreferrer">${text('footerSupport')} ↗</a><a href="https://example.invalid/community" target="_blank" rel="noopener noreferrer">${text('footerCommunity')} ↗</a><a href="/terms/">${text('footerTerms')}</a><a href="/privacy/">${text('footerPrivacy')}</a></nav><a class="px-dash-footer-email" href="mailto:contact@example.invalid">contact@example.invalid</a>`;
  main.appendChild(node);
 }
 function boot(){settings();banners();register();adminTab();footer();refresh();new MutationObserver(translate).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.addEventListener('focus',refresh);window.PxGrowth={refresh,settings,setSettingsTab};
})();
