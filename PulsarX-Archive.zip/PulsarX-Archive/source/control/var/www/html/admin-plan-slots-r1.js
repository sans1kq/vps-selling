(function(){
  'use strict';
  const overview=document.getElementById('tab-overview');
  if(!overview||document.getElementById('adminPlanSlots'))return;
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const panel=document.createElement('section');panel.id='adminPlanSlots';panel.className='panel aps-panel';
  panel.innerHTML='<div class="panel-head"><div><h3>Current slots</h3><p class="aps-note">Occupied and reserved places against the existing plan limits.</p></div><button type="button" class="btn btn-small" id="apsRefresh">Refresh</button></div><div id="apsError" class="aps-error" role="alert"></div><div class="table-scroll"><table><thead><tr><th>Plan</th><th>Occupied / limit</th><th>Available</th></tr></thead><tbody id="apsRows"><tr><td colspan="3" class="loading">Loading plan slots…</td></tr></tbody></table></div><p class="aps-note aps-foot"><span id="apsUpdated" role="status">Refreshes every 30s while Overview is visible.</span><span>Server creation also checks the node resources.</span></p>';
  const host=document.getElementById('hostUsageBox')?.closest('.panel');
  if(host?.parentElement===overview)overview.insertBefore(panel,host);else overview.appendChild(panel);
  const rows=document.getElementById('apsRows'),error=document.getElementById('apsError'),button=document.getElementById('apsRefresh'),updated=document.getElementById('apsUpdated');
  let busy=false,unauthorized=false;
  async function load(){
    const token=localStorage.getItem('pulsarx_admin_token');
    if(!token||busy||unauthorized)return;
    busy=true;button.disabled=true;panel.setAttribute('aria-busy','true');error.textContent='';
    try{
      const response=await fetch('/api/admin/plan-slots',{headers:{Authorization:'Bearer '+token},cache:'no-store'});
      if(token!==localStorage.getItem('pulsarx_admin_token'))return;
      if(response.status===401||response.status===403){unauthorized=true;location.href='/adminlogin/';throw new Error('Admin session required.');}
      if(!response.ok)throw new Error('Could not load plan slots. Try Refresh.');
      const data=await response.json();
      if(token!==localStorage.getItem('pulsarx_admin_token'))return;
      if(!Array.isArray(data.plans)||!data.plans.every(p=>typeof p.plan==='string'&&Number.isSafeInteger(p.used)&&p.used>=0&&Number.isSafeInteger(p.max)&&p.max>=0&&Number.isSafeInteger(p.free)&&p.free===Math.max(0,p.max-p.used)))throw new Error('Unexpected plan slot response.');
      rows.innerHTML=data.plans.length?data.plans.map(p=>{
        const name={mini:'Mini',plus:'Plus',nano:'Nano'}[p.plan]||p.plan;
        return '<tr><td><strong>'+esc(name)+'</strong></td><td class="aps-numbers">'+p.used+' / '+p.max+'</td><td><span class="aps-free '+(p.free===0?'is-full':'')+'">'+p.free+(p.free===0?' · full':'')+'</span></td></tr>';
      }).join(''):'<tr><td colspan="3" class="loading">No plans configured</td></tr>';
      const when=new Date(data.checked_at);
      updated.textContent=Number.isFinite(when.getTime())?'Updated '+when.toLocaleTimeString('en-GB',{timeZone:'UTC'})+' UTC · refreshes every 30s':'Updated · refreshes every 30s';
    }catch(exc){
      rows.innerHTML='<tr><td colspan="3" class="loading">Plan slots unavailable</td></tr>';updated.textContent='Not updated';error.textContent=exc.message;
    }finally{busy=false;button.disabled=false;panel.setAttribute('aria-busy','false');}
  }
  button.addEventListener('click',load);
  document.querySelector('.tab-item[data-tab="overview"]')?.addEventListener('click',load);
  setInterval(()=>{if(document.visibilityState!=='hidden'&&overview.classList.contains('active'))load();},30000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='hidden'&&overview.classList.contains('active'))load();});
  if(overview.classList.contains('active'))load();
})();
