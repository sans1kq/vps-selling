(() => {
  const form=document.querySelector('#promo-deploy');
  const text={
    welcomeTopup:['Первое пополнение: скидка 10%. По приглашению друга — 20%.',
      'Save 10% on your first top-up, or 20% with a friend’s invitation.',
      'Ai 10% reducere la prima alimentare sau 20% cu invitația unui prieten.'],
    inviteRule:['После первого пополнения вы можете пригласить одного друга.',
      'After your first top-up, you can invite one friend.',
      'După prima alimentare poți invita un prieten.'],
    promoName:['Промокод на Nano VPS','Nano VPS promo code','Cod promoțional pentru Nano VPS'],
    voucherIntro:['Введите код, чтобы создать Nano VPS на срок, указанный в акции.','Redeem your code to create a Nano VPS for the time included in your offer.','Introdu codul pentru a crea un Nano VPS pe durata inclusă în ofertă.'],
    voucherLabel:['Промокод','Promo code','Cod promoțional'],
    voucherAction:['Активировать код','Redeem code','Activează codul'],
    promoDeploy:['Создать VPS по промокоду','Deploy with promo code','Creează VPS cu un cod'],
    promoError:['Не удалось применить код. Проверьте код и его срок действия.',
      'Could not redeem this code. Check the code and its expiry.',
      'Codul nu a putut fi aplicat. Verifică numele și valabilitatea.']
  };
  Pulse.merge(text);Pulse.apply();
  if(!form)return;
  form.onsubmit=async event=>{
    event.preventDefault();
    if(!localStorage.getItem('pulsarx_token')){location.href='/login/?next=%2Fdashboard%2F%3Ftab%3Dsettings';return;}
    const button=form.querySelector('button'),out=form.querySelector('[role=status]');
    button.disabled=true;out.textContent='';
    try {
      const r=await fetch('/api/promotions/deploy',{method:'POST',headers:{
        Authorization:'Bearer '+localStorage.getItem('pulsarx_token'),'Content-Type':'application/json'},
        body:JSON.stringify({name:form.elements.code.value.trim()})});
      if(r.status===401){location.href='/login/?next=%2Fdashboard%2F%3Ftab%3Dsettings';return;}
      if(!r.ok){const data=await r.json();throw Error(typeof data.detail==='string'?data.detail:Pulse.t('promoError'));}
      location.href='/dashboard/?created=1';
    }catch(e){out.textContent=e.message||Pulse.t('promoError');}finally{button.disabled=false;}
  };
})();
