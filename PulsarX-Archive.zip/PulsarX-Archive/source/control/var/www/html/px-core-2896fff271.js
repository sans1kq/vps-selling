/* PulsarX / Event horizon. Original procedural artwork, no external assets. */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PulsarXCore = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function random(seed) {
    let value = seed >>> 0;
    return () => {
      value = (Math.imul(value, 1664525) + 1013904223) >>> 0;
      return value / 4294967296;
    };
  }
  function ellipse(ctx, x, y, rx, ry, rotation, start, end) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rotation || 0, start || 0, end === undefined ? TAU : end);
  }
  class PulsarXCore {
    constructor(canvas, options) {
      options = options || {};
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d', { alpha: true });
      if (!this.ctx) throw new Error('Canvas 2D is unavailable');
      this.compact = !!options.compact;
      this.makeCanvas = options.makeCanvas || ((w, h) => {
        const result = document.createElement('canvas'); result.width = w; result.height = h; return result;
      });
      this.random = random(17334);
      this.stars = Array.from({ length: this.compact ? 55 : 130 }, () => ({
        x: (this.random() - .5) * 690, y: (this.random() - .5) * 620,
        r: this.random() * .85 + .25, a: this.random() * .5 + .1, phase: this.random() * TAU,
      }));
      this.dust = Array.from({ length: this.compact ? 40 : 100 }, () => ({
        r: 106 + this.random() * 152, phase: this.random() * TAU,
        speed: .04 + this.random() * .09, size: .4 + this.random() * .85,
      }));
      this.disc = this.makeDisc();
      this.resize(options.width || 680, options.height || 610, options.dpr || 1);
    }
    resize(width, height, dpr) {
      this.width = Math.max(1, Number(width) || 1);
      this.height = Math.max(1, Number(height) || 1);
      this.dpr = clamp(Number(dpr) || 1, .5, this.compact ? 1.35 : 1.8);
      this.canvas.width = Math.round(this.width * this.dpr);
      this.canvas.height = Math.round(this.height * this.dpr);
    }
    makeDisc() {
      const size = this.compact ? 700 : 1000;
      const canvas = this.makeCanvas(size, size), c = canvas.getContext('2d');
      const rnd = random(82340), scale = size / 600;
      c.scale(scale, scale); c.translate(300, 300);
      const wash = c.createRadialGradient(0, 0, 75, 0, 0, 265);
      wash.addColorStop(0, 'rgba(160,120,255,0)');
      wash.addColorStop(.14, 'rgba(185,145,255,.24)');
      wash.addColorStop(.35, 'rgba(109,58,229,.40)');
      wash.addColorStop(.7, 'rgba(87,34,183,.12)');
      wash.addColorStop(1, 'rgba(91,46,170,0)');
      c.fillStyle = wash; c.fillRect(-300, -300, 600, 600);
      c.globalCompositeOperation = 'screen';
      const bands = this.compact ? 110 : 190;
      for (let band = 0; band < bands; band++) {
        const fraction = band / (bands - 1), base = 93 + fraction * 151;
        const curl = (1 - fraction) * .34, phase = fraction * 5.6;
        const luminosity = Math.pow(1 - fraction, .7);
        c.beginPath();
        const segments = this.compact ? 100 : 160;
        for (let segment = 0; segment <= segments; segment++) {
          const angle = segment / segments * TAU;
          const radius = base + Math.sin(angle * 3 + fraction * 15) * (2 + fraction * 9)
            + Math.sin(angle * 7 - fraction * 22) * (1.5 + fraction * 3);
          const warped = angle + curl * Math.sin(angle * 2 + phase);
          const x = Math.cos(warped) * radius, y = Math.sin(warped) * radius;
          if (segment) c.lineTo(x, y); else c.moveTo(x, y);
        }
        const red = Math.round(105 + luminosity * 125), green = Math.round(53 + luminosity * 123);
        const light = c.createLinearGradient(-220, -170, 210, 190);
        light.addColorStop(0, `rgba(98,55,181,${.08 + luminosity * .10})`);
        light.addColorStop(.43, `rgba(${red},${green},255,${.12 + luminosity * .20})`);
        light.addColorStop(.72, `rgba(239,199,255,${.12 + luminosity * .72})`);
        light.addColorStop(1, `rgba(123,71,226,${.08 + luminosity * .18})`);
        c.strokeStyle = light;
        c.lineWidth = .25 + rnd() * 1.25; c.stroke();
      }
      for (let lane = 0; lane < 77; lane++) {
        const start = (lane % 7) / 7 * TAU + Math.floor(lane / 7) * .035, offset = rnd() * 26;
        c.beginPath();
        for (let step = 0; step < 96; step++) {
          const radius = 92 + step / 95 * (122 + offset);
          const angle = start + Math.log(radius / 92) * 2.35;
          const wobble = Math.sin(step * .19 + start * 4) * 1.8;
          const x = Math.cos(angle) * (radius + wobble), y = Math.sin(angle) * (radius + wobble);
          if (step) c.lineTo(x, y); else c.moveTo(x, y);
        }
        c.strokeStyle = lane % 11 === 0 ? 'rgba(238,216,255,.39)' : `rgba(158,104,255,${.07 + rnd() * .16})`;
        c.lineWidth = lane % 11 === 0 ? 1.1 : .5; c.stroke();
      }
      for (let i = 0; i < (this.compact ? 1500 : 3300); i++) {
        const radius = 97 + Math.pow(rnd(), 1.6) * 155, angle = rnd() * TAU;
        const alpha = (1 - (radius - 97) / 180) * (.12 + rnd() * .62);
        c.strokeStyle = `rgba(207,172,255,${alpha})`;
        c.lineWidth = .25 + rnd() * .65;
        ellipse(c, 0, 0, radius, radius, 0, angle, angle + .003 + rnd() * .018); c.stroke();
      }
      c.globalCompositeOperation = 'destination-out';
      const cut = c.createRadialGradient(0, 0, 78, 0, 0, 94);
      cut.addColorStop(0, 'rgba(0,0,0,1)'); cut.addColorStop(.73, 'rgba(0,0,0,1)'); cut.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = cut; c.beginPath(); c.arc(0, 0, 94, 0, TAU); c.fill();
      return canvas;
    }
    render(seconds, input) {
      input = input || {};
      const t = Number(seconds) || 0, x = clamp(input.x || 0, -1, 1), y = clamp(input.y || 0, -1, 1);
      const pulse = clamp(input.pulse || 0, 0, 1), ctx = this.ctx;
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.clearRect(0, 0, this.width, this.height);
      const scale = Math.min(this.width / 650, this.height / 580);
      ctx.translate(this.width * .51 + x * 8, this.height * .49 + y * 5); ctx.scale(scale, scale);
      for (let i = 0; i < this.stars.length; i++) {
        const star = this.stars[i], flicker = .82 + .18 * Math.sin(t * .45 + star.phase);
        ctx.fillStyle = `rgba(207,198,250,${star.a * flicker})`;
        ctx.beginPath(); ctx.arc(star.x - x * (i % 3 + 1), star.y - y * 3, star.r, 0, TAU); ctx.fill();
        if (i % 31 === 0) {
          ctx.strokeStyle = `rgba(207,198,250,${star.a * .5})`; ctx.lineWidth = .5;
          ctx.beginPath(); ctx.moveTo(star.x - 4, star.y); ctx.lineTo(star.x + 4, star.y);
          ctx.moveTo(star.x, star.y - 4); ctx.lineTo(star.x, star.y + 4); ctx.stroke();
        }
      }
      ctx.save(); ctx.rotate(-.34 + x * .07);
      const breathing = 1 + Math.sin(t * .66) * .018 + pulse * .055;
      ctx.scale(breathing, breathing);
      const aura = ctx.createRadialGradient(0, 0, 63, 0, 0, 310);
      aura.addColorStop(0, 'rgba(110,61,210,0)'); aura.addColorStop(.35, `rgba(119,61,230,${.20 + pulse * .15})`);
      aura.addColorStop(.72, 'rgba(96,44,176,.065)'); aura.addColorStop(1, 'rgba(58,28,99,0)');
      ctx.fillStyle = aura; ctx.fillRect(-330, -330, 660, 660);
      ctx.save();
      ctx.rotate(.22); ctx.setLineDash([2, 10]); ctx.lineWidth = .65;
      ctx.strokeStyle = 'rgba(157,124,233,.17)'; ellipse(ctx, 0, 0, 281, 223); ctx.stroke();
      ctx.setLineDash([]); ctx.strokeStyle = 'rgba(157,124,233,.14)'; ellipse(ctx, 0, 0, 285, 223, 0, .35, 2.7); ctx.stroke();
      ctx.restore();
      ctx.save();
      ctx.scale(1, .76 + y * .055); ctx.rotate(t * .065);
      ctx.globalCompositeOperation = 'screen'; ctx.globalAlpha = .9;
      ctx.drawImage(this.disc, -300, -300, 600, 600);
      ctx.rotate(-t * .025 - .7); ctx.globalAlpha = .22;
      ctx.drawImage(this.disc, -310, -310, 620, 620);
      ctx.restore();
      // A genuinely dark centre is the visual anchor. The lit edge stays sharp.
      const well = ctx.createRadialGradient(-12, -12, 8, 0, 0, 95);
      well.addColorStop(0, '#040409'); well.addColorStop(.76, '#05050c');
      well.addColorStop(.94, '#0b0717'); well.addColorStop(1, 'rgba(17,9,32,0)');
      ctx.fillStyle = well; ellipse(ctx, 0, 0, 94, 73); ctx.fill();
      const rim = ctx.createLinearGradient(-105, -80, 112, 78);
      rim.addColorStop(0, 'rgba(149,92,255,.04)'); rim.addColorStop(.30, 'rgba(179,128,255,.65)');
      rim.addColorStop(.66, 'rgba(250,232,255,1)'); rim.addColorStop(1, 'rgba(143,93,255,.2)');
      ctx.save(); ctx.globalCompositeOperation = 'screen';
      for (let layer = 0; layer < 4; layer++) {
        ctx.strokeStyle = rim; ctx.lineWidth = [11, 5, 2.1, .65][layer];
        ctx.globalAlpha = [.08, .18, .95, .65][layer];
        ellipse(ctx, 0, 0, 95 + layer * .38, 73.5 + layer * .3); ctx.stroke();
      }
      ctx.globalAlpha = 1;
      // Tiny orbiting fragments make rotation visible without a heavy render loop.
      for (const particle of this.dust) {
        const a = particle.phase + t * particle.speed;
        const px = Math.cos(a) * particle.r, py = Math.sin(a) * particle.r * .76;
        const alpha = clamp((Math.sin(a + .8) + 1) * .35, .06, .8);
        ctx.fillStyle = `rgba(226,198,255,${alpha})`;
        ctx.beginPath(); ctx.arc(px, py, particle.size, 0, TAU); ctx.fill();
      }
      const flareAngle = 1.1 + t * .1;
      const fx = Math.cos(flareAngle) * 117, fy = Math.sin(flareAngle) * 89;
      const flare = ctx.createRadialGradient(fx, fy, 0, fx, fy, 49);
      flare.addColorStop(0, 'rgba(255,232,255,.32)'); flare.addColorStop(.12, 'rgba(195,151,255,.15)');
      flare.addColorStop(1, 'rgba(155,90,245,0)');
      ctx.fillStyle = flare; ctx.fillRect(fx - 49, fy - 49, 98, 98);
      if (pulse > .008) {
        const progress = 1 - pulse;
        ctx.globalAlpha = Math.sin(progress * Math.PI) * .42;
        ctx.strokeStyle = '#bda1ff'; ctx.lineWidth = .8;
        ellipse(ctx, 0, 0, 115 + progress * 208, 88 + progress * 159); ctx.stroke();
      }
      ctx.restore(); ctx.restore();
    }
    destroy() {
      this.disc.width = 1; this.disc.height = 1;
      this.canvas.width = 1; this.canvas.height = 1;
      this.stars.length = 0; this.dust.length = 0;
    }
  }
  return PulsarXCore;
});
