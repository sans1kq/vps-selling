/* Server controls presentation. Existing controllers own every server/payment action. */
(() => {
  'use strict';
  const P=window.Pulse;
  if(!P)return;
  const box=document.getElementById('serversContent');
  if(!box)return;
  P.merge({
    dashConnection:['Подключение','Connection','Conectare'],
    dashCommand:['Команда SSH','SSH command','Comandă SSH'],
    dashCopyCommand:['Копировать команду','Copy command','Copiază comanda'],
    dashCopyAddress:['Скопировать адрес','Copy address','Copiază adresa'],
    dashCopyValue:['Скопировать','Copy','Copiază'],
    dashHost:['Адрес сервера','Server address','Adresa serverului'],
    dashUser:['Пользователь','Username','Utilizator'],
    dashSshPort:['SSH-порт','SSH port','Port SSH'],
    dashPower:['Управление питанием','Power controls','Control alimentare'],
    dashResources:['Ресурсы','Resources','Resurse'],
    dashCpu:['Процессор','CPU','Procesor'],
    dashMemory:['Память','Memory','Memorie'],
    dashDisk:['NVMe-диск','NVMe storage','Stocare NVMe'],
    dashPorts:['Порты приложений','Application ports','Porturi pentru aplicații'],
    dashPortsHelp:['Приложение должно слушать указанный TCP-порт. Кнопка рядом копирует полный адрес.','Your application must listen on the assigned TCP port. The button beside it copies the full address.','Aplicația trebuie să asculte pe portul TCP indicat. Butonul alăturat copiază adresa completă.'],
    dashNoPorts:['Дополнительные порты пока не назначены.','No additional ports have been assigned yet.','Nu sunt încă alocate porturi suplimentare.'],
    dashNotRunning:['Сервер сейчас не работает. SSH станет доступен после запуска.','The server is not running. SSH becomes available after it starts.','Serverul nu este pornit. SSH devine disponibil după pornire.'],
    dashRenew:['Продлить сервер','Renew server','Reînnoiește serverul'],
    dashClose:['Закрыть управление сервером','Close server controls','Închide administrarea serverului'],
    dashUpgrade:['Больше ресурсов для проекта','More room for your project','Mai multe resurse pentru proiect'],
    dashUpgradeNote:['Стоимость и условия — перед подтверждением.','Review the price and terms before confirming.','Vezi prețul și condițiile înainte de confirmare.']
  });
  const label=(tag,key,className='')=>{
    const n=document.createElement(tag);n.dataset.t=key;n.textContent=P.t(key);if(className)n.className=className;return n;
  };
  const icon=name=>{const n=document.createElement('span');n.className='dash-icon';n.setAttribute('aria-hidden','true');n.innerHTML=P.icon(name);return n;};
  const cardFor=root=>Array.from(box.querySelectorAll('[data-server-card]')).find(n=>n.dataset.serverCard===root.dataset.serverDetail);
  function copyButton(value,key='dashCopyValue'){
    const b=document.createElement('button');b.type='button';b.className='dash-copy';b.dataset.dashboardCopy=value;
    b.setAttribute('aria-label',P.t(key)+(value?' · '+value:''));b.title=P.t(key);b.append(icon('copy'));
    b.disabled=!value;return b;
  }
  function fact(key,value){
    const n=document.createElement('div');n.className='dash-fact';n.append(label('small',key));
    const line=document.createElement('div');line.className='dash-fact-value';
    const code=document.createElement('code');code.textContent=value;line.append(code,copyButton(value));n.append(line);return n;
  }
  function state(root){
    const badge=cardFor(root)?.querySelector('.status-badge');
    return badge?Array.from(badge.classList).find(n=>n.startsWith('status-')&&n!=='status-badge')?.slice(7):'';
  }
  function passwordState(root){
    root.classList.toggle('dash-needs-password',!!root.querySelector('.ssh-access-section [data-server-password]'));
  }
  function metrics(root){
    root.querySelectorAll('[data-usage] > .meter').forEach((meter,index)=>{
      if(meter.dataset.dashboardMetric)return;
      const spans=meter.querySelectorAll('.meter-label > span');if(spans.length!==2)return;
      meter.dataset.dashboardMetric='1';
      const key=['dashCpu','dashMemory','dashDisk'][index],symbol=['cpu','memory','disk'][index];
      if(key){
        const short=document.createElement('span');short.className='dash-metric-short';short.textContent=['CPU','RAM','NVMe'][index];short.setAttribute('aria-hidden','true');
        spans[0].replaceChildren(icon(symbol),label('span',key,'dash-metric-label'),short);
      }
      const value=spans[1].textContent,parts=index===0?value.match(/^([\d.,]+)(%)$/):value.match(/^(.*?)\s\/\s(.*)$/);
      if(parts){const strong=document.createElement('strong'),unit=document.createElement('small');strong.textContent=parts[1];unit.textContent=index===0?parts[2]:' / '+parts[2];spans[1].replaceChildren(strong,unit);}
      spans[1].classList.add('dash-metric-value');
    });
  }
  function mount(root){
    if(root.dataset.dashboardUi){passwordState(root);metrics(root);return;}
    const head=root.querySelector('.detail-head'),password=root.querySelector('.ssh-access-section'),connection=root.querySelector('.detail-connection'),usage=root.querySelector('.usage-section'),ports=root.querySelector('.ports-section');
    if(!head||!password||!connection||!usage||!ports)return;
    root.dataset.dashboardUi='1';root.classList.add('dash-server-panel');
    const close=head.querySelector('[data-close-detail]');if(close){close.setAttribute('aria-label',P.t('dashClose'));close.title=P.t('dashClose');}
    const card=cardFor(root),badge=card?.querySelector('.status-badge'),identity=card?.querySelector('.server-identity small');
    const heading=head.querySelector('h2')?.parentElement;
    if(heading&&identity){const system=document.createElement('span');system.className='dash-server-system';system.textContent=identity.textContent;heading.append(system);}
    if(badge){const status=badge.cloneNode(true);status.classList.add('dash-current-status');head.insertBefore(status,close||null);}
    const expiry=card?.querySelector('.server-term');
    if(expiry){
      const overview=document.createElement('div');overview.className='dash-server-overview';
      const when=document.createElement('div');when.className='dash-expiry';when.append(icon('clock'));
      const text=document.createElement('div'),caption=document.createElement('small'),date=document.createElement('strong');
      caption.textContent=expiry.querySelector('small')?.textContent||'';date.textContent=expiry.querySelector('strong')?.textContent||'';text.append(caption,date);when.append(text);overview.append(when);
      if(card.querySelector('[data-renew]')){const renew=document.createElement('button');renew.type='button';renew.className='btn btn-secondary dash-renew';renew.dataset.dashboardRenew='';renew.append(label('span','dashRenew'),icon('arrow'));overview.append(renew);}
      head.after(overview);
    }
    const controls=connection.querySelector('.control-actions');
    if(controls?.querySelector('button')){
      const bar=document.createElement('div');bar.className='dash-power';bar.append(label('span','dashPower'),controls);
      (root.querySelector('.dash-server-overview')||head).after(bar);
    }
    const access=document.createElement('section');access.className='dash-access';
    const title=document.createElement('div');title.className='dash-section-heading';title.append(icon('code'),label('h3','dashConnection'));
    password.before(access);access.append(title,password,connection);
    const commandLabel=connection.querySelector('h3');if(commandLabel){commandLabel.dataset.t='dashCommand';commandLabel.textContent=P.t('dashCommand');}
    const code=connection.querySelector('.code-line code'),copy=connection.querySelector('[data-copy-ssh]');
    if(copy){copy.classList.add('dash-command-copy');copy.append(label('span','dashCopyCommand'));copy.setAttribute('aria-label',P.t('dashCopyCommand'));copy.title=P.t('dashCopyCommand');}
    const endpoint=code?.textContent.trim().match(/^ssh\s+([^\s@]+)@([^\s]+)\s+-p\s+(\d+)$/);
    if(endpoint){
      const facts=document.createElement('div');facts.className='dash-endpoints';facts.append(fact('dashUser',endpoint[1]));
      const port=ports.querySelector('.service-port');
      if(port){
        port.classList.add('dash-fact');const caption=port.querySelector('small'),number=port.querySelector('strong');
        if(caption){caption.dataset.t='dashSshPort';caption.textContent=P.t('dashSshPort');}
        if(number){const row=document.createElement('div');row.className='dash-fact-value';row.append(number,copyButton(number.textContent.trim()));port.append(row);}
        facts.append(port);
      }else facts.append(fact('dashSshPort',endpoint[3]));
      access.append(facts);
    }
    const currentState=state(root);if(code&&currentState&&currentState!=='running')access.append(label('p','dashNotRunning','dash-connection-note'));
    const resourceTitle=usage.querySelector('.meter-label > strong');if(resourceTitle){resourceTitle.dataset.t='dashResources';resourceTitle.textContent=P.t('dashResources');resourceTitle.setAttribute('role','heading');resourceTitle.setAttribute('aria-level','3');}
    const portTitle=ports.querySelector('h3'),portHelp=ports.querySelector('.help-text');
    if(portTitle){portTitle.dataset.t='dashPorts';portTitle.textContent=P.t('dashPorts');}
    if(portHelp){portHelp.dataset.t='dashPortsHelp';portHelp.textContent=P.t('dashPortsHelp');}
    ports.querySelectorAll('.ports-grid > .port-chip:not(.service-port)').forEach(chip=>{
      const number=chip.querySelector('strong'),caption=chip.querySelector('small');if(!number)return;
      const port=number.textContent.trim();chip.classList.add('dash-app-port');
      if(caption){caption.textContent='TCP';caption.classList.add('dash-protocol');}
      const copy=copyButton(endpoint&&/^\d+$/.test(port)?endpoint[2]+':'+port:'','dashCopyAddress');chip.append(copy);
    });
    if(!ports.querySelector('.ports-grid > .port-chip'))ports.append(label('p','dashNoPorts','dash-empty-ports'));
    const upgrade=root.querySelector('.upgrade-panel');
    if(upgrade){
      const info=upgrade.querySelector('div');if(info){info.prepend(label('small','dashUpgrade','dash-upgrade-kicker'));info.append(label('small','dashUpgradeNote','dash-upgrade-note'));}
    }
    passwordState(root);metrics(root);
  }
  const bound=new WeakSet();
  function bindCopyAndRenew(){
    box.querySelectorAll('[data-dashboard-copy],[data-copy-ssh],[data-dashboard-renew]').forEach(b=>{
      if(bound.has(b))return;bound.add(b);
      b.addEventListener('click',event=>{
        if(b.disabled)return;
        const root=b.closest('[data-server-detail][data-dashboard-ui]');if(!root)return;
        event.preventDefault();event.stopImmediatePropagation();
        if(b.hasAttribute('data-dashboard-renew')){
          if(document.querySelector('dialog[open]'))return;
          const source=cardFor(root)?.querySelector('[data-renew]');if(source&&!source.disabled)source.click();return;
        }
        const value=b.hasAttribute('data-dashboard-copy')?b.dataset.dashboardCopy:root.querySelector('.code-line code')?.textContent.trim();
        if(value)P.copy(value);
      });
    });
  }
  let observer,queued=false;
  function refresh(){
    queued=false;observer?.disconnect();
    box.querySelectorAll('[data-server-detail]').forEach(mount);
    box.querySelectorAll('[data-dashboard-renew]').forEach(b=>{const root=b.closest('[data-server-detail]'),source=root&&cardFor(root)?.querySelector('[data-renew]');b.disabled=!source||source.disabled;});
    bindCopyAndRenew();
    observer?.observe(box,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled']});
  }
  function schedule(){if(queued)return;queued=true;Promise.resolve().then(refresh);}
  observer=new MutationObserver(schedule);refresh();
  document.addEventListener('px:lang',schedule);
})();
