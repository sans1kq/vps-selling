/* PulsarX dashboard: prepaid crypto billing (pay / extend / countdowns). */
let pricingData = null;
let openPayments = null;

(function () {
  const st = document.createElement('style');
  st.textContent = '.mon-select{color-scheme:dark}.mon-select option{background:#1a1a24;color:#e6e6ef}' +
    '.bill-left-warn{color:#f87171}.bill-link{text-decoration:none;display:inline-block}';
  document.head.appendChild(st);
})();

async function loadPricing() {
  if (pricingData) return pricingData;
  try {
    const res = await fetch('/api/servers/pricing');
    pricingData = await res.json();
  } catch (e) {
    pricingData = { prices: {}, discount_pct: {} };
  }
  return pricingData;
}

async function refreshOpenPayments() {
  try {
    const res = await fetch('/api/servers/payments/open', { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return;
    const data = await res.json();
    const changed = JSON.stringify(data) !== JSON.stringify(openPayments);
    openPayments = data;
    if (changed && document.getElementById('overviewContent')) renderOverview();
  } catch (e) {}
}

function fmtUtc(iso) {
  return new Date(iso).toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
}

function periodLabel(m) {
  const names = { 1: t('deploy_period_1', '1 month'), 3: t('deploy_period_3', '3 months'),
                  6: t('deploy_period_6', '6 months'), 12: t('deploy_period_12', '12 months') };
  return names[m];
}

function durationText(ms) {
  const mins = Math.floor(ms / 60000);
  const d = Math.floor(mins / 1440), h = Math.floor((mins % 1440) / 60), m = mins % 60;
  const ud = t('dash_bill_unit_d', 'd'), uh = t('dash_bill_unit_h', 'h'), um = t('dash_bill_unit_m', 'min');
  if (d > 0) return d + ' ' + ud + ' ' + h + ' ' + uh;
  if (h > 0) return h + ' ' + uh + ' ' + m + ' ' + um;
  return Math.max(m, 0) + ' ' + um;
}

function timeLeftBadge(s) {
  if (s.trial_expires_at) {
    const ms = new Date(s.trial_expires_at).getTime() - Date.now();
    return ' · ' + (ms > 0 ? durationText(ms) : '0 min') + ' · 24h free';
  }
  if (!s.paid_until || s.has_subscription) return '';
  const ms = new Date(s.paid_until).getTime() - Date.now();
  if (ms <= 0) return ' · ' + t('dash_bill_ended', 'paid period ended');
  return ' · ' + t('dash_bill_left', '{time} left').replace('{time}', durationText(ms));
}

function billingBlockHtml() {
  const rows = currentServers.filter(s => !s.trial_expires_at && !s.has_subscription &&
    (s.status === 'pending_approval' ||
     (s.paid_until && (s.status === 'running' || s.status === 'suspended'))));
  if (rows.length === 0) return '';
  if (!pricingData) {
    loadPricing().then(() => { if (document.getElementById('overviewContent')) renderOverview(); });
  }
  if (openPayments === null) refreshOpenPayments();
  const prices = (pricingData && pricingData.prices) || {};
  const disc = (pricingData && pricingData.discount_pct) || {};
  const items = rows.map(s => {
    let info, controls = '', note = '';
    if (s.status === 'pending_approval') {
      const pay = (openPayments || []).find(p => p.server_id === s.id && p.kind === 'new');
      if (pay) {
        info = t('dash_bill_wait', 'Waiting for payment') + ' · $' + pay.amount_usd + ' / ' + periodLabel(pay.months)
          + ' · <span class="bill-countdown" data-exp="' + pay.expires_at + '"></span>';
        controls = `<a class="btn bill-link" href="${pay.checkout_url}">${t('dash_bill_open_btn', 'Open payment page')}</a>`;
      } else if (openPayments === null) {
        info = t('dash_bill_wait', 'Waiting for payment');
      } else {
        info = t('dash_bill_gone', 'Payment time ran out - this request is removed automatically. Deploy again to start over.');
      }
    } else {
      const ms = new Date(s.paid_until).getTime() - Date.now();
      const warn = ms < 3 * 864e5 ? ' bill-left-warn' : '';
      const frozen = s.status === 'suspended' ? t('dash_bill_frozen', 'Frozen - extend to bring it back online') + ' · ' : '';
      info = frozen + t('dash_bill_paid_until', 'Paid until {date}').replace('{date}', fmtUtc(s.paid_until))
        + ' · <span class="' + warn + '">' + timeLeftBadge(s).replace(' · ', '') + '</span>';
      const opts = [1, 3, 6, 12].map(m => {
        const p = prices[s.plan] && prices[s.plan][String(m)];
        const off = disc[String(m)] ? ' (-' + disc[String(m)] + '%)' : '';
        return `<option value="${m}">${periodLabel(m)}${off}${p ? ' - $' + p : ''}</option>`;
      }).join('');
      controls = `<select class="mon-select bill-months" data-id="${s.id}" style="margin-bottom:0;">${opts}</select>
          <button class="btn bill-pay-btn" data-id="${s.id}">${t('dash_bill_extend_btn', 'Extend')}</button>`;
      note = `<div class="sub" style="opacity:.6;font-size:12px;flex-basis:100%;">${t('dash_bill_add_note', 'The new period is added on top of the time that is left.')}</div>`;
    }
    return `
      <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:12px 0;border-top:1px solid var(--border, #22222e);">
        <div><b>${s.container_name}</b><div class="sub" style="opacity:.75;">${info}</div></div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">${controls}</div>
        ${note}
        <div class="domain-err" id="bill-err-${s.id}" style="flex-basis:100%;"></div>
      </div>`;
  }).join('');
  return `
    <div class="stat-card" style="margin-top:18px;">
      <div class="label">${t('dash_bill_title', 'Billing')}</div>
      <div class="sub" style="opacity:.75;margin-bottom:6px;">${t('dash_bill_sub', 'Pay from your balance — nothing is charged automatically.')}</div>
      ${items}
    </div>`;
}

function bindBillingBlock() {
  document.querySelectorAll('.bill-pay-btn').forEach(btn => {
    btn.addEventListener('click', () => startPayment(btn.dataset.id, btn));
  });
  tickCountdowns();
}

async function startPayment(id, btn) {
  const sel = document.querySelector(`.bill-months[data-id="${id}"]`);
  const err = document.getElementById(`bill-err-${id}`);
  err.textContent = '';
  btn.disabled = true;
  try {
    await window.PxWallet.confirmOrder({kind:'renew', server_id:id, months:parseInt(sel.value,10)});
  } catch (e) { err.textContent = e.message; }
  finally { btn.disabled = false; }
}

function tickCountdowns() {
  document.querySelectorAll('.bill-countdown').forEach(el => {
    const ms = new Date(el.dataset.exp).getTime() - Date.now();
    if (ms <= 0) { el.textContent = t('dash_bill_timeout', 'time is up'); return; }
    const sec = Math.floor(ms / 1000);
    el.textContent = t('dash_bill_expires_in', 'expires in {time}')
      .replace('{time}', String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0'));
  });
}
setInterval(tickCountdowns, 1000);
setInterval(() => {
  try { if (currentServers.some(x => x.status === 'pending_approval')) refreshOpenPayments(); } catch (e) {}
}, 15000);

window.addEventListener('load', () => {
  const p = new URLSearchParams(location.search).get('payment');
  if (!p) return;
  history.replaceState(null, '', location.pathname);
  if (p.indexOf('succ') === 0) {
    showToast(t('dash_bill_toast_ok', 'Payment sent'),
              t('dash_bill_toast_ok_sub', 'Waiting for the network confirmation - this page updates by itself'));
    let n = 0;
    const timer = setInterval(() => { loadServers(); if (++n >= 40) clearInterval(timer); }, 15000);
  } else {
    showToast(t('dash_bill_toast_fail', 'Payment not completed'),
              t('dash_bill_toast_fail_sub', 'You can start it again from the Overview page'));
  }
});

/* Corner badge: visible on every dashboard page, not just Overview. */
function billingCount() {
  const unpaid = currentServers.filter(s => !s.trial_expires_at && s.status === 'pending_approval').length;
  const dueSoon = currentServers.filter(s => !s.has_subscription && s.paid_until &&
    (s.status === 'running' || s.status === 'suspended') &&
    (new Date(s.paid_until).getTime() - Date.now()) < 3 * 864e5).length;
  return unpaid + dueSoon;
}

function renderBillingBadge() {
  let el = document.getElementById('billBadge');
  if (!el) {
    el = document.createElement('button');
    el.id = 'billBadge';
    el.className = 'nav-item';
    el.style.cssText = 'position:fixed;top:18px;right:22px;z-index:50;width:auto;padding:8px 14px;border-radius:10px;display:none;align-items:center;gap:8px;';
    el.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg><span id="billBadgeText"></span>';
    el.addEventListener('click', () => {
      document.querySelectorAll('.nav-item[data-page]').forEach(b => b.classList.remove('active'));
      document.querySelector('.nav-item[data-page="overview"]').classList.add('active');
      document.querySelectorAll('.page').forEach(p => p.classList.remove('show'));
      document.getElementById('page-overview').classList.add('show');
      renderOverview();
    });
    document.body.appendChild(el);
  }
  const n = billingCount();
  if (n > 0) {
    el.style.display = 'flex';
    document.getElementById('billBadgeText').textContent = t('dash_bill_badge', '{n} need payment').replace('{n}', n);
  } else {
    el.style.display = 'none';
  }
}
setInterval(renderBillingBadge, 15000);

// PulsarX free instance lifetime v1
