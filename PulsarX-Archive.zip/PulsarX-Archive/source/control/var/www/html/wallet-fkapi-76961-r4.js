(function () {
  'use strict';
  const copy = {
    en: { title:'Balance', available:'Available balance', sub:'USD for your PulsarX instances. Renew only when you choose.', topup:'Top up via AnyPay', amount:'Amount in USD', go:'Continue to AnyPay', note:'Payment methods and any fees are shown by AnyPay before payment. A top-up adds funds to your account; it does not create or renew an instance.', history:'Balance history', empty:'No transactions yet. Top up your balance to get started.', recent:'Recent top-ups', orders:'Paid operations', refresh:'Refresh', checking:'Checking…', check:'Check payment', pending:'Awaiting confirmation', credited:'Credited', closed:'Not completed', expired:'Expired', review:'Needs support review', queued:'Queued', working:'Processing', completed:'Completed', refunded:'Returned to balance', purchase:'Instance payment', refund:'Creation refund', notice:'Returned from AnyPay. Waiting for verified payment confirmation; this page will refresh automatically.', failed:'Payment was not completed. You can try again below.', frozen:'Your balance is under review. Please contact support.', unavailable:'Top-ups are temporarily unavailable.', error:'Could not complete the request. Please try again.', range:'Enter an amount within the permitted range.', confirm:'Confirm payment', pay:'Pay from balance', cancel:'Cancel', cost:'This amount will be deducted from your balance.', short:'Your balance is too low. Top up, then return to this purchase.', add:'Top up balance', success:'Payment accepted', processing:'Your payment is saved. Check the operation status in your dashboard.', balance:'Your balance', more:'Show more', awaiting:'Payment found. Waiting for AnyPay notification.', new:'New instance', renew:'Renewal', upgrade:'Upgrade to Plus', deadline:'Review the payment details in AnyPay and save your receipt.' },
    ru: { title:'Баланс', available:'Доступный баланс', sub:'Доллары для ваших инстансов PulsarX. Продлевайте, когда нужно вам.', topup:'Пополнить через AnyPay', amount:'Сумма в USD', go:'Перейти к AnyPay', note:'Способы оплаты и возможные комиссии AnyPay покажет до оплаты. Пополнение добавляет деньги на баланс: инстанс нужно купить или продлить отдельно.', history:'История баланса', empty:'Операций пока нет. Пополните баланс, чтобы начать.', recent:'Последние пополнения', orders:'Оплаченные операции', refresh:'Обновить', checking:'Проверяем…', check:'Проверить платёж', pending:'Ждём подтверждения', credited:'Зачислено', closed:'Не завершён', expired:'Срок истёк', review:'Нужна проверка поддержки', queued:'В очереди', working:'Выполняется', completed:'Завершено', refunded:'Возвращено на баланс', purchase:'Оплата инстанса', refund:'Возврат за создание', notice:'Вы вернулись из AnyPay. Ждём проверенного подтверждения платежа; баланс обновится автоматически.', failed:'Оплата не завершена. Ниже можно попробовать снова.', frozen:'Баланс на проверке. Обратитесь в поддержку.', unavailable:'Пополнение временно недоступно.', error:'Не удалось выполнить запрос. Попробуйте ещё раз.', range:'Введите сумму в допустимом диапазоне.', confirm:'Подтвердить оплату', pay:'Оплатить с баланса', cancel:'Отмена', cost:'Эта сумма спишется с баланса.', short:'На балансе не хватает средств. Пополните его и вернитесь к покупке.', add:'Пополнить баланс', success:'Оплата принята', processing:'Оплата сохранена. Статус операции доступен в кабинете.', balance:'Ваш баланс', more:'Показать ещё', awaiting:'Платёж найден. Ждём уведомление AnyPay.', new:'Новый инстанс', renew:'Продление', upgrade:'Апгрейд до Plus', deadline:'Проверьте условия оплаты в AnyPay и сохраните квитанцию.' },
    ro: { title:'Sold', available:'Sold disponibil', sub:'USD pentru instantele PulsarX. Reinnoiesti cand alegi tu.', topup:'Alimenteaza prin AnyPay', amount:'Suma in USD', go:'Continua la AnyPay', note:'AnyPay afiseaza metodele de plata si eventualele comisioane inainte de plata. Alimentarea adauga bani in cont; cumpararea sau reinnoirea instantei se face separat.', history:'Istoricul soldului', empty:'Nu exista tranzactii. Alimenteaza soldul pentru a incepe.', recent:'Alimentari recente', orders:'Operatiuni platite', refresh:'Actualizeaza', checking:'Se verifica…', check:'Verifica plata', pending:'Se asteapta confirmarea', credited:'Creditat', closed:'Neefectuat', expired:'Expirat', review:'Necesita verificarea suportului', queued:'In asteptare', working:'Se proceseaza', completed:'Finalizat', refunded:'Returnat in sold', purchase:'Plata instantei', refund:'Rambursare pentru creare', notice:'Ai revenit de la AnyPay. Asteptam confirmarea verificata a platii; soldul se va actualiza automat.', failed:'Plata nu a fost finalizata. Poti incerca din nou mai jos.', frozen:'Soldul este in verificare. Contacteaza suportul.', unavailable:'Alimentarile sunt temporar indisponibile.', error:'Cererea nu a putut fi finalizata. Incearca din nou.', range:'Introdu o suma in intervalul permis.', confirm:'Confirma plata', pay:'Plateste din sold', cancel:'Anuleaza', cost:'Aceasta suma va fi retrasa din sold.', short:'Sold insuficient. Alimenteaza contul, apoi revino la cumparare.', add:'Alimenteaza soldul', success:'Plata acceptata', processing:'Plata a fost salvata. Verifica starea operatiunii in panou.', balance:'Soldul tau', more:'Arata mai mult', awaiting:'Plata gasita. Asteptam notificarea AnyPay.', new:'Instanta noua', renew:'Reinnoire', upgrade:'Upgrade la Plus', deadline:'Verifica detaliile platii in AnyPay si pastreaza dovada.' }
  };
  Object.assign(copy.en, {
    topup:'Top up balance', go:'Create invoice', pending:'Awaiting payment', creating:'Preparing invoice', confirming:'Confirming payment', cancelled:'Closed by you',
    note:'Choose a payment provider. Available methods, crypto networks and fees are shown on the payment page. A top-up adds USD to your balance; buy or renew an instance separately.',
    method:'Payment method', anypayHint:'Cards and other available methods', freekassaHint:'Methods enabled for this store', plisioHint:'Cryptocurrency checkout', resume:'Continue payment', reminder:'You have an unpaid invoice',
    active:'Continue or close your open invoice before creating another.', expires:'Time left', until:'Local checkout deadline', timerDone:'Checkout time has expired',
    timerNote:'This timer closes the invoice on this site. The processor controls its payment status; verified late payments are still credited.',
    closeInvoice:'Close invoice', closeTitle:'Close this unpaid invoice?', closeNote:'Only close it if you have not sent money. Closing hides its checkout here; it does not stop a transfer at the processor. A verified late payment will still be credited.',
    back:'Back', minimize:'Minimize reminder', expand:'Expand reminder', details:'Open balance', totalOpen:'Open invoices',
    confirmingNote:'Funds were detected. Wait for confirmation; do not pay again.', checkoutError:'The payment page is temporarily unavailable. Your invoice is saved; try again shortly.',
    checkingError:'Payment confirmation is temporarily unavailable. Try again shortly.', closeError:'A payment is being confirmed. Wait for its result.',
    awaiting:'Payment found. Waiting for the processor notification.', notice:'Returned from checkout. The balance updates after verified confirmation.',
    failed:'Checkout was closed. You can continue the same unpaid invoice below.', deadline:'Review the amount and, for crypto, the exact coin and network before sending.',
  });
  Object.assign(copy.ru, {
    topup:'Пополнить баланс', go:'Создать счёт', pending:'Ожидает оплаты', creating:'Готовим счёт', confirming:'Подтверждаем платёж', cancelled:'Закрыт вами',
    note:'Выберите платёжного оператора. Доступные способы, криптосети и комиссии указаны на странице оплаты. Пополнение добавляет USD на баланс; покупка и продление инстанса оплачиваются отдельно.',
    method:'Способ оплаты', anypayHint:'Карты и другие доступные способы', freekassaHint:'Способы, подключённые магазину', plisioHint:'Оплата криптовалютой', resume:'Продолжить оплату', reminder:'У вас есть неоплаченный счёт',
    active:'Завершите или закройте открытый счёт, прежде чем создавать новый.', expires:'Осталось', until:'Срок оплаты на сайте', timerDone:'Время для оплаты истекло',
    timerNote:'Таймер закрывает счёт на сайте. Статус оплаты определяет платёжный оператор; подтверждённый поздний платёж тоже будет зачислен.',
    closeInvoice:'Закрыть счёт', closeTitle:'Закрыть неоплаченный счёт?', closeNote:'Закрывайте счёт, только если ещё не отправляли деньги. Это уберёт переход к оплате здесь, но не остановит перевод у оператора. Подтверждённый поздний платёж будет зачислен.',
    back:'Назад', minimize:'Свернуть уведомление', expand:'Развернуть уведомление', details:'Открыть баланс', totalOpen:'Открытых счетов',
    confirmingNote:'Оплата обнаружена. Дождитесь подтверждения, повторно платить не нужно.', checkoutError:'Страница оплаты временно недоступна. Счёт сохранён — попробуйте открыть его чуть позже.',
    checkingError:'Подтверждение платежа временно недоступно. Попробуйте чуть позже.', closeError:'Платёж уже подтверждается. Дождитесь результата.',
    awaiting:'Платёж найден. Ждём уведомление платёжного оператора.', notice:'Вы вернулись со страницы оплаты. Баланс обновится после проверенного подтверждения.',
    failed:'Страница оплаты закрыта. Ниже можно продолжить оплату того же счёта.', deadline:'Перед переводом проверьте сумму, а для криптовалюты — точную монету и сеть.',
  });
  Object.assign(copy.ro, {
    topup:'Alimenteaza soldul', go:'Creeaza factura', pending:'Asteapta plata', creating:'Se pregateste factura', confirming:'Se confirma plata', cancelled:'Inchisa de tine',
    note:'Alege un procesator de plati. Metodele disponibile, retelele crypto si comisioanele sunt afisate la plata. Alimentarea adauga USD in sold; cumpara sau reinnoieste instanta separat.',
    method:'Metoda de plata', anypayHint:'Carduri si alte metode disponibile', freekassaHint:'Metode activate pentru magazin', plisioHint:'Plata in criptomoneda', resume:'Continua plata', reminder:'Ai o factura neplatita',
    active:'Continua sau inchide factura deschisa inainte de a crea alta.', expires:'Timp ramas', until:'Termenul platii pe site', timerDone:'Timpul pentru plata a expirat',
    timerNote:'Cronometrul inchide factura pe site. Procesatorul stabileste starea platii; platile intarziate confirmate sunt creditate.',
    closeInvoice:'Inchide factura', closeTitle:'Inchizi factura neplatita?', closeNote:'Inchide factura numai daca nu ai trimis bani. Inchiderea ascunde plata aici, dar nu opreste transferul la procesator. O plata intarziata confirmata va fi creditata.',
    back:'Inapoi', minimize:'Restrange notificarea', expand:'Extinde notificarea', details:'Deschide soldul', totalOpen:'Facturi deschise',
    confirmingNote:'Plata a fost detectata. Asteapta confirmarea; nu plati din nou.', checkoutError:'Pagina de plata este temporar indisponibila. Factura este salvata; incearca din nou.',
    checkingError:'Confirmarea platii este temporar indisponibila. Incearca mai tarziu.', closeError:'Plata se confirma deja. Asteapta rezultatul.',
    awaiting:'Plata gasita. Asteptam notificarea procesatorului.', notice:'Ai revenit de la plata. Soldul se actualizeaza dupa confirmarea verificata.',
    failed:'Pagina de plata a fost inchisa. Poti continua aceeasi factura mai jos.', deadline:'Verifica suma si, pentru crypto, moneda si reteaua exacta inainte de transfer.',
  });
  const lang = () => window.pulsarxI18n?.getLang() || 'en';
  const tr = key => (copy[lang()] || copy.en)[key] || key;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = value => '$' + (Number(value) / 100).toFixed(2);
  const invoiceNumber = value => {
    const raw=String(value), number=Number(raw);
    return /^\d+$/.test(raw)&&Number.isSafeInteger(number)&&number>=86000000000000
      ? String(number-86000000000000+50) : raw;
  };
  const date = value => value ? new Date(value).toLocaleString(lang() === 'ru' ? 'ru-RU' : lang() === 'ro' ? 'ro-RO' : 'en-GB', {dateStyle:'medium', timeStyle:'short'}) : '';
  Object.assign(copy.en, {fkTitle:'Cards + crypto · KASSA', plisioTitle:'Crypto · Plisio', fkMethod:'Payment method in KASSA', freekassaHint:'SBP, Russian cards and cryptocurrency', fkUnavailable:'KASSA methods are unavailable. You can use Plisio or try again later.', uncertain:'The request was already sent to KASSA. Check the saved invoice or contact support; a duplicate will not be created.'});
  Object.assign(copy.ru, {fkTitle:'Карты + криптовалюта · KASSA', plisioTitle:'Криптовалюта · Plisio', fkMethod:'Способ оплаты в KASSA', freekassaHint:'СБП, карты РФ и криптовалюта', fkUnavailable:'Способы KASSA недоступны. Можно выбрать Plisio или попробовать позже.', uncertain:'Запрос уже отправлен в KASSA. Проверьте сохранённый счёт или обратитесь в поддержку; повторный заказ не создаётся.'});
  Object.assign(copy.ro, {fkTitle:'Carduri + crypto · KASSA', plisioTitle:'Crypto · Plisio', fkMethod:'Metoda de plata in KASSA', freekassaHint:'SBP, carduri rusesti si criptomoneda', fkUnavailable:'Metodele KASSA sunt indisponibile. Alege Plisio sau incearca mai tarziu.', uncertain:'Cererea a fost trimisa la KASSA. Verifica factura salvata sau contacteaza suportul; nu cream o comanda duplicata.'});
  const providerName = value => value === 'freekassa' ? tr('fkTitle') : value === 'plisio' ? tr('plisioTitle') : 'AnyPay';
  const active = row => row && (row.status === 'pending' || row.status === 'creating');
  let cached = null, offset = 0, currentHistory = [], loading = false, hasPending = false, clockOffset = 0, submitting = false;
  let collapsedId = sessionStorage.getItem('px-wallet-reminder-collapsed') || '';
  const busyActions = new Set();
  let failedAuthToken = null;
  let selectedMethod = sessionStorage.getItem('px-wallet-topup-method');

  function updatePaymentMethods() {
    const selected = document.querySelector('input[name="walletProvider"]:checked')?.value;
    const box = document.getElementById('walletFkMethods');
    if (box) box.hidden = selected !== 'freekassa';
    updateFormLock();
  }
  async function api(path, body, passive=false) {
    const response = await fetch('/api/wallet' + path, { method: body === undefined ? 'GET' : 'POST', headers:{Authorization:'Bearer ' + localStorage.getItem('pulsarx_token'), ...(body === undefined ? {} : {'Content-Type':'application/json'})}, ...(body === undefined ? {} : {body:JSON.stringify(body)}) });
    const data = await response.json();
    if (response.status === 401) { document.getElementById('pxWalletPaymentNotice')?.remove(); failedAuthToken=localStorage.getItem('pulsarx_token'); if(!passive)location.href='/login/'; throw new Error(tr('error')); }
    if (!response.ok) {
      const detail = data.detail;
      const message = detail?.code === 'checkout_uncertain' ? tr('uncertain') : detail?.code === 'insufficient_balance' ? tr('short') : detail?.code === 'active_topup' ? tr('active') :
        response.status === 503 ? tr(path.endsWith('/check') ? 'checkingError' : 'checkoutError') :
        path.endsWith('/cancel') && response.status === 409 ? tr('closeError') : typeof detail === 'string' ? detail : tr('error');
      const error = new Error(message); error.code = detail?.code; throw error;
    }
    return data;
  }
  function intent(payload) {
    const user = JSON.parse(localStorage.getItem('pulsarx_user') || '{}');
    const name = 'px-wallet-intent:' + (user.id || user.email || '') + ':' + JSON.stringify(payload);
    let key = sessionStorage.getItem(name);
    if (!key) { key = crypto.randomUUID(); sessionStorage.setItem(name, key); }
    return {name, key};
  }
  async function createOrder(payload, expected) {
    const identity = intent(payload);
    const result = await api('/orders', {...payload, expected_amount_cents:expected, request_key:identity.key});
    sessionStorage.removeItem(identity.name);
    await refreshSummary().catch(() => {});
    return result;
  }
  async function refreshSummary() {
    const token=localStorage.getItem('pulsarx_token');
    if (!token||token===failedAuthToken) { cached=null;document.getElementById('pxWalletPaymentNotice')?.remove();return null; }
    cached = await api('',undefined,true);
    if (cached.server_time) clockOffset = new Date(cached.server_time).getTime() - Date.now();
    const badge = document.getElementById('walletNavValue');
    if (badge) badge.textContent = money(cached.balance_cents);
    const deploy = document.getElementById('walletDeployBalance');
    if (deploy) deploy.textContent = tr('balance') + ': ' + money(cached.balance_cents);
    updateReminder(cached.pending_topup);
    updateFormLock();
    return cached;
  }
  function countdown(row) {
    if (row.payment_in_progress) return `<p class="wallet-note">${esc(tr('confirmingNote'))}</p>`;
    if (!active(row) || !row.expires_at) return '';
    return `<div class="wallet-countdown"><span>${esc(tr('expires'))}</span><time data-wallet-expiry="${esc(row.expires_at)}" role="timer" aria-live="off">--:--</time></div><div class="wallet-row-sub">${esc(tr('until'))}: ${esc(date(row.expires_at))}</div>`;
  }
  function invoiceActions(row) {
    const id = esc(row.id);
    return `<div class="wallet-invoice-actions">${row.can_resume?`<button type="button" class="btn wallet-resume" data-wallet-action="checkout" data-invoice="${id}" data-pay-until="${esc(row.expires_at)}">${esc(tr('resume'))} ↗</button>`:''}${active(row)?`<button type="button" class="wallet-check" data-wallet-action="check" data-invoice="${id}" data-check="${id}">${esc(tr('check'))}</button>`:''}${row.can_cancel?`<button type="button" class="wallet-check wallet-close-invoice" data-wallet-action="cancel" data-invoice="${id}">${esc(tr('closeInvoice'))}</button>`:''}</div>`;
  }
  function invoice(row, featured=false) {
    const title = `${providerName(row.provider)} · ${money(row.amount_cents)}`;
    return `<${featured?'section':'div'} class="${featured?'wallet-active-invoice':'wallet-row wallet-invoice-row'}"><div class="wallet-invoice-main">${featured?`<div class="wallet-eyebrow">${esc(tr(row.payment_in_progress?'confirming':'reminder'))}</div>`:''}<div class="wallet-row-title">${esc(title)}</div><div class="wallet-row-sub">${esc(date(row.created_at))} · #${esc(invoiceNumber(row.id))}</div>${countdown(row)}${invoiceActions(row)}${row.awaiting_notification?`<div class="wallet-row-sub">${esc(tr('awaiting'))}</div>`:''}${featured?`<p class="wallet-note">${esc(tr('timerNote'))}</p>`:''}</div><span class="wallet-state ${row.status==='credited'?'good':''}">${esc(tr(row.payment_in_progress?'confirming':row.status))}</span></${featured?'section':'div'}>`;
  }
  function updateReminder(row) {
    let holder = document.getElementById('pxWalletPaymentNotice');
    if (!active(row)) { holder?.remove(); return; }
    if (!holder) { holder=document.createElement('aside'); holder.id='pxWalletPaymentNotice'; holder.setAttribute('role','region'); document.body.appendChild(holder); }
    const collapsed = collapsedId === String(row.id);
    holder.className='wallet-payment-notice'+(collapsed?' is-collapsed':'');
    holder.setAttribute('aria-label',tr(row.payment_in_progress?'confirming':'reminder'));
    holder.innerHTML=`<div class="wallet-notice-head"><span class="wallet-notice-dot" aria-hidden="true"></span><strong>${esc(tr(row.payment_in_progress?'confirming':'reminder'))}</strong><button type="button" class="wallet-notice-toggle" data-wallet-toggle="${esc(row.id)}" aria-expanded="${!collapsed}" aria-label="${esc(tr(collapsed?'expand':'minimize'))}">${collapsed?'+':'−'}</button></div><div class="wallet-notice-details"><div class="wallet-notice-value">${money(row.amount_cents)} <span>${esc(providerName(row.provider))} · #${esc(invoiceNumber(row.id))}</span></div>${countdown(row)}${invoiceActions(row)}<a class="wallet-details-link" href="/dashboard/?tab=wallet">${esc(tr('details'))}${cached?.pending_count>1?' · '+cached.pending_count+' '+esc(tr('totalOpen')):''} →</a><div class="wallet-error" data-notice-error role="alert"></div></div>`;
    tickCountdowns();
  }
  function tickCountdowns() {
    const now = Date.now() + clockOffset;
    document.querySelectorAll('[data-wallet-expiry]').forEach(timer=>{
      const remaining=Math.max(0,Math.ceil((new Date(timer.dataset.walletExpiry).getTime()-now)/1000));
      if(!Number.isFinite(remaining))return;
      const hours=Math.floor(remaining/3600), minutes=Math.floor(remaining%3600/60), seconds=remaining%60;
      timer.textContent=remaining?(hours?String(hours).padStart(2,'0')+':':'')+String(minutes).padStart(2,'0')+':'+String(seconds).padStart(2,'0'):tr('timerDone');
      timer.classList.toggle('is-urgent',remaining<300);
    });
    document.querySelectorAll('[data-pay-until]').forEach(button=>{
      if(new Date(button.dataset.payUntil).getTime()<=now){button.disabled=true;button.textContent=tr('expired');}
    });
  }
  function updateFormLock() {
    const form=document.getElementById('walletTopupForm'); if(!form||!cached)return;
    const locked=Boolean(cached.pending_topup)||!cached.topup_available||cached.frozen;
    form.querySelectorAll('input,button,select').forEach(el=>{el.disabled=locked||submitting;});
    const selected=form.querySelector('input[name="walletProvider"]:checked')?.value;
    if(selected==='freekassa'&&!form.querySelector('#walletFkMethod option'))form.querySelector('[type="submit"]').disabled=true;
    const message=document.getElementById('walletActiveWarning');
    if(message){message.hidden=!cached.pending_topup;message.textContent=tr('active');}
  }
  function renderHistory(items, append=false) {
    const holder = document.getElementById('walletHistory'); if (!holder) return;
    currentHistory = append ? currentHistory.concat(items) : items;
    holder.innerHTML = currentHistory.length ? currentHistory.map(row => `<div class="wallet-row"><div><div class="wallet-row-title">${esc(tr(row.kind))}</div><div class="wallet-row-sub">${esc(row.kind === 'topup' ? (row.label?.startsWith('FreeKassa')?'KASSA':row.label?.startsWith('Plisio')?'Plisio':'AnyPay') : row.label)} · ${esc(date(row.created_at))}</div></div><div class="wallet-row-value ${row.amount_cents>0?'positive':''}">${row.amount_cents>0?'+':'−'}${money(Math.abs(row.amount_cents))}</div></div>`).join('') : `<div class="wallet-empty">${esc(tr('empty'))}</div>`;
  }
  async function load() {
    if (loading) return; loading = true;
    const holder = document.getElementById('walletContent'); if (!holder) { loading = false; return; }
    try {
      const [balance, history, topups, orders] = await Promise.all([refreshSummary(), api('/history'), api('/topups'), api('/orders')]);
      if(!balance)return;
      hasPending=topups.some(active)||orders.some(r=>r.status==='queued'||r.status==='working'); offset=history.items.length;
      const providers=balance.providers||['anypay'];
      const methods=providers;
      let fkMethods=[];
      if(providers.includes('freekassa')){
        try { const data=await api('/freekassa/methods'); fkMethods=Array.isArray(data.methods)?data.methods.filter(x=>Number.isInteger(x.id)&&typeof x.name==='string'):[]; }
        catch(error) { if(failedAuthToken)throw error; }
      }
      let fkSelected=Number(sessionStorage.getItem('px-wallet-fk-method')||44);
      if(!fkMethods.some(x=>x.id===fkSelected))fkSelected=fkMethods[0]?.id;
      const fkControl=providers.includes('freekassa')?`<div id="walletFkMethods"><label class="wallet-label" for="walletFkMethod">${esc(tr('fkMethod'))}</label><select id="walletFkMethod" class="wallet-select">${fkMethods.map(x=>`<option value="${x.id}" ${x.id===fkSelected?'selected':''}>${esc(x.name)}</option>`).join('')}</select>${fkMethods.length?'':`<p class="wallet-warning">${esc(tr('fkUnavailable'))}</p>`}</div>`:'';
      if(!methods.includes(selectedMethod))selectedMethod=methods[0]||null;
      const payment=balance.pending_topup;
      holder.innerHTML = `<div class="wallet-shell">${balance.frozen?`<div class="wallet-warning">${esc(tr('frozen'))}</div>`:''}<div id="walletReturnNotice"></div><section class="wallet-hero"><div class="wallet-eyebrow">${esc(tr('available'))} · USD</div><div class="wallet-amount">${money(balance.balance_cents)}</div><div class="wallet-muted">${esc(tr('sub'))}</div></section>${payment?invoice(payment,true):''}<div class="wallet-grid"><section class="wallet-card"><h2>${esc(tr('topup'))}</h2><p id="walletActiveWarning" class="wallet-warning" hidden>${esc(tr('active'))}</p><form id="walletTopupForm"><fieldset class="wallet-methods"><legend class="wallet-label">${esc(tr('method'))}</legend>${methods.map(name=>`<label class="wallet-method"><input type="radio" name="walletProvider" value="${esc(name)}" ${name===selectedMethod?'checked':''} ${name==='freekassa'?'aria-controls="walletFkMethods"':''}><span><strong>${esc(providerName(name))}</strong><small>${esc(tr(name==='freekassa'?'freekassaHint':name==='plisio'?'plisioHint':'anypayHint'))}</small></span></label>`).join('')}</fieldset>${fkControl}<label class="wallet-label" for="walletAmount">${esc(tr('amount'))} · ${money(balance.min_topup_cents)}–${money(balance.max_topup_cents)}</label><div class="wallet-picks">${[300,500,1000,2000].filter(v=>v>=balance.min_topup_cents&&v<=balance.max_topup_cents).map(v=>`<button type="button" data-cents="${v}">${money(v)}</button>`).join('')}</div><div class="wallet-input-wrap"><span>$</span><input id="walletAmount" inputmode="decimal" autocomplete="off" value="5.00" maxlength="9" required aria-describedby="walletTopupNote"><span>USD</span></div><button class="btn wallet-topup-btn" type="submit">${esc(tr('go'))} ↗</button><p class="wallet-note" id="walletTopupNote">${esc(tr('note'))}</p><p class="wallet-note">${esc(balance.topup_available?tr('deadline'):tr('unavailable'))}</p><div class="wallet-error" id="walletTopupError" role="alert"></div></form></section><section class="wallet-card"><div class="wallet-toolbar"><h2>${esc(tr('history'))}</h2><button class="wallet-check" id="walletRefresh">${esc(tr('refresh'))}</button></div><div id="walletHistory"></div><button class="wallet-check wallet-more" id="walletMore" ${history.has_more?'':'hidden'}>${esc(tr('more'))}</button></section></div><section class="wallet-card"><h2>${esc(tr('recent'))}</h2><div id="walletTopups">${topups.length?topups.map(row=>invoice(row)).join(''):`<div class="wallet-empty">${esc(tr('empty'))}</div>`}</div>${orders.length?`<div class="wallet-operations"><h2>${esc(tr('orders'))}</h2>${orders.map(row=>`<div class="wallet-row"><div><div class="wallet-row-title">${esc(tr(row.kind))} · ${esc(row.plan)} · ${money(row.amount_cents)}</div><div class="wallet-row-sub">${esc(date(row.created_at))}</div></div><span class="wallet-state ${row.status==='completed'||row.status==='refunded'?'good':''}">${esc(tr(row.status))}</span></div>`).join('')}</div>`:''}<div class="wallet-error" id="walletCheckError" role="alert"></div></section></div>`;
      renderHistory(history.items); updateFormLock(); tickCountdowns();
      document.getElementById('walletTopupForm').addEventListener('submit', submitTopup);
      holder.querySelectorAll('input[name="walletProvider"]').forEach(input=>input.addEventListener('change',()=>{selectedMethod=input.value;sessionStorage.setItem('px-wallet-topup-method',selectedMethod);updatePaymentMethods();}));
      document.getElementById('walletFkMethod')?.addEventListener('change',e=>sessionStorage.setItem('px-wallet-fk-method',e.target.value));
      updatePaymentMethods();
      holder.querySelectorAll('[data-cents]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('walletAmount').value=(Number(b.dataset.cents)/100).toFixed(2);holder.querySelectorAll('[data-cents]').forEach(x=>x.classList.toggle('active',x===b));}));
      document.getElementById('walletRefresh').addEventListener('click',()=>load());
      document.getElementById('walletMore').addEventListener('click',async e=>{const button=e.currentTarget;button.disabled=true;try{const data=await api('/history?offset='+offset);offset+=data.items.length;renderHistory(data.items,true);document.getElementById('walletMore').hidden=!data.has_more;}catch(error){document.getElementById('walletCheckError').textContent=error.message;}finally{button.disabled=false;}});
      if (returnState) {
        const returned=topups.find(r=>String(r.id)===returnId), n=document.getElementById('walletReturnNotice');
        n.className=returned?.status==='credited'||returnState==='success'?'wallet-success':'wallet-warning';
        n.textContent=returned?.status==='credited'?tr('credited'):tr(returnState==='success'?'notice':'failed');
      }
    } catch(error) {
      if (!holder.querySelector('.wallet-shell')) holder.innerHTML='<div class="wallet-error" role="alert">'+esc(error.message)+'</div>';
      else {const errorBox=document.getElementById('walletCheckError');if(errorBox)errorBox.textContent=error.message;}
    } finally { loading=false; }
  }
  function goCheckout(row) {
    const url=new URL(row.checkout_url);
    const valid=url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&!url.hash&&
      (row.provider==='plisio'?url.hostname==='plisio.net'&&/^\/invoice\/[a-f0-9]{24}$/.test(url.pathname)&&!url.search:
        row.provider==='freekassa'?['pay.freekassa.net','pay.fk.money'].includes(url.hostname)&&url.pathname.startsWith('/')&&url.href.length<=4096:row.provider==='anypay'&&url.hostname==='anypay.io'&&url.pathname==='/merchant');
    if(!valid)throw new Error(tr('error'));
    location.assign(url.href);
  }
  async function submitTopup(event) {
    event.preventDefault(); if(submitting)return;
    if(cached?.pending_topup){updateReminder(cached.pending_topup);return;}
    const error=document.getElementById('walletTopupError'); error.textContent='';
    const raw=document.getElementById('walletAmount').value.trim().replace(',','.');
    if (!/^\d{1,6}(?:\.\d{1,2})?$/.test(raw)) {error.textContent=tr('range');return;}
    const [whole, fraction='']=raw.split('.'), amount=Number(whole)*100+Number(fraction.padEnd(2,'0'));
    if (!cached||!cached.topup_available||amount<cached.min_topup_cents||amount>cached.max_topup_cents) {error.textContent=tr('range');return;}
    const method=document.querySelector('input[name="walletProvider"]:checked')?.value||cached.providers?.[0]||'anypay';
    const provider=method;
    const provider_method=provider==='freekassa'?Number(document.getElementById('walletFkMethod')?.value):undefined;
    if(provider==='freekassa'&&(!Number.isInteger(provider_method)||provider_method<=0)){error.textContent=tr('fkUnavailable');return;}
    submitting=true; updateFormLock(); const identity=intent({topup:amount,provider,provider_method});
    try {
      const row=await api('/topups',{amount_cents:amount,provider,provider_method,request_key:identity.key});
      sessionStorage.removeItem(identity.name);
      if(row.checkout_url)goCheckout(row);else await load();
    } catch(e) {await refreshSummary().catch(()=>{});if(cached?.pending_topup)await load();document.getElementById('walletTopupError').textContent=e.message;}
    finally{submitting=false;updateFormLock();}
  }
  async function confirmClose() {
    if(document.querySelector('dialog.wallet-dialog[open]'))return false;
    const dialog=document.createElement('dialog'); dialog.className='wallet-dialog';dialog.setAttribute('aria-labelledby','pxWalletCloseTitle');
    dialog.innerHTML=`<h2 id="pxWalletCloseTitle">${esc(tr('closeTitle'))}</h2><p class="wallet-muted">${esc(tr('closeNote'))}</p><div class="wallet-dialog-actions"><button class="btn btn-ghost" data-close-back>${esc(tr('back'))}</button><button class="btn" data-close-confirm>${esc(tr('closeInvoice'))}</button></div>`;
    document.body.appendChild(dialog); dialog.showModal();
    return new Promise(resolve=>{let accepted=false;dialog.querySelector('[data-close-back]').addEventListener('click',()=>dialog.close());dialog.querySelector('[data-close-confirm]').addEventListener('click',()=>{accepted=true;dialog.close();});dialog.addEventListener('close',()=>{dialog.remove();resolve(accepted);},{once:true});});
  }
  document.addEventListener('click',async event=>{
    const toggle=event.target.closest?.('[data-wallet-toggle]');
    if(toggle){collapsedId=collapsedId===toggle.dataset.walletToggle?'':toggle.dataset.walletToggle;sessionStorage.setItem('px-wallet-reminder-collapsed',collapsedId);updateReminder(cached?.pending_topup);return;}
    const button=event.target.closest?.('[data-wallet-action]');if(!button||button.disabled)return;
    const id=button.dataset.invoice, action=button.dataset.walletAction;
    if(busyActions.has(id))return;busyActions.add(id);button.disabled=true;
    try {
      if(action==='cancel'&&!await confirmClose())return;
      const result=await api('/topups/'+encodeURIComponent(id)+'/'+action,{});
      if(action==='checkout')goCheckout(result);else{
        if(action==='cancel'){
          const identity=intent({topup:result.amount_cents,provider:result.provider,provider_method:result.provider==='freekassa'?result.provider_method:undefined});
          sessionStorage.removeItem(identity.name);
        }
        await refreshSummary();await load();
      }
    } catch(error){
      await refreshSummary().catch(()=>{});
      document.querySelectorAll('#walletCheckError,[data-notice-error]').forEach(box=>{box.textContent=error.message;});
    } finally {busyActions.delete(id);button.disabled=false;tickCountdowns();}
  });
  async function confirmOrder(payload) {
    if(document.querySelector('dialog.wallet-dialog[open]'))return null;
    const quote=await api('/quote',{...payload,request_key:crypto.randomUUID()});
    if(document.querySelector('dialog.wallet-dialog[open]'))return null;
    const dialog=document.createElement('dialog');dialog.className='wallet-dialog';dialog.setAttribute('aria-labelledby','pxWalletConfirmTitle');
    dialog.innerHTML=`<h2 id="pxWalletConfirmTitle">${esc(tr('confirm'))}</h2><div class="wallet-muted">${esc(tr(payload.kind))}</div><div class="wallet-amount">${money(quote.amount_cents)}</div><p class="wallet-muted">${esc(tr('balance'))}: ${money(quote.balance_cents)}</p><p class="wallet-muted">${esc(tr(quote.shortfall_cents?'short':'cost'))}</p><div class="wallet-error" role="alert"></div><div class="wallet-dialog-actions"><button class="btn btn-ghost" data-cancel>${esc(tr('cancel'))}</button>${quote.shortfall_cents?`<a class="btn" href="/dashboard/?tab=wallet">${esc(tr('add'))}</a>`:`<button class="btn" data-confirm>${esc(tr('pay'))}</button>`}</div>`;
    document.body.appendChild(dialog);dialog.showModal();
    return new Promise(resolve=>{
      let busy=false;
      dialog.querySelector('[data-cancel]').addEventListener('click',()=>dialog.close());
      dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
      dialog.addEventListener('close',()=>{dialog.remove();resolve(null);},{once:true});
      dialog.querySelector('[data-confirm]')?.addEventListener('click',async e=>{
        if(busy)return;busy=true;e.currentTarget.disabled=true;dialog.querySelector('[data-cancel]').disabled=true;
        try {const row=await createOrder(payload,quote.amount_cents);resolve(row);dialog.close();if(typeof showToast==='function')showToast(tr('success'),tr('processing'));if(typeof loadServers==='function')loadServers();}
        catch(error){dialog.querySelector('[role="alert"]').textContent=error.message;e.target.disabled=false;dialog.querySelector('[data-cancel]').disabled=false;busy=false;}
      });
    });
  }
  function open() {
    document.querySelector('.nav-item[data-page="wallet"]')?.click(); load();
  }
  const query=new URLSearchParams(location.search), returnState=query.get('wallet_payment'), returnId=query.get('topup');
  window.PxWallet={api, createOrder, confirmOrder, load, open, refreshSummary, tr, money};
  document.querySelector('.nav-item[data-page="wallet"]')?.addEventListener('click',load);
  function init(){
    if(!localStorage.getItem('pulsarx_token'))return;
    refreshSummary().catch(()=>{});
    if(document.getElementById('walletContent')&&(query.get('tab')==='wallet'||returnState))open();
    if(returnState){const clean=new URL(location.href);clean.searchParams.delete('wallet_payment');clean.searchParams.delete('topup');history.replaceState(null,'',clean.pathname+clean.search+clean.hash);}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  setInterval(tickCountdowns,1000);
  setInterval(()=>{
    if(!localStorage.getItem('pulsarx_token')){document.getElementById('pxWalletPaymentNotice')?.remove();return;}
    if(document.visibilityState==='hidden')return;
    if(hasPending&&document.getElementById('page-wallet')?.classList.contains('show')&&!document.activeElement?.closest('#walletTopupForm')&&!document.querySelector('dialog.wallet-dialog[open]'))load();else refreshSummary().catch(()=>{});
  },15000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='hidden')refreshSummary().catch(()=>{});});
  window.addEventListener('focus',()=>refreshSummary().catch(()=>{}));
  window.addEventListener('storage',event=>{if(event.key==='pulsarx_token')refreshSummary().catch(()=>{});});
})();
