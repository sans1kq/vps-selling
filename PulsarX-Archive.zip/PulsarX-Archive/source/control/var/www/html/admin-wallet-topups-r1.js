(function(){
  'use strict';
  const billing=document.getElementById('tab-billing');
  if(!billing||document.getElementById('adminWalletTopups'))return;
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money=value=>'$'+(Number(value)/100).toFixed(2);
  const panel=document.createElement('section');panel.id='adminWalletTopups';panel.className='panel awt-panel';
  panel.innerHTML=`<div class="panel-head"><div><h3>Wallet top-ups</h3><p class="awt-note">Confirmed credits to customer balances, in USD. Unpaid invoices are excluded.</p></div><button class="btn btn-small" id="awtRefresh" type="button">Refresh</button></div>
    <form id="awtFilters" class="awt-filters"><label>User<input class="search-input" name="q" maxlength="160" placeholder="Name, email or user ID"></label><label>From USD<input class="search-input" name="min" inputmode="decimal" placeholder="Any" maxlength="12"></label><label>To USD<input class="search-input" name="max" inputmode="decimal" placeholder="Any" maxlength="12"></label><label>Provider<select name="provider"><option value="">All providers</option><option value="freekassa">KASSA</option><option value="plisio">Plisio</option><option value="anypay">AnyPay (history)</option></select></label><button class="btn btn-small" type="submit">Apply filters</button></form>
    <div class="awt-summary" id="awtSummary" role="status">Open Billing to load wallet credits.</div><div class="awt-error" id="awtError" role="alert"></div>
    <div class="table-scroll"><table><thead><tr><th>User</th><th>Credited USD</th><th>Provider</th><th>Invoice</th><th>Credited at · UTC</th></tr></thead><tbody id="awtRows"><tr><td colspan="5" class="loading">No data loaded</td></tr></tbody></table></div>
    <div class="awt-pagination"><button class="btn btn-small" type="button" id="awtPrev" disabled>Previous</button><span id="awtPage"></span><button class="btn btn-small" type="button" id="awtNext" disabled>Next</button></div>`;
  billing.insertBefore(panel,billing.firstChild);
  const byId=id=>document.getElementById(id),form=byId('awtFilters');
  let offset=0,filters=new URLSearchParams(),loaded=false,busy=false,hasMore=false;
  const amount=value=>{
    const raw=value.trim().replace(',','.');if(!raw)return null;
    if(!/^\d{1,8}(?:\.\d{1,2})?$/.test(raw))throw new Error('Enter an amount in USD with up to two decimal places.');
    const [whole,fraction='']=raw.split('.'),cents=Number(whole)*100+Number(fraction.padEnd(2,'0'));
    if(cents>1000000000)throw new Error('The amount filter is too large.');return cents;
  };
  function setBusy(value){
    busy=value;panel.setAttribute('aria-busy',String(value));
    form.querySelector('[type="submit"]').disabled=value;byId('awtRefresh').disabled=value;
    byId('awtPrev').disabled=value||offset===0;byId('awtNext').disabled=value||!hasMore;
  }
  async function load(){
    if(busy)return;
    const token=localStorage.getItem('pulsarx_admin_token');if(!token)return;
    setBusy(true);byId('awtError').textContent='';
    const query=new URLSearchParams(filters);query.set('offset',String(offset));query.set('limit','30');
    byId('awtSummary').textContent='Loading wallet credits…';
    try{
      const response=await fetch('/api/admin/wallet-topups?'+query,{headers:{Authorization:'Bearer '+token},cache:'no-store'});
      if(response.status===401||response.status===403){location.href='/adminlogin/';throw new Error('Admin session required.');}
      if(!response.ok)throw new Error('Could not load wallet credits. Try Refresh.');
      const data=await response.json();
      if(!Array.isArray(data.items)||data.currency!=='USD')throw new Error('Unexpected report response.');
      if(token!==localStorage.getItem('pulsarx_admin_token'))return;
      loaded=true;hasMore=data.has_more===true;
      byId('awtSummary').textContent=`${data.total} top-ups · ${data.user_count} users · ${money(data.total_cents)} credited (matching filters)`;
      byId('awtRows').innerHTML=data.items.length?data.items.map(row=>{
        const provider={freekassa:'KASSA',plisio:'Plisio',anypay:'AnyPay'}[row.provider]||row.provider;
        const when=new Date(row.credited_at).toLocaleString('en-GB',{timeZone:'UTC',dateStyle:'medium',timeStyle:'short'});
        return `<tr><td><strong>${esc(row.name||row.email)}</strong><span class="awt-detail">${esc(row.email)}</span><span class="awt-user-id">${esc(row.user_id)}</span></td><td class="awt-amount">+${esc(money(row.amount_cents))}${row.needs_review?'<span class="awt-detail awt-review">Account review</span>':''}</td><td>${esc(provider)}${row.method_id?`<span class="awt-detail">Method ${esc(row.method_id)}</span>`:''}</td><td title="Internal ID: ${esc(row.topup_id)}">#${esc(row.invoice_number)}</td><td>${esc(when)}</td></tr>`;
      }).join(''):'<tr><td colspan="5" class="loading">No credited top-ups match these filters.</td></tr>';
      byId('awtPage').textContent=data.total?`${Math.min(offset+1,data.total)}–${offset+data.items.length} of ${data.total}`:'0 results';
    }catch(error){
      hasMore=false;byId('awtSummary').textContent='Report unavailable';byId('awtRows').innerHTML='<tr><td colspan="5" class="loading">Could not load credits</td></tr>';byId('awtPage').textContent='';byId('awtError').textContent=error.message;
    }finally{setBusy(false);}
  }
  form.addEventListener('submit',event=>{
    event.preventDefault();if(busy)return;
    try{
      const min=amount(form.querySelector('[name="min"]').value),max=amount(form.querySelector('[name="max"]').value);
      if(min!==null&&max!==null&&min>max)throw new Error('From USD must not exceed To USD.');
      const next=new URLSearchParams(),q=form.querySelector('[name="q"]').value.trim(),provider=form.querySelector('[name="provider"]').value;
      if(q)next.set('q',q);if(provider)next.set('provider',provider);if(min!==null)next.set('min_cents',String(min));if(max!==null)next.set('max_cents',String(max));
      filters=next;offset=0;load();
    }catch(error){byId('awtError').textContent=error.message;}
  });
  byId('awtRefresh').addEventListener('click',load);
  byId('awtPrev').addEventListener('click',()=>{if(!busy&&offset>0){offset=Math.max(0,offset-30);load();}});
  byId('awtNext').addEventListener('click',()=>{if(!busy&&hasMore){offset+=30;load();}});
  document.querySelector('.tab-item[data-tab="billing"]')?.addEventListener('click',()=>{if(!loaded)load();});
  if(billing.classList.contains('active'))load();
})();
