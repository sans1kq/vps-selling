/* PulsarX v4 / Orbit — presentation only. Existing billing and server actions stay authoritative. */
(function () {
  'use strict';
  const VERSION = '4.0.0';
  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));
  const svg = (path, extra) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true" ' + (extra || '') + '>' + path + '</svg>';
  const searchIcon = svg('<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>');
  const arrowIcon = svg('<path d="M5 12h14m-6-6 6 6-6 6"/>');
  const copy = {
    en: {
      eyebrow: 'LINUX VPS / BUILT FOR WHAT’S NEXT', heading: 'Big ideas.<em>Start small.</em>',
      subtitle: 'Your own Linux server. Full control, live metrics, and room to build. From $3 a month.',
      core: 'PULSAR CORE', signal: 'A LITTLE SPACE. A LOT OF POSSIBILITY.',
      pulse: 'Send a pulse', pause: 'Pause animation', play: 'Play animation', coreHint: 'Move to explore · tap to pulse',
      storyLabel: 'YOUR OWN CONTROL CENTRE', storyTitle: 'A small server.<br>A world of control.',
      storySub: 'From your first connection to your next deployment, the controls you need are right where you need them.',
      preview: 'INTERACTIVE PREVIEW', previewHint: 'Try the power controls or open SSH. This is a demo.',
      search: 'Search or jump to…', searchEmpty: 'No matching pages. Try “server” or “pricing”.',
      searchLabel: 'Quick navigation', close: 'Close', navigate: 'navigate', open: 'open', escape: 'close',
      deploy: 'Deploy a server', dashboard: 'Open dashboard', pricing: 'Explore pricing', faq: 'Questions & answers',
      product: 'Explore the platform', login: 'Sign in', menu: 'Open navigation',
      footerNote: 'Small by design. Built for your next big idea.',
      activeInstances: 'Active instances', shortcut: 'Quick navigation', serverSearch: 'Find an instance…', allStates: 'All states', running: 'Running', suspended: 'Stopped', pending: 'Pending', provisioning: 'Creating', failed: 'Failed', pending_approval: 'Awaiting payment',
      pricingTitle: 'Your space.<br>Your pace.', featuresTitle: 'Built for the way<br>you actually work.', useTitle: 'A home for what<br>you’re building.', faqTitle: 'A few things<br>before you launch.',
      ctaTitle: 'Your next big idea<br>deserves its own space.',
      ctaSub: 'Pick a server. Choose your Linux. Make it yours.',
    },
    ru: {
      eyebrow: 'LINUX VPS / ДЛЯ ТВОИХ НОВЫХ ИДЕЙ', heading: 'Большие идеи.<em>Начни с малого.</em>',
      subtitle: 'Твой Linux-сервер. Полный контроль, живые метрики и место для твоих проектов. От 3 $ в месяц.',
      core: 'ЯДРО ПУЛЬСАРА', signal: 'НЕМНОГО МЕСТА. БОЛЬШИЕ ВОЗМОЖНОСТИ.',
      pulse: 'Отправить импульс', pause: 'Остановить анимацию', play: 'Включить анимацию', coreHint: 'Двигай курсор · нажми для импульса',
      storyLabel: 'ТВОЙ ЦЕНТР УПРАВЛЕНИЯ', storyTitle: 'Маленький сервер.<br>Большой контроль.',
      storySub: 'От первого подключения до следующего запуска — нужные инструменты всегда под рукой.',
      preview: 'ИНТЕРАКТИВНОЕ ДЕМО', previewHint: 'Попробуй управление питанием или открой SSH. Это демонстрация.',
      search: 'Найти или перейти…', searchEmpty: 'Ничего не найдено. Попробуй «сервер» или «тарифы».',
      searchLabel: 'Быстрая навигация', close: 'Закрыть', navigate: 'выбрать', open: 'перейти', escape: 'закрыть',
      deploy: 'Создать сервер', dashboard: 'Открыть панель', pricing: 'Посмотреть тарифы', faq: 'Вопросы и ответы',
      product: 'Возможности платформы', login: 'Войти', menu: 'Открыть меню',
      footerNote: 'Начни с малого. Создай что-то большое.',
      activeInstances: 'Активные серверы', shortcut: 'Быстрая навигация', serverSearch: 'Найти сервер…', allStates: 'Все состояния', running: 'Работает', suspended: 'Остановлен', pending: 'Ожидает', provisioning: 'Создаётся', failed: 'Ошибка', pending_approval: 'Ожидает оплаты',
      pricingTitle: 'Твоё пространство.<br>Твой темп.', featuresTitle: 'Всё для того,<br>как ты работаешь.', useTitle: 'Место для того,<br>что ты создаёшь.', faqTitle: 'Несколько ответов<br>перед стартом.',
      ctaTitle: 'Большой идее<br>нужно своё пространство.',
      ctaSub: 'Выбери сервер. Выбери Linux. Создай своё.',
    },
    ro: {
      eyebrow: 'LINUX VPS / PENTRU IDEILE TALE VIITOARE', heading: 'Idei mari.<em>Începe simplu.</em>',
      subtitle: 'Propriul tău server Linux. Control deplin, resurse live și loc pentru proiectele tale. De la 3 $ pe lună.',
      core: 'NUCLEU PULSAR', signal: 'PUȚIN SPAȚIU. MULTE POSIBILITĂȚI.',
      pulse: 'Trimite un impuls', pause: 'Oprește animația', play: 'Pornește animația', coreHint: 'Mișcă cursorul · apasă pentru un impuls',
      storyLabel: 'PROPRIUL CENTRU DE CONTROL', storyTitle: 'Un server mic.<br>O lume sub control.',
      storySub: 'De la prima conexiune la următoarea lansare, comenzile necesare sunt exact unde ai nevoie de ele.',
      preview: 'DEMONSTRAȚIE INTERACTIVĂ', previewHint: 'Încearcă butoanele de control sau deschide SSH. Este o demonstrație.',
      search: 'Caută sau navighează…', searchEmpty: 'Nicio pagină găsită. Încearcă „server” sau „prețuri”.',
      searchLabel: 'Navigare rapidă', close: 'Închide', navigate: 'selectează', open: 'deschide', escape: 'închide',
      deploy: 'Creează un server', dashboard: 'Deschide panoul', pricing: 'Vezi prețurile', faq: 'Întrebări și răspunsuri',
      product: 'Explorează platforma', login: 'Autentificare', menu: 'Deschide meniul',
      footerNote: 'Mic prin design. Pregătit pentru idei mari.',
      activeInstances: 'Instanțe active', shortcut: 'Navigare rapidă', serverSearch: 'Caută o instanță…', allStates: 'Toate stările', running: 'Pornit', suspended: 'Oprit', pending: 'În așteptare', provisioning: 'Se creează', failed: 'Eroare', pending_approval: 'Așteaptă plata',
      pricingTitle: 'Spațiul tău.<br>Ritmul tău.', featuresTitle: 'Creat pentru modul<br>în care lucrezi.', useTitle: 'Un loc pentru ceea<br>ce construiești.', faqTitle: 'Câteva răspunsuri<br>înainte de lansare.',
      ctaTitle: 'Următoarea idee mare<br>merită propriul spațiu.',
      ctaSub: 'Alege serverul. Alege Linux. Creează ceva al tău.',
    },
  };
  const language = () => copy[document.documentElement.lang] ? document.documentElement.lang : 'en';
  const t = key => copy[language()][key] || copy.en[key] || key;
  function text(node, key) {
    if (!node) return;
    node.removeAttribute('data-i18n'); node.dataset.pxCopy = key; node.innerHTML = t(key);
  }
  function element(tag, name, html) {
    const node = document.createElement(tag); node.className = name;
    if (html !== undefined) node.innerHTML = html; return node;
  }
  function boot() {
    const body = document.body;
    if (!body || body.dataset.pxV4) return;
    body.dataset.pxV4 = VERSION;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const coarse = window.matchMedia('(pointer: coarse)');
    const lowPower = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 4);
    const compact = coarse.matches || window.matchMedia('(max-width: 760px)').matches || !!lowPower;
    const disposers = [];
    const translations = [];
    const listen = (target, event, handler, options) => {
      target.addEventListener(event, handler, options);
      disposers.push(() => target.removeEventListener(event, handler, options));
    };
    // v3.3's full-page animated grid is replaced by the local hero artwork.
    const oldGrid = document.getElementById('px-grid-bg'); if (oldGrid) oldGrid.remove();
    const landing = body.classList.contains('landing-page');
    const nav = $('.nav-inner');
    let core = null;

    function createHero() {
      const grid = $('.hero-v3-grid'); if (!grid) return;
      text($('.hero-copy h1'), 'heading');
      text($('.hero-v3-sub'), 'subtitle');
      text($('.hero-eyebrow > span:last-child'), 'eyebrow');
      text($('.hero-actions .btn-primary'), 'deploy');
      const primary = $('.hero-actions .btn-primary'); if (primary) primary.insertAdjacentHTML('beforeend', arrowIcon);
      const oldConsole = $('.hero-console', grid), story = $('.product-story');
      if (oldConsole && story) {
        const demo = element('div', 'px-control-demo');
        const caption = element('div', 'px-preview-label', '<i></i><span data-px-copy="preview"></span><span class="px-preview-dots">···</span>');
        demo.appendChild(caption); demo.appendChild(oldConsole);
        const hint = element('p', 'px-preview-hint'); text(hint, 'previewHint'); demo.appendChild(hint);
        const oldTerminal = $('.terminal-card', story); if (oldTerminal) oldTerminal.replaceWith(demo); else story.appendChild(demo);
      }
      text($('.story-copy .section-label'), 'storyLabel');
      text($('.story-copy h2'), 'storyTitle'); text($('.story-copy > p'), 'storySub');
      text($('.final-cta h2'), 'ctaTitle'); text($('.final-cta-copy > p'), 'ctaSub');
      text($('#pricing .section-head-v3 h2'), 'pricingTitle');
      text($('#features .section-head-v3 h2'), 'featuresTitle');
      text($('#use-cases .section-head-v3 h2'), 'useTitle');
      text($('#faq .section-head-v3 h2'), 'faqTitle');
      const countCell = document.getElementById('serverCount')?.closest('.live-cell');
      if (countCell) text($('.live-kicker', countCell), 'activeInstances');
      const stage = element('div', 'px-core-stage');
      stage.innerHTML = '<div class="px-core-topline"><span><i></i><span data-px-copy="core"></span></span><span>PX / 001</span></div>' +
        '<div class="px-core-fallback" aria-hidden="true"><div></div></div>' +
        '<canvas class="px-core-canvas" aria-hidden="true"></canvas>' +
        '<div class="px-core-cross px-core-cross-a" aria-hidden="true">+</div><div class="px-core-cross px-core-cross-b" aria-hidden="true">+</div>' +
        '<div class="px-core-signal" data-px-copy="signal"></div>' +
        '<div class="px-core-controls"><button type="button" class="px-pulse-button"><i></i><span data-px-copy="pulse"></span></button>' +
        '<button type="button" class="px-motion-toggle" aria-pressed="false">' + svg('<path d="M9 5v14M15 5v14"/>') + '</button></div>' +
        '<div class="px-core-hint" data-px-copy="coreHint"></div>';
      grid.appendChild(stage);
      if (window.PulsarXCore) setupCore(stage);
      if (!stage.classList.contains('px-core-ready')) {
        $('.px-core-controls', stage)?.remove(); $('.px-core-hint', stage)?.remove(); stage.classList.add('px-core-static');
      }
      // The existing product explorer is retained; an explicit demo label avoids confusing sample data with real usage.
      const showcase = $('.showcase-shell');
      if (showcase) {
        const title = $('.showcase-url', showcase); if (title) text(title, 'preview');
      }
    }

    function setupCore(stage) {
      let paused = reduced.matches, override = false;
      try { paused = paused || localStorage.getItem('pulsarx_v4_motion') === 'paused'; } catch (_) {}
      let visible = true, raf = 0, last = 0, seconds = 14, pulseAt = -10, nextFrame = 0;
      let pointerX = 0, pointerY = 0, smoothX = 0, smoothY = 0;
      const canvas = $('.px-core-canvas', stage), toggle = $('.px-motion-toggle', stage), pulseButton = $('.px-pulse-button', stage);
      try {
        core = new window.PulsarXCore(canvas, { compact });
      } catch (_) { return; }
      stage.classList.add('px-core-ready');
      function draw() {
        core.render(seconds, { x: smoothX, y: smoothY, pulse: Math.max(0, 1 - (seconds - pulseAt) / 1.4) });
      }
      function resize() {
        const rect = stage.getBoundingClientRect();
        core.resize(rect.width, rect.height, window.devicePixelRatio || 1); draw();
      }
      function animate(now) {
        raf = 0;
        if (paused || !visible || document.hidden) return;
        if (now >= nextFrame) {
          seconds += last ? Math.min((now - last) / 1000, .08) : 0;
          last = now; nextFrame = now + (compact ? 32 : 16);
          smoothX += (pointerX - smoothX) * .065; smoothY += (pointerY - smoothY) * .065;
          draw();
        }
        raf = requestAnimationFrame(animate);
      }
      function sync() {
        if (raf) cancelAnimationFrame(raf); raf = 0; last = 0; nextFrame = 0;
        toggle.setAttribute('aria-pressed', String(paused));
        toggle.setAttribute('aria-label', t(paused ? 'play' : 'pause'));
        toggle.title = t(paused ? 'play' : 'pause');
        toggle.innerHTML = paused ? svg('<path d="m9 5 10 7-10 7z"/>') : svg('<path d="M9 5v14M15 5v14"/>');
        body.classList.toggle('px-motion-paused', paused);
        if (!paused && visible && !document.hidden) raf = requestAnimationFrame(animate); else draw();
      }
      function sendPulse() {
        if (paused) {
          // A reduced-motion visitor gets immediate visual feedback without a looping effect.
          pulseButton.classList.add('px-pulse-sent'); setTimeout(() => pulseButton.classList.remove('px-pulse-sent'), 400); return;
        }
        pulseAt = seconds;
      }
      listen(toggle, 'click', () => {
        paused = !paused; override = !paused;
        try { localStorage.setItem('pulsarx_v4_motion', paused ? 'paused' : 'playing'); } catch (_) {}
        sync();
      });
      listen(pulseButton, 'click', sendPulse);
      listen(stage, 'pointerdown', event => { if (!event.target.closest('button')) sendPulse(); });
      if (!coarse.matches) {
        listen(stage, 'pointermove', event => {
          if (paused) return; const rect = stage.getBoundingClientRect();
          pointerX = ((event.clientX - rect.left) / rect.width - .5) * 2;
          pointerY = ((event.clientY - rect.top) / rect.height - .5) * 2;
        }, { passive: true });
        listen(stage, 'pointerleave', () => { pointerX = 0; pointerY = 0; });
      }
      listen(document, 'visibilitychange', sync);
      if (reduced.addEventListener) listen(reduced, 'change', () => { if (!override) paused = reduced.matches; sync(); });
      if ('ResizeObserver' in window) {
        const observer = new ResizeObserver(resize); observer.observe(stage); disposers.push(() => observer.disconnect());
      } else listen(window, 'resize', resize, { passive: true });
      if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => { visible = entries[0].isIntersecting; sync(); }, { rootMargin: '80px' });
        observer.observe(stage); disposers.push(() => observer.disconnect());
      }
      translations.push(sync); disposers.push(() => { if (raf) cancelAnimationFrame(raf); core.destroy(); });
      resize(); sync();
    }

    function navigation() {
      if (!nav) return;
      const links = $('.nav-links', nav);
      if (links) {
        links.id = links.id || 'px-navigation-links';
        const button = element('button', 'px-menu-button', svg('<path d="M5 8h14M5 16h14"/>'));
        button.type = 'button'; button.setAttribute('aria-expanded', 'false'); button.setAttribute('aria-controls', links.id);
        $('.nav-cta', nav)?.appendChild(button);
        const close = () => { links.classList.remove('px-menu-open'); button.setAttribute('aria-expanded', 'false'); };
        listen(button, 'click', () => { const open = links.classList.toggle('px-menu-open'); button.setAttribute('aria-expanded', String(open)); });
        listen(document, 'click', event => { if (!nav.contains(event.target)) close(); });
        listen(document, 'keydown', event => { if (event.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') { close(); button.focus(); } });
        $$('a', links).forEach(link => listen(link, 'click', close));
        translations.push(() => button.setAttribute('aria-label', t('menu')));
        if (landing && 'IntersectionObserver' in window) {
          const observer = new IntersectionObserver(entries => {
            for (const entry of entries) if (entry.isIntersecting) {
              $$('a', links).forEach(link => {
                const active = link.getAttribute('href') === '#' + entry.target.id;
                link.classList.toggle('px-nav-active', active);
                if (active) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
              });
            }
          }, { rootMargin: '-15% 0px -55% 0px', threshold: 0 });
          $$('main section[id]').forEach(section => observer.observe(section)); disposers.push(() => observer.disconnect());
        }
      }
    }

    function commandPalette() {
      const dialog = element('dialog', 'px-command-palette');
      dialog.id = 'px-command-palette'; dialog.setAttribute('aria-labelledby', 'px-command-title');
      dialog.innerHTML = '<div class="px-command-input-wrap">' + searchIcon + '<label id="px-command-title" for="px-command-input" class="px-sr-only" data-px-copy="searchLabel"></label>' +
        '<input id="px-command-input" autocomplete="off" spellcheck="false" role="combobox" aria-autocomplete="list" aria-controls="px-command-results" aria-expanded="true">' +
        '<button type="button" class="px-command-close">' + svg('<path d="m6 6 12 12M18 6 6 18"/>') + '</button></div>' +
        '<div class="px-command-heading">PULSARX / QUICK ACCESS</div><div id="px-command-results" role="listbox"></div>' +
        '<div class="px-command-footer"><span><kbd>↑ ↓</kbd> <span data-px-copy="navigate"></span></span><span><kbd>↵</kbd> <span data-px-copy="open"></span></span><span><kbd>esc</kbd> <span data-px-copy="escape"></span></span></div>';
      body.appendChild(dialog);
      const input = $('input', dialog), results = $('#px-command-results', dialog), close = $('.px-command-close', dialog);
      const commands = [
        { key: 'deploy', url: '/deploy/', keywords: 'server vps create deploy сервер создать instanta creeaza' },
        { key: 'dashboard', url: '/dashboard/', keywords: 'dashboard panel console servers панель серверы panou' },
        { key: 'pricing', url: '/#pricing', keywords: 'pricing price cost mini plus тарифы цена pret' },
        { key: 'product', url: '/#product', keywords: 'product features linux ssh возможности продукт platforma' },
        { key: 'faq', url: '/#faq', keywords: 'faq help support questions помощь вопросы ajutor' },
        { key: 'login', url: '/login/', keywords: 'login sign in account войти аккаунт autentificare' },
      ];
      let active = 0, anchors = [];
      function highlight() {
        anchors.forEach((anchor, i) => { anchor.classList.toggle('px-command-active', active === i); anchor.setAttribute('aria-selected', String(active === i)); });
        if (anchors[active]) input.setAttribute('aria-activedescendant', anchors[active].id); else input.removeAttribute('aria-activedescendant');
      }
      function render() {
        const query = input.value.trim().toLocaleLowerCase(); results.replaceChildren(); active = 0;
        commands.filter(command => (t(command.key) + ' ' + command.keywords).toLocaleLowerCase().includes(query)).forEach((command, i) => {
          const anchor = element('a', 'px-command-result'); anchor.href = command.url; anchor.id = 'px-command-result-' + i;
          anchor.setAttribute('role', 'option'); anchor.tabIndex = -1;
          const label = element('span', '', t(command.key));
          anchor.appendChild(label); anchor.insertAdjacentHTML('beforeend', arrowIcon);
          anchor.addEventListener('pointermove', () => { active = i; highlight(); }); results.appendChild(anchor);
        });
        anchors = $$('.px-command-result', results);
        if (!anchors.length) results.appendChild(element('p', 'px-command-empty', t('searchEmpty')));
        highlight();
      }
      function open() {
        if (dialog.open || dialog.hasAttribute('open')) return;
        input.value = ''; render();
        if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.setAttribute('open', '');
        input.focus();
      }
      function shut() { if (typeof dialog.close === 'function') dialog.close(); else dialog.removeAttribute('open'); }
      listen(input, 'input', render);
      listen(close, 'click', shut);
      listen(dialog, 'click', event => { if (event.target === dialog) shut(); });
      listen(dialog, 'keydown', event => { if (event.key === 'Escape') { event.preventDefault(); shut(); } });
      listen(input, 'keydown', event => {
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault(); if (anchors.length) active = (active + (event.key === 'ArrowDown' ? 1 : -1) + anchors.length) % anchors.length; highlight();
        } else if (event.key === 'Enter') { event.preventDefault(); anchors[active]?.click(); }
      });
      listen(document, 'keydown', event => {
        if ((event.ctrlKey || event.metaKey) && !event.altKey && event.key.toLowerCase() === 'k') { event.preventDefault(); if (dialog.open || dialog.hasAttribute('open')) shut(); else open(); }
      });
      const button = element('button', 'px-quick-search', searchIcon + '<kbd>⌘ K</kbd>');
      button.type = 'button'; button.setAttribute('aria-haspopup', 'dialog'); button.setAttribute('aria-controls', dialog.id);
      if (!/Mac|iPhone|iPad/.test(navigator.platform || '')) $('kbd', button).textContent = 'Ctrl K';
      const host = nav ? $('.nav-cta', nav) : $('.sidebar-footer') || $('.page-head');
      if (host) host.prepend(button);
      listen(button, 'click', open);
      translations.push(() => {
        input.placeholder = t('search'); close.setAttribute('aria-label', t('close'));
        button.setAttribute('aria-label', t('shortcut')); button.title = t('shortcut'); render();
      });
    }

    function pricingHandoff() {
      const months = [1, 3, 6, 12];
      if (landing) {
        const chips = $$('.period-chip');
        function update(month) {
          if (!months.includes(month)) return;
          $$('.plans-v3 .plan-v3').forEach((card, i) => {
            const link = $('a[href*="/deploy/"]', card);
            if (link) link.setAttribute('href', '/deploy/?plan=' + (i === 0 ? 'mini' : 'plus') + '&months=' + month);
          });
        }
        chips.forEach((chip, i) => {
          const choose = () => update(Number(chip.dataset.months) || months[i]);
          listen(chip, 'click', choose);
          listen(chip, 'keydown', event => { if (event.key === 'Enter' || event.key === ' ') choose(); });
        });
        const chosen = chips.find(chip => chip.classList.contains('active'));
        update(Number(chosen?.dataset.months) || 12);
      } else if (body.classList.contains('deploy-page')) {
        const month = Number(new URLSearchParams(window.location.search).get('months'));
        if (months.includes(month)) $('.period-option[data-months="' + month + '"]')?.click();
      }
    }

    function instanceFilter() {
      const host = document.getElementById('instancesContent');
      if (!host || !body.classList.contains('dashboard-page')) return;
      const bar = element('div', 'px-instance-tools');
      bar.innerHTML = '<label class="px-instance-search">' + searchIcon + '<input type="search" autocomplete="off"></label>' +
        '<select class="px-instance-state"></select><span class="px-instance-count" aria-live="polite"></span>';
      host.before(bar);
      const input = $('input', bar), select = $('select', bar), count = $('.px-instance-count', bar);
      const states = ['', 'running', 'suspended', 'provisioning', 'pending', 'pending_approval', 'failed'];
      function filter() {
        const query = input.value.trim().toLocaleLowerCase(), rows = $$('.row-card', host); let shown = 0;
        rows.forEach(row => {
          const searchable = (($('.row-name', row)?.textContent || '') + ' ' + ($('.row-spec', row)?.textContent || '')).toLocaleLowerCase();
          const matches = searchable.includes(query) && (!select.value || select.value === row.dataset.status);
          row.hidden = !matches; if (matches) shown++;
        });
        count.textContent = rows.length ? shown + ' / ' + rows.length : '—';
      }
      translations.push(() => {
        input.placeholder = t('serverSearch'); input.setAttribute('aria-label', t('serverSearch'));
        select.setAttribute('aria-label', t('allStates')); const previous = select.value;
        select.replaceChildren(); states.forEach(state => { const option = document.createElement('option'); option.value = state; option.textContent = t(state || 'allStates'); select.appendChild(option); });
        select.value = previous || ''; filter();
      });
      listen(input, 'input', filter); listen(select, 'change', filter);
      if (typeof MutationObserver === 'function') {
        const observer = new MutationObserver(records => { if (records.some(record => record.type === 'childList' && record.target === host)) filter(); });
        observer.observe(host, { childList: true }); disposers.push(() => observer.disconnect());
      }
    }

    function refinement() {
      // Existing content is always readable, including if observers are unsupported.
      if (!reduced.matches && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => entries.forEach(entry => {
          if (entry.isIntersecting) { entry.target.classList.add('px-entered'); observer.unobserve(entry.target); }
        }), { threshold: .05, rootMargin: '0px 0px 35px 0px' });
        $$('.landing-page .v3-section > .section-head-v3,.landing-page .promise-card,.landing-page .product-story,.landing-page .plans-v3,.landing-page .final-cta').forEach((node, i) => {
          node.classList.add('px-reveal'); node.style.setProperty('--px-delay', (i % 3 * 45) + 'ms'); observer.observe(node);
        });
        disposers.push(() => observer.disconnect());
      }
      if (!coarse.matches && !reduced.matches) {
        $$('.promise-card,.cap-card,.use-card-v3,.plan-v3').forEach(card => {
          listen(card, 'pointermove', event => {
            const rect = card.getBoundingClientRect();
            card.style.setProperty('--px-hover-x', Math.round(event.clientX - rect.left) + 'px');
            card.style.setProperty('--px-hover-y', Math.round(event.clientY - rect.top) + 'px');
          }, { passive: true });
        });
      }
      $$('.faq-item').forEach(item => {
        item.name = 'pulsarx-faq';
        listen(item, 'toggle', () => { if (item.open) $$('.faq-item').forEach(other => { if (other !== item) other.open = false; }); });
      });
      if (landing) {
        const footer = $('.footer-brand'); if (footer) { const note = element('span', 'px-footer-note'); text(note, 'footerNote'); footer.appendChild(note); }
      }
    }
    if (landing) createHero();
    navigation(); commandPalette(); pricingHandoff(); instanceFilter(); refinement();
    function translate() {
      $$('[data-px-copy]').forEach(node => { node.innerHTML = t(node.dataset.pxCopy); });
      // Translation replaces button text only; the decorative arrow is restored separately.
      const primary = $('.hero-actions .btn-primary'); if (primary && !primary.querySelector('svg')) primary.insertAdjacentHTML('beforeend', arrowIcon);
      translations.forEach(fn => fn());
    }
    translate();
    if (typeof MutationObserver === 'function') {
      const observer = new MutationObserver(records => {
        if (records.some(record => record.type === 'attributes' && record.attributeName === 'lang' && record.target === document.documentElement)) translate();
      }); observer.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
      disposers.push(() => observer.disconnect());
    }
    // pagehide with persisted=true enters the back/forward cache; keep the view resumable.
    listen(window, 'pagehide', event => { if (!event.persisted) { while (disposers.length) disposers.pop()(); } });
    window.pulsarxV4 = { version: VERSION };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true }); else boot();
})();
