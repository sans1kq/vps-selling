/* Presentation only: keep payment elements and their listeners intact when moving them. */
(() => {
  'use strict';
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  function arrangeWallet(){
    document.querySelectorAll('#walletHistory .wallet-row-title').forEach(n=>{if(n.textContent==='admin_grant'){n.dataset.t='adminGrant';n.textContent=window.Pulse.t('adminGrant');}});
    const shell=document.querySelector('#walletContent .wallet-shell');
    if(!shell||shell.dataset.financeLayout)return;
    const hero=shell.querySelector('.wallet-hero'),topup=shell.querySelector('.wallet-topup-card'),history=shell.querySelector('.wallet-history-card');
    if(!hero||!topup||!history)return;
    shell.dataset.financeLayout='1';
    const layout=document.createElement('div');layout.className='finance-layout';
    const aside=document.createElement('aside');aside.className='finance-aside';
    const main=document.createElement('div');main.className='finance-main';
    shell.insertBefore(layout,hero);layout.append(aside,main);aside.append(hero);
    hero.querySelector('.px-growth-invite')?.remove();
    const active=shell.querySelector('#walletActiveInvoice');if(active)main.append(active);
    main.append(topup);shell.append(history);shell.querySelector('.wallet-grid')?.remove();
  }
  function revealOnScroll(){
    if(reduced()||!('IntersectionObserver' in window))return;
    const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){entry.target.classList.add('revealed');observer.unobserve(entry.target);}},{threshold:.09,rootMargin:'0px 0px -30px 0px'});
    document.querySelectorAll('[data-reveal]').forEach((node,i)=>{if(node.getBoundingClientRect().top>innerHeight*.88){node.classList.add('will-reveal');node.style.setProperty('--reveal-delay',String(i%2*70)+'ms');observer.observe(node);}else node.classList.add('revealed');});
  }
  function init(){
    revealOnScroll();
    const holder=document.getElementById('walletContent');
    if(holder){new MutationObserver(arrangeWallet).observe(holder,{childList:true,subtree:true});arrangeWallet();}
    document.querySelectorAll('.site-dock a').forEach(a=>{
      const u=new URL(a.href,location.origin),active=u.pathname===location.pathname&&u.search===location.search;
      a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');
    });
    document.addEventListener('click',e=>{
      if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||reduced())return;
      const a=e.target.closest('a[href]');if(!a||a.target||a.download||a.hasAttribute('data-page')||a.matches('[data-open-wallet],[data-open-support],[data-open-settings],[data-open-servers]'))return;
      const u=new URL(a.href,location.href);
      if(u.origin!==location.origin||!['http:','https:'].includes(u.protocol)||u.pathname===location.pathname&&u.search===location.search)return;
      e.preventDefault();document.body.classList.add('is-leaving');
      setTimeout(()=>location.assign(u.href),125);
    });
    window.addEventListener('pageshow',()=>document.body.classList.remove('is-leaving'));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
