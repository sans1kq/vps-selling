/* PulsarX Pulse: shared presentation, language and accessible controls. */
(() => {
  'use strict';
  // Older browsers and the HTTP-only local preview may lack randomUUID.
  // Use the same cryptographic entropy, never Math.random, for request keys.
  if (!crypto.randomUUID && crypto.getRandomValues) {
    Object.defineProperty(crypto,'randomUUID',{value:()=>{
      const bytes=crypto.getRandomValues(new Uint8Array(16));
      bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
      const h=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
      return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);
    }});
  }
  const dictionaries = {};
  let language = ['ru','en','ro'].includes(new URLSearchParams(location.search).get('lang'))
    ? new URLSearchParams(location.search).get('lang') : localStorage.getItem('pulsarx_lang') || 'ru';
  if (!['ru','en','ro'].includes(language)) language = 'ru';
  const index = () => ({ru:0,en:1,ro:2}[language]);
  const icons = {
    arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',chevron:'<path d="m9 5 7 7-7 7"/>',
    server:'<rect x="4" y="3" width="16" height="7" rx="2"/><rect x="4" y="14" width="16" height="7" rx="2"/><path d="M8 6.5h.01M8 17.5h.01M12 6.5h4M12 17.5h4"/>',
    wallet:'<path d="M4 7h15v14H4zM4 7l12-4v4"/><path d="M15 12h6v5h-6z"/>',
    support:'<path d="M5 13v-1a7 7 0 0 1 14 0v1M5 12H3v6h4v-6zm14 0h2v6h-4v-6zM19 18c0 3-3 3-6 3"/>',
    settings:'<path d="m10 3-.6 2.2-2 .9L5.3 5 3 9l1.7 1.5v3L3 15l2.3 4 2.1-1.1 2 .9L10 21h4l.6-2.2 2-.9 2.1 1.1 2.3-4-1.7-1.5v-3L21 9l-2.3-4-2.1 1.1-2-.9L14 3z"/><circle cx="12" cy="12" r="3"/>',
    check:'<path d="m5 12 4 4 10-10"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',plus:'<path d="M12 5v14M5 12h14"/>',
    lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    code:'<path d="m8 7-5 5 5 5m8-10 5 5-5 5m-3-12-2 14"/>',cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 3v3m6-3v3M9 18v3m6-3v3M3 9h3m-3 6h3m12-6h3m-3 6h3"/>',
    memory:'<rect x="3" y="7" width="18" height="10" rx="2"/><path d="M6 10v4m4-4v4m4-4v4m4-4v4M6 17v3m4-3v3m4-3v3m4-3v3"/>',
    disk:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 4 16 4 16 0V6M4 12c0 4 16 4 16 0"/>',
    gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v9h14v-9M12 8v13M12 8C6 9 5 2 8 3c3-1 4 5 4 5zm0 0c6 1 7-6 4-5-3-1-4 5-4 5z"/>',
    globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
    copy:'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
    telegram:'<path d="m3 11 18-7-5 17-5-6-4 3v-6l10-5-7 7"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
    external:'<path d="M13 3h8v8M21 3l-11 11M9 3H3v18h18v-6"/>',
    logout:'<path d="M10 3H4v18h6M9 12h12m-5-5 5 5-5 5"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',refresh:'<path d="M20 10a8 8 0 0 0-14-5L3 8m0-5v5h5m-4 6a8 8 0 0 0 14 5l3-3m0 5v-5h-5"/>',
    eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    file:'<path d="M14 3H5v18h14V8zM14 3v5h5M8 13h8M8 17h5"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7z"/>',
    debian:'<path d="M14 20c-7 1-12-9-6-14 5-5 14 2 9 7-3 4-9-1-6-4 2-1 4 1 2 3"/>',
    ubuntu:'<circle cx="12" cy="12" r="5"/><circle cx="12" cy="3" r="1.6"/><circle cx="20" cy="17" r="1.6"/><circle cx="4" cy="17" r="1.6"/><path d="M12 7V5m4 10 2 1M8 15l-2 1"/>',
    alpine:'<path d="m2 19 7-13 4 7 3-5 6 11H2zm4-6 3 2 3-2"/>',
    arch:'<path d="m12 2 9 20-6-3-3-6-3 6-6 3 9-20z"/>',
    fedora:'<path d="M12 21h-3a7 7 0 0 1-7-7V9a7 7 0 0 1 7-7h5a7 7 0 0 1 7 7v5a7 7 0 0 1-7 7zM15 5c-4-1-6 0-6 4v10M5 12h10"/>',
    rocky:'<circle cx="12" cy="12" r="9"/><path d="m5 17 6-8 8 10m-9-7 3 4 3-4"/>'
  };
  const t = (key, values={}) => {
    let value = dictionaries[key]?.[index()] ?? dictionaries[key]?.[0] ?? key;
    for (const [name,text] of Object.entries(values)) value=value.split('{'+name+'}').join(String(text));
    return value;
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = name => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(icons[name]||icons.server)+'</svg>';
  function apply(root=document) {
    root.querySelectorAll('[data-t]').forEach(el=>{el.textContent=t(el.dataset.t);});
    root.querySelectorAll('[data-placeholder]').forEach(el=>{el.placeholder=t(el.dataset.placeholder);});
    root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});
    root.querySelectorAll('[data-language]').forEach(el=>{el.value=language;});
    document.documentElement.lang=language;
  }
  function setLang(lang) {
    if (!['ru','en','ro'].includes(lang)) return;
    language=lang;localStorage.setItem('pulsarx_lang',lang);apply();
    document.dispatchEvent(new CustomEvent('px:lang',{detail:lang}));
  }
  function merge(values) { Object.assign(dictionaries,values); }
  async function api(path, options={}, authenticated=true) {
    const saved=localStorage.getItem('pulsarx_token');
    const headers=new Headers(options.headers || {});
    if(authenticated&&saved)headers.set('Authorization','Bearer '+saved);
    if(options.body&&typeof options.body==='string'&&!headers.has('Content-Type'))headers.set('Content-Type','application/json');
    let response;
    try { response=await fetch(path,{cache:'no-store',...options,headers}); }
    catch { throw new Error(t('networkError')); }
    let data;try{data=await response.json();}catch{throw new Error(t('requestError'));}
    if(authenticated&&saved!==localStorage.getItem('pulsarx_token'))throw new Error(t('sessionChanged'));
    if(!response.ok){
      if(response.status===401&&authenticated){localStorage.removeItem('pulsarx_token');localStorage.removeItem('pulsarx_user');location.href='/login/?next='+encodeURIComponent(location.pathname+location.search);}
      const detail=data?.detail;
      const error=new Error(typeof detail==='string'?detail:detail?.message||t('requestError'));
      error.status=response.status;error.detail=detail;throw error;
    }
    return data;
  }
  function toast(title, text='') {
    let holder=document.getElementById('toastContainer');
    if(!holder){holder=document.createElement('div');holder.id='toastContainer';holder.className='toast-container';holder.setAttribute('aria-live','polite');document.body.append(holder);}
    const item=document.createElement('div');item.className='toast';item.setAttribute('role','status');
    const strong=document.createElement('strong');strong.textContent=title;item.append(strong);
    if(text){const p=document.createElement('p');p.textContent=text;item.append(p);}
    holder.append(item);setTimeout(()=>item.remove(),6500);
  }
  function confirm(title, description, danger=false) {
    const dialog=document.createElement('dialog');dialog.className='dialog';
    dialog.innerHTML='<h2>'+esc(title)+'</h2><p>'+esc(description)+'</p><div class="dialog-actions"><button class="btn btn-secondary" data-cancel>'+esc(t('cancel'))+'</button><button class="btn '+(danger?'btn-danger':'')+'" data-confirm>'+esc(t('confirm'))+'</button></div>';
    document.body.append(dialog);dialog.showModal();
    return new Promise(resolve=>{let accepted=false;dialog.querySelector('[data-cancel]').onclick=()=>dialog.close();dialog.querySelector('[data-confirm]').onclick=()=>{accepted=true;dialog.close();};dialog.addEventListener('close',()=>{dialog.remove();resolve(accepted);},{once:true});});
  }
  async function copy(text) {
    try{await navigator.clipboard.writeText(text);toast(t('copied'));}
    catch{const input=document.createElement('textarea');input.value=text;document.body.append(input);input.select();document.execCommand('copy');input.remove();toast(t('copied'));}
  }
  function validNext(value) {
    try{const url=new URL(value||'/dashboard/',location.origin);return url.origin===location.origin&&!url.pathname.startsWith('//')?url.pathname+url.search+url.hash:'/dashboard/';}catch{return '/dashboard/';}
  }
  function currency(cents) {return '$'+(Number(cents||0)/100).toFixed(2);}
  function date(value,short=false) {const d=new Date(typeof value==='number'?value*1000:value);return Number.isFinite(d.getTime())?d.toLocaleString(language,{dateStyle:short?'short':'medium',...(short?{}:{timeStyle:'short'})}):'—';}
  merge({
    navPlans:['Тарифы','Plans','Tarife'],navProduct:['Возможности','Product','Produs'],navSupport:['Поддержка','Support','Suport'],navCommunity:['Сообщество','Community','Comunitate'],login:['Войти','Log in','Autentificare'],dashboard:['Личный кабинет','Dashboard','Panou'],choosePlan:['Выбрать сервер','Choose a server','Alege un server'],
    heroTag:['LINUX VPS ДЛЯ ВАШИХ ПРОЕКТОВ','LINUX VPS FOR YOUR PROJECTS','LINUX VPS PENTRU PROIECTELE TALE'],heroOne:['Linux VPS.','Linux VPS.','Linux VPS.'],heroTwo:['Просто и по делу.','A little more possibility.','Simplu. Exact ce trebuie.'],heroText:['Для сайтов, ботов и небольших приложений. Два понятных тарифа, SSH-доступ и всё управление в одной панели.','For websites, bots and small applications. Two clear plans, SSH access, and one place to manage everything.','Pentru site-uri, boți și aplicații mici. Două tarife clare, acces SSH și administrare într-un singur loc.'],viewPlans:['Смотреть тарифы','Explore plans','Vezi tarifele'],fromPrice:['От $3 в месяц','From $3 per month','De la $3 pe lună'],noAuto:['Без автосписаний','No automatic charges','Fără debitări automate'],artCaption:['Пространство для ваших идей','Room for your ideas','Spațiu pentru ideile tale'],
    factOne:['Полный доступ по SSH','Your own SSH access','Acces propriu prin SSH'],factOneText:['Linux и права root','Linux with root access','Linux cu drepturi root'],factTwo:['Управление в кабинете','One simple dashboard','Un panou simplu'],factTwoText:['Запуск, продление и ресурсы','Power, renewal and resources','Pornire, reînnoire și resurse'],factThree:['Поддержка рядом','Help is close','Suport la îndemână'],factThreeText:['На сайте и в Telegram','On the website and Telegram','Pe site și în Telegram'],
    plansTag:['ВАШ ПЕРВЫЙ ШАГ','YOUR FIRST STEP','PRIMUL PAS'],plansTitle:['Нужный размер.\nПонятная цена.','The right size.\nA clear price.','Dimensiunea potrivită.\nUn preț clar.'],plansText:['Начните с Mini. Для проекта побольше — больше памяти в Plus.','Start with Mini. Choose Plus when your project needs more memory.','Începe cu Mini. Alege Plus când proiectul are nevoie de mai multă memorie.'],miniText:['Для бота, тестового проекта или знакомства с Linux.','For a bot, a development project, or getting to know Linux.','Pentru un bot, un proiect de test sau primii pași în Linux.'],plusText:['Больше памяти для сайта, нескольких сервисов или приложения.','More memory for a website, a few services, or an application.','Mai multă memorie pentru un site, câteva servicii sau o aplicație.'],moreMemory:['Больше памяти','More memory','Mai multă memorie'],perMonth:['/ месяц','/ month','/ lună'],processor:['Процессор','Processor','Procesor'],memory:['Память','Memory','Memorie'],storage:['Диск','Storage','Stocare'],chooseMini:['Выбрать Mini','Choose Mini','Alege Mini'],choosePlus:['Выбрать Plus','Choose Plus','Alege Plus'],planBottom:['Разовая оплата выбранного периода. Продление — когда решите вы.','Pay once for your chosen period. Renew when you choose.','Plătești o dată pentru perioada aleasă. Reînnoiești când decizi.'],resourceInfo:['О ресурсах и подключении','About resources and access','Despre resurse și conectare'],resourceText:['Серверы работают как Linux-контейнеры. vCPU используют общее процессорное время узла. Подключение — по SSH через общий IPv4 и отдельный порт; дополнительные TCP-порты доступны в кабинете.','Servers run as Linux containers. vCPUs share the host CPU time. Connect over SSH through a shared IPv4 and a dedicated port; additional TCP ports are available in your dashboard.','Serverele rulează în containere Linux. vCPU folosesc în comun timpul procesorului gazdă. Conectarea SSH se face printr-un IPv4 comun și un port propriu; porturile TCP suplimentare sunt în panou.'],
    linuxTitle:['Ваш привычный Linux','The Linux you know','Linux-ul cu care te simți acasă'],linuxText:['Выберите систему при создании сервера.','Choose your distribution when creating a server.','Alege distribuția la crearea serverului.'],inviteTitle:['Другу — скидка 10%','10% off for a friend','10% reducere pentru un prieten'],inviteText:['Отправьте свою ссылку. Новый аккаунт друга получит скидку на одно пополнение баланса.','Share your link. Your friend’s new account gets a discount on one balance top-up.','Trimite linkul tău. Contul nou al prietenului primește o reducere la o singură alimentare.'],inviteAction:['Найти свою ссылку','Find your link','Găsește linkul tău'],trialTitle:['Сначала попробовать?','Try it first?','Vrei să încerci mai întâi?'],trialText:['Поделитесь отзывом о сайте с поддержкой и запросите код на 2 часа Mini.','Share feedback about the website with support and request a code for two hours of Mini.','Oferă feedback despre site echipei de suport și solicită un cod pentru două ore de Mini.'],trialAction:['Написать в поддержку','Talk to support','Scrie echipei de suport'],paymentText:['Пополняйте баланс удобным способом','Choose how you top up','Alege cum alimentezi soldul'],faqTitle:['Несколько ответов\nперед стартом','A few answers\nbefore you start','Câteva răspunsuri\nînainte de start'],faq1:['Для чего подойдёт сервер?','What can I run?','Ce pot rula pe server?'],faq1a:['Небольшие сайты, Telegram-боты, скрипты, учебные и тестовые приложения. Выбирайте ресурсы под нагрузку своего проекта.','Small websites, Telegram bots, scripts, learning and test applications. Choose resources that match your project’s workload.','Site-uri mici, boți Telegram, scripturi și aplicații de studiu sau test. Alege resursele în funcție de proiect.'],faq2:['Как получить доступ?','How do I connect?','Cum mă conectez?'],faq2a:['Создайте аккаунт, пополните баланс и выберите сервер. Когда он будет готов, задайте SSH-пароль в кабинете и скопируйте команду подключения.','Create an account, top up your balance and choose a server. When it is ready, set your SSH password in the dashboard and copy the connection command.','Creează un cont, alimentează soldul și alege serverul. Când este gata, setează parola SSH în panou și copiază comanda de conectare.'],faq3:['Как работает продление?','How do renewals work?','Cum funcționează reînnoirea?'],faq3a:['В кабинете виден оплаченный срок. Нажмите «Продлить» и подтвердите оплату с баланса. Новое время добавится к оставшемуся, автоматического списания нет.','Your paid period is shown in the dashboard. Choose Renew and confirm payment from your balance. The new time is added to what is left, with no automatic charge.','Perioada plătită este afișată în panou. Alege Reînnoire și confirmă plata din sold. Timpul nou se adaugă celui rămas, fără debitare automată.'],faq4:['Где спросить, если нужна помощь?','Where can I get help?','Unde pot cere ajutor?'],faq4a:['Создайте обращение в личном кабинете — ответы будут в той же переписке. Или напишите боту @PulsarXSupportBot в Telegram через /tiket.','Open a ticket in your dashboard and read replies in the same conversation. Or contact @PulsarXSupportBot on Telegram with /tiket.','Deschide un tichet în panou și citește răspunsurile în aceeași conversație. Sau scrie botului @PulsarXSupportBot pe Telegram folosind /tiket.'],closingTitle:['Дайте проекту свой сервер.','Give your project a home.','Oferă proiectului tău un server.'],closingText:['Выберите Mini или Plus. Остальное — в одной панели.','Choose Mini or Plus. Everything else is in one dashboard.','Alege Mini sau Plus. Restul este într-un singur panou.'],terms:['Условия использования','Terms of service','Condiții de utilizare'],privacy:['Конфиденциальность','Privacy policy','Confidențialitate'],footerLine:['Небольшие серверы. Ваши большие идеи.','Small servers. Your big ideas.','Servere mici. Ideile tale mari.'],
    servers:['Серверы','Servers','Servere'],balance:['Баланс','Balance','Sold'],support:['Поддержка','Support','Suport'],settings:['Настройки','Settings','Setări'],newServer:['Создать сервер','Create a server','Creează un server'],backHome:['На главную','Back to home','Pagina principală'],signout:['Выйти','Log out','Deconectare'],cancel:['Отмена','Cancel','Anulează'],confirm:['Подтвердить','Confirm','Confirmă'],save:['Сохранить','Save','Salvează'],copy:['Копировать','Copy','Copiază'],copied:['Скопировано','Copied','Copiat'],loading:['Загрузка…','Loading…','Se încarcă…'],refresh:['Обновить','Refresh','Actualizează'],requestError:['Не удалось выполнить запрос. Попробуйте ещё раз.','Could not complete the request. Please try again.','Cererea nu a putut fi finalizată. Încearcă din nou.'],networkError:['Не удалось связаться с сервером. Проверьте подключение и повторите.','Could not reach the server. Check your connection and try again.','Conexiunea cu serverul a eșuat. Verifică rețeaua și încearcă din nou.'],sessionChanged:['Аккаунт изменился. Обновите страницу.','Your account changed. Refresh the page.','Contul s-a schimbat. Reîncarcă pagina.'],email:['Электронная почта','Email address','Adresă de email'],password:['Пароль','Password','Parolă'],community:['Сообщество','Community','Comunitate'],helpSide:['Вопросы по серверу или оплате?','Questions about a server or payment?','Întrebări despre server sau plată?'],supportSide:['Мы рядом в поддержке.','Support is right here.','Echipa de suport este aici.'],back:['Назад','Back','Înapoi']
  });
  merge({supportPublicTitle:['Поможем разобраться.','Let’s work it out.','Hai să găsim soluția.'],supportPublicText:['Вопрос по серверу, оплате или первым шагам? Выберите удобный способ связи. Переписка на сайте и в Telegram доступна поддержке в одной панели.','A question about your server, a payment, or getting started? Choose the channel that suits you. Website and Telegram conversations reach the same support inbox.','Ai o întrebare despre server, plăți sau primii pași? Alege canalul potrivit. Conversațiile de pe site și Telegram ajung în același panou de suport.'],supportSiteTitle:['В личном кабинете','In your dashboard','În panoul personal'],supportSiteText:['Создайте обращение и получайте ответы прямо на сайте. Ваша учётная запись уже будет привязана к обращению.','Open a ticket and receive replies right here. Your PulsarX account will already be linked to the request.','Deschide un tichet și primește răspunsuri direct pe site. Contul tău PulsarX este deja asociat solicitării.'],writeTicket:['Создать обращение','Open a ticket','Deschide un tichet'],supportTelegramText:['Откройте @PulsarXSupportBot, отправьте /tiket и следующим сообщением опишите проблему.','Open @PulsarXSupportBot, send /tiket, then describe your issue in the next message.','Deschide @PulsarXSupportBot, trimite /tiket, apoi descrie problema în următorul mesaj.'],openTelegram:['Открыть Telegram','Open Telegram','Deschide Telegram'],supportEmailText:['Также можно написать на почту:','You can also email us:','Ne poți scrie și prin email:'],supportPrivacyText:['Не отправляйте пароли, платёжные ключи и коды входа. Telegram-аккаунт сам по себе не подтверждает владение аккаунтом PulsarX.','Do not send passwords, payment keys or login codes. A Telegram account alone does not verify ownership of a PulsarX account.','Nu trimite parole, chei de plată sau coduri de autentificare. Un cont Telegram nu confirmă singur proprietatea unui cont PulsarX.']});
  window.Pulse={t,esc,icon,apply,merge,api,toast,confirm,copy,validNext,currency,date,getLang:()=>language};
  window.pulsarxI18n={getLang:()=>language,setLang,t};
  window.showToast=toast;
  function init() {
    apply();
    document.querySelectorAll('[data-language]').forEach(el=>el.addEventListener('change',()=>setLang(el.value)));
    const menu=document.querySelector('[data-mobile-menu]'),nav=document.querySelector('.header-nav');
    menu?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
    nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menu?.setAttribute('aria-expanded','false');}));
    document.querySelectorAll('[data-account-link]').forEach(a=>{if(localStorage.getItem('pulsarx_token')){a.href='/dashboard/';a.dataset.t='dashboard';a.textContent=t('dashboard');}});
    const canvas=document.querySelector('[data-blackhole]');
    if(canvas&&window.PulsarXCore){
      try{
        const small=window.innerWidth<600,core=new window.PulsarXCore(canvas,{compact:true,width:560,height:510,dpr:Math.min(devicePixelRatio||1,small?1.2:1.5)});
        canvas.parentElement.querySelector('.hero-art-static')?.remove();
        const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
        let last=0;
        function frame(now){if(document.visibilityState!=='hidden'&&(reduced||now-last>(small?75:45))){core.render(reduced?0:now/1000);last=now;}if(!reduced)requestAnimationFrame(frame);}
        requestAnimationFrame(frame);
      }catch{canvas.remove();}
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
