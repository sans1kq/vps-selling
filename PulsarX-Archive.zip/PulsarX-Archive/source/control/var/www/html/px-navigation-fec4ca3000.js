/* Public account links follow the verified session, including changes in another tab. */
(() => {
  'use strict';
  const P=window.Pulse;
  P.merge({
    navLogin:['Войти в аккаунт','Log in to account','Intră în cont'],
    classicLogin:['Твоё облако — в одном шаге.','Your cloud, one step away.','Cloud-ul tău, la un pas.'],
    classicRegister:['Начни с малого. Запусти своё.','Start small. Build your own.','Începe simplu. Creează ceva al tău.'],
    classicForgot:['Верни доступ. Проекты подождут.','Get back to your projects.','Revino la proiectele tale.'],
    classicReset:['Новый пароль. Тот же аккаунт.','A new password. The same account.','O parolă nouă. Același cont.'],
    classicVerify:['Один код — и готово.','One code. Then you’re in.','Un cod și ești gata.'],
    classicLoginCopy:['Войди, чтобы вернуться к своим серверам.','Sign in to get back to your servers.','Intră în cont pentru a reveni la serverele tale.'],
    classicRegisterCopy:['Выбери Linux и запусти первый проект.','Choose Linux and launch your first project.','Alege Linux și pornește primul proiect.'],
    classicForgotCopy:['Восстановление аккаунта не меняет пароль SSH.','Account recovery leaves your SSH password unchanged.','Recuperarea contului nu schimbă parola SSH.'],
    classicResetCopy:['Серверы продолжают работать.','Your servers keep running.','Serverele tale continuă să funcționeze.'],
    classicVerifyCopy:['Подтверди почту, чтобы открыть кабинет.','Confirm your email to open your dashboard.','Confirmă emailul pentru a deschide panoul.'],
    authStepDetails:['Почта и пароль','Email and password','Email și parolă'],
    authStepProfile:['Данные аккаунта','Account details','Datele contului'],
    authStepEmail:['Твоя почта','Your email','Emailul tău'],
    authStepCode:['Код из письма','Emailed code','Codul din email'],
    authStepDashboard:['Личный кабинет','Your dashboard','Panoul tău'],
    authStepPassword:['Новый пароль','New password','Parolă nouă'],
    authPrivateNote:['Вход с подтверждением по почте','Email verification at sign-in','Autentificare cu verificare prin email'],
    authCreatePassword:['От 8 символов','At least 8 characters','Cel puțin 8 caractere']
  });
  let verified=null,generation=0,controller=null;
  const token=()=>localStorage.getItem('pulsarx_token');
  function render(){
    const member=!!verified&&verified===token();
    document.querySelectorAll('[data-account-link]').forEach(a=>{
      a.href=member?'/dashboard/':'/login/';a.dataset.accountState=member?'member':'guest';
      const label=a.querySelector('[data-account-label]');
      if(label){label.dataset.t=member?'dashboard':'navLogin';label.textContent=P.t(label.dataset.t);}
      const mark=a.querySelector('[data-account-icon]');
      if(mark){mark.dataset.icon=member?'server':'user';mark.innerHTML=P.icon(mark.dataset.icon);}
      const current=new URL(a.href,location.href);
      const active=current.pathname===location.pathname&&current.search===location.search;
      a.classList.toggle('active',active);
      if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
    });
  }
  async function verify(){
    const ticket=++generation,saved=token();controller?.abort();controller=null;verified=null;render();
    if(!saved||!document.querySelector('[data-account-link]'))return;
    const current=new AbortController();controller=current;
    const deadline=setTimeout(()=>current.abort(),5000);
    try{
      const response=await fetch('/api/auth/me',{method:'GET',cache:'no-store',headers:{Authorization:'Bearer '+saved},signal:current.signal});
      if(ticket!==generation||token()!==saved)return;
      if(response.status===401){localStorage.removeItem('pulsarx_token');localStorage.removeItem('pulsarx_user');return;}
      if(response.ok){
        const user=await response.json();
        if(ticket===generation&&token()===saved&&typeof user?.id==='string'&&user.id)verified=saved;
      }
    }catch{/* Keep credentials on network failure; the public navigation stays in guest state. */}
    finally{clearTimeout(deadline);if(ticket===generation){controller=null;render();}}
  }
  function init(){
    verify();
    document.addEventListener('px:lang',render);
    window.addEventListener('storage',event=>{if(event.key===null||event.key==='pulsarx_token')verify();});
    window.addEventListener('pageshow',event=>{if(event.persisted)verify();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
