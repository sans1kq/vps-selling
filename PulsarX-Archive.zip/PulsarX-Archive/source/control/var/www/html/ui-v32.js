(function(){
  if (window.__pulsarxV32) return;
  window.__pulsarxV32 = true;
  if (!document.body || !document.body.classList.contains('landing-page')) return;

  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const mobile = !!(window.matchMedia && window.matchMedia('(max-width: 820px), (pointer: coarse)').matches);
  const lowPower = !!((navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 4));
  const passiveMode = reduced || mobile || lowPower;
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (a,b) => a + Math.random() * (b-a);

  /* ---------- Hero instance: live metrics + real buttons ---------- */
  (function heroDemo(){
    const hero = document.querySelector('.hero-console');
    if (!hero) return;
    hero.removeAttribute('aria-hidden');
    const status = hero.querySelector('.console-status');
    const metrics = hero.querySelectorAll('.console-metric b');
    const chart = hero.querySelector('.console-chart');
    const svg = chart && chart.querySelector('svg');
    const paths = svg ? svg.querySelectorAll('path') : [];
    const actions = hero.querySelectorAll('.console-action');
    if (metrics.length < 3 || actions.length < 3) return;

    let running = true, busy = false, sshOpen = false;
    let cpu = 24, ram = 612, disk = 3.8;
    let samples = [18,20,23,28,26,21,17,25,34,31,24,20,27,38,35,26,22,29,33,28,24,31,27,24];

    actions.forEach((el, i) => {
      if (el.tagName !== 'BUTTON') {
        el.setAttribute('role','button'); el.setAttribute('tabindex','0');
        el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }});
      }
      el.dataset.liveAction = i === 0 ? 'restart' : i === 1 ? 'power' : 'ssh';
    });
    const restartBtn = actions[0], powerBtn = actions[1], sshBtn = actions[2];

    const terminal = document.createElement('div');
    terminal.className = 'hero-live-terminal';
    terminal.innerHTML = '<div><span class="prompt">$</span> ssh root@203.0.113.42</div><div class="muted">Connecting to Frankfurt...</div><div><span class="ok">✓</span> authenticated · <span class="strong">px-web-01</span></div><br><div><span class="prompt">root@px-web-01:~#</span> systemctl --no-pager --failed</div><div class="strong">0 loaded units listed.</div><div><span class="prompt">root@px-web-01:~#</span> <span class="cursor"></span></div>';
    const actionRow = hero.querySelector('.console-actions');
    actionRow.parentNode.insertBefore(terminal, actionRow);

    function setStatus(label, mode){
      if (!status) return;
      const dot = '<i></i> ';
      status.innerHTML = dot + label;
      status.classList.toggle('is-warn', mode === 'warn');
      status.classList.toggle('is-off', mode === 'off');
    }
    function tickMetric(el){ el.parentElement.classList.add('metric-tick'); setTimeout(()=>el.parentElement.classList.remove('metric-tick'),180); }
    function renderMetrics(){
      metrics[0].textContent = Math.round(cpu) + '%';
      metrics[1].textContent = Math.round(ram) + ' MB';
      metrics[2].textContent = disk.toFixed(1) + ' GB';
      tickMetric(metrics[0]);
    }
    function renderChart(){
      if (paths.length < 2) return;
      const w = 500, h = 110, top = 10, bottom = 92;
      const pts = samples.map((v,i) => [i/(samples.length-1)*w, bottom - (clamp(v,0,100)/100)*(bottom-top)]);
      const line = pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
      paths[1].setAttribute('d', line);
      paths[0].setAttribute('d', line + ' L500 110 L0 110 Z');
    }
    function liveTick(){
      if (!running || busy) return;
      cpu = clamp(cpu + rand(-7,7), 8, 58);
      ram = clamp(ram + rand(-24,25), 520, 760);
      disk = clamp(disk + rand(0,0.018), 3.8, 4.2);
      samples.push(cpu); samples.shift();
      renderMetrics(); renderChart();
    }
    if (!passiveMode) setInterval(liveTick, 1800);

    restartBtn.addEventListener('click', async () => {
      if (busy || !running) return;
      busy = true; restartBtn.disabled = true; powerBtn.disabled = true;
      setStatus('RESTARTING', 'warn');
      cpu = 3; samples.push(3); samples.shift(); renderMetrics(); renderChart();
      await sleep(650);
      cpu = 0; renderMetrics();
      await sleep(700);
      running = true; cpu = 18; setStatus('RUNNING');
      restartBtn.disabled = false; powerBtn.disabled = false; busy = false; liveTick();
    });
    powerBtn.addEventListener('click', async () => {
      if (busy) return;
      if (running) {
        running = false; cpu = 0; samples = samples.map(()=>0); renderMetrics(); renderChart();
        setStatus('STOPPED','off'); chart && chart.classList.add('is-idle'); powerBtn.textContent = 'START';
      } else {
        busy = true; powerBtn.disabled = true; setStatus('STARTING','warn');
        await sleep(850); running = true; busy = false; powerBtn.disabled = false; powerBtn.textContent = 'STOP'; chart && chart.classList.remove('is-idle'); setStatus('RUNNING'); cpu = 16; liveTick();
      }
    });
    sshBtn.addEventListener('click', () => {
      sshOpen = !sshOpen; hero.classList.toggle('ssh-open', sshOpen); sshBtn.classList.toggle('is-active', sshOpen); sshBtn.textContent = sshOpen ? 'METRICS' : 'SSH';
    });
  })();

  /* ---------- Product terminal: auto type commands ---------- */
  (function terminalTypewriter(){
    const card = document.querySelector('.terminal-card');
    const body = card && card.querySelector('.terminal-body');
    const head = card && card.querySelector('.terminal-head');
    if (!card || !body || !head) return;

    const replay = document.createElement('button');
    replay.type = 'button'; replay.className = 'terminal-replay'; replay.textContent = '↻ REPLAY'; replay.setAttribute('aria-label','Replay terminal demo');
    head.appendChild(replay);

    const script = [
      {kind:'cmd', prompt:'$ ', text:'ssh root@203.0.113.42'},
      {kind:'out', cls:'faint', text:"The authenticity of host '203.0.113.42' has been established."},
      {kind:'html', html:'<span class="good">✓</span> connected to <span class="strong">px-web-01</span>'},
      {kind:'blank'},
      {kind:'cmd', prompt:'root@px-web-01:~# ', text:'uptime'},
      {kind:'out', text:'18:42:11 up 3 days, load average: 0.08, 0.11, 0.09'},
      {kind:'cmd', prompt:'root@px-web-01:~# ', text:'free -h'},
      {kind:'out', html:'Mem:  <span class="strong">1.0Gi</span> total   612Mi used   388Mi available'},
      {kind:'cmd', prompt:'root@px-web-01:~# ', text:'', cursor:true}
    ];
    let runId = 0;
    async function typeText(el, text, speed, id){
      for (let i=0;i<text.length;i++) { if (id !== runId) return false; el.textContent += text[i]; await sleep(speed + Math.random()*12); }
      return true;
    }
    async function play(){
      const id = ++runId; body.innerHTML=''; body.classList.add('is-typing'); replay.disabled = true;
      for (const item of script) {
        if (id !== runId) return;
        const line = document.createElement('div'); line.className='terminal-line';
        if (item.cls) line.classList.add(item.cls);
        body.appendChild(line);
        if (item.kind === 'blank') { line.innerHTML='&nbsp;'; await sleep(120); continue; }
        if (item.kind === 'html') { line.innerHTML=item.html; line.classList.add('enter'); await sleep(360); continue; }
        if (item.kind === 'out') { if (item.html) line.innerHTML=item.html; else line.textContent=item.text; line.classList.add('enter'); await sleep(330); continue; }
        const p = document.createElement('span'); p.className='prompt'; p.textContent=item.prompt; line.appendChild(p);
        const txt = document.createElement('span'); line.appendChild(txt);
        if (item.text) { const ok = await typeText(txt,item.text,reduced?0:24,id); if(!ok)return; await sleep(260); }
        if (item.cursor) { const c=document.createElement('span'); c.className='terminal-cursor'; line.appendChild(c); }
      }
      replay.disabled = false;
    }
    replay.addEventListener('click', play);
    if (passiveMode) { replay.disabled=false; return; }
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver(entries => { if(entries.some(e=>e.isIntersecting)){ io.disconnect(); play(); } }, {threshold:.35});
      io.observe(card);
    } else play();
  })();

  /* ---------- Dashboard showcase: real tabs + auto cycling ---------- */
  (function dashboardShowcase(){
    const shell = document.querySelector('.showcase-shell');
    const main = shell && shell.querySelector('.showcase-main');
    const tabs = shell ? Array.from(shell.querySelectorAll('.showcase-nav-item')) : [];
    if (!shell || !main || tabs.length < 4) return;
    shell.removeAttribute('aria-hidden');
    const overviewHTML = main.innerHTML;
    const keys = ['overview','instances','monitoring','settings'];
    let active = 0, hover = false, manualUntil = 0;

    tabs.forEach((tab,i)=>{
      tab.setAttribute('role','button'); tab.setAttribute('tabindex','0'); tab.dataset.demoTab=keys[i];
      const activate = () => { manualUntil=Date.now()+18000; show(i,true); };
      tab.addEventListener('click',activate);
      tab.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate();}});
    });
    shell.addEventListener('mouseenter',()=>hover=true); shell.addEventListener('mouseleave',()=>hover=false);

    function titleFor(i){ const s=tabs[i].querySelector('span'); return s ? s.textContent.trim() : keys[i]; }
    function header(title, right){ return '<div class="showcase-main-head"><h3>'+title+'</h3><div class="showcase-demo-hint"><i></i>'+(right||'interactive preview')+'</div></div>'; }
    function instancesHTML(){ return header(titleFor(1),'2 / 2 online') + '<div class="demo-instance-list">'+
      '<div class="demo-instance-card"><div><div class="demo-instance-title">px-web-01</div><div class="demo-instance-meta">Mini · Debian 12 · 203.0.113.42</div></div><div class="demo-instance-actions"><button type="button" class="demo-mini-btn">RESTART</button><button type="button" class="demo-mini-btn">STOP</button></div></div>'+
      '<div class="demo-instance-card"><div><div class="demo-instance-title">bot-worker</div><div class="demo-instance-meta">Plus · Ubuntu 24.04 · 203.0.113.71</div></div><div class="demo-instance-actions"><button type="button" class="demo-mini-btn">RESTART</button><button type="button" class="demo-mini-btn">STOP</button></div></div>'+
      '</div><div class="showcase-panel" style="margin-top:10px"><div class="showcase-panel-title">SSH ACCESS</div><div class="showcase-ssh">$ ssh <b>root@203.0.113.42</b><span class="terminal-cursor" style="margin-left:5px"></span></div></div>';
    }
    function monitoringHTML(){ return header(titleFor(2),'refresh 3s') + '<div class="demo-monitor-grid"><div class="demo-monitor-card"><small>CPU</small><b data-demo-metric="cpu">24%</b></div><div class="demo-monitor-card"><small>RAM</small><b data-demo-metric="ram">61%</b></div><div class="demo-monitor-card"><small>DISK</small><b data-demo-metric="disk">38%</b></div><div class="demo-monitor-card"><small>NET TX</small><b data-demo-metric="net">1.8 MB</b></div></div><div class="demo-live-chart"><svg viewBox="0 0 500 120" preserveAspectRatio="none"><defs><linearGradient id="v32mon" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8b7cff" stop-opacity=".22"/><stop offset="1" stop-color="#8b7cff" stop-opacity="0"/></linearGradient></defs><path data-demo-chart-fill fill="url(#v32mon)"/><path data-demo-chart-line fill="none" stroke="#9d91ff" stroke-width="2"/></svg></div>';
    }
    function settingsHTML(){ return header(titleFor(3),'account settings') + '<div class="demo-settings"><div class="demo-setting-row"><span>Account email</span><b>u•••@mail.com</b></div><div class="demo-setting-row"><span>SSH password recovery</span><b>AVAILABLE</b></div><div class="demo-setting-row"><span>Language</span><b>'+String(document.documentElement.lang||'en').toUpperCase()+'</b></div><div class="demo-setting-row"><span>Live usage refresh</span><span class="demo-toggle" aria-hidden="true"></span></div></div>';
    }
    function bindMiniButtons(){
      main.querySelectorAll('.demo-mini-btn').forEach(btn=>btn.addEventListener('click',()=>{ const old=btn.textContent; btn.textContent=old==='STOP'?'STARTING…':'RESTARTING…'; btn.disabled=true; setTimeout(()=>{btn.textContent=old==='STOP'?'START':old;btn.disabled=false;},850); }));
    }
    function chartTick(){
      if (active !== 2) return;
      const cpu=Math.round(rand(14,48)), ram=Math.round(rand(54,69)), disk=38, net=rand(.8,3.6).toFixed(1);
      const vals={cpu:cpu+'%',ram:ram+'%',disk:disk+'%',net:net+' MB'};
      Object.keys(vals).forEach(k=>{const el=main.querySelector('[data-demo-metric="'+k+'"]');if(el)el.textContent=vals[k];});
      const arr=Array.from({length:20},(_,i)=>clamp(cpu+Math.sin(i*.8)*10+rand(-8,8),4,78));
      const pts=arr.map((v,i)=>[i/(arr.length-1)*500,105-v]);
      const line=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
      const l=main.querySelector('[data-demo-chart-line]'), f=main.querySelector('[data-demo-chart-fill]'); if(l)l.setAttribute('d',line); if(f)f.setAttribute('d',line+' L500 120 L0 120 Z');
    }
    function overviewTick(){
      if(active!==0)return;
      const pills=main.querySelectorAll('.showcase-pill');
      if(pills[0])pills[0].textContent='CPU '+Math.round(rand(17,34))+'%'; if(pills[1])pills[1].textContent='RAM '+Math.round(rand(57,65))+'%';
      if(pills[3])pills[3].textContent='CPU '+Math.round(rand(7,18))+'%'; if(pills[4])pills[4].textContent='RAM '+Math.round(rand(30,39))+'%';
      const rows=main.querySelectorAll('.showcase-bar-row'); const v=[Math.round(rand(18,34)),Math.round(rand(58,65)),38]; rows.forEach((row,i)=>{const bar=row.querySelector('i'), txt=row.lastElementChild;if(bar)bar.style.width=v[i]+'%';if(txt)txt.textContent=v[i]+'%';});
    }
    function show(i, byUser){
      if(i===active && !byUser)return; active=i;
      tabs.forEach((t,n)=>{t.classList.toggle('active',n===i);t.setAttribute('aria-pressed',n===i?'true':'false'); if(n===i){t.classList.add('demo-flash');setTimeout(()=>t.classList.remove('demo-flash'),460);}});
      main.classList.add('demo-switching');
      setTimeout(()=>{
        main.innerHTML = i===0 ? overviewHTML : i===1 ? instancesHTML() : i===2 ? monitoringHTML() : settingsHTML();
        main.classList.remove('demo-switching');main.classList.add('demo-ready');setTimeout(()=>main.classList.remove('demo-ready'),220);
        if(i===1)bindMiniButtons(); if(i===2)chartTick(); if(i===0)overviewTick();
      },110);
    }
    if(!passiveMode) setInterval(()=>{if(active===0)overviewTick();if(active===2)chartTick();},1900);
    if(!passiveMode) setInterval(()=>{ if(hover||Date.now()<manualUntil)return; show((active+1)%tabs.length,false); },6800);
  })();

  /* ---------- Capability cards: click to reveal a live micro-demo ---------- */
  (function capabilityDemos(){
    const cards = Array.from(document.querySelectorAll('.cap-card'));
    if (!cards.length) return;
    const demos = [
      '<div class="cap-demo-row"><code>myapp.pulsarx.example.invalid → 203.0.113.42</code><span class="cap-demo-ok">HTTPS ✓</span></div>',
      '<div class="cap-demo-row"><code>root@px-web-01</code><span class="cap-demo-ok">SSH READY</span></div>',
      '<div class="cap-demo-pills"><button type="button" class="cap-demo-pill active">RUNNING</button><button type="button" class="cap-demo-pill">RESTART</button><button type="button" class="cap-demo-pill">STOP</button></div>',
      '<div class="cap-demo-row"><span>CPU</span><div class="cap-demo-meter"><i style="width:24%"></i></div><b>24%</b></div><div class="cap-demo-row" style="margin-top:7px"><span>RAM</span><div class="cap-demo-meter"><i style="width:61%"></i></div><b>61%</b></div>',
      '<div class="cap-demo-pills"><button type="button" class="cap-demo-pill active">Debian 13</button><button type="button" class="cap-demo-pill">Ubuntu 24.04</button><button type="button" class="cap-demo-pill">Alpine 3.23</button></div>',
      '<div class="cap-demo-row"><code>1 core · 1 GB · 25 GB</code><span class="cap-demo-ok">ISOLATED</span></div>',
      '<div class="cap-demo-row"><code>482107 → new SSH password</code><span class="cap-demo-ok">VERIFIED ✓</span></div>',
      '<div class="cap-demo-row"><code>Mini  →  Plus</code><div class="cap-demo-meter"><i style="width:82%"></i></div><span class="cap-demo-ok">READY</span></div>'
    ];
    cards.forEach((card,i)=>{
      card.setAttribute('tabindex','0'); card.setAttribute('role','button'); card.setAttribute('aria-expanded','false');
      const demo=document.createElement('div');demo.className='cap-card-demo';demo.innerHTML=demos[i]||'';card.appendChild(demo);
      function toggle(){
        const will=!card.classList.contains('demo-active'); cards.forEach(c=>{c.classList.remove('demo-active');c.setAttribute('aria-expanded','false');}); if(will){card.classList.add('demo-active');card.setAttribute('aria-expanded','true');}
      }
      card.addEventListener('click',e=>{ if(e.target.closest('button'))return; toggle(); });
      card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});
      demo.querySelectorAll('.cap-demo-pill').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation(); const group=btn.parentElement; group.querySelectorAll('.cap-demo-pill').forEach(b=>b.classList.remove('active'));btn.classList.add('active'); if(btn.textContent==='STOP'){btn.textContent='START';}else if(btn.textContent==='RESTART'){btn.textContent='RESTARTING…';setTimeout(()=>{btn.textContent='RESTART';},700);} }));
    });
    if(!passiveMode){
      setInterval(()=>{ const active=document.querySelector('.cap-card.demo-active'); if(!active)return; active.querySelectorAll('.cap-demo-meter i').forEach((bar,n)=>{bar.style.width=(n?rand(54,69):rand(14,48)).toFixed(0)+'%';}); },1500);
    }
  })();

  /* ---------- Pricing period controls: pull real public pricing ---------- */
  (function pricingPeriods(){
    const chips=Array.from(document.querySelectorAll('.period-chip'));
    const plans=Array.from(document.querySelectorAll('.plan-v3'));
    if(!chips.length||plans.length<2)return;
    const months=[1,3,6,12]; let pricing=null;
    chips.forEach((chip,i)=>{chip.dataset.months=String(months[i]);chip.setAttribute('role','button');chip.setAttribute('tabindex','0');});
    const fallback={mini:{'1':3,'3':8.55,'6':16.2,'12':30.6},plus:{'1':5,'3':14.25,'6':27,'12':51}};
    function total(plan,m){const src=pricing&&pricing.prices&&pricing.prices[plan];const v=src&&src[String(m)];return Number(v||fallback[plan][String(m)]);}
    function render(m){
      chips.forEach(c=>c.classList.toggle('active',Number(c.dataset.months)===m));
      plans.forEach((card,i)=>{
        const plan=i===0?'mini':'plus'; const t=total(plan,m); const monthly=t/m;
        const price=card.querySelector('.plan-price'); if(!price)return;
        let value=price.querySelector('.plan-price-value'); if(!value){const nodes=Array.from(price.childNodes);const firstText=nodes.find(n=>n.nodeType===3&&n.textContent.trim());value=document.createElement('span');value.className='plan-price-value';value.textContent=firstText?firstText.textContent.trim():(plan==='mini'?'$3':'$5');if(firstText)price.replaceChild(value,firstText);else price.prepend(value);}
        value.textContent='$'+(Math.round(monthly*100)/100).toFixed(monthly%1?2:0); card.classList.remove('price-tick');void card.offsetWidth;card.classList.add('price-tick');
        let state=card.querySelector('.plan-period-state');if(!state){state=document.createElement('div');state.className='plan-period-state';price.insertAdjacentElement('afterend',state);}
        const disc=pricing&&pricing.discount_pct&&pricing.discount_pct[String(m)]; const d=disc!=null?Number(disc):(m===3?5:m===6?10:m===12?15:0);
        state.innerHTML=m===1?'1 month · $'+t.toFixed(2)+' total':m+' months · $'+t.toFixed(2)+' total'+(d?' · <b>−'+d+'%</b>':'');
      });
    }
    function choose(chip){render(Number(chip.dataset.months));}
    chips.forEach(chip=>{chip.addEventListener('click',()=>choose(chip));chip.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose(chip);}});});
    render(12);
    fetch('/api/servers/pricing').then(r=>r.ok?r.json():Promise.reject()).then(d=>{pricing=d;const a=chips.find(c=>c.classList.contains('active'));render(Number(a&&a.dataset.months||12));}).catch(()=>{});
  })();

  /* ---------- Animate real server count changes instead of hard jumps ---------- */
  (function countUp(){
    const el=document.getElementById('serverCount'); if(!el||!('MutationObserver'in window))return; let last=null,guard=false;
    const mo=new MutationObserver(()=>{if(guard)return;const next=parseInt(el.textContent,10);if(!Number.isFinite(next)){last=null;return;}if(last===null){last=next;return;}const from=last;last=next;if(passiveMode||from===next)return;guard=true;const start=performance.now(),dur=420;function frame(now){const p=Math.min(1,(now-start)/dur);el.textContent=String(Math.round(from+(next-from)*(1-Math.pow(1-p,3))));if(p<1)requestAnimationFrame(frame);else{el.textContent=String(next);guard=false;}}requestAnimationFrame(frame);});mo.observe(el,{childList:true,characterData:true,subtree:true});
  })();
})();

/* PulsarX landing plan extras */
(() => {
  function addPlanExtras() {
    if (document.getElementById('px-plan-extras')) return;

    const pricing = document.querySelector('.pricing-v3-wrap');
    if (!pricing) return;

    const extras = document.createElement('div');
    extras.id = 'px-plan-extras';
    extras.className = 'px-plan-extras';
    extras.innerHTML = `
      <div class="px-plan-extra">
        <span class="px-plan-extra-icon">◆</span>
        <span>NVMe SSD</span>
      </div>
      <div class="px-plan-extra">
        <span class="px-plan-extra-icon">∞</span>
        <span>Unlimited traffic</span>
      </div>
      <div class="px-plan-extra">
        <span class="px-plan-extra-icon">↯</span>
        <span>2 Gbps public bandwidth</span>
      </div>
    `;

    pricing.insertAdjacentElement('afterend', extras);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addPlanExtras);
  } else {
    addPlanExtras();
  }
})();
