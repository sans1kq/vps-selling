/* PulsarX background v3.3.5 — adaptive. */
(function(){
  'use strict';
  if(document.getElementById('px-grid-bg')) return;
  const mobile=matchMedia('(max-width:820px), (pointer:coarse)').matches;
  const reduced=matchMedia('(prefers-reduced-motion:reduce)').matches;
  const lowPower=(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4)||(navigator.deviceMemory&&navigator.deviceMemory<=4);

  const wrap=document.createElement('div');
  wrap.id='px-grid-bg';
  wrap.setAttribute('aria-hidden','true');
  wrap.innerHTML='<div class="grid"></div><div class="squares"></div><div class="fade"></div>';
  document.body.prepend(wrap);

  if(!mobile && !lowPower && !reduced){
    const host=wrap.querySelector('.squares');
    const data=[
      [7,15,28,16,-30,19],[18,72,40,-20,-36,25],[31,34,20,28,24,22],[45,84,34,-18,-42,29],
      [58,20,48,24,30,31],[68,62,24,-28,-24,21],[79,79,38,20,-38,27],[89,28,22,-22,30,23],
      [12,48,18,26,20,18],[52,52,54,-16,28,34],[92,58,30,-30,-18,26],[73,8,19,18,26,20]
    ];
    data.forEach((v,i)=>{
      const el=document.createElement('i');
      el.className='sq'+(i%4===0?' alt':'');
      el.style.left=v[0]+'%';el.style.top=v[1]+'%';
      el.style.setProperty('--s',v[2]+'px');el.style.setProperty('--dx',v[3]+'px');el.style.setProperty('--dy',v[4]+'px');el.style.setProperty('--d',v[5]+'s');
      el.style.animationDelay=(-(i*1.7))+'s';host.appendChild(el);
    });

    let raf=0,x=0,y=0;
    addEventListener('pointermove',e=>{
      x=((e.clientX/innerWidth)-.5)*14;y=((e.clientY/innerHeight)-.5)*12;
      if(raf)return;
      raf=requestAnimationFrame(()=>{wrap.style.setProperty('--px-grid-x',x.toFixed(1)+'px');wrap.style.setProperty('--px-grid-y',y.toFixed(1)+'px');raf=0;});
    },{passive:true});
  }
})();
