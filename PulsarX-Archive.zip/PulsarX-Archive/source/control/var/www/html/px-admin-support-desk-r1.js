/* PulsarX Support web r1: visible Telegram rejection causes and explicit safe retries. */
(() => {
  'use strict';
  const bar=document.querySelector('.tabbar'),content=document.querySelector('.content');
  if(!bar||!content||!document.getElementById('tab-overview')||document.getElementById('tab-support'))return;
  const tab=document.createElement('button');tab.type='button';tab.className='tab-item';tab.dataset.tab='support';tab.textContent='Поддержка';bar.append(tab);
  const panel=document.createElement('div');panel.className='tab-panel';panel.id='tab-support';
  panel.innerHTML=`<div class="ps-header"><div><h2>Поддержка</h2><p>Обращения с сайта и из Telegram. Почта остаётся отдельным каналом.</p><p id="psAlerts"></p></div><span id="psWorker">Проверяем соединение…</span></div>
  <p class="ps-notice" id="psIdentity">Личность в Telegram не подтверждена. Перед изменением VPS, доступа или оплаты подтвердите владельца аккаунта.</p>
  <div id="psError" class="ps-error" role="status"></div>
  <div class="ps-layout"><section class="panel ps-inbox"><div class="ps-filters"><select id="psFilter" aria-label="Статус обращения"><option value="open">Открытые</option><option value="closed">Закрытые</option><option value="all">Все обращения</option></select><input id="psSearch" placeholder="Имя, @ник или номер обращения" aria-label="Поиск обращений"><button type="button" class="btn btn-small" id="psRefresh">Обновить</button></div><div id="psTickets" class="ps-ticket-list"></div><button type="button" class="btn btn-small" id="psMoreTickets" hidden>Ещё обращения</button></section>
  <section class="panel ps-thread"><div id="psThreadTitle" class="ps-thread-title">Выберите обращение</div><button type="button" class="btn btn-small" id="psOlder" hidden>Ранние сообщения</button><div id="psMessages" class="ps-messages"><p class="ps-empty">Здесь появятся сообщения и вложения клиента.</p></div><form id="psReply" hidden><label for="psText">Ответ клиенту</label><textarea id="psText" maxlength="4000" rows="4" placeholder="Напишите ответ…" required></textarea><div class="ps-reply-actions"><button type="button" class="btn btn-small" id="psState">Закрыть обращение</button><button type="submit" class="btn" id="psSend">Отправить ответ</button></div><p class="ps-muted">Ответ на сайте сразу появится в кабинете клиента. Для Telegram проверяйте статус доставки бота.</p></form></section></div>`;
  content.append(panel);
  const el=id=>document.getElementById(id);
  let selected=null,currentTicket=null,moreTickets=null,older=null,busyList=false,busyThread=false,busySend=false,stopped=false,searchTimer;
  let replies=new Map(),pendingReply=null,initializedThread=false;
  const token=()=>localStorage.getItem('pulsarx_admin_token');
  const visible=()=>panel.classList.contains('active')&&!document.hidden;
  const fail=e=>{el('psError').textContent=e.message||'Не удалось загрузить поддержку. Повторите запрос.';};
  const stamp=n=>new Date(n*1000).toLocaleString();
  async function api(path,options={}){
    const authToken=token();if(!authToken||stopped)throw new Error('Войдите в панель администратора заново.');
    const response=await fetch('/api/admin/support'+path,{...options,cache:'no-store',headers:{...options.headers,Authorization:'Bearer '+authToken}});
    if(token()!==authToken)throw new Error('Сессия администратора изменилась. Обновите страницу.');
    if([401,403,422].includes(response.status)&&response.status!==422){stopped=true;location.href='/adminlogin/';throw new Error('Сессия администратора завершена.');}
    if(!response.ok)throw new Error(response.status===409?'Обращение изменилось. Обновите его перед ответом.':'Ошибка запроса поддержки ('+response.status+').');
    const value=await response.json();if(token()!==authToken)throw new Error('Сессия администратора изменилась. Обновите страницу.');return value;
  }
  async function loadList(append=false){
    if(busyList||!token()||stopped)return;busyList=true;
    try{
      const params=new URLSearchParams({status:el('psFilter').value,q:el('psSearch').value.trim()});
      if(append&&moreTickets)params.set('before',String(moreTickets));
      const data=await api('?'+params);if(!Array.isArray(data.tickets))throw new Error('Неожиданный ответ списка обращений.');
      if(!append)el('psTickets').replaceChildren();
      for(const t of data.tickets){
        const b=document.createElement('button');b.type='button';b.className='ps-ticket'+(t.id===selected?' is-selected':'')+(t.unread?' is-unread':'');b.dataset.ticket=String(t.id);
        const head=document.createElement('strong');head.textContent='#'+t.id+' · '+(t.subject||t.name);
        const sub=document.createElement('span');sub.textContent=(t.channel==='web'?'Сайт · '+t.name+' · ':'Telegram · '+(t.username?'@'+t.username+' · ':''))+t.status+' · '+stamp(t.updated);
        b.append(head,sub);b.addEventListener('click',()=>choose(t.id));el('psTickets').append(b);
      }
      if(!el('psTickets').children.length){const p=document.createElement('p');p.className='ps-empty';p.textContent='Подходящих обращений нет.';el('psTickets').append(p);}
      moreTickets=data.next_before;el('psMoreTickets').hidden=!moreTickets;
      tab.textContent='Поддержка'+(data.unread?' · '+data.unread:'');
      const healthy=!data.worker_error&&Date.now()/1000-data.poll_at<60;
      el('psWorker').textContent=healthy?'Бот подключён':('Бот требует проверки'+(data.worker_error?' · '+data.worker_error:''));
      el('psWorker').className=healthy?'ps-online':'ps-error';el('psError').textContent='';
      const alerts=data.notifications||{};
      el('psAlerts').textContent=alerts.enabled?'Личные уведомления Telegram: включены · '+(alerts.username?'@'+alerts.username:alerts.name||'linked account'):'Личные уведомления Telegram: выключены';
      if(alerts.last_delivery)el('psAlerts').textContent+=' · Последнее уведомление: '+alerts.last_delivery+(alerts.last_error?' · '+reason(alerts.last_error):'');
    }catch(e){fail(e);el('psWorker').textContent='Соединение недоступно';}finally{busyList=false;}
  }
  function choose(id){
    if(selected===id)return;
    if(el('psText').value.trim()&&!window.confirm('Удалить неотправленный черновик и открыть другое обращение?'))return;
    selected=id;currentTicket=null;replies=new Map();pendingReply=null;initializedThread=false;el('psText').value='';
    el('psThreadTitle').textContent='Загружаем обращение #'+id+'…';el('psReply').hidden=true;el('psMessages').replaceChildren();
    document.querySelectorAll('.ps-ticket').forEach(b=>b.classList.toggle('is-selected',Number(b.dataset.ticket)===id));loadThread();
  }
  const delivery={available:'Доступно на сайте',queued:'В очереди',sending:'Отправляется…',sent:'Отправлено',failed:'Ошибка доставки',unknown:'Доставка не подтверждена — проверьте перед повтором',received:'Получено'};
  function reason(error){
    const key=String(error||'').split(':')[0];
    const labels={bot_blocked_by_user:'Пользователь заблокировал бота. Для получения ответа ему нужно разблокировать бота.',recipient_deactivated:'Аккаунт получателя удалён или деактивирован.',chat_not_started:'Получателю нужно открыть бота и нажать Start.',chat_not_found:'Telegram не находит чат получателя. Ему нужно снова открыть бота и написать сообщение.',invalid_bot_token:'Telegram отклонил токен бота. Требуется проверить настройку токена на сервере.',telegram_forbidden:'Telegram запретил отправку в этот чат.',telegram_bad_request:'Telegram отклонил параметры сообщения.',chat_topic_unavailable:'Telegram не находит тему чата получателя.',message_too_long:'Сообщение слишком длинное.',empty_message:'Текст сообщения пуст.',rate_limited:'Telegram ограничил частоту отправки.',telegram_service_unavailable:'Сервис Telegram временно недоступен.',network_or_response_error:'Нет подтверждения доставки из-за ошибки связи. Не повторяйте вслепую.',worker_restarted_during_send:'Сервис перезапустился во время отправки; результат не подтверждён.',telegram_http_error:'В старой записи нет точной причины. Повторите один ответ, чтобы получить её.',polling_conflict:'С этим ботом уже работает другой получатель обновлений.'};
    const detail=String(error||'').split(':').slice(2).join(':');
    if(detail&&['telegram_bad_request','telegram_http_error','telegram_forbidden','chat_topic_unavailable'].includes(key))return (labels[key]||'Telegram отклонил сообщение.')+' '+detail;
    return labels[key]||'Отправка не подтверждена. Проверьте состояние бота.';
  }
  function renderMessages(){
    const box=el('psMessages'),atBottom=box.scrollHeight-box.scrollTop-box.clientHeight<80,oldHeight=box.scrollHeight;
    box.replaceChildren();
    for(const m of [...replies.values()].sort((a,b)=>a.id-b.id)){
      const item=document.createElement('article');item.className='ps-message ps-'+m.direction;
      const meta=document.createElement('div');meta.className='ps-message-meta';meta.textContent=(m.direction==='in'?'Клиент':m.direction==='out'?'Поддержка':'Бот')+' · '+stamp(m.created);
      const body=document.createElement('div');body.className='ps-message-body';body.textContent=m.body;item.append(meta,body);
      for(const f of m.attachments||[]){
        const b=document.createElement('button');b.type='button';b.className='btn btn-small ps-file';b.textContent=f.name+' · '+(f.status==='ready'?'Скачать':f.status==='pending'?'Готовится…':f.status==='too_large'?'Больше 10 MB':'Файл недоступен');b.disabled=f.status!=='ready';
        b.addEventListener('click',()=>download(f));item.append(b);
      }
      if(m.direction!=='in'){
        const state=document.createElement('div');state.className='ps-delivery ps-'+m.delivery;state.textContent=(delivery[m.delivery]||m.delivery)+(m.error?' · '+reason(m.error):'');item.append(state);
        if(m.direction==='out'&&m.delivery==='failed'&&currentTicket?.status==='open'){
          const retry=document.createElement('button');retry.type='button';retry.className='btn btn-small ps-file ps-retry';retry.textContent='Повторить отправку';retry.disabled=busySend;
          retry.addEventListener('click',()=>retryMessage(m.id,retry));item.append(retry);
        }
      }
      box.append(item);
    }
    if(atBottom||!oldHeight)box.scrollTop=box.scrollHeight;
  }
  async function loadThread(past=false){
    if(!selected||busyThread||stopped)return;busyThread=true;const id=selected;
    try{
      const data=await api('/'+id+(past&&older?'?before='+older:''));if(selected!==id)return;
      if(!data.ticket||!Array.isArray(data.messages))throw new Error('Неожиданный ответ обращения.');
      currentTicket=data.ticket;
      el('psIdentity').textContent=data.ticket.channel==='web'?'Обращение с сайта: подтверждённая сессия PulsarX · '+data.ticket.name+' · ID аккаунта '+data.ticket.web_user_id:'Личность в Telegram не подтверждена. Перед изменением VPS, доступа или оплаты подтвердите владельца аккаунта.';
      el('psThreadTitle').textContent='#'+id+' · '+(data.ticket.subject?data.ticket.subject+' · ':'')+data.ticket.name+(data.ticket.username?' · @'+data.ticket.username:'')+' · '+data.ticket.status;
      for(const m of data.messages)replies.set(m.id,m);
      if(past||!initializedThread){older=data.next_before;initializedThread=true;}
      el('psOlder').hidden=!older;
      renderMessages();el('psReply').hidden=false;
      el('psState').textContent=data.ticket.status==='open'?'Закрыть обращение':'Открыть обращение снова';
      el('psSend').disabled=data.ticket.status!=='open'||busySend;el('psText').disabled=data.ticket.status!=='open';
    }catch(e){fail(e);}finally{busyThread=false;if(selected!==id)loadThread();}
  }
  async function download(file){
    try{
      const authToken=token();if(!authToken)throw new Error('Войдите заново.');
      const r=await fetch('/api/admin/support/files/'+file.id+'/download',{cache:'no-store',headers:{Authorization:'Bearer '+authToken}});
      if(!r.ok||token()!==authToken)throw new Error('Не удалось скачать вложение.');
      const objectUrl=URL.createObjectURL(await r.blob());const a=document.createElement('a');a.href=objectUrl;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);
    }catch(e){fail(e);}
  }
  async function retryMessage(messageId,button){
    if(busySend||!selected||currentTicket?.status!=='open')return;
    const id=selected;busySend=true;button.disabled=true;el('psSend').disabled=true;
    try{await api('/messages/'+messageId+'/retry',{method:'POST'});if(selected===id)await loadThread();}
    catch(e){fail(e);}
    finally{busySend=false;button.disabled=false;el('psSend').disabled=currentTicket?.status!=='open';document.querySelectorAll('.ps-retry').forEach(n=>n.disabled=currentTicket?.status!=='open');}
  }
  tab.addEventListener('click',()=>{document.querySelectorAll('.tab-item,.tab-panel').forEach(n=>n.classList.remove('active'));tab.classList.add('active');panel.classList.add('active');loadList();loadThread();});
  el('psRefresh').addEventListener('click',()=>{loadList();loadThread();});
  el('psFilter').addEventListener('change',()=>loadList());
  el('psSearch').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadList(),350);});
  el('psMoreTickets').addEventListener('click',()=>loadList(true));el('psOlder').addEventListener('click',()=>loadThread(true));
  el('psState').addEventListener('click',async()=>{
    if(!currentTicket||busySend)return;const id=selected,newState=currentTicket.status==='open'?'closed':'open';
    try{await api('/'+id+'/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:newState})});await loadThread();await loadList();}catch(e){fail(e);}
  });
  el('psReply').addEventListener('submit',async e=>{
    e.preventDefault();const body=el('psText').value.trim(),id=selected;if(!body||!id||busySend||!currentTicket||currentTicket.status!=='open')return;
    if(!pendingReply||pendingReply.text!==body||pendingReply.ticket!==id)pendingReply={text:body,ticket:id,request_id:crypto.randomUUID()};
    busySend=true;el('psSend').disabled=true;el('psText').disabled=true;
    try{
      await api('/'+id+'/reply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:pendingReply.text,request_id:pendingReply.request_id})});
      if(selected===id){el('psText').value='';pendingReply=null;await loadThread();}
    }catch(err){fail(err);}finally{busySend=false;el('psSend').disabled=currentTicket?.status!=='open';el('psText').disabled=currentTicket?.status!=='open';}
  });
  setInterval(()=>{if(visible()){loadList();loadThread();}},15000);
  const target=new URLSearchParams(location.search||'').get('support_ticket');
  if(target&&/^[1-9][0-9]{0,12}$/.test(target)){tab.click();choose(Number(target));}
})();
