/* Presentation only: legal navigation/languages and accessible admin tabs. */
(() => {
  'use strict';
  const kind=document.body.dataset.pagesKind;
  if(kind==='terms'||kind==='privacy'){
    const P=window.Pulse;
    if(!P)return; // With JavaScript unavailable, all three document versions remain readable.
    P.merge({pagesDocuments:['Документы','Documents','Documente'],pagesOnThisPage:['На этой странице','On this page','Pe această pagină'],pagesQuestions:['Есть вопрос? Написать в поддержку ↗','Questions? Contact support ↗','Ai întrebări? Contactează asistența ↗'],skipContent:['К содержимому','Skip to content','Sari la conținut']});
    function render(){
      const lang=P.getLang();
      const blocks=Array.from(document.querySelectorAll('.terms-block[data-lang]'));
      const active=blocks.find(block=>block.dataset.lang===lang);
      if(!active)return;
      blocks.forEach(block=>{const on=block===active;block.hidden=!on;block.classList.toggle('active',on);block.setAttribute('aria-hidden',String(!on));});
      const title=active.querySelector('h1');if(title)document.title='PulsarX Cloud — '+title.textContent;
      document.querySelectorAll('.doc-switch').forEach(link=>{
        link.href='/'+link.dataset.document+'/?lang='+lang;
        if(link.dataset.document===kind)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');
      });
      const toc=document.getElementById('documentToc');toc.replaceChildren();
      active.querySelectorAll('h2').forEach((heading,index)=>{
        if(!heading.id)heading.id='document-'+lang+'-'+index;
        const link=document.createElement('a');link.href='#'+heading.id;link.textContent=heading.textContent;
        toc.appendChild(link);
      });
      document.querySelectorAll('.site-footer a[href]').forEach(link=>{
        let url;try{url=new URL(link.getAttribute('href'),document.baseURI);}catch{return;}
        if(url.origin===location.origin&&['/terms/','/privacy/'].includes(url.pathname)){url.searchParams.set('lang',lang);link.href=url.pathname+url.search;}
      });
      P.apply();
    }
    document.addEventListener('px:lang',render);render();
  }
  if(kind==='admin'){
    const bar=document.querySelector('.tabbar'),ready=new WeakSet();
    if(!bar)return;
    const paths={overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',billing:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h3"/>',instances:'<rect x="4" y="3" width="16" height="7" rx="2"/><rect x="4" y="14" width="16" height="7" rx="2"/><path d="M8 6h.01M8 17h.01M13 6h4M13 17h4"/>',support:'<path d="M5 12a7 7 0 0 1 14 0M3 12h4v7H3zm14 0h4v7h-4zM19 19c0 2-3 2-6 2"/>',giftcodes:'<path d="M3 8h18v4H3zm2 4v9h14v-9M12 8v13"/><path d="M12 8C4 8 5 1 9 3c2 1 3 5 3 5zm0 0c8 0 7-7 3-5-2 1-3 5-3 5z"/>'};
    const vertical=()=>!matchMedia('(max-width:700px)').matches;
    function decorate(){
      bar.setAttribute('role','tablist');bar.setAttribute('aria-orientation',vertical()?'vertical':'horizontal');
      const tabs=Array.from(bar.querySelectorAll('.tab-item'));
      tabs.forEach(tab=>{
        const key=tab.dataset.tab;if(!key)return;
        if(!tab.id)tab.id='admin-tab-'+key;
        tab.setAttribute('role','tab');tab.setAttribute('aria-controls','tab-'+key);
        tab.setAttribute('aria-selected',String(tab.classList.contains('active')));tab.tabIndex=tab.classList.contains('active')?0:-1;
        const panel=document.getElementById('tab-'+key);
        if(panel){panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',tab.id);}
        if(!tab.querySelector('.admin-nav-icon')){
          const icon=document.createElement('span');icon.className='admin-nav-icon';icon.setAttribute('aria-hidden','true');
          icon.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+(paths[key]||paths.overview)+'</svg>';tab.prepend(icon);
        }
        if(!ready.has(tab)){
          ready.add(tab);
          tab.addEventListener('keydown',event=>{
            const current=Array.from(bar.querySelectorAll('.tab-item')),i=current.indexOf(tab);let next;
            if(event.key==='ArrowDown'||event.key==='ArrowRight')next=(i+1)%current.length;
            if(event.key==='ArrowUp'||event.key==='ArrowLeft')next=(i+current.length-1)%current.length;
            if(event.key==='Home')next=0;if(event.key==='End')next=current.length-1;
            if(next!==undefined){event.preventDefault();current[next].click();current[next].focus();}
            if((event.key==='Enter'||event.key===' ')&&tab.tagName!=='BUTTON'){event.preventDefault();tab.click();}
          });
        }
      });
      const active=tabs.find(tab=>tab.classList.contains('active')),title=document.getElementById('adminSectionTitle');
      if(active&&title){const copy=active.cloneNode(true);copy.querySelectorAll('.tab-count,.admin-nav-icon').forEach(n=>n.remove());title.textContent=copy.textContent.trim();}
    }
    decorate();
    new MutationObserver(decorate).observe(bar,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
    window.addEventListener('resize',decorate);
  }
})();
