/* Show verified configured bot contact; email remains usable without JavaScript. */
(() => {
  'use strict';
  if(document.querySelector('.ps-public-contact'))return;
  fetch('/api/support/contact',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(data=>{
    if(!data||!/^[A-Za-z0-9_]{5,32}$/.test(data.username))return;
    const node=document.createElement('div');node.className='ps-public-contact';node.setAttribute('aria-label','Support contacts');
    const email=document.createElement('a');email.href='mailto:contact@example.invalid';email.textContent='contact@example.invalid';
    const telegram=document.createElement('a');telegram.href='https://t.me/'+data.username;telegram.textContent='Telegram · @'+data.username;telegram.target='_blank';telegram.rel='noopener noreferrer';
    node.append(email,telegram);document.body.append(node);
  }).catch(()=>{});
})();
