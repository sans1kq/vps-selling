(()=>{'use strict';const $=id=>document.getElementById(id),tg=window.Telegram?.WebApp;
const init=tg?.initData||new URLSearchParams(location.hash.slice(1)).get('tgWebAppData');
let pairing,invoice,q,draft,key,revision=0,busy=false;
const msg=x=>{$('msg').textContent=x};
async function api(path,body){const r=await fetch('/api/telegram/mini/'+path,{method:body?'POST':'GET',credentials:'omit',cache:'no-store',headers:{'X-Px-Init':init,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const o=await r.json();if(!r.ok)throw Error(typeof o.detail==='string'?o.detail:'Не удалось выполнить запрос.');return o}
function action(id,fn){$(id).onclick=async()=>{if(busy)return;busy=true;$(id).disabled=true;try{msg('');await fn()}catch(e){msg(e.message)}finally{busy=false;$(id).disabled=false}}}
async function status(){const me=await api('me');$('pair').hidden=me.linked;$('wallet').hidden=!me.linked;$('account').textContent=me.linked?me.email+' · Баланс: $'+(me.balance_cents/100).toFixed(2):'Ваш Telegram ID: '+me.telegram_id;}
function reset(){revision++;q=null;invoice=null;key=null;$('review').hidden=true;$('agree').checked=false}
for(const id of ['plan','months','amount','ref'])$(id).oninput=()=>{if(id==='amount')$('plan').value='';reset()};
for(const b of $('picks').children)b.onclick=()=>{$('amount').value=b.textContent;$('plan').value='';reset()};
action('get',async()=>{if(!$('email').value||!$('email').reportValidity())return;pairing=(await api('request',{email:$('email').value})).id;$('step').hidden=false;msg('Если аккаунт существует, код появится в открытом кабинете.');});
action('confirm',async()=>{await api('confirm',{id:pairing,code:$('pin').value});await status();msg('Telegram привязан.')});
action('refresh',status);
action('quote',async()=>{reset();const rev=revision;draft={apply_referral:$('ref').checked,...($('plan').value?{plan_key:$('plan').value,months:Number($('months').value)}:{amount_cents:Math.round(Number($('amount').value)*100)})};const result=await api('quote',draft);if(rev!==revision)return;q=result;key=crypto.randomUUID();$('amount').value=(q.credit_cents/100).toFixed(2);$('total').textContent='На баланс: $'+$('amount').value+' · К оплате: '+q.stars+' ⭐ (наценка 30% учтена)';$('review').hidden=false});
action('pay',async()=>{if(!q||!$('agree').checked)throw Error('Проверьте сумму и примите условия.');const rev=revision;const result=invoice||await api('invoice',{...draft,request_key:key,expected_stars:q.stars,expected_credit_cents:q.credit_cents,accepted_terms:true});if(rev!==revision)return;invoice=result;if(!tg?.openInvoice){location.assign(invoice.url);return}tg.openInvoice(invoice.url,async state=>{if(state==='paid'||state==='pending'){reset();msg('Проверяем зачисление…');try{await status();msg('Если баланс ещё не обновился, нажмите «Обновить баланс».')}catch(e){msg(e.message)}}});});
if(!init){msg('Откройте приложение кнопкой в @PulsarXPayBot.');return}
tg?.ready();tg?.expand();status().then(()=>msg('')).catch(e=>msg(e.message));
})();
