(() => {
  'use strict';
  const el = id => document.getElementById(id);
  const tg = window.Telegram?.WebApp;
  const init = tg?.initData || new URLSearchParams(location.hash.slice(1)).get('tgWebAppData');
  const translations = {
    "Поддержка ↗": "Support ↗",
    "Пополнение баланса": "Wallet top-up",
    "Подключение к кошельку": "Connecting to your wallet",
    "Проверяем аккаунт Telegram…": "Checking your Telegram account…",
    "Откройте кошелёк в Telegram": "Open your wallet in Telegram",
    "В чате платёжного бота нажмите Start, затем «Открыть кошелёк».": "In the payment bot chat, press Start and then open the wallet.",
    "Перейти к боту ↗": "Open bot ↗",
    "В личный кабинет": "Go to dashboard",
    "Привязка аккаунта": "Link your account",
    "Введите почту своего аккаунта PulsarX. Код появится в открытом личном кабинете.": "Enter your PulsarX email. Your code will appear in your PulsarX dashboard.",
    "Электронная почта": "Email address",
    "Получить код": "Get code",
    "Откройте": "Open your",
    "личный кабинет": "dashboard",
    "и введите код в течение пяти минут.": "and enter the code within five minutes.",
    "Восьмизначный код": "Eight-digit code",
    "Подтвердить привязку": "Confirm account link",
    "Запросить код снова": "Request another code",
    "Сумма пополнения": "Top-up amount",
    "Зачислить на баланс": "Amount to add",
    "Быстрый выбор суммы": "Preset amounts",
    "Рассчитать по тарифу": "Calculate by server plan",
    "Тариф": "Plan",
    "Своя сумма": "Custom amount",
    "Срок": "Term",
    "1 месяц": "1 month",
    "3 месяца": "3 months",
    "6 месяцев": "6 months",
    "12 месяцев": "12 months",
    "Применить реферальную скидку": "Apply referral discount",
    "Рассчитать в Stars": "Calculate in Stars",
    "Детали пополнения": "Top-up details",
    "Детали платежа": "Payment details",
    "Расчёт": "Estimate",
    "К оплате в Telegram": "Pay in Telegram",
    "На баланс": "Wallet credit",
    "Текущий баланс": "Current balance",
    "Счёт действует ещё": "Invoice expires in",
    "В сумму Stars включена наценка способа 30%.": "The Stars total includes the 30% payment method markup.",
    "Принимаю": "I accept the",
    "условия оплаты": "payment terms",
    "Оплатить в Telegram": "Pay with Telegram",
    "Открыть счёт": "Open invoice",
    "Другой способ открыть счёт": "Other ways to open this invoice",
    "Открыть счёт в браузере ↗": "Open invoice in browser ↗",
    "Или скопируйте ссылку в «Избранное» Telegram и откройте на телефоне под тем же аккаунтом.": "Or send the link to your Telegram Saved Messages and open it on your phone with the same account.",
    "Ссылка на счёт": "Invoice link",
    "Скопировать ссылку": "Copy link",
    "Обновить статус": "Refresh status",
    "Повторить подключение": "Retry connection",
    "Кошелёк PulsarX": "PulsarX Wallet",
    "Подготовлен": "Ready",
    "Ждёт оплаты": "Awaiting payment",
    "Проверьте счёт": "Check invoice",
    "Обработка": "Processing",
    "На проверке": "Under review",
    "Зачислено": "Credited",
    "Возвращено": "Refunded",
    "Истёк": "Expired",
    "Рассчитано": "Quoted",
    "Текущий счёт": "Current invoice",
    "Telegram обрабатывает платёж. Если подтверждение задерживается, обратитесь в поддержку с номером счёта ": "Telegram is processing the payment. If confirmation is delayed, contact support with invoice ID ",
    "Счёт на ": "Your invoice for ",
    " сохранён. Вернитесь к оплате до окончания таймера.": " is saved. Complete payment before it expires.",
    "Срок счёта закончился. Если вы уже оплатили, дождитесь зачисления или обратитесь в поддержку.": "This invoice has expired. If you already paid, wait for the credit or contact support.",
    "Ожидаем подтверждение Telegram. Баланс обновится автоматически.": "Waiting for Telegram confirmation. Your balance will update automatically.",
    "Средства зачислены на баланс PulsarX.": "The funds have been added to your PulsarX balance.",
    "Срок оплаты истёк. Можно рассчитать новое пополнение.": "The invoice has expired. You can start a new top-up.",
    "Не удалось выполнить запрос. Проверьте соединение и повторите.": "Request failed. Check your connection and try again.",
    "Баланс ограничен. Обратитесь в поддержку.": "Your wallet is restricted. Please contact support.",
    "Telegram привязан.": "Telegram account linked.",
    "Получена некорректная ссылка на счёт.": "The invoice link is invalid.",
    "Проверяем зачисление…": "Checking payment…",
    "Ожидаем подтверждение Telegram.": "Waiting for Telegram confirmation.",
    "Оплата отменена. Можно открыть этот же счёт.": "Payment was cancelled. You can reopen the same invoice.",
    "Платёж не завершён. Проверьте статус счёта.": "Payment was not completed. Check the invoice status.",
    "Средства зачислены.": "Funds credited.",
    "Ссылка скопирована.": "Link copied.",
    "Скопируйте выделенную ссылку.": "Copy the selected link.",
    "Код неверен, истёк или аккаунт уже привязан.": "The code is incorrect, has expired, or the account is already linked.",
    "Закройте и снова откройте мини-приложение через бота.": "Close the Mini App and reopen it from the bot.",
    "Stars пока не подключён. Выберите другой способ оплаты.": "Stars is unavailable. Choose another payment method.",
    "Telegram временно недоступен. Проверьте статус операции перед повтором.": "Telegram is unavailable. Check the invoice status before trying again.",
    "Неверный тариф или период.": "Invalid plan or term.",
    "Пополнение Stars: от $1 до $100.": "Enter a Stars top-up from $1 to $100.",
    "Проверьте условия.": "Review the payment terms.",
    "Реферальная скидка недоступна.": "The referral discount is unavailable.",
    "Реферальная скидка уже использована или зарезервирована.": "The referral discount has already been used or reserved.",
    "Сначала завершите или отмените другое пополнение.": "Complete or cancel your existing top-up first.",
    "Уже есть счёт Stars. Проверьте его статус.": "You already have a Stars invoice. Check its status.",
    "Требуется привязка.": "Link your account first.",
    "Счёт закрыт или уже обрабатывается.": "The invoice is closed or is already being processed.",
    "Счёт не найден.": "Invoice not found.",
    "Цена изменилась. Обновите расчёт.": "The price changed. Request a new quote.",
    "Укажите сумму пополнения.": "Enter a top-up amount.",
    "Обновите счёт.": "Refresh the invoice.",
    "Не удалось получить ссылку на счёт.": "Could not obtain an invoice link.",
    "Баланс ограничен.": "Your wallet is restricted.",
    "Сначала привяжите Telegram.": "Link Telegram first.",
    "Этот запрос уже использован для другой суммы.": "This request was already used for a different amount.",
    "Выберите способ открытия готового счёта ниже.": "Choose how to open your saved invoice below."
};
  let lang = 'en';
  try { if (localStorage.getItem('px-mini-language') === 'ru') lang = 'ru'; } catch {}
  const t = key => lang === 'en' ? translations[key] || key : key;
  const original = new Map(Object.entries(translations).map(([ru,en])=>[en,ru]));
  const staticText = [];
  const walker = document.createTreeWalker(document.querySelector('main'), NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const key = original.get(node.data.trim());
    if (key) staticText.push([node,key,node.data]);
  }
  function translatePage() {
    document.documentElement.lang = lang;
    el('language').value = lang;
    for (const [node,key,english] of staticText) {
      node.data = english.replace(english.trim(),t(key));
    }
    el('picks').setAttribute('aria-label',t('Быстрый выбор суммы'));
    el('receipt').setAttribute('aria-label',t('Детали пополнения'));
  }
  translatePage();
  const pending = invoice => ['created','sent','approved','send_unknown'].includes(invoice?.state);
  const labels = {created:'Подготовлен', sent:'Ждёт оплаты', send_unknown:'Проверьте счёт', approved:'Обработка', awaiting_receipt:'На проверке', paid:'Зачислено', refunded:'Возвращено', expired:'Истёк'};
  const money = cents => '$' + (cents / 100).toFixed(2);
  const show = (id, visible) => { el(id).hidden = !visible; };
  let lastMessage = '';
  const message = text => { lastMessage=text; el('msg').textContent=t(text); };
  let account, quote, draft, requestKey, pairId, busy = false, checking = false;
  let revision = 0, clockOffset = 0, edited = false, nativeOpen = false;

  async function api(path, body) {
    const response = await fetch('/api/telegram/mini/' + path, {
      method: body === undefined ? 'GET' : 'POST', credentials:'omit', cache:'no-store',
      headers:{'X-Px-Init':init, 'Content-Type':'application/json'},
      body:JSON.stringify(body)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(typeof data.detail === 'string' ? data.detail : 'Не удалось выполнить запрос. Проверьте соединение и повторите.');
    return data;
  }
  function displayInvoice() {
    return pending(account?.invoice) || !edited ? account?.invoice : null;
  }
  function tick() {
    const inv = account?.invoice;
    const timed = pending(inv) && inv.state !== 'approved';
    show('timeRow', timed);
    if (!timed) return;
    const seconds = Math.max(0, Math.ceil((Date.parse(inv.expires_at) - Date.now() - clockOffset) / 1000));
    el('clock').textContent = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2,'0');
    el('resume').disabled = seconds === 0 || busy || nativeOpen || account.frozen;
  }
  function render() {
    const inv = displayInvoice(), value = inv || quote, active = pending(inv);
    const state = inv?.state || '';
    show('draft',!active); show('pendingInfo',active);
    el('draftTitle').textContent = active ? t('Текущий счёт') : t('Сумма пополнения');
    if (active) el('pendingInfo').textContent = state === 'approved'
      ? t('Telegram обрабатывает платёж. Если подтверждение задерживается, обратитесь в поддержку с номером счёта ') + inv.id + '.'
      : t('Счёт на ') + money(inv.credit_cents) + t(' сохранён. Вернитесь к оплате до окончания таймера.');
    el('badge').dataset.state = state;
    el('badge').textContent = t(labels[state]) || (quote ? t('Рассчитано') : t('Расчёт'));
    el('total').textContent = value ? value.stars.toLocaleString(lang) : '—';
    el('credit').textContent = value ? money(value.credit_cents) : '—';
    el('hint').textContent = state === 'awaiting_receipt' ? t('Срок счёта закончился. Если вы уже оплатили, дождитесь зачисления или обратитесь в поддержку.')
      : state === 'approved' ? t('Ожидаем подтверждение Telegram. Баланс обновится автоматически.')
      : state === 'paid' ? t('Средства зачислены на баланс PulsarX.')
      : state === 'expired' ? t('Срок оплаты истёк. Можно рассчитать новое пополнение.')
      : t('В сумму Stars включена наценка способа 30%.');
    const handoff = el('handoff');
    const transferable = active && state !== 'approved' && inv.id === handoff.dataset.invoice && Date.parse(inv.expires_at) > Date.now()+clockOffset;
    show('handoff',transferable);
    if (!transferable) handoff.open = false;
    show('review', Boolean(quote) && !active);
    show('resume', active && state !== 'approved');
    show('balanceRow', Boolean(account?.linked));
    show('refresh', Boolean(account?.linked));
    el('pay').disabled = !el('agree').checked || !quote || busy || nativeOpen;
    for (const node of el('draft').elements) node.disabled = busy || active || Boolean(account?.frozen);
    if (!active && !busy && !account?.frozen) {
      el('months').disabled = !el('plan').value;
      el('amount').disabled = Boolean(el('plan').value);
    }
    for (const b of el('picks').children) b.setAttribute('aria-pressed', String(!el('plan').value && Number(el('amount').value) === Number(b.dataset.amount)));
    tick();
  }
  async function status() {
    const me = await api('me');
    account = me;
    if (me.server_time) clockOffset = Date.parse(me.server_time) - Date.now();
    show('loading', false); show('retry', false); show('pair', !me.linked); show('wallet', me.linked);
    el('account').textContent = me.linked ? me.email : 'Telegram ID ' + me.telegram_id;
    if (me.linked) el('balance').textContent = money(me.balance_cents);
    if (me.frozen) message('Баланс ограничен. Обратитесь в поддержку.');
    render();
  }
  function action(id, event, fn) {
    el(id).addEventListener(event, async e => {
      e.preventDefault();
      if (busy || nativeOpen) return;
      busy = true; const button = e.submitter || e.currentTarget;
      button.disabled = true; message('');
      try { await fn(); }
      catch (error) { message(error.message); }
      finally { busy = false; button.disabled = false; render(); }
    });
  }
  function invalidate() {
    revision++; edited = true; quote = draft = requestKey = null;
    el('agree').checked = false; message(''); render();
  }
  el('draft').addEventListener('input', e => {
    if (e.target.id === 'amount') el('plan').value = '';
    invalidate();
  });
  for (const button of el('picks').children) button.onclick = () => {
    el('amount').value = button.dataset.amount; el('plan').value = ''; invalidate();
  };
  el('agree').onchange = render;
  el('pin').oninput = () => { el('pin').value = el('pin').value.replace(/\D/g,'').slice(0,8); };
  action('emailStep','submit',async () => {
    pairId = (await api('request',{email:el('email').value.trim()})).id;
    show('emailStep',false); show('step',true); el('pin').value = ''; el('pin').focus();
  });
  el('back').onclick = () => { if (!busy) { show('step',false); show('emailStep',true); el('email').focus(); } };
  action('step','submit',async () => {
    await api('confirm',{id:pairId,code:el('pin').value}); el('pin').value = '';
    await status(); message('Telegram привязан.');
  });
  action('draft','submit',async () => {
    invalidate();
    const serial = revision;
    draft = {...(el('plan').value
      ? {plan_key:el('plan').value, months:Number(el('months').value)}
      : {amount_cents:Math.round(Number(el('amount').value)*100)})};
    const value = await api('quote',draft);
    if (serial !== revision) return;
    quote = value; requestKey = crypto.randomUUID(); el('amount').value = (value.credit_cents / 100).toFixed(2);
    render(); el('receipt').scrollIntoView({block:'nearest'});
  });
  async function sync() {
    if (checking) return;
    checking = true;
    try { await status(); }
    catch (error) { message(error.message); if (!account) { show('loading',false); show('retry',true); } }
    finally { checking = false; }
  }
  async function openPayment(resume) {
    const inv = account?.invoice;
    if (!resume && (!quote || !el('agree').checked)) return;
    const desktop = ['tdesktop','macos','unigram','web','weba','webk'].includes(tg?.platform);
    const saved = resume && inv?.id === el('handoff').dataset.invoice && el('invoiceLink').value;
    let result;
    try {
      result = saved ? {id:inv.id,url:saved} : resume ? await api('invoices/'+encodeURIComponent(inv.id)+'/open',{})
        : await api('invoice',{...draft,request_key:requestKey,expected_stars:quote.stars,expected_credit_cents:quote.credit_cents,accepted_terms:true});
    } catch (error) { await sync(); throw error; }
    if (!/^https:\/\/t\.me\/[A-Za-z0-9_$-]+$/.test(result.url) && !/^https:\/\/t\.me\/invoice\/[A-Za-z0-9_-]+$/.test(result.url)) throw Error('Получена некорректная ссылка на счёт.');
    if (!resume) {
      account.invoice = {...quote,id:result.id,expires_at:result.expires_at,state:'sent'};
      quote = null; edited = false; el('agree').checked = false;
    }
    el('handoff').dataset.invoice = result.id;
    el('invoiceLink').value = result.url;
    el('browserInvoice').href = result.url;
    render();
    if (desktop && !saved) {
      el('handoff').open = true;
      message('Выберите способ открытия готового счёта ниже.');
      return;
    }
    if (tg?.openInvoice && tg.isVersionAtLeast?.('6.1')) {
      nativeOpen = true;
      try {
        tg.openInvoice(result.url, async state => {
          nativeOpen = false;
          if (state === 'failed') el('handoff').open = true;
          message(({paid:'Проверяем зачисление…',pending:'Ожидаем подтверждение Telegram.',cancelled:'Оплата отменена. Можно открыть этот же счёт.',failed:'Платёж не завершён. Проверьте статус счёта.'})[state] || '');
          await sync();
          if (account?.invoice?.state === 'paid') message('Средства зачислены.');
        });
      } catch (error) { nativeOpen = false; throw error; }
    } else if (tg?.openTelegramLink) tg.openTelegramLink(result.url);
    else location.assign(result.url);
  }
  el('browserInvoice').onclick = event => {
    if (tg?.openLink && tg.isVersionAtLeast?.('6.1')) {
      event.preventDefault();
      tg.openLink(el('browserInvoice').href);
    }
  };
  el('copyInvoice').onclick = async () => {
    try { await navigator.clipboard.writeText(el('invoiceLink').value); message('Ссылка скопирована.'); }
    catch { el('invoiceLink').focus(); el('invoiceLink').select(); message('Скопируйте выделенную ссылку.'); }
  };
  action('pay','click',() => openPayment(false));
  action('resume','click',() => openPayment(true));
  action('refresh','click',sync); action('retry','click',sync);
  el('language').onchange = () => {
    lang = el('language').value;
    try { localStorage.setItem('px-mini-language',lang); } catch {}
    translatePage(); render(); message(lastMessage);
  };
  window.addEventListener('pageshow', event => {
    if (!event.persisted) return;
    try { lang = localStorage.getItem('px-mini-language') === 'ru' ? 'ru' : 'en'; } catch {}
    translatePage(); render(); message(lastMessage);
  });
  if (!init) {
    show('loading',false); show('outside',true);
    fetch('/api/telegram/capabilities',{cache:'no-store'}).then(r=>r.json()).then(data=>{
      if (data.enabled && /^https:\/\/t\.me\/[A-Za-z0-9_]+$/.test(data.bot_url)) {
        el('bot').href = data.bot_url; show('bot',true);
      }
    }).catch(()=>{});
    return;
  }
  tg?.ready(); tg?.expand(); sync();
  setInterval(tick,1000);
  setInterval(() => { if (!document.hidden && !busy && !nativeOpen && (pending(account?.invoice) || account?.invoice?.state === 'awaiting_receipt')) sync(); },5000);
  document.addEventListener('visibilitychange',() => { if (!document.hidden && !busy) sync(); });
})();
