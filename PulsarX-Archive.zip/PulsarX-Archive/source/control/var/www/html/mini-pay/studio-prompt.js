(() => {
  let pending, dialog, reopen, busy = false, accountToken;
  const remove = () => {
    dialog?.remove(); reopen?.remove();
    dialog = reopen = pending = null;
  };
  async function poll() {
    const token = localStorage.getItem('pulsarx_token');
    if (token !== accountToken) { remove(); accountToken = token; }
    if (!token || busy || document.hidden || !window.Pulse) return;
    busy = true;
    try {
      const {prompt} = await Pulse.api('/api/telegram/mini/prompt',{cache:'no-store'});
      if (token !== localStorage.getItem('pulsarx_token')) { remove(); return; }
      if (!prompt) { remove(); return; }
      if (pending?.id === prompt.id) return;
      remove(); pending = prompt;
      dialog = document.createElement('dialog'); dialog.id = 'pxMiniCode';
      dialog.setAttribute('aria-labelledby','miniCodeHeading');
      dialog.innerHTML = '<h2 id="miniCodeHeading">Код для Telegram</h2><p class="identity"></p><strong></strong><p>Введите код в PulsarX Pay, если вы сами запросили привязку.</p><button type="button">Закрыть</button>';
      dialog.querySelector('.identity').textContent = 'Telegram ID ' + prompt.telegram_id;
      dialog.querySelector('strong').textContent = prompt.code.slice(0,4) + ' ' + prompt.code.slice(4);
      dialog.querySelector('button').onclick = () => dialog.close();
      reopen = document.createElement('button'); reopen.type = 'button'; reopen.id = 'pxShowMiniCode';
      reopen.textContent = 'Показать код для Telegram'; reopen.hidden = true;
      reopen.onclick = () => { if (Date.parse(pending.expires_at) <= Date.now()) { remove(); return; } dialog.showModal(); reopen.hidden = true; };
      const trigger = reopen; dialog.onclose = () => { trigger.hidden = false; };
      document.body.append(dialog,reopen); dialog.showModal();
    } catch { /* A transient network error must not dismiss a valid code. */ }
    finally { busy = false; }
  }
  setInterval(() => { if (pending && Date.parse(pending.expires_at) <= Date.now()) remove(); },1000);
  setInterval(poll,7000);
  document.addEventListener('visibilitychange',poll); window.addEventListener('focus',poll);
  window.addEventListener('storage',poll); poll();
})();
