(function(){
  'use strict';
  const copy={
    ru:{button:'Продлить VPS',title:'Продление VPS',server:'Выберите VPS',period:'Период продления',next:'Продолжить',cancel:'Отмена',loading:'Загружаем ваши VPS…',empty:'Нет VPS, доступных для продления. Бесплатные серверы на 24 часа и серверы с отдельной подпиской здесь не продлеваются.',note:'Оплата с баланса после подтверждения суммы. Новый период добавляется к оставшемуся сроку; если срок истёк — отсчитывается от текущего момента.',until:'Оплачен до',error:'Не удалось загрузить VPS. Попробуйте ещё раз.',unavailable:'Оплата временно недоступна. Обновите страницу.',months:{1:'1 месяц',3:'3 месяца',6:'6 месяцев',12:'12 месяцев'}},
    en:{button:'Renew VPS',title:'Renew your VPS',server:'Choose VPS',period:'Renewal period',next:'Continue',cancel:'Cancel',loading:'Loading your VPS…',empty:'No VPS is available for renewal. Free 24-hour instances and instances using a separate subscription cannot be renewed here.',note:'Pay from your balance after confirming the amount. The new period is added to the remaining time, or starts now if the paid period has ended.',until:'Paid until',error:'Could not load your VPS. Please try again.',unavailable:'Payment is temporarily unavailable. Refresh the page.',months:{1:'1 month',3:'3 months',6:'6 months',12:'12 months'}},
    ro:{button:'Reînnoiește VPS',title:'Reînnoirea VPS',server:'Alege VPS',period:'Perioada de reînnoire',next:'Continuă',cancel:'Anulează',loading:'Se încarcă VPS-urile…',empty:'Nu există VPS-uri disponibile pentru reînnoire. Instanțele gratuite de 24 de ore și cele cu abonament separat nu pot fi reînnoite aici.',note:'Plătești din sold după confirmarea sumei. Noua perioadă se adaugă la timpul rămas sau începe acum dacă perioada plătită a expirat.',until:'Plătit până la',error:'Nu s-au putut încărca VPS-urile. Încearcă din nou.',unavailable:'Plata este temporar indisponibilă. Reîncarcă pagina.',months:{1:'1 lună',3:'3 luni',6:'6 luni',12:'12 luni'}}
  };
  const language=()=>window.pulsarxI18n?.getLang()||document.documentElement.lang||'en';
  const tr=key=>(copy[language()]||copy.en)[key];
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const eligible=s=>s&&!s.trial_expires_at&&!s.has_subscription&&!s.subscription_cancelled&&!s.upgrade_pending&&['running','suspended'].includes(s.status)&&Number.isFinite(new Date(s.paid_until||'').getTime());
  let busy=false,loadingServers=false;
  function mount(){
    const overview=document.getElementById('page-overview');if(!overview)return;
    const head=overview.querySelector('.page-head');if(!head)return;
    let button=document.getElementById('pxRenewVps');
    if(!button){button=document.createElement('button');button.id='pxRenewVps';button.type='button';button.className='btn px-renew-button';button.setAttribute('aria-haspopup','dialog');button.addEventListener('click',renew);head.appendChild(button);}
    const title=tr(loadingServers?'loading':'button');
    if(button.textContent!==title)button.textContent=title;
    button.disabled=busy;
    if(!document.getElementById('pxRenewError')){const error=document.createElement('div');error.id='pxRenewError';error.className='px-renew-error';error.setAttribute('role','alert');head.insertAdjacentElement('afterend',error);}
  }
  function pick(rows){
    const dialog=document.createElement('dialog');dialog.className='px-renew-dialog';dialog.setAttribute('aria-labelledby','pxRenewTitle');
    dialog.innerHTML=`<h2 id="pxRenewTitle">${esc(tr('title'))}</h2>${rows.length?`<form id="pxRenewForm"><label for="pxRenewServer">${esc(tr('server'))}</label><select id="pxRenewServer">${rows.map((s,index)=>`<option value="${esc(s.id)}" ${index===0?'selected':''}>${esc(s.container_name)} · ${esc(String(s.plan||'').toUpperCase())}</option>`).join('')}</select><p id="pxRenewUntil" class="px-renew-note"></p><label for="pxRenewMonths">${esc(tr('period'))}</label><select id="pxRenewMonths">${[1,3,6,12].map(n=>`<option value="${n}" ${n===1?'selected':''}>${esc(tr('months')[n])}</option>`).join('')}</select><p class="px-renew-note">${esc(tr('note'))}</p><div class="px-renew-actions"><button type="button" class="btn btn-ghost" data-renew-cancel>${esc(tr('cancel'))}</button><button type="submit" class="btn">${esc(tr('next'))}</button></div></form>`:`<p class="px-renew-note">${esc(tr('empty'))}</p><div class="px-renew-actions"><button type="button" class="btn btn-ghost" data-renew-cancel>${esc(tr('cancel'))}</button></div>`}`;
    document.body.appendChild(dialog);
    return new Promise(resolve=>{
      let choice=null;
      dialog.querySelector('[data-renew-cancel]').addEventListener('click',()=>dialog.close());
      dialog.addEventListener('close',()=>{dialog.remove();resolve(choice);},{once:true});
      if(rows.length){
        const select=dialog.querySelector('#pxRenewServer');
        const details=()=>{const s=rows.find(x=>x.id===select.value);dialog.querySelector('#pxRenewUntil').textContent=s?tr('until')+': '+new Date(s.paid_until).toLocaleString(language()==='ru'?'ru-RU':language()==='ro'?'ro-RO':'en-GB',{dateStyle:'medium',timeStyle:'short'}):'';};
        select.addEventListener('change',details);details();
        dialog.querySelector('form').addEventListener('submit',event=>{event.preventDefault();const s=rows.find(x=>x.id===select.value),months=Number(dialog.querySelector('#pxRenewMonths').value);if(!eligible(s)||![1,3,6,12].includes(months))return;choice={kind:'renew',server_id:s.id,months};dialog.close();});
      }
      dialog.showModal();
    });
  }
  async function renew(){
    if(busy||document.querySelector('dialog[open]'))return;
    busy=true;loadingServers=true;mount();const error=document.getElementById('pxRenewError');error.textContent='';
    const token=localStorage.getItem('pulsarx_token');
    try{
      if(!token){location.href='/login/';return;}
      if(typeof window.PxWallet?.confirmOrder!=='function')throw new Error(tr('unavailable'));
      const response=await fetch('/api/servers',{headers:{Authorization:'Bearer '+token},cache:'no-store'});
      if(response.status===401){location.href='/login/';return;}
      if(!response.ok)throw new Error(tr('error'));
      const data=await response.json();if(!Array.isArray(data))throw new Error(tr('error'));
      if(token!==localStorage.getItem('pulsarx_token'))return;
      loadingServers=false;mount();
      const choice=await pick(data.filter(eligible));
      if(choice&&token===localStorage.getItem('pulsarx_token'))await window.PxWallet.confirmOrder(choice);
    }catch(e){error.textContent=e.message||tr('error');}
    finally{busy=false;loadingServers=false;mount();}
  }
  function init(){
    mount();const overview=document.getElementById('page-overview');
    if(typeof MutationObserver!=='undefined'){
      if(overview)new MutationObserver(mount).observe(overview,{childList:true,subtree:true});
      new MutationObserver(mount).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
