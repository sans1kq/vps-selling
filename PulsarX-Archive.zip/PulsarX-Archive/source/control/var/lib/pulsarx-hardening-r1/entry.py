#!/usr/bin/env python3
"""PulsarX: pinned code ownership and guarded root SSH public-key access.

No package upgrade, reboot, API restart, guest command, payment or email.
SSH settings change only after a separate successful public-key connection.
"""
import argparse,base64,contextlib,fcntl,hashlib,ipaddress,json,os,pwd,re,stat,struct,subprocess,sys,tempfile,time,urllib.request,urllib.error
from pathlib import Path

RELEASE='HARDENING-20261111-r1'
EXPECTED={'app/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'app/action_log.py': '401e09b2afa53053819d9f062d6472bc92a8116f05ebd623819bc437d29bdfb6', 'app/admin_desk.py': '783971e849ea57c782027695387ea757fc592cf108499665568433c37d0f7de3', 'app/anypay_service.py': '1ebc8098ca8e683a4d818555e3cd45bd47c912d0c661dca33b5cfdb2d2df0f83', 'app/auth.py': '04e76896eb596444a8632f4878d63e99487cdc4c478faf759d68b1d17f4d75f6', 'app/billing_check.py': '9b8625cd99b1aeecf0a7ae88eb543b0b60a112384de3b6835713a759f23b23b5', 'app/capacity_layout.py': '805f566ba896b37fe1deb75380857c318ef7892897cdffec7c6165a52285910b', 'app/capacity_service.py': '9d80addc12a3e8158b9086cd7166634a614ada7fd7c4dc995de5225dee425f46', 'app/config.py': '40cc0ab1d78eccaaeebb2696fdaa35aebe1848f786984364b274ff7f38ccb23b', 'app/database.py': 'ae199149036ab7ec40ccafe2e2e59b8737b585947bcb94e32cf90528ab772c12', 'app/domain_service.py': 'aa24daf668a60eea73427da6c3ea28ff710cd3e301162f6be149a46bddf1e32d', 'app/email_service.py': 'f4ed43b7039ba353dce253009b63588134a3a428348d42d65dfbe116ad5831ce', 'app/email_templates.py': '72f42a1c985d23def6412e7d1766ccd5cd463532320fe351456b5e782bee9109', 'app/flex_capacity.py': '7f5c566ee4cb4983ae9ff869d4081c7d35dcd403693f3dfa11929a7701b2ebf9', 'app/flex_catalog.py': '4f29c75373fd6ca506471dca76edd0945bac171b0e962550c73dd26874286e1f', 'app/gift_renewal.py': 'c3956f36f813f43dfb2a6c4de2cc60da5c619dd7fe1dae427fe965d1ba71c041', 'app/growth_models.py': '1d918e55987c575205cb77fdf0cda1ce64decfecda51e60a76d03fac83efdfbd', 'app/growth_service.py': 'aa5517572794aae0f4484a9e132d9fd157fdff0e6bad820ae113d29d9cfd2534', 'app/idmap_service.py': '3b7392edf1264246232b5e18767399f87a38a333329a8a51aa1e859c026b1f07', 'app/incus_service.py': '91326a2515c97e1e6120c3fcae33afb65b90ecb878f23d026fd1906d1d5765a1', 'app/launch_smoke.py': '5d1a9c26095615c2939dd9474820a7f20571f4e16c728472fe3b71bf34b90e14', 'app/lemonsqueezy_service.py': '4550599106cd4948383f918c50c6fa6f71e974e604810923d117a0d79277c63c', 'app/main.py': 'd051fab6abd401f0bc3d3654df17f689f2ecc074192fcc4e18c7a5786944bfd4', 'app/models.py': '52472d47e8561ad9f13f3a7fcfa01772517b80b83d938a4b73a262654fdbf935', 'app/payments_cron.py': '1a2238a9c42fab1c97f3cd985b39f020da12d2f1b8037cf409f24197095f7f7a', 'app/payments_service.py': '011aa2fde77c7752bb11fe35b465a9821725cf8ea9d1ca2298179ad5f39ce858', 'app/plisio_service.py': '2503f3d1f8184fd1e8b0436003b108f2d5afcbe281aeea7b2c96d9b67f15f239', 'app/pool_cleanup.py': '662dfc71cfc67c3795ce48802e742e31bd60d1aafb3b80098f3feab56879851d', 'app/routers/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'app/routers/admin.py': '76de5cae8c7a754276cfbc5c1a912be62eae872d575e51d057a7ca04042b58ab', 'app/routers/admin_capacity.py': '4ac6aebc258895e0d490ae21bc76a2e435e898a59d55ee2c103e8bd0a94fa9f4', 'app/routers/admin_support.py': '66472f0bf4912f5aa853e21581b4f293c50ebbeab09a7705572f2ef5c8073cdb', 'app/routers/admin_wallet.py': '8f5be95f39829adc4939fdaec0cf4d297caff8c14a62be7bd850d5ef2cd732b1', 'app/routers/auth.py': '7f9ff06f436ad885a4492fe32c86d5180500236819439e7ef86759870bdbbbf6', 'app/routers/growth.py': 'd1a13d64bb7bd853b3e246481a1306b13b1cfc6440a8af9acf52c3dc8feda278', 'app/routers/servers.py': '9b4f1a8fedf3b7abef8dd68dba12d6e3b985c89f2bfe7135d1c299f2980ba949', 'app/routers/wallet.py': '08600ab8d68d70674ab63b0867fe14ba17bcee227444603de460a87b8388e93e', 'app/routers/wallet_rollypay.py': 'd32f699e8308dd05c7c437fa5815b26ab65dae5149517d4c0bc9fa4f6cd2f534', 'app/routers/web_support.py': '43ebf78fad011bb330ce3690b2be87da42ab8d2845fafeed4c8a85ed5b2a0d2e', 'app/routers/webhooks.py': '39b50688cd116dd00355fbbac57d41e854ca4091074db7f9bb3e87b8448b7991', 'app/schemas.py': '055209db5d28c20dd394bd27486b6918298d4ffef0b21111ddbe8bd9fa958472', 'app/server_access.py': '302eacfb050f44498ead752ca5e0b710db5be5a00230b032b693351a630a891d', 'app/support_bot.py': '936a135d66bea279dfde3f437e09d9b49d281d95a05d562ab33305ee47a35477', 'app/support_store.py': 'dfd85ed37b342bcb08bbd361f0da6e9b2edc92fb73074ae5bb3ee29c42804d33', 'app/trial_service.py': 'a78495eaa9bb87a69b6eced342a17a69ee30af29a11b51ee0d5eaf721b377d22', 'app/wallet_freekassa.py': 'd2aa290c3277dfeabe47f490433cad1f411368011b142715ceb74ed0993012f2', 'app/wallet_models.py': 'c464074cb7ab5e74541e9b9c6081d492bf4e519ae23178ceb3dec9685a2ee19d', 'app/wallet_plisio.py': 'c1a26157a0ad153ffbdd84ca249d0327a72e492e57fc8d456db875ba9751724d', 'app/wallet_rollypay.py': '5ffbb8fc1a0bef68216c62c3d36c38ea54c0cc8947356c8892a9de1a692f793a', 'app/wallet_schema.py': '2dcde16cdfd12a74b9d668711f2723e4366322b267162ba775e255f05e4a9033', 'app/wallet_service.py': '19c80b816ed4235ce38a5cfc2e501b7cf6859edc592ede10f8d57cc2461874bd', 'app/wallet_worker.py': 'a2a58e59b27880b2880caa153c106994193ea6d929c6176dfdca463e0bf40d46', 'app/web_support.py': '48f935e1e6af5c8ce363182b03d34a0fba2e17ce56b700ff132fe650e8bca7dc', 'scripts/add_domain.sh': '4d8d9b9ddbab7d6e76730b701f4a2907f7cd4ca68bf864dc9214aad95911be63', 'scripts/remove_domain.sh': 'f0bb719b09b85fcf4ce27ee19f305cc03fc012c3abc9b285027e982a0cfb8b73'}
ROOT=Path('/opt/pulsarx-backend')
STATE=Path('/var/lib/pulsarx-hardening-r1')
SSH_CONFIG=Path('/etc/ssh/sshd_config')
SSH_INCLUDE=Path('/etc/ssh/pulsarx-key-auth-r1.conf')
KEYS=Path('/root/.ssh/authorized_keys')
SSH_BODY=b'# PulsarX guarded root public-key access\nMatch User root\n    PubkeyAuthentication yes\n    PasswordAuthentication no\n    KbdInteractiveAuthentication no\n    PermitRootLogin prohibit-password\n'
SSH_BLOCK=b'\n# PulsarX HARDENING-20261111-r1\nMatch all\nInclude /etc/ssh/pulsarx-key-auth-r1.conf\n'
IP={'control':'192.0.2.11','host':'192.0.2.12'}

class Stop(RuntimeError):pass
def digest(data):return hashlib.sha256(data).hexdigest()
def run(args,timeout=25,check=True):
    try:r=subprocess.run(args,capture_output=True,text=True,timeout=timeout,env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LC_ALL':'C','HOME':'/root'})
    except (OSError,subprocess.TimeoutExpired):raise Stop('Command unavailable or timed out: '+str(args[0]))
    if check and r.returncode:raise Stop('Command failed: '+str(args[0])+' '+str(args[1] if len(args)>1 else '')+'; raw output withheld')
    return r
def host(role):
    if os.geteuid()!=0:raise Stop('Root/sudo is required')
    rows=json.loads(run(['ip','-json','address','show']).stdout)
    if IP[role] not in {a.get('local') for row in rows for a in row.get('addr_info',[])}:raise Stop('Wrong host for this action')
def safe_chain(path,include_self=True):
    path=Path(path);items=list(path.parents)
    if include_self:items.insert(0,path)
    for p in items:
        s=p.lstat()
        if not stat.S_ISDIR(s.st_mode) or s.st_uid!=0 or s.st_mode&0o022:raise Stop('Unsafe parent directory: '+str(p))
def regular(path,limit=2_000_000):
    p=Path(path);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        s=os.fstat(fd)
        if not stat.S_ISREG(s.st_mode) or s.st_size>limit or s.st_nlink!=1:raise Stop('Unexpected file type, links or size: '+str(p))
        with os.fdopen(os.dup(fd),'rb') as f:data=f.read(limit+1)
        if len(data)>limit:raise Stop('File too large')
        return data,{'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'sha256':digest(data)}
    finally:os.close(fd)
def atomic(path,data,mode=0o600,uid=0,gid=0):
    path=Path(path);safe_chain(path.parent)
    if path.is_symlink():raise Stop('Refusing a symlink: '+str(path))
    fd,tmp=tempfile.mkstemp(prefix='.px-hardening-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fchown(f.fileno(),uid,gid);os.fchmod(f.fileno(),mode);os.fsync(f.fileno())
        os.replace(tmp,path)
        dfd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(dfd)
        finally:os.close(dfd)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def setup():
    safe_chain(STATE.parent)
    if not STATE.exists():STATE.mkdir(mode=0o700)
    safe_chain(STATE)
    if stat.S_IMODE(STATE.stat().st_mode)!=0o700:raise Stop('Private state directory mode differs')
@contextlib.contextmanager
def locked():
    setup();fd=os.open(STATE/'lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX);yield
    finally:os.close(fd)
def save(name,data):atomic(STATE/name,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode())
def load(name):
    p=STATE/name
    return json.loads(regular(p)[0]) if p.exists() else None
def health():
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for route,wanted in [('/api/health',(200,)),('/api/auth/me',(401,403,422))]:
        req=urllib.request.Request('http://127.0.0.1:8000'+route)
        try:
            with opener.open(req,timeout=5) as r:status=r.status
        except urllib.error.HTTPError as e:status=e.code;e.close()
        except OSError:raise Stop('API health request unavailable')
        if status not in wanted:raise Stop('API health/authentication precondition failed')
def access_report(paths):
    snippet='import os,json,sys;print(json.dumps([{ "path":p,"read":os.access(p,os.R_OK),"write":os.access(p,os.W_OK)} for p in json.loads(sys.argv[1])]))'
    return json.loads(run(['runuser','-u','pulsarx','--','/usr/bin/python3','-I','-c',snippet,json.dumps([str(p) for p in paths])]).stdout)
def pinned_sources():
    actual={p.relative_to(ROOT).as_posix() for p in (ROOT/'app').rglob('*.py')}
    expected={p for p in EXPECTED if p.startswith('app/')}
    if actual!=expected:raise Stop('Backend source inventory changed; send a fresh review report')
    result={}
    for relative,expected_hash in EXPECTED.items():
        p=ROOT/relative;safe_chain(p.parent);data,m=regular(p)
        if digest(data)!=expected_hash:raise Stop('Backend changed since the review: '+relative)
        result[relative]=(data,m)
    return result
def code_apply():
    host('control');health();account=pwd.getpwnam('pulsarx')
    with locked():
        sources=pinned_sources();paths=[ROOT/n for n in sources]
        install_guard_entry()
        if any(not r['read'] for r in access_report(paths)):raise Stop('Application cannot read all reviewed source files before change')
        journal=load('code.json')
        if journal and journal.get('phase')=='complete':
            if any(r['write'] for r in access_report(paths)):raise Stop('Completed code protection has drifted; send current file metadata')
            health();print('CODE VERIFIED: reviewed files readable, not writable by pulsarx; API healthy');return
        if not journal:
            journal={'release':RELEASE,'phase':'prepared','before':{n:m for n,(_,m) in sources.items()},'cache_before':{},'started_at':int(time.time())}
            save('code.json',journal)
        elif any(journal['before'].get(n,{}).get('sha256')!=m['sha256'] for n,(_,m) in sources.items()):raise Stop('Saved code ownership checkpoint differs')
        # The application directories already have root ownership. Freeze existing bytecode
        # directories before removing only derived cache files for reviewed module names.
        caches={}
        for relative in sources:
            p=ROOT/relative
            if p.suffix=='.py':caches.setdefault(p.parent/'__pycache__',set()).add(p.stem)
        for cache,names in caches.items():
            if not cache.exists() and not cache.is_symlink():continue
            s=cache.lstat()
            if not stat.S_ISDIR(s.st_mode):raise Stop('Unexpected Python cache path')
            key=str(cache.relative_to(ROOT));journal['cache_before'].setdefault(key,{'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)})
            save('code.json',journal)
            os.chown(cache,0,account.pw_gid,follow_symlinks=False);os.chmod(cache,0o750,follow_symlinks=False)
            for p in cache.iterdir():
                if p.name.endswith('.pyc') and any(p.name.startswith(stem+'.') for stem in names):
                    if p.is_dir() and not p.is_symlink():raise Stop('Unexpected directory in Python cache')
                    p.unlink()
        for relative,(data,m) in sources.items():
            if m['uid']!=0 or m['mode']&0o022:
                current,_=regular(ROOT/relative)
                if current!=data:raise Stop('Source changed during protection; checkpoint retained')
                atomic(ROOT/relative,data,0o750 if m['mode']&0o111 else 0o640,gid=account.pw_gid)
        if any(r['write'] or not r['read'] for r in access_report(paths+[p for p in caches if p.exists()])):raise Stop('Application source access verification failed')
        pinned_sources();health()
        journal.update(phase='complete',completed_at=int(time.time()),verified_files=len(paths));save('code.json',journal)
        print('CODE COMPLETE: '+str(len(paths))+' source files verified; bytecode caches protected; file contents preserved; API stayed running')
def code_rollback():
    host('control')
    with locked():
        s=load('code.json')
        if not s:raise Stop('No code ownership checkpoint')
        for relative,m in s['before'].items():
            p=ROOT/relative;data,current=regular(p)
            if digest(data)!=m['sha256']:raise Stop('Changed source prevents metadata rollback: '+relative)
        for relative,m in s['before'].items():
            p=ROOT/relative;data,_=regular(p);atomic(p,data,m['mode'],m['uid'],m['gid'])
        for relative,m in s.get('cache_before',{}).items():
            p=ROOT/relative
            if p.is_dir() and not p.is_symlink():os.chown(p,m['uid'],m['gid']);os.chmod(p,m['mode'])
        s['phase']='rolled_back';save('code.json',s);print('CODE ROLLED BACK: original ownership/modes; no application data restored')
def public_key(raw):
    parts=raw.decode('ascii').strip().split()
    if len(parts)<2 or parts[0]!='ssh-ed25519' or '\n' in raw.decode('ascii').strip():raise Stop('Exactly one plain Ed25519 public key is required')
    try:
        blob=base64.b64decode(parts[1],validate=True)
        n=struct.unpack('!I',blob[:4])[0];alg=blob[4:4+n];length=struct.unpack('!I',blob[4+n:8+n])[0]
        if alg!=b'ssh-ed25519' or length!=32 or len(blob)!=8+n+length:raise ValueError()
    except (ValueError,struct.error):raise Stop('Malformed Ed25519 public key')
    return ('ssh-ed25519 '+parts[1]+' pulsarx-operator\n').encode(),digest(blob)
def connection():
    p=os.environ.get('SSH_CONNECTION','').split()
    if len(p)!=4:raise Stop('This SSH stage requires a live remote SSH connection')
    try:ipaddress.ip_address(p[0]);ipaddress.ip_address(p[2])
    except ValueError:raise Stop('Invalid SSH connection identity')
    if p[2]!=IP['host'] or p[3]!='22':raise Stop('Unexpected SSH destination')
    return p[0]
def ssh_effective(address):
    query='user=root,addr='+address+',host='+address+',laddr='+IP['host']+',lport=22'
    out=run(['/usr/sbin/sshd','-T','-C',query]).stdout
    return dict(line.split(' ',1) for line in out.splitlines() if ' ' in line)
def key_only(settings):
    return settings.get('pubkeyauthentication')=='yes' and settings.get('passwordauthentication')=='no' and settings.get('kbdinteractiveauthentication')=='no' and settings.get('permitrootlogin') in ('prohibit-password','without-password')
def ssh_state(nonce):
    if not re.fullmatch('[a-f0-9]{32}',nonce or ''):raise Stop('Invalid run identity')
    s=load('ssh.json')
    if not s or s.get('nonce')!=nonce:raise Stop('SSH checkpoint identity differs')
    return s
def ssh_enroll(path,nonce):
    host('host');address=connection();line,fingerprint=public_key(regular(path,8192)[0])
    with locked():
        old=load('ssh.json')
        if old and old.get('phase')=='armed':raise Stop('Previous SSH rollback guard is active; use Status or RollbackSSH before retrying')
        if old and old.get('phase')=='complete' and key_only(ssh_effective(address)):
            if old.get('fingerprint_sha256')!=fingerprint:raise Stop('Another operator key completed this package; use the original key or review key rotation separately')
            print('SSH_ALREADY_COMPLETE');return
        if not re.fullmatch('[a-f0-9]{32}',nonce or ''):raise Stop('Invalid run identity')
        install_guard_entry()
        safe_chain(KEYS.parent.parent)
        if not KEYS.parent.exists():KEYS.parent.mkdir(mode=0o700)
        safe_chain(KEYS.parent)
        oldkeys,meta=regular(KEYS,500000) if KEYS.exists() else (b'',{'uid':0,'gid':0,'mode':0o600})
        if meta['uid']!=0 or meta['mode']&0o022:raise Stop('Existing authorized_keys is writable by another account')
        token=line.split()[1]
        # Restricted copies of this same key do not become unrestricted silently.
        found=[r for r in oldkeys.splitlines() if token in r.split()]
        if found and not any(r.split()[:2]==line.split()[:2] for r in found):raise Stop('This key already has SSH restrictions; choose another operator key')
        atomic(STATE/('authorized_keys-'+nonce+'.before'),oldkeys)
        if not found:atomic(KEYS,oldkeys+(b'\n' if oldkeys and not oldkeys.endswith(b'\n') else b'')+line,0o600)
        s={'release':RELEASE,'phase':'enrolled','nonce':nonce,'fingerprint_sha256':fingerprint,'address':address,'enrolled_at':int(time.time())}
        save('ssh.json',s)
        print('KEY ENROLLED: existing SSH keys and password access retained. Next: separate public-key proof')
def ssh_proof(nonce):
    host('host');address=connection()
    with locked():
        s=ssh_state(nonce)
        if s['phase'] not in ('enrolled','key_verified'):raise Stop('SSH proof checkpoint is not ready')
        if s['address']!=address:raise Stop('SSH source changed; repeat enrollment from the current client')
        s.update(phase='key_verified',key_verified_at=int(time.time()));save('ssh.json',s)
        print('KEY_PROOF:'+nonce)
def install_guard_entry():
    raw=Path(__file__).read_bytes();compile(raw,'entry.py','exec');atomic(STATE/'entry.py',raw,0o700)
def reload_ssh():
    run(['/usr/sbin/sshd','-t']);run(['systemctl','reload','ssh.service'])
def rollback_locked(s):
    if s['phase']!='armed':return False
    current,m=regular(SSH_CONFIG)
    before=regular(STATE/('sshd_config-'+s['nonce']+'.before'))[0]
    if current.count(SSH_BLOCK)==1:
        # Removing only our appended block preserves unrelated later edits.
        restored=before if digest(current)==s.get('applied_sha256') else current.replace(SSH_BLOCK,b'',1)
        atomic(SSH_CONFIG,restored,m['mode'],m['uid'],m['gid'])
    elif current!=before:raise Stop('SSH configuration changed outside this package; restore requires review')
    if SSH_INCLUDE.exists() and regular(SSH_INCLUDE)[0]==SSH_BODY:SSH_INCLUDE.unlink()
    reload_ssh();s.update(phase='rolled_back',rolled_back_at=int(time.time()));save('ssh.json',s)
    return True
def ssh_arm(nonce):
    host('host');address=connection()
    with locked():
        s=ssh_state(nonce)
        if s['phase']!='key_verified' or s['address']!=address or time.time()-s.get('key_verified_at',0)>900:raise Stop('Recent separate key proof is required')
        if key_only(ssh_effective(address)):
            s.update(phase='complete',completed_at=int(time.time()),already_key_only=True);save('ssh.json',s);print('SSH ALREADY KEY ONLY: effective root policy verified');return
        safe_chain(SSH_CONFIG.parent);before,m=regular(SSH_CONFIG)
        if m['uid']!=0 or m['mode']&0o022:raise Stop('Unsafe sshd_config permissions')
        if SSH_BLOCK in before or SSH_INCLUDE.exists() or SSH_INCLUDE.is_symlink():raise Stop('Existing SSH include needs review; no configuration change')
        run(['/usr/sbin/sshd','-t'])
        if run(['systemctl','is-active','ssh.service'],check=False).returncode:raise Stop('SSH service is not active')
        atomic(STATE/('sshd_config-'+nonce+'.before'),before);install_guard_entry()
        s.update(phase='armed',armed_at=int(time.time()),applied_sha256=digest(before+SSH_BLOCK),unit='pulsarx-ssh-guard-'+nonce)
        save('ssh.json',s)
        try:
            run(['systemd-run','--quiet','--unit='+s['unit'],'--on-active=5m','--timer-property=AccuracySec=1s','/usr/bin/python3','-I',str(STATE/'entry.py'),'--action','ssh-rollback','--nonce',nonce])
            if run(['systemctl','is-active',s['unit']+'.timer'],check=False).returncode:raise Stop('Rollback timer did not arm')
            atomic(SSH_INCLUDE,SSH_BODY,0o644);atomic(SSH_CONFIG,before+SSH_BLOCK,m['mode'],m['uid'],m['gid'])
            run(['/usr/sbin/sshd','-t'])
            if not key_only(ssh_effective(address)):raise Stop('A Match/Include override prevents the intended root SSH policy')
            reload_ssh()
        except Exception:
            rollback_locked(s);raise
        print('SSH ARMED: key-only root access; automatic rollback in 5 minutes unless a new SSH connection commits')
def ssh_commit(nonce):
    host('host');address=connection()
    with locked():
        s=ssh_state(nonce)
        if s['phase']=='complete' and key_only(ssh_effective(address)):print('SSH COMPLETE: public-key login verified');return
        if s['phase']!='armed' or s['address']!=address:raise Stop('SSH guard already expired or source changed; password policy may have rolled back')
        if not key_only(ssh_effective(address)):raise Stop('Effective SSH policy differs; rollback remains armed')
        if regular(SSH_INCLUDE)[0]!=SSH_BODY or regular(SSH_CONFIG)[0].count(SSH_BLOCK)!=1:raise Stop('SSH configuration drift; rollback remains armed')
        s.update(phase='complete',completed_at=int(time.time()));save('ssh.json',s)
        run(['systemctl','stop',s['unit']+'.timer'],check=False)
        print('SSH COMPLETE: second public-key connection verified; root password login disabled; customer SSH ports unchanged')
def ssh_rollback(nonce=None):
    host('host')
    with locked():
        s=ssh_state(nonce) if nonce else load('ssh.json')
        if not s:raise Stop('No SSH checkpoint')
        if nonce is None and s['phase']=='complete' and not s.get('already_key_only'):
            s['phase']='armed';save('ssh.json',s)
        changed=rollback_locked(s)
        print('SSH ROLLED BACK: previous password policy restored; enrolled key retained' if changed else 'SSH: no pending policy change to roll back')
def status(role):
    host(role)
    with locked():
        code=load('code.json');ssh=load('ssh.json')
        view={'release':RELEASE,'role':role,'code':{k:code.get(k) for k in ('phase','completed_at','verified_files')} if code else None,'ssh':{k:ssh.get(k) for k in ('phase','completed_at','nonce','unit','already_key_only')} if ssh else None}
        if role=='host':view['effective_root_ssh']={k:v for k,v in ssh_effective(connection()).items() if k in ('pubkeyauthentication','passwordauthentication','kbdinteractiveauthentication','permitrootlogin')}
        print(json.dumps(view,indent=2))
def main():
    p=argparse.ArgumentParser();p.add_argument('--action',required=True,choices=('code-apply','code-rollback','ssh-enroll','ssh-proof','ssh-arm','ssh-commit','ssh-rollback','status'));p.add_argument('--public-key');p.add_argument('--nonce');p.add_argument('--role',choices=IP,default='host');a=p.parse_args()
    print('RELEASE: '+RELEASE,flush=True)
    if a.action=='code-apply':code_apply()
    elif a.action=='code-rollback':code_rollback()
    elif a.action=='ssh-enroll':ssh_enroll(a.public_key,a.nonce)
    elif a.action=='ssh-proof':ssh_proof(a.nonce)
    elif a.action=='ssh-arm':ssh_arm(a.nonce)
    elif a.action=='ssh-commit':ssh_commit(a.nonce)
    elif a.action=='ssh-rollback':ssh_rollback(a.nonce)
    else:status(a.role)
if __name__=='__main__':
    try:main()
    except (Stop,OSError,ValueError) as e:
        print('STOPPED: '+(str(e) if isinstance(e,Stop) else type(e).__name__)+'. No guest or financial rollback was attempted.',file=sys.stderr);sys.exit(1)
