#!/usr/bin/env python3
"""Bounded Debian package update. No reboot, guest command or automatic rollback."""
import argparse
import contextlib
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid

RELEASE = 'OS-UPDATE-20261113-r1'
STATE = Path('/var/lib/pulsarx-os-update-r1')
BACKUPS = Path('/var/backups')
BOOT = Path('/boot')
SSH = Path('/etc/ssh')
KEYS = Path('/root/.ssh/authorized_keys')
ARCHIVES = Path('/var/cache/apt/archives')
KERNEL = '6.12.116+deb13-amd64'
IPS = {'control': '192.0.2.11', 'host': '192.0.2.12'}
TARGETS = {
    'linux-image-amd64': '6.12.116-1',
    'linux-image-' + KERNEL: '6.12.116-1',
    'openssh-server': '1:10.0p1-7+deb13u4',
    'openssh-client': '1:10.0p1-7+deb13u4',
    'openssh-sftp-server': '1:10.0p1-7+deb13u4',
    'openssl': '3.5.7-1~deb13u3',
    'libssl3t64': '3.5.7-1~deb13u3',
    'openssl-provider-legacy': '3.5.7-1~deb13u3',
}
PRIMARY = ('linux-image-amd64', 'openssh-server', 'openssl')
ENV = {'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'HOME': '/root', 'LC_ALL': 'C',
       'DEBIAN_FRONTEND': 'noninteractive', 'NEEDRESTART_MODE': 'l'}
MAX_BACKUP_AGE = 36 * 3600


class Stop(RuntimeError):
    pass


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_dirs(path):
    for p in [Path(path), *Path(path).parents]:
        st = p.lstat()
        if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or st.st_mode & 0o022:
            raise Stop('Unsafe parent directory: ' + str(p))


def read_file(path, limit=4_000_000):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > limit:
            raise Stop('Unexpected file type, links or size: ' + str(path))
        with os.fdopen(os.dup(fd), 'rb') as f:
            data = f.read(limit + 1)
        if len(data) > limit: raise Stop('File grew beyond the read limit: ' + str(path))
        return data
    finally:
        os.close(fd)


def atomic(path, data, mode=0o600):
    path = Path(path); safe_dirs(path.parent)
    if path.is_symlink():
        raise Stop('Refusing symlink: ' + str(path))
    fd, tmp = tempfile.mkstemp(prefix='.px-os-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            os.fchmod(f.fileno(), mode); f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def save(name, data):
    atomic(STATE / name, (json.dumps(data, indent=2, sort_keys=True) + '\n').encode())


def load():
    p = STATE / 'state.json'
    return json.loads(read_file(p)) if p.exists() else None


def setup():
    safe_dirs(STATE.parent)
    if not STATE.exists(): STATE.mkdir(mode=0o700)
    safe_dirs(STATE)
    if stat.S_IMODE(STATE.stat().st_mode) != 0o700:
        raise Stop('State directory must be private')


@contextlib.contextmanager
def lock(name):
    setup()
    fd = os.open(STATE / name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise Stop('Another update operation is active')
        yield
    finally:
        os.close(fd)


def run(args, timeout=45, check=True):
    try:
        r = subprocess.run(args, capture_output=True, text=True, env=ENV, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        raise Stop('Command unavailable or timed out: ' + str(args[0]))
    if check and r.returncode:
        raise Stop('Command failed: ' + str(args[0]) + '; raw output withheld')
    return r


def long_run(args, label):
    # Do not kill dpkg on an arbitrary timeout. The independent worker owns it.
    fd = os.open(STATE / 'private-apt.log', os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'ab', buffering=0) as log:
        log.write(('\nSTAGE: ' + label + '\n').encode())
        r = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, env=ENV)
    if r.returncode:
        raise Stop(label + ' failed; diagnostic: ' + str(STATE / 'private-apt.log'))


def host(role):
    if os.geteuid() != 0: raise Stop('Run as root or sudo')
    os_release = Path('/etc/os-release').read_text()
    if not re.search(r'^ID=\"?debian\"?$', os_release, re.M) or not re.search(r'^VERSION_ID=\"?13\"?$', os_release, re.M):
        raise Stop('This package is for Debian 13 only')
    if run(['dpkg', '--print-architecture']).stdout.strip() != 'amd64': raise Stop('Expected amd64')
    addresses = json.loads(run(['ip', '-json', 'address', 'show']).stdout)
    if IPS[role] not in {x.get('local') for a in addresses for x in a.get('addr_info', [])}:
        raise Stop('Wrong host for role ' + role)


def ssh_source(role):
    parts = os.environ.get('SSH_CONNECTION', '').split()
    if len(parts) != 4 or parts[2] != IPS[role] or parts[3] != '22':
        raise Stop('Start from a direct authenticated SSH connection')
    ipaddress.ip_address(parts[0])
    return parts[0]


def unit(name):
    r = run(['systemctl', 'show', name, '-p', 'ActiveState', '-p', 'Result', '-p', 'ExecMainStatus', '-p', 'ExecMainExitTimestamp'])
    return dict(line.split('=', 1) for line in r.stdout.splitlines() if '=' in line)


def active(name):
    if unit(name).get('ActiveState') != 'active': raise Stop('Required service is not active: ' + name)


def ssh_check(role, address):
    run(['/usr/sbin/sshd', '-t'])
    user = 'root' if role == 'host' else 'debian'
    q = 'user=' + user + ',addr=' + address + ',host=' + address + ',laddr=' + IPS[role] + ',lport=22'
    values = dict(x.split(' ', 1) for x in run(['/usr/sbin/sshd', '-T', '-C', q]).stdout.splitlines() if ' ' in x)
    if values.get('pubkeyauthentication') != 'yes' or values.get('passwordauthentication') != 'no' or values.get('kbdinteractiveauthentication') != 'no':
        raise Stop('Expected public-key SSH policy is not effective for the current client')
    if role == 'host' and values.get('permitrootlogin') not in ('without-password', 'prohibit-password'):
        raise Stop('Root SSH policy differs from the completed hardening')
    active('ssh.service')
    return {k: values.get(k) for k in ('pubkeyauthentication', 'passwordauthentication', 'kbdinteractiveauthentication', 'permitrootlogin')}


def api_health():
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for path, allowed in [('/api/health', (200,)), ('/api/auth/me', (401, 403, 422))]:
        try:
            with opener.open('http://127.0.0.1:8000' + path, timeout=8) as r: status = r.status
        except urllib.error.HTTPError as e: status = e.code; e.close()
        except OSError: raise Stop('API health request unavailable')
        if status not in allowed: raise Stop('API health/private authentication check failed')
    active('pulsarx-api.service'); active('nginx.service')


def guests():
    rows = json.loads(run(['incus', '--force-local', '--project', 'default', 'list', '--format=json']).stdout)
    if not isinstance(rows, list): raise Stop('Unexpected Incus inventory')
    result = {}
    for row in rows:
        name = row.get('name', '')
        if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,100}', name): raise Stop('Unexpected guest name')
        cfg = row.get('expanded_config', row.get('config', {}))
        result[name] = {'status': row.get('status'), 'autostart': cfg.get('boot.autostart'),
                        'last_power': cfg.get('volatile.last_state.power'),
                        'cpu': cfg.get('limits.cpu'), 'memory': cfg.get('limits.memory'),
                        'processes': cfg.get('limits.processes')}
    return result


def backup_check(role, names):
    service = 'pulsarx-backup.service' if role == 'control' else 'pulsarx-container-backup.service'
    u = unit(service)
    if u.get('ActiveState') != 'inactive' or u.get('Result') != 'success' or u.get('ExecMainStatus') != '0':
        raise Stop('A completed successful ordinary backup is required: ' + service)
    stamp = u.get('ExecMainExitTimestamp', '')
    epoch = int(run(['date', '--date=' + stamp, '+%s']).stdout.strip()) if stamp else 0
    if not -60 <= time.time() - epoch < MAX_BACKUP_AGE:
        raise Stop('Last successful backup is older than 36 hours or its timestamp is invalid')
    if role == 'host':
        covered = False
        for folder in sorted(BACKUPS.glob('pulsarx-container-run-*'), reverse=True)[:10]:
            p = folder / 'complete.json'
            if not p.is_file() or p.is_symlink(): continue
            try:
                safe_dirs(p.parent)
                data = json.loads(read_file(p))
                covered = set(names) <= set(data.get('instances', [])) and -60 <= time.time() - p.stat().st_mtime < MAX_BACKUP_AGE
            except (ValueError, TypeError, OSError, Stop): continue
            if covered: break
        if not covered: raise Stop('No recent completion receipt covers every current guest; ordinary backup required')
    return {'service': service, 'completed_utc': stamp, 'receipt_coverage': role == 'host'}


def installed():
    data = run(['dpkg-query', '-W', '-f=${Package}\t${Version}\t${db:Status-Abbrev}\n', *TARGETS], check=False).stdout
    result = {}
    for line in data.splitlines():
        parts = line.split('\t')
        if len(parts) == 3 and parts[2].startswith('ii'): result[parts[0]] = parts[1]
    return result


def validate_plan(text, before):
    changes = {}
    for line in text.splitlines():
        if line.startswith(('Remv ', 'Purg ')): raise Stop('APT proposed a package removal')
        if not line.startswith(('Inst ', 'Conf ')): continue
        m = re.match(r'^(Inst|Conf) ([A-Za-z0-9+.-]+)(?::([a-z0-9]+))?(?: \[[^\]]+\])? \(([^ )]+)(?: |\))', line)
        if not m: raise Stop('Unrecognized APT plan entry')
        action, name, arch, version = m.groups()
        if name not in TARGETS or version != TARGETS[name] or arch not in (None, 'amd64', 'all'):
            raise Stop('APT plan differs from the reviewed scope: ' + name + '=' + version)
        if action == 'Inst': changes[name] = version
    for name, version in before.items():
        if name in changes and run(['dpkg', '--compare-versions', changes[name], 'lt', version], check=False).returncode == 0:
            raise Stop('Refusing downgrade: ' + name)
    return changes


def apt_base():
    return ['apt-get', '-o', 'DPkg::Lock::Timeout=60', '-o', 'Acquire::Retries=3',
            '-o', 'APT::Get::AllowUnauthenticated=false', '-o', 'Acquire::AllowInsecureRepositories=false',
            '--no-remove', '--no-install-recommends']


def apt_targets():
    return [name + '=' + TARGETS[name] for name in PRIMARY]


def simulate(before):
    r = run(apt_base() + ['--simulate', 'install', *apt_targets()], timeout=120)
    atomic(STATE / 'private-plan.txt', r.stdout.encode())
    return validate_plan(r.stdout, before)


def apt_gate(stream):
    # APT v1 pre-install hook. Every actual archive is checked before dpkg runs.
    for line in stream:
        value = line.rstrip('\n')
        if not value: continue
        p = Path(value)
        if p.parent != ARCHIVES or p.suffix != '.deb' or p.is_symlink(): raise Stop('Unexpected APT archive path')
        safe_dirs(p.parent)
        st = p.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_uid != 0 or st.st_mode & 0o022: raise Stop('Unsafe APT archive')
        raw = run(['dpkg-deb', '-f', str(p)]).stdout
        fields = dict(x.split(': ', 1) for x in raw.splitlines() if ': ' in x and not x.startswith(' '))
        name = fields.get('Package')
        if name not in TARGETS or fields.get('Version') != TARGETS[name] or fields.get('Architecture') not in ('amd64', 'all'):
            raise Stop('Actual archive is outside the reviewed package scope')
    print('APT ARCHIVE GATE: allowed package names and versions verified', flush=True)


def checkpoint_ssh():
    paths = [SSH / 'sshd_config', SSH / 'pulsarx-key-auth-r1.conf', KEYS]
    paths += sorted((SSH / 'sshd_config.d').glob('*.conf'))
    paths += sorted(SSH.glob('ssh_host_*_key.pub'))
    manifest = {}
    folder = STATE / 'ssh-before'
    folder.mkdir(mode=0o700, exist_ok=True); safe_dirs(folder)
    for p in paths:
        if not p.exists(): continue
        safe_dirs(p.parent); raw = read_file(p)
        name = str(p).replace('/', '_')
        atomic(folder / name, raw)
        manifest[str(p)] = sha(raw)
    save('ssh-before.json', manifest)
    return manifest


def verify_ssh_bytes(manifest):
    for name, digest in manifest.items():
        if sha(read_file(Path(name))) != digest:
            raise Stop('SSH file changed during package installation: ' + name + '; original saved privately')


def boot_report():
    files = {}
    for name in ['vmlinuz-' + KERNEL, 'initrd.img-' + KERNEL]:
        p = BOOT / name
        files[name] = p.is_file() and p.stat().st_size > 0
    grub = BOOT / 'grub/grub.cfg'
    return {'running_kernel': os.uname().release, 'target_kernel': KERNEL, 'boot_files': files,
            'grub_menu_has_target': grub.is_file() and KERNEL.encode() in read_file(grub, 8_000_000),
            'reboot_required_for_target': os.uname().release != KERNEL}


def verify_packages():
    actual = installed()
    if any(actual.get(p) != v for p, v in TARGETS.items()): raise Stop('Installed package versions differ from the fixed target')
    if run(['dpkg', '--audit']).stdout.strip(): raise Stop('dpkg reports unfinished package configuration')
    boot = boot_report()
    if not all(boot['boot_files'].values()): raise Stop('Target kernel or initramfs file is missing')
    return actual, boot


def preflight(role, address):
    ssh_policy = ssh_check(role, address)
    if run(['dpkg', '--audit']).stdout.strip(): raise Stop('dpkg needs attention before an update')
    holds = set(run(['apt-mark', 'showhold']).stdout.split())
    if holds & TARGETS.keys(): raise Stop('A target package is held; no hold will be overridden')
    for path, minimum in [('/', 3 * 1024**3), ('/boot', 450 * 1024**2), ('/var/cache/apt', 600 * 1024**2)]:
        if shutil.disk_usage(path).free < minimum: raise Stop('Insufficient working space at ' + path)
    if role == 'control': api_health(); inventory = {}
    else: active('incus.service'); inventory = guests()
    backup = backup_check(role, inventory)
    return {'ssh': ssh_policy, 'guests': inventory, 'backup': backup, 'packages': installed(), 'boot': boot_report()}


def set_phase(s, phase, message):
    s.update(phase=phase, message=message, updated_at=int(time.time()))
    save('state.json', s)
    print(phase.upper() + ': ' + message, flush=True)


def public_status(role):
    s = load()
    if not s: return {'role': role, 'phase': 'not_started', 'worker_active': False}
    if s['role'] != role: raise Stop('Saved role differs')
    busy = unit(s['unit']).get('ActiveState') in ('active', 'activating', 'reloading')
    return {k: s.get(k) for k in ('role', 'phase', 'message', 'updated_at', 'apt_started', 'changes', 'boot_after', 'guests_after', 'remaining_updates')} | {'worker_active': busy}


def worker(role):
    host(role)
    with lock('worker.lock'):
        s = load()
        if not s or s['role'] != role or s['phase'] != 'queued': raise Stop('Worker checkpoint mismatch')
        try:
            set_phase(s, 'checking', 'Checking SSH, package state, services and recent ordinary backups')
            before = preflight(role, s['source']); s['before'] = before; save('state.json', s)
            set_phase(s, 'refreshing', 'Refreshing signed APT indexes; application and guests remain available')
            long_run(['apt-get', '-o', 'Acquire::Retries=3', '-o', 'APT::Update::Error-Mode=any',
                      '-o', 'Acquire::AllowInsecureRepositories=false', 'update'], 'APT index refresh')
            for p in PRIMARY:
                policy = run(['apt-cache', 'policy', p]).stdout
                m = re.search(r'^\s*Candidate:\s*(\S+)', policy, re.M)
                if not m or m.group(1) != TARGETS[p]: raise Stop('New APT candidate needs review: ' + p)
            changes = simulate(before['packages']); s['changes'] = changes; save('state.json', s)
            if role == 'control' and changes: raise Stop('Control host now needs package changes; reviewed plan expected zero')
            if changes:
                checkpoint = checkpoint_ssh()
                set_phase(s, 'downloading', 'Downloading the fixed package set before installation')
                long_run(apt_base() + ['-y', '--download-only', 'install', *apt_targets()], 'Package download')
                if simulate(installed()) != changes: raise Stop('Package plan changed after download')
                preflight(role, s['source'])
                hook = '/usr/bin/python3 -I ' + str(STATE / 'entry.py') + ' --action apt-gate'
                s['apt_started'] = True
                set_phase(s, 'installing', 'Installing reviewed packages; do not reboot or kill APT')
                long_run(apt_base() + ['-y', '--no-download', '-o', 'DPkg::Options::=--force-confold',
                         '-o', 'DPkg::Pre-Install-Pkgs::=' + hook, 'install', *apt_targets()], 'Package installation')
                verify_ssh_bytes(checkpoint)
            set_phase(s, 'verifying', 'Checking installed versions, SSH and running services; no reboot')
            versions, boot = verify_packages(); s['packages_after'] = versions; s['boot_after'] = boot
            ssh_check(role, s['source'])
            if role == 'control': api_health()
            else:
                active('incus.service'); after = guests(); s['guests_after'] = after
                changed = [n for n, row in before['guests'].items() if row['status'] == 'Running' and after.get(n, {}).get('status') != 'Running']
                if changed: raise Stop('Previously running guests need review: ' + ', '.join(changed) + '; none will be restarted automatically')
                for n, row in before['guests'].items():
                    if n in after and any(row[k] != after[n][k] for k in ('cpu', 'memory', 'processes')):
                        raise Stop('Guest resource settings changed concurrently: ' + n)
            remaining = run(['apt-get', '--simulate', 'upgrade'], timeout=120, check=False)
            s['remaining_updates'] = [line.split()[1] for line in remaining.stdout.splitlines() if line.startswith('Inst ')] if remaining.returncode == 0 else None
            set_phase(s, 'complete', 'Fixed package set verified. Kernel activation and remaining updates are separate stages')
        except Exception as e:
            message = str(e) if isinstance(e, Stop) else type(e).__name__ + '; private diagnostic needed'
            set_phase(s, 'failed', message)
            raise Stop(message)


def start(role):
    host(role); source = ssh_source(role)
    with lock('start.lock'):
        old = load()
        if old:
            state = public_status(role)
            if state['worker_active'] or old['phase'] == 'complete':
                print('PXJSON:' + json.dumps(state)); return
            if old.get('apt_started'):
                raise Stop('An installation already started and needs review; do not rerun APT or reboot blindly. Use Status')
        ssh_check(role, source)
        raw = read_file(Path(__file__))
        compile(raw, 'entry.py', 'exec'); atomic(STATE / 'entry.py', raw, 0o700)
        s = {'release': RELEASE, 'role': role, 'source': source, 'phase': 'queued', 'apt_started': False,
             'message': 'Independent worker queued', 'updated_at': int(time.time()),
             'unit': 'pulsarx-os-update-' + role + '-' + uuid.uuid4().hex[:10] + '.service'}
        save('state.json', s)
        r = run(['systemd-run', '--quiet', '--unit=' + s['unit'], '--service-type=exec',
                 '--property=UMask=0077', '--property=Nice=10', '--property=TimeoutStartSec=infinity',
                 '/usr/bin/python3', '-I', str(STATE / 'entry.py'), '--action', 'worker', '--role', role], check=False)
        if r.returncode and not public_status(role)['worker_active']: raise Stop('Worker launch failed; use Status')
        print('PXJSON:' + json.dumps(public_status(role)))


def verify(role):
    host(role); source = ssh_source(role); setup(); s = load()
    if not s or s['role'] != role or s['phase'] != 'complete': raise Stop('Package worker has not completed')
    actual, boot = verify_packages(); ssh_check(role, source)
    if role == 'control': api_health()
    else: active('incus.service'); guests()
    print('VERIFIED: ' + role + '; independent SSH connection, package versions and services checked')
    print('PXJSON:' + json.dumps(public_status(role) | {'boot_now': boot, 'packages_verified': True}))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--action', required=True, choices=('start', 'status', 'worker', 'verify', 'apt-gate'))
    p.add_argument('--role', choices=IPS, default='host')
    a = p.parse_args()
    print('RELEASE: ' + RELEASE, flush=True)
    if a.action == 'apt-gate': apt_gate(sys.stdin); return
    if a.action == 'start': start(a.role)
    elif a.action == 'worker': worker(a.role)
    elif a.action == 'verify': verify(a.role)
    else:
        host(a.role); setup(); print('PXJSON:' + json.dumps(public_status(a.role)))


if __name__ == '__main__':
    try: main()
    except (Stop, OSError, ValueError) as e:
        print('STOPPED: ' + (str(e) if isinstance(e, Stop) else type(e).__name__) + '. No reboot or guest rollback performed.', file=sys.stderr)
        sys.exit(1)
