#!/bin/bash
set -euo pipefail
umask 077

BACKUP_DIR="/opt/pulsarx-backup/local"
RCLONE_CONFIG="/root/.config/rclone/rclone.conf"
RCLONE_REMOTE="b2backup:pulsarx-backups/containers"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"

# PulsarX container backup integrity v1
exec /usr/bin/python3 /opt/pulsarx-backup/flex_backup.py --backup
