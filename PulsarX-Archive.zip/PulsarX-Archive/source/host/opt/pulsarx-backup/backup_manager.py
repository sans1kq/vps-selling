#!/usr/bin/env python3
"""PulsarX container backup manager: checked exports, permanent bounded rotation.

--check is read-only. --apply installs and permanently removes the listed excess
backup versions. The newest existing cloud copy of every container name survives.
Containers, their power states, pools, network, database/config backups and B2
account caps are never modified by this tool.
"""
import argparse
import base64
import configparser
from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid

CONFIG = Path('/root/.config/rclone/rclone.conf')
BUCKET = 'pulsarx-backups'

ORIGINAL_BODY = 'for name in $(incus list -c n --format csv); do\n  echo "Exporting $name..."\n  OUT="$BACKUP_DIR/${name}_${TIMESTAMP}.tar.gz"\n  incus export "$name" "$OUT" --compression gzip\ndone\n\n# --- Upload to B2 ---\nif command -v rclone >/dev/null 2>&1 && [ -f "$RCLONE_CONFIG" ]; then\n  rclone --config "$RCLONE_CONFIG" copy "$BACKUP_DIR" "$RCLONE_REMOTE/" --include "*_${TIMESTAMP}.tar.gz" --quiet\n\n  # remote retention: keep last 7 per container (~1 week daily)\n  for name in $(incus list -c n --format csv); do\n    rclone --config "$RCLONE_CONFIG" lsf "$RCLONE_REMOTE/" | grep "^${name}_" | sort | head -n -3 | while read -r f; do\n      rclone --config "$RCLONE_CONFIG" deletefile "$RCLONE_REMOTE/$f" --quiet\n    done\n  done\nelse\n  echo "WARNING: rclone not configured — this backup stayed local-only" >&2\nfi\n\n# --- Local retention: keep last 3 per container (space on VPS-2 is limited) ---\nfor name in $(incus list -c n --format csv); do\n  ls -t "$BACKUP_DIR/${name}_"*.tar.gz 2>/dev/null | tail -n +2 | xargs -r rm --\ndone\n\necho "Container backups done: $TIMESTAMP"\n'

def load_credentials(path=CONFIG):
    if not path.is_file() or path.is_symlink():
        raise RuntimeError("Expected the existing regular rclone config file")
    parser = configparser.ConfigParser(interpolation=None)
    try:
        parser.read_string(path.read_text())
    except (configparser.Error, UnicodeError):
        raise RuntimeError("Cannot parse rclone config; values are hidden") from None
    if not parser.has_section("b2backup"):
        raise RuntimeError("The existing b2backup remote is missing")
    section = parser["b2backup"]
    if section.get("type") != "b2" or section.get("endpoint", "").strip():
        raise RuntimeError("Expected the native Backblaze B2 remote and default endpoint")
    account, key = section.get("account", ""), section.get("key", "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{4,200}", account) or not re.fullmatch(r"[A-Za-z0-9_+=/-]{8,300}", key):
        raise RuntimeError("Unsupported rclone credential format; values are hidden")
    return account, key


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class B2:
    def __init__(self, account, key, opener=None):
        self.opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        basic = base64.b64encode((account + ":" + key).encode()).decode()
        auth = self.request("https://api.backblazeb2.com/b2api/v4/b2_authorize_account", "GET", "Basic " + basic)
        storage = auth.get("apiInfo", {}).get("storageApi", {})
        url = storage.get("apiUrl", "")
        parsed = urllib.parse.urlsplit(url)
        if (parsed.scheme != "https" or not re.fullmatch(r"api[0-9]*\.backblazeb2\.com", parsed.netloc)
                or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise RuntimeError("Backblaze returned an unexpected API endpoint")
        self.url = url.rstrip("/")
        self.token = auth.get("authorizationToken", "")
        if not isinstance(self.token, str) or not re.fullmatch(r"[!-~]{1,50000}", self.token):
            raise RuntimeError("Backblaze returned an invalid authorization token")
        allowed = storage.get("allowed", {})
        if not {"listFiles", "deleteFiles"}.issubset(set(allowed.get("capabilities", []))):
            raise RuntimeError("The existing B2 key needs listFiles and deleteFiles capabilities")
        if allowed.get("namePrefix") not in (None, ""):
            raise RuntimeError("A prefix-restricted B2 key cannot validate the whole backup bucket")
        matches = [b for b in (allowed.get("buckets") or []) if b.get("name") == BUCKET]
        if len(matches) == 1:
            self.bucket_id = matches[0].get("id")
        elif not allowed.get("buckets") or "listBuckets" in allowed.get("capabilities", []):
            buckets = self.call("b2_list_buckets", {"accountId": auth["accountId"], "bucketName": BUCKET})
            matches = [b for b in buckets.get("buckets", []) if b.get("bucketName") == BUCKET]
            if len(matches) != 1:
                raise RuntimeError("Could not uniquely identify pulsarx-backups")
            self.bucket_id = matches[0].get("bucketId")
        else:
            raise RuntimeError("The B2 key does not identify the requested bucket")
        if not isinstance(self.bucket_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,200}", self.bucket_id):
            raise RuntimeError("Invalid backup bucket identifier")

    def request(self, url, method, authorization, body=None):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Authorization": authorization, "Content-Type": "application/json"})
        try:
            with self.opener.open(req, timeout=40) as response:
                payload = response.read(8 * 1024 * 1024 + 1)
            if len(payload) > 8 * 1024 * 1024:
                raise RuntimeError("Backblaze response exceeds the size limit")
            result = json.loads(payload)
            if not isinstance(result, dict):
                raise RuntimeError("Unexpected Backblaze response")
            return result
        except urllib.error.HTTPError as exc:
            try:
                code = json.loads(exc.read(65536)).get("code", "http_error")
            except (ValueError, AttributeError):
                code = "http_error"
            if not isinstance(code, str) or not re.fullmatch(r"[a-z0-9_]{1,80}", code):
                code = "http_error"
            raise RuntimeError("Backblaze HTTP %s (%s); credentials hidden" % (exc.code, code)) from None
        except (urllib.error.URLError, TimeoutError):
            raise RuntimeError("Backblaze network/TLS request failed; credentials hidden") from None
        except (ValueError, UnicodeError):
            raise RuntimeError("Cannot parse Backblaze response; values are hidden") from None

    def call(self, operation, body):
        if operation not in ("b2_list_buckets", "b2_delete_file_version"):
            raise RuntimeError("Unexpected B2 write-method operation")
        return self.request(self.url + "/b2api/v4/" + operation, "POST", self.token, body)

    def inventory(self):
        records, cursor, seen = [], {}, set()
        for page in range(100):
            query = {"bucketId": self.bucket_id, "maxFileCount": 1000, **cursor}
            url = self.url + "/b2api/v4/b2_list_file_versions?" + urllib.parse.urlencode(query)
            result = self.request(url, "GET", self.token)
            rows = result.get("files")
            if not isinstance(rows, list):
                raise RuntimeError("Incomplete B2 version inventory")
            for row in rows:
                if not isinstance(row, dict) or row.get("bucketId") != self.bucket_id:
                    raise RuntimeError("A file belongs to another bucket")
                identifier = row.get("fileId")
                if not isinstance(identifier, str) or not identifier or identifier in seen:
                    raise RuntimeError("Missing or duplicate B2 file ID")
                if (not isinstance(row.get("fileName"), str) or row.get("action") not in ("upload", "hide", "start", "folder")
                        or not isinstance(row.get("contentLength"), int) or row["contentLength"] < 0):
                    raise RuntimeError("Malformed B2 file metadata")
                try:
                    row["uploadTimestamp"] = int(row["uploadTimestamp"])
                except (KeyError, TypeError, ValueError):
                    raise RuntimeError("Missing B2 upload timestamp") from None
                seen.add(identifier)
                records.append(row)
            name, identifier = result.get("nextFileName"), result.get("nextFileId")
            if name is None:
                return records
            new = {"startFileName": name, "startFileId": identifier}
            if new == cursor:
                raise RuntimeError("B2 pagination did not advance")
            cursor = new
        raise RuntimeError("Backup inventory exceeds this repair's page limit")

    def delete(self, record):
        return self.call("b2_delete_file_version", {"fileName": record["fileName"], "fileId": record["fileId"]})


def identity(record):
    return tuple(record[key] for key in ("fileId", "fileName", "action", "contentLength", "uploadTimestamp"))


def current_files(records):
    grouped = {}
    for row in records:
        if row["action"] not in ("upload", "hide"):
            continue
        grouped.setdefault(row["fileName"], []).append(row)
    result = {}
    for name, rows in grouped.items():
        rows.sort(key=lambda r: r["uploadTimestamp"], reverse=True)
        if len(rows) > 1 and rows[0]["uploadTimestamp"] == rows[1]["uploadTimestamp"]:
            raise RuntimeError("Ambiguous current file timestamp: " + name)
        if rows[0]["action"] == "upload":
            result[name] = rows[0]
    return result


def private_write(path, data):
    with path.open("xb") as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(data)


def atomic_write(path, data):
    before = path.stat()
    fd, temporary = tempfile.mkstemp(prefix=".backup-repair-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            os.fchmod(stream.fileno(), stat.S_IMODE(before.st_mode))
            if os.geteuid() == 0:
                os.fchown(stream.fileno(), before.st_uid, before.st_gid)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


SOURCE = Path('/opt/pulsarx-backup/backup_containers.sh')
HELPER = Path('/opt/pulsarx-backup/backup_manager.py')
LOCAL = Path('/opt/pulsarx-backup/local')
HOST = 'pulsar2'
MARKER = '# PulsarX container backup integrity v1'
BUDGET = 9_000_000_000
MAX_KEEP = 3
MANAGED = re.compile(r'(mini-[0-9a-f]{10})_([0-9]{8}_[0-9]{6})\.tar\.gz\Z')
WRAPPER = MARKER + '\nexec /usr/bin/python3 /opt/pulsarx-backup/backup_manager.py --backup\n'


def log(message):
    print(message, flush=True)


def archive_key(filename):
    match = MANAGED.fullmatch(filename)
    if not match:
        return None
    try:
        datetime.strptime(match[2], '%Y%m%d_%H%M%S')
    except ValueError:
        return None
    return match[1], match[2]


def cloud_key(row):
    name = row['fileName']
    if not name.startswith('containers/') or '/' in name[len('containers/'):]:
        return None
    return archive_key(name[len('containers/'):])


def remote_sha1(row):
    direct = row.get('contentSha1', '')
    metadata = (row.get('fileInfo') or {}).get('large_file_sha1', '')
    for value in (direct, metadata):
        if isinstance(value, str) and re.fullmatch('[0-9a-fA-F]{40}', value):
            return value.lower()
    return None


def get_b2(client, operation, params):
    if operation not in ('b2_list_unfinished_large_files', 'b2_get_upload_url'):
        raise RuntimeError('Unexpected backup read operation')
    return client.request(client.url + '/b2api/v4/' + operation + '?' + urllib.parse.urlencode(params), 'GET', client.token)


def no_unfinished(client):
    result = get_b2(client, 'b2_list_unfinished_large_files', {'bucketId': client.bucket_id, 'maxFileCount': 1})
    if not isinstance(result.get('files'), list):
        raise RuntimeError('Could not check unfinished uploads')
    if result['files'] or result.get('nextFileId'):
        raise RuntimeError('An unfinished upload exists in this bucket; stopped without cancelling it')


def upload_allowed(client):
    try:
        response = get_b2(client, 'b2_get_upload_url', {'bucketId': client.bucket_id})
    except RuntimeError as exc:
        if str(exc) == 'Backblaze HTTP 403 (storage_cap_exceeded); credentials hidden':
            return False
        raise
    if (response.get('bucketId') != client.bucket_id or not response.get('uploadUrl')
            or not response.get('authorizationToken')):
        raise RuntimeError('Incomplete upload-permission response; sensitive values hidden')
    return True


def remote_plan(rows, active, incoming_bytes=0, budget=BUDGET):
    if type(incoming_bytes) is not int or incoming_bytes < 0:
        raise RuntimeError('Invalid incoming backup size')
    # One representative per export filename. A hidden upload is still a
    # recoverable version, so keep the newest point even for retired instances.
    groups = {}
    for row in rows:
        key = cloud_key(row)
        if row['action'] == 'upload' and key:
            groups.setdefault(key[0], []).append(row)
    keep, protect, selected = set(), set(), []
    for name, entries in groups.items():
        entries.sort(key=lambda row: (cloud_key(row)[1], row['uploadTimestamp'], row['fileId']), reverse=True)
        seen_exports = set()
        limit = MAX_KEEP if name in active else 1
        for row in entries:
            key = cloud_key(row)[1]
            if key not in seen_exports and len(seen_exports) < limit:
                keep.add(row['fileId'])
                seen_exports.add(key)
            else:
                selected.append(row)
        protect.add(entries[0]['fileId'])
    total = sum(row['contentLength'] for row in rows if row['action'] == 'upload')
    remaining = total - sum(row['contentLength'] for row in selected) + incoming_bytes
    # Reduce older recovery points if needed, but never the newest existing
    # cloud backup for any name, even before a replacement upload succeeds.
    if remaining > budget:
        optional = [row for row in rows if row['fileId'] in keep - protect]
        optional.sort(key=lambda row: (cloud_key(row)[1], row['uploadTimestamp'], row['fileId']))
        for row in optional:
            if remaining <= budget:
                break
            selected.append(row)
            keep.remove(row['fileId'])
            remaining -= row['contentLength']
    if remaining > budget:
        raise RuntimeError('Cannot fit this backup within the 9 GB bucket budget while keeping every last cloud copy')
    for row in selected:
        value = (row.get('fileRetention') or {}).get('value') or {}
        if value.get('mode') or (row.get('legalHold') or {}).get('value') == 'on':
            raise RuntimeError('A planned old backup has Object Lock protection')
    # Remove older versions first; deleting a current version must not expose
    # another old version scheduled for removal under the same filename.
    selected.sort(key=lambda row: (row['fileName'], row['uploadTimestamp'], row['fileId']))
    return {'delete': selected, 'keep': keep, 'protect': protect,
            'retained': [{'fileName': row['fileName'], 'fileId': row['fileId'], 'bytes': row['contentLength']}
                         for row in rows if row['fileId'] in keep],
            'forecast_bytes': remaining, 'before_bytes': total}


def assert_remote_preserved(before, after, allowed):
    later = {row['fileId']: identity(row) for row in after}
    for row in before:
        if row['fileId'] not in allowed and later.get(row['fileId']) != identity(row):
            raise RuntimeError('An unselected cloud version changed; stopped for review')
    old, new = current_files(before), current_files(after)
    for name, row in old.items():
        if row['fileId'] not in allowed and (name not in new or identity(new[name]) != identity(row)):
            raise RuntimeError('A protected current backup changed; stopped for review')


def delete_remote(client, before, plan, report, names_fn, expected_names):
    allowed = {row['fileId'] for row in plan['delete']}
    if allowed & plan['protect']:
        raise RuntimeError('The plan includes a last cloud copy')
    completed = []
    for row in plan['delete']:
        if names_fn() != expected_names:
            raise RuntimeError('The instance list changed during rotation; retry next run')
        state = client.inventory()
        assert_remote_preserved(before, state, allowed)
        live = {entry['fileId']: entry for entry in state}
        for protected in plan['protect']:
            if protected not in live:
                raise RuntimeError('A last cloud copy is no longer present')
        if row['fileId'] in live:
            if identity(live[row['fileId']]) != identity(row):
                raise RuntimeError('A deletion candidate changed')
            error = None
            try:
                client.delete(row)
            except Exception as exc:
                error = exc
            after = client.inventory()
            assert_remote_preserved(before, after, allowed)
            if any(entry['fileId'] == row['fileId'] for entry in after):
                if error:
                    raise error
                raise RuntimeError('Cloud deletion could not be verified')
        completed.append(row['fileId'])
        private_write(report / ('cloud-delete-%03d.json' % len(completed)), json.dumps({'fileId': row['fileId'], 'fileName': row['fileName'], 'bytes': row['contentLength']}).encode())
        log('REMOVED OLD CLOUD VERSION: ' + row['fileName'])
    final = client.inventory()
    assert_remote_preserved(before, final, allowed)
    if any(row['fileId'] in allowed for row in final):
        raise RuntimeError('A selected old cloud version remains')
    return final


def file_signature(path):
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode):
        raise RuntimeError('Expected a regular local archive: ' + path.name)
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)


def validate_archive(path):
    before = file_signature(path)
    found, payload = False, False
    try:
        # Stream through tar and then through the gzip footer. No extraction.
        with gzip.open(path, 'rb') as stream:
            with tarfile.open(fileobj=stream, mode='r|') as archive:
                for member in archive:
                    if member.name.removeprefix('./') == 'backup/index.yaml' and member.isfile() and member.size > 0:
                        found = True
                    elif member.name.removeprefix('./').startswith('backup/') and member.isfile() and member.size > 0:
                        payload = True
            while stream.read(1024 * 1024):
                pass
    except (OSError, EOFError, tarfile.TarError):
        raise RuntimeError('Archive CRC/tar validation failed: ' + path.name) from None
    if not found or not payload:
        raise RuntimeError('Incus backup metadata/payload is missing: ' + path.name)
    sha1 = hashlib.sha1()
    with path.open('rb') as stream:
        while True:
            chunk = stream.read(4 * 1024 * 1024)
            if not chunk:
                break
            sha1.update(chunk)
    if file_signature(path) != before:
        raise RuntimeError('A local archive changed during validation')
    return {'path': str(path), 'signature': before, 'sha1': sha1.hexdigest(), 'bytes': before[2]}


def local_plan(directory=LOCAL):
    if directory.is_symlink() or not directory.is_dir() or directory.resolve() != directory:
        raise RuntimeError('Expected the existing local backup directory')
    groups = {}
    for path in directory.iterdir():
        key = archive_key(path.name)
        if key:
            file_signature(path)
            groups.setdefault(key[0], []).append(path)
    keep, delete = {}, []
    for name, paths in sorted(groups.items()):
        paths.sort(key=lambda path: archive_key(path.name)[1], reverse=True)
        chosen = None
        for path in paths:
            log('CHECK LOCAL: ' + path.name)
            try:
                chosen = validate_archive(path)
                break
            except RuntimeError as exc:
                log('KEEP UNTIL A VALID COPY EXISTS: ' + str(exc))
        if chosen is None:
            log('NO VALID LOCAL COPY: ' + name + '; existing files left in place')
            continue
        keep[name] = chosen
        delete.extend({'path': str(path), 'signature': file_signature(path)} for path in paths if str(path) != chosen['path'])
    return {'keep': keep, 'delete': delete, 'directory': str(directory), 'free_bytes': shutil.disk_usage(directory).free}


def delete_local(plan, report):
    for kept in plan['keep'].values():
        path = Path(kept['path'])
        if file_signature(path) != tuple(kept['signature']):
            raise RuntimeError('A validated retained local archive changed')
    for i, row in enumerate(plan['delete']):
        path = Path(row['path'])
        name = archive_key(path.name)[0]
        kept = plan['keep'].get(name)
        if not kept or file_signature(Path(kept['path'])) != tuple(kept['signature']):
            raise RuntimeError('Cannot remove an old local file without its validated replacement')
        if file_signature(path) != tuple(row['signature']):
            raise RuntimeError('An old local file changed during rotation')
        private_write(report / ('local-delete-%03d.json' % i), json.dumps(row).encode())
        path.unlink()
        log('REMOVED OLD LOCAL ARCHIVE: ' + path.name)
    for row in plan['keep'].values():
        os.chmod(row['path'], 0o600)


def command(args, label, report=None, timeout=60):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError(label + ' timed out') from None
    if result.returncode:
        if report is not None:
            private_write(report / ('command-error-' + uuid.uuid4().hex[:8] + '.txt'), (result.stdout[-64000:] + result.stderr[-64000:]).encode())
        raise RuntimeError(label + ' failed (exit %d); see private report if available' % result.returncode)
    return result.stdout


def instance_names():
    rows = json.loads(command(['incus', '--force-local', '--project', 'default', 'list', '--format', 'json'], 'Local Incus list'))
    if not isinstance(rows, list):
        raise RuntimeError('Unexpected Incus instance list')
    names = set()
    for row in rows:
        name = row.get('name')
        if not isinstance(name, str) or not re.fullmatch(r'mini-[0-9a-f]{10}', name) or name in names:
            raise RuntimeError('Unexpected/duplicate instance name; backup scope needs review')
        if row.get('type') not in ('container', 'virtual-machine'):
            raise RuntimeError('Unexpected Incus instance type')
        names.add(name)
    return names


def runtime_preflight():
    for executable in ('incus', 'rclone'):
        if shutil.which(executable) is None:
            raise RuntimeError('Required command missing: ' + executable)
    flags = command(['rclone', 'help', 'flags'], 'rclone flag discovery')
    if '--immutable' not in flags or '--b2-disable-checksum' not in flags:
        raise RuntimeError('Installed rclone is missing required immutable/checksum flags')


def safe_parent(path):
    if path.is_symlink() or not path.is_dir() or path.resolve() != path:
        raise RuntimeError('Unexpected backup/report parent directory')


def make_report(parent, prefix):
    safe_parent(parent)
    path = parent / (prefix + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    path.mkdir(mode=0o700)
    return path


def save_plan(report, label, rows, remote, local):
    private_write(report / (label + '-inventory.json'), json.dumps(rows, indent=2).encode())
    serial = {key: sorted(value) if isinstance(value, set) else value for key, value in remote.items()}
    private_write(report / (label + '-plan.json'), json.dumps({'remote': serial, 'local': local}, indent=2).encode())


def preview(names, remote, local):
    log('POLICY: up to 3 cloud points for existing instances; latest 1 for retired instances; at least 1 existing cloud point per name always protected.')
    log('LOCAL: keep 1 validated archive per name; files without a validated replacement are preserved.')
    log('BUDGET: 9.000 GB in this bucket; account caps unchanged.')
    log('INCUS DEFAULT PROJECT: ' + (', '.join(sorted(names)) or '(empty)'))
    for row in remote['retained']:
        log('KEEP CLOUD: %s bytes=%d' % (row['fileName'], row['bytes']))
    for row in local.get('keep', {}).values():
        log('KEEP LOCAL: %s bytes=%d' % (Path(row['path']).name, row['bytes']))
    if 'free_bytes' in local:
        log('LOCAL DISK FREE: %.3f GB' % (local['free_bytes'] / 1e9))
    for row in remote['delete']:
        log('PERMANENT CLOUD DELETE: %s bytes=%d id=%s' % (row['fileName'], row['contentLength'], row['fileId']))
    for row in local['delete']:
        log('LOCAL DELETE: ' + Path(row['path']).name)
    log('PLAN: %d old cloud versions (%.3f GB), %d old local archives.' % (
        len(remote['delete']), sum(row['contentLength'] for row in remote['delete']) / 1e9, len(local['delete'])))
    log('CLOUD AFTER PLAN: %.3f GB' % (remote['forecast_bytes'] / 1e9))


def export_instance(name, directory, report, previous_size=0):
    # Incus may keep a temporary export plus the downloaded archive. Preserve
    # a reserve and the previous validated file throughout this operation.
    minimum = max(2 * 1024**3, int(previous_size * 2.5) + 1024**3)
    if shutil.disk_usage(directory).free < minimum:
        raise RuntimeError('Insufficient temporary disk space for a safe export of ' + name)
    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    filename = name + '_' + timestamp + '.tar.gz'
    target = directory / filename
    if target.exists() or target.is_symlink():
        raise RuntimeError('Export filename already exists; previous archive preserved')
    with tempfile.TemporaryDirectory(prefix='.pulsarx-export-', dir=directory) as stage:
        os.chmod(stage, 0o700)
        temporary = Path(stage) / filename
        log('EXPORT: ' + name)
        command(['incus', '--force-local', '--project', 'default', 'export', name, str(temporary), '--compression', 'gzip', '--quiet'],
                'Incus export ' + name, report, timeout=7200)
        metadata = validate_archive(temporary)
        os.chmod(temporary, 0o600)
        os.replace(temporary, target)
        metadata['path'] = str(target)
        metadata['signature'] = file_signature(target)
        log('LOCAL READY: %s bytes=%d SHA1=%s' % (filename, metadata['bytes'], metadata['sha1']))
        return metadata


def checked_upload(client, metadata, report):
    path = Path(metadata['path'])
    if file_signature(path) != tuple(metadata['signature']):
        raise RuntimeError('The validated upload source changed')
    remote_name = 'containers/' + path.name
    before = client.inventory()
    if any(row['fileName'] == remote_name for row in before):
        raise RuntimeError('Cloud filename already exists; immutable backup was not overwritten')
    if sum(row['contentLength'] for row in before if row['action'] == 'upload') + metadata['bytes'] > BUDGET:
        raise RuntimeError('Bucket budget changed before upload; validated local archive preserved')
    no_unfinished(client)
    command(['rclone', '--config', str(CONFIG), 'copyto', str(path), 'b2backup:' + BUCKET + '/' + remote_name,
             '--immutable', '--b2-disable-checksum=false', '--transfers', '1', '--quiet'], 'B2 upload ' + path.name, report, timeout=7200)
    after = client.inventory()
    assert_remote_preserved(before, after, set())
    uploaded = current_files(after).get(remote_name)
    if (not uploaded or uploaded['contentLength'] != metadata['bytes'] or remote_sha1(uploaded) != metadata['sha1']
            or file_signature(path) != tuple(metadata['signature'])):
        raise RuntimeError('Uploaded archive size/SHA1 verification failed; previous cloud copies preserved')
    log('CLOUD VERIFIED: ' + path.name)


def backup_job(client, directory=LOCAL, report_parent=Path('/var/backups'), names_fn=instance_names):
    report = make_report(report_parent, 'pulsarx-container-run-')
    log('REPORT: ' + str(report))
    try:
        names = names_fn()
        local = local_plan(directory)
        private_write(report / 'local-before.json', json.dumps(local, indent=2).encode())
        delete_local(local, make_report(report, 'local-before-'))
        new = []
        for name in sorted(names):
            previous = local['keep'].get(name, {}).get('bytes', 0)
            new.append(export_instance(name, directory, report, previous))
            # Local rotation runs before any cloud operation, including failure.
            refreshed = local_plan(directory)
            delete_local(refreshed, make_report(report, 'local-after-export-'))
        if names_fn() != names:
            raise RuntimeError('Instances changed during export; local archives kept, cloud unchanged')
        runtime_preflight()
        if callable(client):
            client = client()
        no_unfinished(client)
        rows = client.inventory()
        plan = remote_plan(rows, names, sum(row['bytes'] for row in new))
        save_plan(report, 'pre-upload', rows, plan, {'keep': new, 'delete': []})
        preview(names, plan, {'delete': []})
        rotated = delete_remote(client, rows, plan, make_report(report, 'cloud-before-'), names_fn, names)
        if sum(row['contentLength'] for row in rotated if row['action'] == 'upload') + sum(row['bytes'] for row in new) > BUDGET:
            raise RuntimeError('Bucket grew during rotation; cannot fit pending uploads safely')
        if not upload_allowed(client):
            raise RuntimeError('B2 storage_cap_exceeded; validated local archives kept, no upload performed')
        for metadata in new:
            checked_upload(client, metadata, report)
        if names_fn() != names:
            raise RuntimeError('Instances changed during upload; verified cloud copies kept, coverage needs retry')
        after = client.inventory()
        final_plan = remote_plan(after, names)
        save_plan(report, 'post-upload', after, final_plan, {'keep': new, 'delete': []})
        delete_remote(client, after, final_plan, make_report(report, 'cloud-after-'), names_fn, names)
        private_write(report / 'complete.json', json.dumps({'instances': sorted(names), 'archives': new}).encode())
        log('COMPLETE: local archives validated; every new cloud archive verified by size and SHA1.')
    except BaseException:
        log('BACKUP INCOMPLETE: see ' + str(report))
        raise
    return report


def patch_script(text):
    for line in ('BACKUP_DIR="/opt/pulsarx-backup/local"',
                 'RCLONE_CONFIG="/root/.config/rclone/rclone.conf"',
                 'RCLONE_REMOTE="b2backup:pulsarx-backups/containers"'):
        if text.count(line) != 1:
            raise RuntimeError('Unexpected container-backup configuration; no changes made')
    if MARKER in text:
        if not text.endswith(WRAPPER) or text.count(MARKER) != 1:
            raise RuntimeError('The existing backup wrapper was customized')
        return text
    if text.count(ORIGINAL_BODY) != 1 or not text.endswith(ORIGINAL_BODY):
        raise RuntimeError('The original backup body differs from the reviewed source; no changes made')
    if re.search(r'^\s*(trap|exec)\b', text, re.M):
        raise RuntimeError('A custom backup trap/exec needs review')
    prefix = text[:-len(ORIGINAL_BODY)]
    if prefix.count('set -euo pipefail') != 1:
        raise RuntimeError('Unexpected Bash safety options')
    prefix = prefix.replace('set -euo pipefail', 'set -euo pipefail\numask 077', 1)
    return prefix + WRAPPER


def install(client, apply=False, source=SOURCE, helper=HELPER, directory=LOCAL, report_parent=Path('/var/backups'), names_fn=instance_names):
    if source.is_symlink() or not source.is_file() or source.resolve() != source:
        raise RuntimeError('Expected the existing backup_containers.sh')
    original = source.read_bytes()
    patched = patch_script(original.decode()).encode()
    if subprocess.run(['/bin/bash', '-n'], input=patched, capture_output=True).returncode:
        raise RuntimeError('Patched backup wrapper failed Bash syntax validation')
    payload = Path(__file__).read_bytes()
    compile(payload, str(helper), 'exec')
    if helper.is_symlink() or (helper.exists() and not helper.is_file()):
        raise RuntimeError('Unexpected backup helper target')
    if helper.exists() and b'PulsarX container backup manager' not in helper.read_bytes():
        raise RuntimeError('An unrelated helper already exists at the target')
    names = names_fn()
    no_unfinished(client)
    before = client.inventory()
    plan = remote_plan(before, names)
    local = local_plan(directory)
    preview(names, plan, local)
    if not apply:
        log('CHECK OK: no scripts or archives changed; no versions removed.')
        return None
    if names_fn() != names or source.read_bytes() != original:
        raise RuntimeError('Instances or script changed before installation')
    now = client.inventory()
    assert_remote_preserved(before, now, set())
    if sorted(identity(row) for row in remote_plan(now, names)['delete']) != sorted(identity(row) for row in plan['delete']):
        raise RuntimeError('The cleanup plan changed before installation')
    report = make_report(report_parent, 'pulsarx-container-backup-fix-')
    private_write(report / 'backup_containers.sh', original)
    if helper.exists():
        private_write(report / 'backup_manager.py', helper.read_bytes())
    save_plan(report, 'install', before, plan, local)
    try:
        if helper.exists():
            atomic_write(helper, payload)
        else:
            private_write(helper, payload)
        os.chmod(helper, 0o644)
        if helper.read_bytes() != payload:
            raise RuntimeError('Installed helper verification failed')
        if original != patched:
            atomic_write(source, patched)
        delete_local(local, make_report(report, 'local-'))
        final = delete_remote(client, before, plan, make_report(report, 'cloud-'), names_fn, names)
        private_write(report / 'complete.json', json.dumps({'cloud_bytes': sum(row['contentLength'] for row in final if row['action'] == 'upload')}).encode())
    except BaseException:
        log('INSTALL/CLEANUP INCOMPLETE; already deleted versions cannot be restored. Report: ' + str(report))
        raise
    log('APPLIED: backup job replaced; selected excess archives permanently removed.')
    log('REPORT AND SCRIPT BACKUP: ' + str(report))
    try:
        log('UPLOAD PROBE: ' + ('ALLOWED' if upload_allowed(client) else 'BLOCKED storage_cap_exceeded; account cap unchanged'))
    except RuntimeError as exc:
        log('UPLOAD PROBE: UNAVAILABLE; installation completed. ' + str(exc))
    log('NEXT: the existing timer will run the new job; a successful cloud backup still needs confirmation.')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true', help='Read-only installation and cleanup preview (default)')
    group.add_argument('--apply', action='store_true', help='Install the job and permanently rotate excess archives')
    group.add_argument('--backup', action='store_true', help='Run the installed daily backup job')
    args = parser.parse_args()
    if os.geteuid() != 0 or socket.gethostname().split('.')[0] != HOST:
        raise RuntimeError('Run with sudo on new compute 192.0.2.12 (' + HOST + ')')
    os.umask(0o077)
    with open('/run/lock/pulsarx-container-backup.lock', 'a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another backup/rotation is running') from None
        if not args.backup:
            state = command(['systemctl', 'show', 'pulsarx-container-backup.service', '-p', 'ActiveState', '--value'], 'Service state').strip()
            if state in ('active', 'activating', 'deactivating', 'reloading'):
                raise RuntimeError('The existing backup service is running; wait for it to finish')
            user = command(['systemctl', 'show', 'pulsarx-container-backup.service', '-p', 'User', '--value'], 'Service user').strip()
            if user not in ('', 'root'):
                raise RuntimeError('The backup service uses a non-root account; installation needs review')
        if args.backup:
            backup_job(lambda: B2(*load_credentials()))
        else:
            runtime_preflight()
            client = B2(*load_credentials())
            install(client, args.apply)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        sys.exit(1)
