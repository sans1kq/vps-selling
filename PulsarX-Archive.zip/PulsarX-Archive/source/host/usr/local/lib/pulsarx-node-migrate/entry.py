#!/usr/bin/env python3
"""PulsarX node migration entry point; no credentials are passed through Windows."""
import argparse
from datetime import datetime,timezone,timedelta
import fcntl
import json
import os
from pathlib import Path
import pwd
import sys
import time
import uuid
from common import *


def bootstrap_control():
    check_host('control');private_dir(STATE)
    journal=STATE/'control.json';s=read_json(journal)
    if s and s.get('release')!=RELEASE:raise Failure('Another migration release is installed')
    if s and s.get('phase')=='finished':raise Failure('Migration already finished; use --status')
    if not s:
        s={'release':RELEASE,'nonce':uuid.uuid4().hex,'phase':'bootstrap','nodes':{}};write_json(journal,s)
    key=STATE/'id_ed25519'
    if not key.exists():run(['ssh-keygen','-q','-t','ed25519','-N','','-C',AUTH_TAG+s['nonce'],'-f',str(key)],'Create temporary constrained transport key')
    public=parse_pubkey(regular(str(key)+'.pub').decode())
    info={'release':RELEASE,'nonce':s['nonce'],'public_key':public,'control':PLAN['hosts']['control']}
    user=pwd.getpwnam('debian');path=Path(user.pw_dir)/'pulsarx-node-bootstrap.json'
    atomic(path,json.dumps(info),uid=user.pw_uid,gid=user.pw_gid)
    print('BOOTSTRAP: '+str(path),flush=True)


def bootstrap_node(role,path):
    check_host(role);private_dir(STATE)
    v=json.loads(regular(path).decode())
    if v.get('release')!=RELEASE or v.get('control')!=PLAN['hosts']['control'] or not re.fullmatch(r'[0-9a-f]{32}',v.get('nonce','')):
        raise Failure('Bootstrap identity rejected')
    key=parse_pubkey(v['public_key']);s=read_json(STATE/'node.json')
    if s and (s.get('nonce')!=v['nonce'] or s.get('role')!=role):raise Failure('Different node migration is already enrolled')
    if not s:s={'release':RELEASE,'nonce':v['nonce'],'role':role}
    login='debian' if role=='old' else 'root';user=pwd.getpwnam(login)
    d=Path(user.pw_dir)/'.ssh'
    if d.is_symlink():raise Failure('SSH directory symlink rejected')
    d.mkdir(exist_ok=True,mode=0o700)
    if d.stat().st_uid not in (0,user.pw_uid) or d.stat().st_mode&0o022:raise Failure('Unsafe SSH directory')
    os.chown(d,user.pw_uid,user.pw_gid);d.chmod(0o700)
    auth=d/'authorized_keys'
    before=regular(auth).decode() if auth.exists() else ''
    if role=='old':
        run(['runuser','-u','debian','--','/usr/bin/sudo','-n','/usr/bin/true'],'Existing passwordless sudo prerequisite')
    expiry=(datetime.now(timezone.utc)+timedelta(days=7)).strftime('%Y%m%d%H%M%SZ')
    command=('/usr/bin/sudo -n ' if role=='old' else '')+'/usr/bin/python3 /usr/local/lib/pulsarx-node-migrate/entry.py --rpc'
    tag=AUTH_TAG+s['nonce']
    line='from="192.0.2.11",restrict,expiry-time="'+expiry+'",command="'+command+'" '+key+' '+tag
    lines=[x for x in before.splitlines() if tag not in x]
    atomic(auth,'\n'.join([*lines,line])+'\n',uid=user.pw_uid,gid=user.pw_gid)
    s['auth_user']=login;s['auth_key']=key;write_json(STATE/'node.json',s)
    ssh_pub=parse_pubkey(regular('/etc/ssh/ssh_host_ed25519_key.pub').decode())
    receipt={'release':RELEASE,'nonce':s['nonce'],'role':role,'host':PLAN['hosts'][role],'ssh_host_key':ssh_pub}
    out=Path(user.pw_dir)/('pulsarx-node-'+role+'.json')
    atomic(out,json.dumps(receipt),uid=user.pw_uid,gid=user.pw_gid)
    print('ENROLLED: '+role+'; source-restricted forced command; existing SSH access retained.',flush=True)
    print('RECEIPT: '+str(out),flush=True)


def enroll(path):
    from control import state,save,rpc
    s=state();v=json.loads(regular(path).decode());role=v.get('role')
    if role not in ('old','new') or v.get('release')!=RELEASE or v.get('nonce')!=s['nonce'] or v.get('host')!=PLAN['hosts'][role]:
        raise Failure('Enrollment receipt mismatch')
    key=parse_pubkey(v['ssh_host_key']);s.setdefault('nodes',{})[role]={'host_key':key};save(s)
    lines=[PLAN['hosts'][r]+' '+node['host_key'] for r,node in sorted(s['nodes'].items())]
    atomic(STATE/'known_hosts','\n'.join(lines)+'\n')
    data=rpc(s,role,'inspect')
    if data.get('build')!=BUILD:raise Failure('Node code was not updated; rerun the normal Migrate stage with the new installer')
    print('PINNED: '+role+' SSH host key, Incus TLS fingerprint and '+BUILD+' verified.',flush=True)


def constrained_rpc():
    import nodes
    private_dir(STATE)
    with open(STATE/'rpc.lock','a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise Failure('Another node migration operation is running') from None
        raw=sys.stdin.buffer.read(4*1024**2+1)
        if len(raw)>4*1024**2:raise Failure('RPC request limit')
        v=json.loads(raw)
        result=nodes.rpc(v)
        print(json.dumps({'ok':True,'result':result}),flush=True)


def start(follow=False):
    from control import state,preflight
    s=state()
    if s.get('phase') in ('finished','awaiting_dns'):
        print(s.get('message','Migration reached its final checkpoint.'),flush=True);return
    running=prop('pulsarx-node-migration.service','ActiveState') in ('active','activating')
    token=s.get('launch_token')
    if not running:
        if not s.get('app_paused') and not s.get('target_may_write'):preflight(s)
        token=uuid.uuid4().hex;s['launch_token']=token;write_json(STATE/'control.json',s)
        run(['systemd-run','--unit=pulsarx-node-migration','--collect','--no-block','--property=Type=exec',
            '--property=RuntimeMaxSec=4h','--property=Nice=5',
            '/usr/bin/python3',str(LIB/'entry.py'),'--worker'],'Start independent migration worker')
    print('WORKER: running independently of this SSH session. Reconnect with --status if needed.',flush=True)
    if follow:
        previous=None;startup_deadline=time.monotonic()+20
        while True:
            current=read_json(STATE/'control.json')
            if token and current.get('worker_seen_token')!=token and time.monotonic()<startup_deadline:
                time.sleep(0.25);continue
            view=tuple(current.get(k) for k in ('phase','message','updated_at'))
            if view!=previous:
                print('PHASE: '+str(current.get('phase'))+' | '+str(current.get('message','')),flush=True);previous=view
            current_state=prop('pulsarx-node-migration.service','ActiveState')
            if current_state not in ('active','activating'):
                if current.get('phase') not in ('awaiting_dns','finished'):
                    reason=current.get('message') if current.get('worker_seen_token')==token else 'Worker did not enter its saved checkpoint'
                    raise Failure('Worker stopped: '+str(reason)+'. Run --status; do not manually start the old VPS.')
                break
            time.sleep(3)


def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--bootstrap-control',action='store_true');g.add_argument('--bootstrap-node',choices=['old','new'])
    g.add_argument('--enroll',type=Path);g.add_argument('--rpc',action='store_true');g.add_argument('--start',action='store_true')
    g.add_argument('--continue',dest='resume',action='store_true');g.add_argument('--worker',action='store_true')
    g.add_argument('--status',action='store_true');g.add_argument('--finish',action='store_true');g.add_argument('--relay',action='store_true')
    g.add_argument('--management-filter',action='store_true')
    p.add_argument('--bootstrap-file',type=Path);p.add_argument('--follow',action='store_true')
    a=p.parse_args()
    if os.geteuid()!=0:raise Failure('Run with sudo/root')
    if a.rpc:
        try:constrained_rpc()
        except Exception as e:
            reason=str(e) if isinstance(e,Failure) else type(e).__name__
            print(json.dumps({'ok':False,'error':reason}),flush=True)
        return
    print('RELEASE: '+BUILD,flush=True)
    if a.bootstrap_control:bootstrap_control();return
    if a.bootstrap_node:
        if not a.bootstrap_file:raise Failure('Bootstrap file required')
        bootstrap_node(a.bootstrap_node,a.bootstrap_file);return
    if a.enroll:enroll(a.enroll);return
    if a.management_filter:
        import nodes
        from firewall import apply_management
        if nodes.state()['role']!='new':raise Failure('Management filter is destination-only')
        apply_management();return
    if a.relay:
        import nodes
        s=nodes.state()
        if s['role']!='old':raise Failure('Relay is source-only')
        nodes.relay(s,True);return
    import control
    if a.status:control.status();return
    if a.finish:control.finish();return
    if a.start or a.resume:start(a.follow);return
    if a.worker:
        private_dir(STATE)
        with open(STATE/'worker.lock','a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise Failure('Migration worker already holds the lock') from None
            s=control.state();s['worker_seen_token']=s.get('launch_token');s['worker_started_at']=int(time.time())
            s['resuming_from']=s.get('phase');s.pop('error',None)
            control.save(s,'checking','Rechecking the saved checkpoint before resuming.')
            control.worker()


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:raise SystemExit('SSH monitor interrupted; independent worker continues. Run --status.')
    except Failure as e:raise SystemExit('STOPPED: '+str(e))
    except Exception as e:raise SystemExit('STOPPED: '+type(e).__name__+'; values hidden; inspect saved status.')
